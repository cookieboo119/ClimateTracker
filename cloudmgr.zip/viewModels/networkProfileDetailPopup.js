/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * backup module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton','ojs/ojlabelvalue', 'ojs/ojformlayout','ojs/ojbootstrap', 'ojs/ojlabelvalue',  'ojs/ojlabel'], function (oj, ko, actionsHelper, popupHelper, constants) {
    /**
     * The view model for the main content view template
     */
    function networkProfileDetailViewModel()
    {
        var self = this;
        console.log('Network Profile Detail View Model');
        self.networkProfileDetailPopupTitle = ko.observable('');
        self.networkProfileDescription = ko.observable('Loading...');
        self.useRegionalSubnets = ko.observable('');
        self.isRegionSingleAD = ko.observable('');
        self.EbsCompartment = ko.observable('Loading...');
        self.NetworkCompartment = ko.observable('Loading...');
        self.region = ko.observable('Loading...');
        self.vcn = ko.observable('Loading...');
        self.subnetType = ko.observable('Loading...');
        self.ad = ko.observable('Loading...');
        self.dbTierSubnetType = ko.observable('Loading...');
        self.dbTierSubnetName = ko.observable('Loading...');
        self.appTierSubnetType = ko.observable('Loading...');
        self.appTierSubnetName = ko.observable('Loading...');
        self.lbaasSubnetName = ko.observable('Loading...');
        self.lbaasHASubnetName = ko.observable('Loading...');
        self.lbaasSubnetType = ko.observable('Loading...');
        self.displayLoadBalancerHASubnetPopupRegion = ko.observable('');
        self.appTierSubnetType_External = ko.observable('Loading...');
        self.appTierSubnetName_External = ko.observable('Loading...');
        self.lbaasSubnetName_External = ko.observable('Loading...');
        self.lbaasHASubnetName_External = ko.observable('Loading...');
        self.lbaasSubnetType_External = ko.observable('Loading...');
        self.displayLoadBalancerHASubnetPopupRegion_External = ko.observable('');
        self.displayExternalZoneRegion = ko.observable(true);
         

        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));

        self.popupCloseHandler = function (event, ui)
        {
            var popup = document.getElementById("networkProfileDetailPopup");
            popup.close();
        };

        self.popupOpen = function (networkProfileName, event)
        {
            var popup = document.getElementById("networkProfileDetailPopup");
            popup.open(event.target);
            self.networkProfileDetailPopupTitle(networkProfileName + ' details');
            if (self.EbsCompartment() !== 'Loading...')
            {
                self.clearData(event);
            }
            self.loadData(networkProfileName, event, self.handleLoadbalancerHASubnetPopupRegion);
        };

        self.clearData = function (event)
        {
            self.EbsCompartment('Loading...');
            self.NetworkCompartment('Loading...');
            self.region('Loading...');
            self.vcn('Loading...');
            self.subnetType('Loading...');
            self.ad('Loading...');
            self.dbTierSubnetType('Loading...');
            self.dbTierSubnetName('Loading...');
            self.appTierSubnetType('Loading...');
            self.appTierSubnetName('Loading...');
            self.lbaasSubnetName('Loading...');
            self.lbaasHASubnetName('Loading...');
            self.appTierSubnetType_External('Loading...');
            self.appTierSubnetName_External('Loading...');
            self.lbaasSubnetName_External('Loading...');
            self.lbaasHASubnetName_External('Loading...');
            self.networkProfileDescription('Loading...');
        };

        self.handleLoadbalancerHASubnetPopupRegion = function () {
            console.log("regional=" + self.useRegionalSubnets());
            console.log("singleAd=" + self.isRegionSingleAD());
            console.log("type=" + self.lbaasSubnetType());


            if (self.useRegionalSubnets() ||
                    self.isRegionSingleAD() ||
                    self.lbaasSubnetType() === 'Private') {
                self.displayLoadBalancerHASubnetPopupRegion(false);
            } else
                self.displayLoadBalancerHASubnetPopupRegion(true);


            if (self.useRegionalSubnets() ||
                    self.isRegionSingleAD() ||
                    self.lbaasSubnetType_External() === 'Private') {
                self.displayLoadBalancerHASubnetPopupRegion_External(false);
            } else
                self.displayLoadBalancerHASubnetPopupRegion_External(true);

            console.log('self.displayLoadBalancerHASubnetPopupRegion : ' + self.displayLoadBalancerHASubnetPopupRegion());
        };

        self.loadData = function (networkProfileName, event, callback)
        {
            actionsHelper.getNetworkProfileDetails(networkProfileName, function (error, details)
            {
                var ebsCompartmentName = details.ebsCompartment;
                var networkCompartmentName = details.networkCompartment;
                var region = details.region;
                var vcn = details.vcn;
                var description = details.description;
                var useRegionalSubnets = details.useRegionalSubnets;
                var isRegionSingleAD = details.isRegionSingleAD;
                var availabilityDomain = details.availabilityDomain;
                var useRegional = details.useRegionalSubnets;
                var subnetType = '';
                if (typeof (useRegional) !== 'undefined' && useRegional !== null)
                {
                    if (useRegional)
                    {
                        subnetType = constants.subnetType.Regional;
                    } else
                    {
                        subnetType = constants.subnetType.AvailabilityDomainSpecific;
                    }
                }

                var dbTierSubnetType = (details.dbTier.isPrivate === true) ? "Private" : "Public";
                var dbTierSubnetName = details.dbTier.subnetName;
                var internalAppTierNode = details.appTier.internal[0];
                var appTierSubnetType = (internalAppTierNode.isPrivate === true) ? "Private" : "Public";
                var appTierSubnetName = internalAppTierNode.subnetName;
                var internalLBaaSNode = details.lbaas.internal;
                var lbaasSubnetType = (internalLBaaSNode.isPrivate === true) ? "Private" : "Public";
                var lbaasSubnetName = internalLBaaSNode.subnetName;
                var lbaasHASubnetName = internalLBaaSNode.haSubnetName;



                var appTierSubnetType_External = '';
                var appTierSubnetName_External = '';
                var lbaasSubnetType_External = '';
                var lbaasSubnetName_External = '';
                var lbaasHASubnetName_External = '';

                if (typeof (details.appTier.external) !== 'undefined' && typeof (details.appTier.external[0] !== 'undefined') && typeof (details.lbaas.external) !== 'undefined' )
                {

                    var externalAppTierNode = details.appTier.external[0];
                    appTierSubnetType_External = (externalAppTierNode.isPrivate === true) ? "Private" : "Public";
                    appTierSubnetName_External = externalAppTierNode.subnetName;
                    var externalLBaaSNode = details.lbaas.external;
                    lbaasSubnetType_External = (externalLBaaSNode.isPrivate === true) ? "Private" : "Public";
                    lbaasSubnetName_External = externalLBaaSNode.subnetName;
                    lbaasHASubnetName_External = externalLBaaSNode.haSubnetName;
                    self.displayExternalZoneRegion(true);
                }
                else
                {
                    self.displayExternalZoneRegion(false);
                }

                self.EbsCompartment(ebsCompartmentName);
                self.networkProfileDescription(description);
                self.useRegionalSubnets(useRegionalSubnets);
                self.isRegionSingleAD(isRegionSingleAD);
                self.NetworkCompartment(networkCompartmentName);
                self.region(region);
                self.ad(availabilityDomain);
                self.vcn(vcn);
                self.subnetType(subnetType);
                self.dbTierSubnetType(dbTierSubnetType);
                self.dbTierSubnetName(dbTierSubnetName);
                self.appTierSubnetType(appTierSubnetType);
                self.appTierSubnetName(appTierSubnetName);
                self.lbaasSubnetType(lbaasSubnetType);
                self.lbaasHASubnetName(lbaasHASubnetName);
                self.lbaasSubnetName(lbaasSubnetName);
                self.appTierSubnetType_External(appTierSubnetType_External);
                self.appTierSubnetName_External(appTierSubnetName_External);
                self.lbaasSubnetType_External(lbaasSubnetType_External);
                self.lbaasHASubnetName_External(lbaasHASubnetName_External);
                self.lbaasSubnetName_External(lbaasSubnetName_External);
                callback();
            });
            
        };


    }

    return networkProfileDetailViewModel;
});
