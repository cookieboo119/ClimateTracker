define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper',
    'ebs/navigation/pageNavigationHelper', 'ebs/utils/dateTimeHelper', 'ebs/utils/networkProfileHelper',
    'ojs/ojarraydataprovider', 'ebs/utils/helpMenu', 'ojs/ojvalidator-regexp', 'ebs/utils/versionUtils',
    'ebs/utils/createCloneTrainUtils', 'ebs/utils/lovUtils', 'ojs/ojasyncvalidator-numberrange', 'jquery', 'ojs/ojmenu', 'ojs/ojpopup',
    'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojselectcombobox', 'ojs/ojinputtext', 'ojs/ojknockout-validation',
    'ojs/ojradioset', 'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojmodule', 'ojs/ojbutton', 'ojs/ojinputnumber',
    'ojs/ojcheckboxset', 'ojs/ojmessages', 'ojs/ojtable', 'ojs/ojvalidationgroup'],
        function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper, dateTimeHelper,
                networkProfileHelper, ArrayDataProvider, helpMenu, RegExpValidator, versionUtils, createCloneUtils, lovUtils)
        {

            function BaseStandByTrainViewModel(trainContext)
            {
                console.log('Train Context --' + trainContext);
                var self = this;
                var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
                var envName = rootViewModel.standByEnvironmentName();
                rootViewModel.showNavTab(false);

                self.sourceEnvDetails = '';

                /* Train related variables */
                self.disableNextBtn = ko.observable(false);
                self.disablePrevBtn = ko.observable(false);
                self.selected = ko.observable(constants.navModules.volumeCloneModule);
                self.currentStep = ko.observable(constants.navModules.volumeCloneModule);
                self.currentModule = ko.observable(self.currentStep());
                self.disableSubmitBtn = ko.observable(false);
                self.isDB19Cminimum = ko.observable(false);
                self.stepArray = ko.observableArray([
                    {label: oj.Translations.getTranslatedString('pageHeader.cloneEnvPageHeader'), id: constants.navModules.volumeCloneModule, rank: 0, disabled: false},
                    {label: oj.Translations.getTranslatedString('pageHeader.dbTier'), id: constants.navModules.dbTierDetailsModule, rank: 1, disabled: false},
                    {label: oj.Translations.getTranslatedString('pageHeader.topology'), id: constants.navModules.topologyDetailsModule, rank: 2, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.postProvisioningOptions'), id: constants.navModules.postProvisioningStepsModule, rank: 3, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.uploadKeys'), id: constants.navModules.uploadKeysModule, rank: 4, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.review'), id: constants.navModules.reviewModule, rank: 5, disabled: true}
                ]);
                self.nameToRankMap = new Map();
                for (var i = 0; i < self.stepArray().length; i++)
                {
                    self.nameToRankMap.set(self.stepArray()[i].id, self.stepArray()[i].rank);
                }

                /* First step in the train */
                self.envNameInputValue = ko.observable('');
                self.appsPassword = ko.observable('');
                self.weblogicPassword = ko.observable('');
                self.networkName = ko.observable('loading...');
                self.compartment = ko.observable('loading...');

                /* Database Section */
                self.showComputeRadioSelection = ko.observable('inline');
                self.useInternalValueForValidation = false;
                self.showPDBPromptForCompute = ko.observable('No');
                self.dbSIDInputValue = ko.observable();
                self.computePDBName = ko.observable('');
                self.dbCompShapeChoiceOptionsList = ko.observableArray();
                self.dbCompShapeChoiceOptionsDataProvider = new ArrayDataProvider(self.dbCompShapeChoiceOptionsList, {idAttribute: 'value'});
                self.dbCompSelectedShapeValue = ko.observable('');
                self.renderTDECheckBox = ko.observable('true');
                self.TDECheckBoxOptionValue = ko.observableArray(['Y']);
                self.renderBackupAdminPwdFields = ko.observable('true');
                self.backupAdminPwd = ko.observable('');
                self.backupReEnterAdminPwd = ko.observable('');
                var DBPasswdCharactervalidator = function ()
                {};
                oj.Object.createSubclass(DBPasswdCharactervalidator, oj.Validator, "DBPasswdCharactervalidator");
                self.dbPasswdCharactervalidator = [new DBPasswdCharactervalidator()];
                var BackupPasswordValidator = function ()
                {};
                oj.Object.createSubclass(BackupPasswordValidator, oj.Validator, "BackupPasswordValidator");
                self.backupPasswordValidator = [new BackupPasswordValidator()];
                self.faultDomainSelectionCompute = ko.observable('Auto');
                self.faultDomainChoiceList = ko.observableArray();
                self.advancedOptionsDisplayed_compute = ko.observable(false);
                self.minimumStorageRequiredForCloningStandbyDB = ko.observable(250);
                self.totalStorageForDBTier = ko.observable(250);
                self.standbyDatabaseAdminPwd = ko.observable();
                self.standbyDatabaseWalletPwd = ko.observable();
                self.activeDatabaseWalletPwd = ko.observable();
                self.activeDatabaseAdminPwd = ko.observable();
                self.dbTypeUsed = ko.observable('Compute');
                // This is required in SSH keys step to identify single or multi vm
                self.deploymentType = ko.observable('');

                /* Topology Section */
                self.isExternalZoneAllowed = ko.observable(true);
                self.faultDomainChoiceList = ko.observableArray();
                self.storagePerAppNode = ko.observable("150 GB");
                self.appShapeChoiceOptionsList = ko.observableArray();
                self.lbShapes = ko.observableArray([{'label': '', 'value': ''}]);
                self.lbaasOptionValue = ko.observable('DEPLOY_NEW');
                self.loadBalancerOptionEnabled = ko.observable(true);
                self.appTierShapeOfStandbyNode = ko.observable('');

                self.pageLevelMessages = ko.observableArray([]);
                

                //logical host/domain feature
                self.dbLogicalDomainCustomMsg = ko.observableArray([]);
                var bypassHostnameValidation = rootViewModel.properties.has("hostname_validation_enabled") ?
                        (rootViewModel.properties.get("hostname_validation_enabled") === false) : false;
                self.dbLogicalHostNamePrefixValue = ko.observable('');
                self.dbLogicalDomainName = ko.observable('');
                var DBLogicalHostDomainOverallLengthValidator = function()
                {};
                 oj.Object.createSubclass(DBLogicalHostDomainOverallLengthValidator, oj.Validator, "DBLogicalHostDomainOverallLengthValidator");
                DBLogicalHostDomainOverallLengthValidator.prototype.validate = function (value)
                {
                   if (!value || value === '')
                        return true;
                    
                   if(value.indexOf(" ") >= 0)
                   {
                       var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameContainsWhiteSpaceMsg');
                       throw new Error(dbLogicalDomainCustomMsg);
                   }
                   
                   //not start or end with dot (.)
                   if(value.indexOf(".") === 0 || value.indexOf(".") === (value.length - 1))
                   {
                       var logicalDomainCustomMsg =  oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                       throw new Error(logicalDomainCustomMsg);
                   }
                   
                   //max domain value length is 128
                    if(value.length > 128)
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameLengthValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }

                    //last character of domain value cannot be number               
                    if(!isNaN(value.charAt(value.length -1)))
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameLastCharacterValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }
                   
                   var segments = value.split(".");
                   for(var i=0; i<segments.length ; i++)
                   {
                       var segment = segments[i];
                       if(segment)
                       {
                           if(segment.length > 63)
                           {
                              var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentExceedsMaxLengthMsg');
                              throw new Error(dbLogicalDomainCustomMsg);
                           }
                           if((segment.indexOf("-") === 0) || 
                              (segment.indexOf("-") === (segment.length -1)))
                            {
                              var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentNotStartEndWithHyphenMsg');
                              throw new Error(dbLogicalDomainCustomMsg);
                            }
                            //check for special charactors
                            var pattern = new RegExp('^(?:([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[A-Za-z0-9]))$');
                            if(!pattern.test(segment))
                            {
                                var logicalDomainCustomMsg =  oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                                throw new Error(logicalDomainCustomMsg);
                            }
                       }
                   }
                   
                   var totalLength = value.length;
                   if(self.dbLogicalHostNamePrefixValue())
                       totalLength += self.dbLogicalHostNamePrefixValue().length;
                   if(totalLength > 255)
                   {
                       var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameExceedsMaxLengthMsg');
                       throw new Error(dbLogicalDomainCustomMsg);
                   }
                   
                   return true;
                };
                
                var DBLogicalHostDuplicateValidator = function ()
                {};
                oj.Object.createSubclass(DBLogicalHostDuplicateValidator, oj.Validator, "DBLogicalHostDuplicateValidator");
                DBLogicalHostDuplicateValidator.prototype.validate = function (value)
                {
                    //compare against DB tier logical host prefix
                    if (!value || value === '')
                        return true;

                    var dbType = self.dbTypeUsed();
                    var topologyDetailsViewModel = ko.dataFor(document.getElementById('zonesListView'));
                    if (topologyDetailsViewModel)
                    {
                        var appsLHNArray = topologyDetailsViewModel.getAllAppsLogicalHostname();
                        if (appsLHNArray && appsLHNArray.length > 0)
                        {
                            if (dbType === 'Compute')
                            {
                                if (self.isDuplicateLogicalHostNameValue(appsLHNArray, value))
                                    throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'));
                            } 
                        }
                    }

                    return true;
                };

                self.isDuplicateLogicalHostNameValue = function (appsLHNArray, dbLHN, dbLHN1)
                {
                    var isDuplicate = false;
                    for (var i = 0; i < appsLHNArray.length; i++)
                    {
                        var appNodeCount = appsLHNArray[i].length;
                        outterloop:
                                for (var j = 0; j < appNodeCount; j++)
                        {
                            var appNodeLogicalHost = appsLHNArray[i][j];
                            if ((dbLHN.toLowerCase() === appNodeLogicalHost.toLowerCase()) || 
                                (dbLHN1 && dbLHN1.toLowerCase() === appNodeLogicalHost.toLowerCase()))
                            {
                                isDuplicate = true;
                                break outterloop;
                            }
                        }


                    }
                    return isDuplicate;
                };

                self.dbLogicalHostNamePrefixValidator = [
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^(?:([a-zA-Z]|[a-zA-Z][a-zA-Z0-9]{0,26}[A-Za-z0-9]))$',
                                hint: oj.Translations.getTranslatedString('validationMsgs.logicalHostPrefixValidationMsg'),
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.logicalHostPrefixValidationMsg')
                            })),
                    new DBLogicalHostDuplicateValidator()
                ];


                self.dbLogicalHostNameValidator = [
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^(?:([a-zA-Z]|[a-zA-Z][a-zA-Z0-9]{0,28}[A-Za-z0-9]))$',
                                hint: oj.Translations.getTranslatedString('validationMsgs.logicalHostNameValidationMsg'),
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.logicalHostNameValidationMsg')
                            })),
                    new DBLogicalHostDuplicateValidator()
                ];

                self.dbLogicalDomainNameValidator = [
                     (bypassHostnameValidation ? '' : new DBLogicalHostDomainOverallLengthValidator())                                 
                ];



                /* Review Page */
                self.selectedEbsVerValue = ko.observable();
                self.selectedDBReleaseValue = ko.observable();
                self.selectedNetworkProfileName = ko.observable();
                self.enableTDEFlagForComputeInReviewScreen = ko.observable(true);
                self.dataBaseNameInputValue = ko.observable();
                self.dbSIDInputValue.subscribe((dbSidInputValueChange) => {
                    console.log('Observable Subscription event for db Sid Value change : ' + dbSidInputValueChange);
                    self.dataBaseNameInputValue(dbSidInputValueChange);
                });

                var ComputePDBNameValidator = function ()
                {};
                oj.Object.createSubclass(ComputePDBNameValidator, oj.Validator, "ComputePDBNameValidator");
                self.computePdbNameValidator = [new ComputePDBNameValidator()];

                DBPasswdCharactervalidator.prototype.validate = function (value)
                {
                    return createCloneUtils.validateDBPasswordCharacter(self, value);
                };

                ComputePDBNameValidator.prototype.validate = function (value)
                {
                    return createCloneUtils.validateComputePDBName(value);
                };

                BackupPasswordValidator.prototype.validate = function (value)
                {
                    return createCloneUtils.validateBackupPassword(self, value);
                };


                self.modulePath = ko.pureComputed(function ()
                {
                    console.log('Getting Module Path..');
                    createCloneUtils.disableTrainSteps(self.currentModule(), self.stepArray());
                    // Adding context as 'promoteStandBy' instead of self.currentModule() as each steps of train pointing to same help doc
                    helpMenu.addElementAndRemoveDuplicate('promoteStandby');
                    return (constants.navModules.createEnvironmentModule + '/' + self.currentModule());
                });

                self.handleBackLinkBaseFunction = function (event, ui, trainElementIdentifier)
                {
                    var context = ko.contextFor(document.getElementById(trainElementIdentifier));
                    var prevModule = constants.navModules.envListModule;
                    pageNavigationHelper.navigateToPage(context, prevModule, prevModule, true);
                };

                self.optionChangeHandler = function (event, ui)
                {
                    var toStep = event.detail.toStep;
                    var fromStep = event.detail.fromStep;
                    var newOption = toStep.id;
                    var newOptionRank = toStep.rank;
                    var previousOption = event.detail.fromStep.id;
                    var previousOptionRank = fromStep.rank;
                    if (newOptionRank > previousOptionRank)
                    {
                        self.validateAndGotoNextStep(previousOption, newOption, event);
                    } else
                    {
                        self.selected(newOption);
                        self.currentStep(newOption);
                        self.currentModule(self.currentStep());
                    }
                };

                self.postOptionChangeHandler = function (event, ui)
                {

                };

                self.prevStep = function ()
                {
                    var prev = $('#train').ojTrain('previousSelectableStep');
                    if (prev !== null)
                    {
                        self.selected(prev);
                        self.currentStep(prev);
                        console.log('current step in the train (prev clicked)' + self.selected());
                        createCloneUtils.disableTrainSteps(self.selected(), self.stepArray());
                        if (prev === constants.navModules.volumeCloneModule)
                        {
                            self.disableNextBtn(false);
                        }
                        self.currentModule(self.currentStep());
                    }
                };

                self.nextStep = function ()
                {
                    var next = $('#train').ojTrain('nextSelectableStep');
                    self.selected(next);
                };

                self.addPageLevelMessage = function (pageName, messageSeverity, messageSummary, messageDetail, clearAllPrevMessages)
                {
                    var newPageMessageObject = new Object();
                    newPageMessageObject.severity = messageSeverity;
                    newPageMessageObject.summary = messageSummary;
                    newPageMessageObject.detail = messageDetail;
                    if (typeof (clearAllPrevMessages) !== 'undefined' && clearAllPrevMessages) {
                        var tempArray = new Array();
                        tempArray.push(newPageMessageObject);
                        self.pageLevelMessages(tempArray);
                    } else {
                        var tempArray = self.pageLevelMessages();
                        tempArray.push(newPageMessageObject);
                        self.pageLevelMessages(tempArray);
                    }

                };
                self.clearPageLevelMessagesOnNavigation = function ()
                {
                    self.pageLevelMessages([]);
                };


                self.validateAndGotoNextStep = function (previousStep, nextStep, trainSelectionEvent)
                {
                    var invalid = false;
                    if (nextStep !== null)
                    {
                        createCloneUtils.disableTrainSteps(self.selected(), self.stepArray());
                        if (previousStep === constants.navModules.volumeCloneModule) {
                            var viewModelOfFirstStepInTrain = ko.dataFor(document.getElementById('volumeClonePage'));
                            invalid = viewModelOfFirstStepInTrain.validateEntries();
                            if (!invalid) {
                                self.stepArray()[2].disabled = false;
                                self.stepArray()[3].disabled = false;
                                self.stepArray()[4].disabled = false;
                                self.stepArray()[5].disabled = false;
                            }
                        } else if (previousStep === constants.navModules.dbTierDetailsModule) {
                            var viewModelOfDbTierPG = ko.dataFor(document.getElementById('DBTier1'));
                            invalid = viewModelOfDbTierPG.validateEntries();
                        }

                        if (previousStep === constants.navModules.topologyDetailsModule && !this.topologyPageValid())
                        {
                            console.log('Errors found ..');
                            invalid = true;
                        }

                        if (previousStep === constants.navModules.postProvisioningStepsModule)
                        {
                            var execPlanCustomizationViewModel = ko.dataFor(document.getElementById('customTasksListingTab'));
                            if (typeof (execPlanCustomizationViewModel) !== 'undefined') {
                                var isExecPlanPageValid = execPlanCustomizationViewModel.isFormValid();
                                if (!isExecPlanPageValid)
                                {
                                    console.log('Errors found ..');
                                    invalid = true;
                                }
                            }
                        }

                        if (previousStep === constants.navModules.uploadKeysModule) {
                            var uploadKeysViewModel = ko.dataFor(document.getElementById('uploadKeysPGForm'));
                            if (typeof (uploadKeysViewModel) !== 'undefined') {
                                var isUploadKeysPageValid = uploadKeysViewModel.isFormValid();
                                if (!isUploadKeysPageValid) {
                                    console.log('Errors found in upload keys module.');
                                    invalid = true;
                                }
                            }
                        }


                        if (invalid)
                        {
                            if (!$.isEmptyObject(trainSelectionEvent))
                            {
                                trainSelectionEvent.preventDefault();
                            }
                            self.stayInSameStep(previousStep);
                        } else
                        {
                            console.log('current step in the train (next clicked) ' + self.selected());
                            self.performServerSideValidations(previousStep, nextStep, trainSelectionEvent);
                        }
                    }
                };

                self.topologyPageValid = function ()
                {
                    var zonesListViewElement = document.getElementById('zonesListView');
                    var viewModuleOfTopologyPG = ko.dataFor(zonesListViewElement);
                    return viewModuleOfTopologyPG.isTopologyValid();
                };

                self.performServerSideValidations = function (prevStep, nextStep, trainSelectionEvent)
                {
                    var proceed = false;
                    if (prevStep === constants.navModules.uploadKeysModule)
                    {
                        self.disableNextBtn(true);
                        createCloneUtils.performSSHKeysPGServerValidation(self, prevStep, nextStep, trainSelectionEvent);
                    } else
                    {
                        proceed = true;
                    }
                    if (proceed)
                    {
                        self.proceeedToNextStep(prevStep, nextStep, trainSelectionEvent);
                    }

                };


                self.stayInSameStep = function (prevStep)
                {
                    self.selected(prevStep);
                    self.currentStep(prevStep);
                    self.currentModule(self.currentStep());
                };

                self.proceeedToNextStep = function (prevStep, nextStep, trainSelectionEvent)
                {
                    var prevStepRank = self.nameToRankMap.get(prevStep);
                    var nextStepRank = self.nameToRankMap.get(nextStep);

                    if (nextStepRank - prevStepRank > 1)
                    {
                        // We are not allowed to skip steps at this moment. so go to next step.
                        var prevStepIdx = self.findIndexOfATrainStep(prevStep);
                        if (prevStepIdx !== -1)
                        {
                            if (!$.isEmptyObject(trainSelectionEvent))
                            {
                                trainSelectionEvent.preventDefault();
                            }
                            var newIdxToMove = prevStepIdx + 1;
                            nextStep = self.stepArray()[newIdxToMove].id;
                        }

                    }

                    self.selected(nextStep);
                    self.currentStep(nextStep);
                    self.currentModule(self.currentStep());
                };


                self.findIndexOfATrainStep = function (stepName)
                {
                    for (var i = 0; i < self.stepArray().length; i++)
                    {
                        var currentStepName = self.stepArray()[i].id;
                        if (currentStepName === stepName)
                        {
                            return i;
                        }
                    }
                    return -1;
                };


                actionsHelper.getEnvDetails(envName, function (error, envDetail) {
                    if (error === '') {
                        self.sourceEnvDetails = envDetail;
                        var networkProfileName = envDetail.networkProfile;
                        self.networkName(envDetail.networkProfile);
                        self.selectedNetworkProfileName(envDetail.networkProfile);
                        self.selectedDBReleaseValue(envDetail.dbTier.version);
                        self.selectedEbsVerValue(envDetail.version);
                        var isDBMajorVersion19AndAbove = versionUtils.isDBMajorVersionGreaterThanOrEqualToNineteen(envDetail.dbTier.version);
                        if (isDBMajorVersion19AndAbove)
                        {
                            self.isDB19Cminimum(true);
                            self.showPDBPromptForCompute('Yes');
                            var pdbNameInDetails = envDetail.dbTier.pdbName;
                            if(pdbNameInDetails !== null && pdbNameInDetails !== ''){
                                self.computePDBName(pdbNameInDetails);
                            }

                        } else
                        {
                            self.isDB19Cminimum(false);
                            self.showPDBPromptForCompute('No');
                            self.computePDBName('');
                        }
                        actionsHelper.getNetworkProfileDetails(networkProfileName, function (error, details)
                        {
                            self.compartment(details.ebsCompartment);
                            var lbaasSection = details.lbaas;
                            if (lbaasSection === null || typeof (lbaasSection) === 'undefined' || lbaasSection === '')
                            {
                                console.log('Disabling LBAAS');
                                self.loadBalancerOptionEnabled(false);
                                self.lbaasOptionValue("USE_EXISTING");
                            }
                            var lbaasSubnetOCID = lbaasSection.internal.subnetOCID;
                            if (lbaasSubnetOCID === null || typeof (lbaasSubnetOCID) === 'undefined' || lbaasSubnetOCID === '')
                            {
                                console.log('Disabling LBAAS');
                                self.loadBalancerOptionEnabled(false);
                                self.lbaasOptionValue("USE_EXISTING");
                            } else
                            {
                                self.loadBalancerOptionEnabled(true);
                                console.log('Enabling LBAAS');
                                self.lbaasOptionValue("DEPLOY_NEW");
                            }

                            if (typeof (lbaasSection.external) !== 'undefined' && lbaasSection.external !== '' &&
                                    typeof (lbaasSection.external.subnetOCID) !== 'undefined' && lbaasSection.external.subnetOCID !== ''
                                    )
                            {
                                self.isExternalZoneAllowed(true);
                            } else {
                                self.isExternalZoneAllowed(false);
                            }

                            actionsHelper.getTagNamespaceInformation(networkProfileName, function (error, tagDetails) {
                                var viewModelOfTrainFirstStep = ko.dataFor(document.getElementById(constants.divTags.envClonePage));
                                if (viewModelOfTrainFirstStep)
                                    viewModelOfTrainFirstStep.tagNamespaceOptionsList.removeAll();
                                var tagDetailsLen = tagDetails.length;
                                if (null !== tagDetails && tagDetailsLen > 0) {
                                    var tagOptions = new Array();
                                    var optionData = new Object();
                                    optionData.label = 'None (add a free-form tag)';
                                    optionData.value = 'none';
                                    tagOptions.push(optionData);
                                    for (var i = 0; i < tagDetailsLen; i++) {
                                        var metaData = tagDetails[i];
                                        if (null !== metaData.label && metaData.label.length > 0) {
                                            var optionData = new Object();
                                            optionData.label = metaData.label;
                                            optionData.value = metaData.value;
                                            tagOptions.push(optionData);
                                        }
                                    }
                                    if (viewModelOfTrainFirstStep)
                                    {
                                        viewModelOfTrainFirstStep.tagNamespaceOptionsList(tagOptions);
                                        lovUtils.lovOptionsUpdated(viewModelOfTrainFirstStep.tagNamespaceOptionsList(), viewModelOfTrainFirstStep.selectedTagNamespace);
                                        viewModelOfTrainFirstStep.tagKeyList(tagDetails);
                                    }
                                }
                            });
                        });
                        actionsHelper.getFaultDomains(networkProfileName, function (error, faultDomains)
                        {
                            self.faultDomainChoiceList(faultDomains);
                        });
                        actionsHelper.getOCIShapes(function (error, envMetadata)
                        {
                            self.dbCompShapeChoiceOptionsList(envMetadata.computeds);
                            var dbShapeFromSource = envDetail.dbTier.shape;
                            self.dbCompSelectedShapeValue(dbShapeFromSource);
                            self.appShapeChoiceOptionsList(envMetadata.app);
                            try {
                                self.appTierShapeOfStandbyNode(envDetail.appTier.zones[0].nodes[0].shape);
                            } catch (e) {
                                console.log('Exception while setting the app shape of the 1st node :' + e);
                            }
                            self.lbShapes(envMetadata.lb);
                        });
                        if ("release-standby" === trainContext) {
                            self.dbSIDInputValue(envDetail.dbTier.databaseName);
                        }

                    }
                }, true);

                actionsHelper.getDefaultStorageForStandByAppNode(envName, function (error, storage) {
                    if (error === '') {
                        self.storagePerAppNode(storage.value);
                    }
                });

                self.cancelBaseFunction = function (trainElementIdentifier) {
                    var context = ko.contextFor(document.getElementById("cloneStandByEnvironmentTrainElement"));
                    pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                };

                self.closeConfirmDeletePopup = function (event, ui) {
                    var popup = document.querySelector(constants.divTags.releaseStandByEnvPopupTag);
                    popup.close();
                };


                self.startAnimationListener = function (event, ui)
                {
                    popupHelper.startAnimationListener(constants.divTags.releaseStandByEnvPopupTag, event, ui);
                };

                self.confirmationPopupCloseHandler = function (data, event) {
                    popupHelper.confmPopuCloseHandler(constants.divTags.releaseStandByEnvPopupTag, data, event);
                };

            }

            return BaseStandByTrainViewModel;
        });
