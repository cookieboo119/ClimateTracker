/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

package com.bloomberg.datalic.dlws;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import com.bloomberg.datalic.dlws.stubs.ProgramFlag;

public class PerSecurity {

    public static final int SUCCESS = 0;
    public static final int DATA_NOT_AVAILABLE = 100;
    public static final int REQUEST_ERROR = 200;
    // Set POLL_FREQUENCY to 30 seconds per best practices documented in
    // Data License User Guide
    public static final int POLL_FREQUENCY = 30000; // value is in msecs

    // Initialize static map of sampleName to the Java class that implements the
    // said sample
    private static final Map<String, Class<?>> sampleNamesMap = createSampleNamesMap();

    // Initialize static map of allowed program flags
    private static final Map<String, ProgramFlag> allowedProgramFlagsMap = createProgramFlagsMap();

    public static void main(String[] args) {
        // Setup command line options
        String allSamples = getSampleNames();
        Option sampleName = new Option("s", "sampleName", true,
                "Name of the sample code to run. Options are: " + allSamples);
        String allProgramFlags = getProgramFlags();
        Option programFlag = new Option("p", "programFlag", true,
                "The program flag to be used with the sample code. "
                        + "NOTE: This choice may have financial implications, "
                        + "please refer to the Data License User Guide for more details. "
                        + "Options are: " + allProgramFlags);
        Options options = new Options();
        options.addOption(sampleName);
        options.addOption(programFlag);

        CommandLineParser commandLineParser = new DefaultParser();
        HelpFormatter helpFormatter = new HelpFormatter();
        CommandLine commandLine = null;

        // Parse command line options
        try {
            commandLine = commandLineParser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            helpFormatter.printHelp("DLWSJavaSample", options);
            System.exit(1);
        }

        // Validate command line options
        // Check sample name
        String sampleNameStr = commandLine.getOptionValue("sampleName");
        if (sampleNameStr == null) {
            System.out.println("sampleName is a mandatory argument!");
            helpFormatter.printHelp("DLWSJavaSample", options);
            System.exit(1);
        }

        Class<?> sampleClass = getSampleClass(sampleNameStr);
        if (sampleClass == null) {
            System.out.println("sampleName " + sampleNameStr + " is invalid!");
            helpFormatter.printHelp("DLWSJavaSample", options);
            System.exit(1);
        }

        // Check program flag
        String programFlagStr = commandLine.getOptionValue("programFlag");
        if (programFlagStr == null) {
            System.out.println("programFlag is a mandatory argument!");
            helpFormatter.printHelp("DLWSJavaSample", options);
            System.exit(1);
        }

        ProgramFlag programFlagHeader = getProgramFlagHeader(programFlagStr);
        if (programFlagHeader == null) {
            System.out.println("programFlag is a mandatory argument!");
            helpFormatter.printHelp("DLWSJavaSample", options);
            System.exit(1);
        }

        // Read and validate runtime.properties
        Properties runtimeProperties = loadProperties("runtime.properties");
        String dlwsCertPath = runtimeProperties.getProperty("dlws.cert.path");
        if (dlwsCertPath == null) {
            System.out.println("Required property 'dlws.cert.path' missing in runtime.properties!");
            System.exit(1);
        }
        String dlwsCertPassword = runtimeProperties.getProperty("dlws.cert.password");
        if (dlwsCertPassword == null) {
            System.out.println("Required property 'dlws.cert.password' missing in runtime.properties!");
            System.exit(1);
        }
        String dlwsCertType = runtimeProperties.getProperty("dlws.cert.type");
        if (dlwsCertType == null) {
            System.out.println("Required property 'dlws.cert.type' missing in runtime.properties!");
            System.exit(1);
        }

        // Set appropriate system properties
        System.setProperty("javax.net.ssl.keyStore", dlwsCertPath);
        System.setProperty("javax.net.ssl.keyStorePassword", dlwsCertPassword);
        System.setProperty("javax.net.ssl.keyStoreType", dlwsCertType);

        /*
         * Proxy settings can be updated as follows:
         * System.setProperty("https.proxyHost", "proxy.bloomberg.com");
         * System.setProperty("https.proxyPort", "80");
         */

        // Run desired sample code
        try {
            Object sampleInstance = (Object) sampleClass.newInstance();
            Method run = sampleClass.getMethod("run", ProgramFlag.class);
            System.out.println("**********Running " + sampleNameStr + " sample**********");
            run.invoke(sampleInstance, programFlagHeader);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Create a map of Sample Name -> Java Sample Class
    private static Map<String, Class<?>> createSampleNamesMap() {
        Map<String, Class<?>> map = new HashMap<String, Class<?>>();
        map.put("Cancel", com.bloomberg.datalic.dlws.Cancel.class);
        map.put("GetActions", com.bloomberg.datalic.dlws.GetActions.class);
        map.put("GetAllQuotes", com.bloomberg.datalic.dlws.GetAllQuotes.class);
        map.put("GetCompany", com.bloomberg.datalic.dlws.GetCompany.class);
        map.put("GetCompanyFieldSet", com.bloomberg.datalic.dlws.GetCompanyFieldSet.class);
        map.put("GetData", com.bloomberg.datalic.dlws.GetData.class);
        map.put("GetDataBulk", com.bloomberg.datalic.dlws.GetDataBulk.class);
        map.put("GetDataFieldSet", com.bloomberg.datalic.dlws.GetDataFieldSet.class);
        map.put("GetDataMacro", com.bloomberg.datalic.dlws.GetDataMacro.class);
        map.put("GetDataOverrides", com.bloomberg.datalic.dlws.GetDataOverrides.class);
        map.put("GetDataPricingSourceHeader",
                com.bloomberg.datalic.dlws.GetDataPricingSourceHeader.class);
        map.put("GetFields", com.bloomberg.datalic.dlws.GetFields.class);
        map.put("GetHistory", com.bloomberg.datalic.dlws.GetHistory.class);
        map.put("GetHistoryMacro", com.bloomberg.datalic.dlws.GetHistoryMacro.class);
        map.put("GetHistoryPricingSourceHeader",
                com.bloomberg.datalic.dlws.GetHistoryPricingSourceHeader.class);
        map.put("GetQuotes", com.bloomberg.datalic.dlws.GetQuotes.class);
        map.put("PortfolioValidation", com.bloomberg.datalic.dlws.PortfolioValidation.class);
        map.put("Scheduled", com.bloomberg.datalic.dlws.Scheduled.class);
        map.put("GetCorrections", com.bloomberg.datalic.dlws.GetCorrections.class);
        return map;
    }

    // Return Java class corresponding to given sampleName string
    private static Class<?> getSampleClass(String sampleName) {
        return sampleNamesMap.get(sampleName);
    }

    // Get a string consisting of all supported sample names
    private static String getSampleNames() {
        StringBuilder keys = new StringBuilder();
        keys.append("|");
        for (String key : sampleNamesMap.keySet()) {
            keys.append(key);
            keys.append("|");
        }
        return keys.toString();
    }

    // Create a map of program flag string -> ProgramFlag enum
    private static Map<String, ProgramFlag> createProgramFlagsMap() {
        Map<String, ProgramFlag> map = new HashMap<String, ProgramFlag>();
        map.put("scheduled", ProgramFlag.ONESHOT);
        map.put("adhoc", ProgramFlag.ADHOC);
        return map;
    }

    // Return ProgramFlag enum corresponding to given programFlag string
    private static ProgramFlag getProgramFlagHeader(String programFlag) {
        return allowedProgramFlagsMap.get(programFlag.toLowerCase());
    }

    // Get a string consisting of all allowed program flags
    private static String getProgramFlags() {
        StringBuilder keys = new StringBuilder();
        keys.append("|");
        for (String key : allowedProgramFlagsMap.keySet()) {
            keys.append(key);
            keys.append("|");
        }
        return keys.toString();
    }

    // Load properties file
    private static Properties loadProperties(String filepath) {
        InputStream input = null;
        Properties properties = null;
        try {
            input = new FileInputStream(filepath);
            properties = new Properties();
            properties.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return properties;
    }

}
