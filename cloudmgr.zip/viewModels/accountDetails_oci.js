/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * infraAccountDetails module
 */
define(['ojs/ojcore', 'knockout', 'jquery', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/popup/popupHelper', 'ebs/utils/progressHelper', 'ojs/ojarraydataprovider', 'ebs/constants', 'ojs/ojvalidator-regexp',
    'ebs/utils/helpMenu','ojs/ojlabel', 'ojs/ojknockout', 'ojs/ojinputtext', 'ojs/ojselectcombobox', 'ojs/ojfilepicker','ojs/ojmessages','ojs/ojpopup','ojs/ojbutton',  'ojs/ojdialog', 'ojs/ojformlayout', "ojs/ojprogress-circle"
], function (oj, ko, $, actionsHelper, pageNavigationHelper, popupHelper, progressHelper, ArrayDataProvider, constants, RegExpValidator, helpMenu) {
    /**
     * The view model for the main content view template
     */
    function infraAccountDetailsContentViewModel() {
        var self = this;

        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));

        self.tenancyGroupValid = ko.observable();
        self.saveButtonDisabled = ko.observable(true);
        self.apiKeyMsg = ko.observable();
        self.apiKeyHelpMsg = ko.observable(oj.Translations.getTranslatedString('helpMsgs.uploadApiKey'));
        /**
         * Following values should be retrieved from the REST service:
         *
         * 1. Title
         * 2. subTitle
         * 3. Regions List
         *
         */
        self.title = ko.observable(oj.Translations.getTranslatedString('pageHeader.accountDetails'));
        self.subTitle = ko.observable(oj.Translations.getTranslatedString('pageHeader.updateAccountDetails'));
        self.swiftPassword = ko.observable();
        self.fingerprint = ko.observable('');
        self.userOCIDReadonly = ko.observable(false);
        self.fingerprintValueChangeListener = ko.observable();
        self.cancelButtonDisabled = ko.observable(false);
        self.doneButtonDisabled = ko.observable(false);
        self.isValidatedUser = ko.observable(false);
        self.isKeyAvailable = ko.observable(false);
        var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.accountDetailsTitle");
        
        self.confirmGetKeyMsg = oj.Translations.getTranslatedString('confirmPopup.getPublicKeyMsg');
        self.registerUserMsg = oj.Translations.getTranslatedString('confirmPopup.registerNewUserMsg');

        self.displayNavigationMenu = ko.observable('none');
        self.showEditUserOCIDBtn = ko.computed(function(){
            if(self.isValidatedUser()) return false;
            else return true;
        });
        self.editUserOCIDBtnText = oj.Translations.getTranslatedString('labels.editLabel'); 
        self.getUserPublicKeyText = oj.Translations.getTranslatedString('labels.getPublicKeyLabel'); 
        self.userPofileUpdated = ko.observable(false);
        self.editUserOCIDPopupTitle = oj.Translations.getTranslatedString("confirmPopup.updateUserOCIDTitle"); 
        self.showUpdateOCIDProgressBar = ko.observable("none");
        self.disableUpdateSubmitBtn = ko.observable(false);
        self.disableUpdateCancelBtn = ko.observable(false);
        self.disableGenerateKeySubmitBtn = ko.observable(false);
        self.disableGenerateKeyCancelBtn = ko.observable(false);
        self.disableRegisterSubmitBtn = ko.observable(false);
        self.disableRegisterCancelBtn = ko.observable(false);
        self.showGenerateKeyProgressBar = ko.observable("none");
        self.showRegisterProgressBar = ko.observable("none");
        self.updateUserOCIDInput = ko.observable(rootViewModel.userOCID());
        
        self.registerUserProgressConfig = progressHelper.getProgressConfig('registerUser', -1, 'Registering user with Cloud Manager.' , self.showRegisterProgressBar);
        
        self.generateKeyProgressConfig = progressHelper.getProgressConfig('updateUserOCID', -1, 'Getting Cloud Manager public key for user.' , self.showGenerateKeyProgressBar);
        
        self.submitOCIDProgressConfig = progressHelper.getProgressConfig('updateUserOCID', -1, 'Updating user OCID.' , self.showUpdateOCIDProgressBar);
        
        self.userProfileLoaded = ko.observable(false);

        self.pageErrorExist = ko.observable(false);

        // Added help menu placeholder
        helpMenu.addElementAndRemoveDuplicate('accountDetails_oci');
                    
        self.inlineMessages = ko.observableArray([
            {
              severity: 'warning',
              summary: oj.Translations.getTranslatedString("validationMsgs.userSetupIncompleteMsg"), 
              detail1: oj.Translations.getTranslatedString("validationMsgs.validateUserMsg1"), 
              detail2: oj.Translations.getTranslatedString("validationMsgs.validateUserMsg2"),
              closeAffordance: 'none'
            }]);
        
        self.lastValidatedTimestamp = ko.observable();
        self.validateErrorMsg = ko.observableArray([]);
        
        var bypassUserOcidValidation = rootViewModel.properties.has("userocid_validation_enabled") ?
                        (rootViewModel.properties.get("userocid_validation_enabled") === false) : false;

        self.setValidationError = function()
        {
            self.lastValidatedTimestamp(new Date().toUTCString());
            self.inlineMessages.removeAll();
            var msgs = [
            {
              severity: 'warning',
              summary: oj.Translations.getTranslatedString("validationMsgs.validateUserSummaryMsg", {timestamp: self.lastValidatedTimestamp()}), 
              detail1: oj.Translations.getTranslatedString("validationMsgs.validateUserMsg1"), 
              detail2: oj.Translations.getTranslatedString("validationMsgs.validateUserMsg2"),
              closeAffordance: 'none'
            }];
           self.inlineMessages(msgs);
        }
        
        var UserOcidPatternValidator = function ()
                {};
                oj.Object.createSubclass(UserOcidPatternValidator, oj.Validator, "UserOcidPatternValidator");
                
        self.userOcidValidator = [
                 (bypassUserOcidValidation ? '' :
                    new RegExpValidator({
                                pattern: '^[a-zA-Z0-9.]*$',
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.invalidUserOCIDFormatMsg')
                            })),
                  (bypassUserOcidValidation ? '' : new UserOcidPatternValidator())
                ];
         
        UserOcidPatternValidator.prototype.validate = function (value)
        {
             if (!value || value === '')
                 return true;
             
             var isValid = true;
            value = value.trim();
            
            if(value.toLowerCase().indexOf('user') < 0)
            {
                isValid = false;
                throw new Error(oj.Translations.getTranslatedString('validationMsgs.invalidUserOCIDMsg'));
            }
            if(value.toLowerCase().indexOf('ocid') < 0)
            {
                isValid = false;
                throw new Error(oj.Translations.getTranslatedString('validationMsgs.invalidUserOCIDMsg'));
            }

            return isValid;
        };

        
        self.categoryOption = { category: 'none' };
        self.inlineMessagesDataprovider = new ArrayDataProvider(self.inlineMessages);
        self.displayInlineMessage = ko.computed(function()
        {
            return !self.pageErrorExist() && self.userOCIDReadonly() && !self.isValidatedUser();
        });
        
       self.pageErrorMessages = ko.observableArray([]);
       self.errorMessagesDataprovider = new ArrayDataProvider(self.pageErrorMessages);                
       self.addPageLevelErrorMessage = function (messageSeverity, messageSummary, messageDetail)
        {
            var newPageMessageObject = new Object();
            newPageMessageObject.severity = messageSeverity;
            newPageMessageObject.summary = messageSummary;
            newPageMessageObject.detail = messageDetail;
            newPageMessageObject.closeAffordance = "none";


            var tempArray = self.pageErrorMessages();
            tempArray.push(newPageMessageObject);
            self.pageErrorExist(true);
            self.pageErrorMessages(tempArray);

        };
        self.clearPageLevelErrorMessage = function()
        {
             self.pageErrorExist(false);
             self.pageErrorMessages([]);
        };
        
        self.userOCIDShortValue = ko.computed(function(){
            var origValue = rootViewModel.userOCID();
            if(origValue && origValue.length > 6)
            return "..." + origValue.substring(origValue.length - 6);
            else return origValue;
        });
        self.tenancyOCIDShortValue = ko.computed(function(){
            var origValue = rootViewModel.tenancyOCID();
            if(origValue && origValue.length > 6)
            return "..." + origValue.substring(origValue.length - 6);
            else return origValue;
        });
        self.userOCIDShown = ko.observable(false);
        self.tenancyOCIDShown = ko.observable(false);
        self.hideLongValueText = "Hide";
        self.showLongValueText = "Show";
        
        actionsHelper.getUserProfile(function (error, userprofile) {
            self.userProfileLoaded(true);
            if (error === '') {
                rootViewModel.userOCID(userprofile.userOCID);
                rootViewModel.fingerprint(userprofile.fingerPrint);
                self.fingerprint(userprofile.fingerPrint);
                rootViewModel.username(userprofile.username);
                self.isValidatedUser(userprofile.isSSHKeysValid);
                if(userprofile.userOCID && userprofile.userOCID !== null && userprofile.userOCID !== '')
                {
                     self.userOCIDReadonly(true);
                }
                else
                {
                     self.userOCIDReadonly(false);
                }
                if (userprofile.isSSHKeysValid) {
                    rootViewModel.tenancyNameValue(userprofile.tenancyName);
                    rootViewModel.tenancyOCID(userprofile.tenancyOCID);
                    rootViewModel.selectedRegionValue(userprofile.region);
                }
                else{
                    self.cancelButtonDisabled(true);
                    actionsHelper.getGlobalProfile(function (error, globalProfile) {
                        if (error === '') {
                            rootViewModel.tenancyNameValue(globalProfile.tenancyName);
                            rootViewModel.tenancyOCID(globalProfile.tenancyOCID);
                            rootViewModel.selectedRegionValue(globalProfile.region);


                        } else
                        {
                            if (error !== null && error !== '')
                            {
                                if (error.status === 504)
                                {
                                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                    self.addPageLevelErrorMessage('error', 'Error in getting Global Profile.', messageContent);
                                } else
                                {
                                    var errorCode = error.responseJSON.code;
                                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                                    {
                                        errorCode = error.status;
                                    }
                                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                                    self.addPageLevelErrorMessage('error', 'Error in getting Global Profile', messageContent);
                                }

                            }
                        }
                    });
                }
            } else
            {
                if (error !== null && error !== '')
                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelErrorMessage( 'error', 'Error in getting User Profile.', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelErrorMessage( 'error', 'Error in getting User Profile', messageContent);
                    }

                }
            }
        });

        self.validators = function () {
            return "";
        };

        self.saveDetails = function () {
            console.log("about to submit the flow");
            var userOCID = document.getElementById("userocid");

            if (rootViewModel.apiKeySet()) {
                self.updateAPIKey();
            } else {
                if (userOCID.valid !== "valid") {
                    userOCID.showMessages();
                    return;
                } else {
                    self.insertUserProfile();
                }
            }

        };
        
        self.startAnimationListener = function (event, ui)
        {
            popupHelper.startAnimationListener(constants.divTags.accountDetailsConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.accountDetailsConfPopupTag, data, event);
        };

        self.insertUserProfile = function () {
            var userOcidElem = document.getElementById('userocid');
            if (userOcidElem !== null && userOcidElem.valid !== 'valid')
            {
               return;
            }
            
            self.clearPageLevelErrorMessage();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.accountInfoMsg");
            //popupHelper.openInfoMsg(constants.divTags.accountDetailsConfPopupTag, infoMsg, msgOrigin);
            var requestBody =
                    {
                       // 'tenancyName': rootViewModel.tenancyNameValue(),
                       // 'tenancyOCID': rootViewModel.tenancyOCID(),
                       // 'region': rootViewModel.selectedRegionValue(),
                       // 'username': rootViewModel.username(),
                        'userOCID': rootViewModel.userOCID() ? rootViewModel.userOCID().trim() : rootViewModel.userOCID()
                    };

            var requestBodyJSON = JSON.stringify(requestBody);
            actionsHelper.createUserProfile(requestBodyJSON, function (error, success) {
                self.showRegisterProgressBar("none");
                self.showGenerateKeyProgressBar("");
                if (error === '') {
                    //var messageContent = oj.Translations.getTranslatedString('confirmPopup.accountInfoMsg');
                    //self.addPageLevelMessage('confirmation', 'Register New User', messageContent);
                    self.downloadPublicKey();
                } else {
                    var popup = document.querySelector('#registerUserPopup');
                    popup.close();
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    //popupHelper.openErrorMsg(constants.divTags.accountDetailsConfPopupTag, response.message, msgOrigin);
                    var messageContent = 'Error Message : ' + response.message;
                    self.addPageLevelErrorMessage('error', 'Error in registering new user', messageContent);
                }
            });

        };

        
        self.generateNewKey = function()
        {
            var popup = document.querySelector('#confirmGenerateNewKey');
            popup.open();
        };
        
        self.registerUser = function()
        {
            var userOCID = document.getElementById("userocid");
            if (userOCID.valid !== "valid") {
                    userOCID.showMessages();
                    return;
                }
            var popup = document.querySelector('#registerUserPopup');
            self.disableRegisterCancelBtn(false);
            self.disableRegisterSubmitBtn(false);
            popup.open();
        };
        
        self.openUpdateOCIDPopup = function()
        {
            var popup = document.querySelector('#updateUserOCIDPopup');
            self.updateUserOCIDInput(rootViewModel.userOCID());
            popup.open();
        };
        
        self.closeConfirmPopup = function() {
            var popup = document.querySelector('#confirmGenerateNewKey');
            popup.close();
        };
        
        self.confirmGetKey = function() {
             self.downloadPublicKey();
             self.closeConfirmPopup();
        };
        
        self.closeRegisterPopup = function() {
            var popup = document.querySelector('#registerUserPopup');
            popup.close();
        };
        
        self.submitRegisterUser = function() {
            self.showRegisterProgressBar("");
            self.disableRegisterCancelBtn(true);
            self.disableRegisterSubmitBtn(true);
            self.insertUserProfile();
        };
        
        self.saveKeyFile = function(key)
        {
            var blob1 = new Blob([key], { type: "text/plain;charset=utf-8" });
 
            var fileName = "CloudMgrPublicKey.pem";
            var isIE = false || !!document.documentMode;
            if (isIE || window.navigator.msSaveBlob) {
                window.navigator.msSaveBlob(blob1, fileName);
            } else {
                var url = window.URL || window.webkitURL;
                var link = url.createObjectURL(blob1);
                var a = document.createElement("a");
                a.download = fileName;
                a.href = link;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
        };
        
        self.downloadPublicKey = function() {
            self.showGenerateKeyProgressBar("");
            self.disableRegisterSubmitBtn(true);
            self.disableRegisterCancelBtn(true);
            actionsHelper.getUserKey(function (error, publicKey) {
                self.clearPageLevelErrorMessage();
                self.showGenerateKeyProgressBar("none");
                self.disableRegisterSubmitBtn(false);
                self.disableRegisterCancelBtn(false);
                var popup = document.querySelector('#registerUserPopup');
                popup.close();
                if (error === '') {
                    rootViewModel.displayPopupId(constants.divTags.accountDetailsConfPopupTag);
                    //popupHelper.openSuccessMsg(constants.divTags.accountDetailsConfPopupTag, oj.Translations.getTranslatedString('confirmPopup.accountSuccessMsg'), msgOrigin);
                   // popupHelper.setSuccessPopupMsg(oj.Translations.getTranslatedString('confirmPopup.accountSuccessMsg'), msgOrigin)
                    self.saveKeyFile(publicKey);
                    
                    if(!self.isValidatedUser())
                      self.recheckUserProfile(true, true); 
                    
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                   // popupHelper.openErrorMsg(constants.divTags.accountDetailsConfPopupTag, response.message, msgOrigin);
                    var messageContent = 'Error Message : ' + response.message;
                    self.addPageLevelErrorMessage( 'error', 'Error in downloading user\'s public key', messageContent);
                }
            });
        };
        
        self.showCompartmentLov = function() {
            /* do nothing */
        };
        
        self.recheckUserProfile = function(redirect /*redirect to landing page if valid profile*/, initial){
            //get user profile and redirect to landing page if user is valid now
            //otherwise just set status and stay on this page.
            self.userProfileLoaded(false);
            actionsHelper.getUserProfile(function (error, userprofile) {
                self.clearPageLevelErrorMessage();
                if (error === '') {
                    rootViewModel.userOCID(userprofile.userOCID);
                    rootViewModel.fingerprint(userprofile.fingerPrint);
                    self.isValidatedUser(userprofile.isSSHKeysValid);
                    self.fingerprint(userprofile.fingerPrint);
                    rootViewModel.username(userprofile.username);
                    if(userprofile.userOCID && userprofile.userOCID !== null && userprofile.userOCID !== '')
                    {
                         self.userOCIDReadonly(true);
                    }
                    else
                    {
                         self.userOCIDReadonly(false);
                    }
                    if(userprofile.isSSHKeysValid)
                    {                
                       rootViewModel.tenancyNameValue(userprofile.tenancyName);
                       rootViewModel.tenancyOCID(userprofile.tenancyOCID);
                       rootViewModel.selectedRegionValue(userprofile.region);
                       if(redirect)
                         pageNavigationHelper.navigateToModule(constants.navModules.landingModule); 
                       else
                         self.userProfileLoaded(true);
                    }
                    else
                    {
                      if(!initial)
                       self.setValidationError();
                       self.userProfileLoaded(true);
                     }
                     
                }                    
                else if (error !== null && error !== '')
                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelErrorMessage( 'error', 'Error in getting User Profile.', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelErrorMessage( 'error', 'Error in getting User Profile', messageContent);
                    }

                    self.userProfileLoaded(true);
                }
               
               });
        }
        
        self.updateUserOCID = function() {
            var userOcidElem = document.getElementById('updateUserocid');
            if (userOcidElem !== null)
                userOcidElem.validate();
            if (userOcidElem !== null && userOcidElem.valid !== 'valid')
            {
               return;
            }
            self.showUpdateOCIDProgressBar("");
            self.disableUpdateSubmitBtn(true);
            self.disableUpdateCancelBtn(true);
            var reqBody =
                {
                    'userOCID': self.updateUserOCIDInput()
                };
            var reqJson = JSON.stringify(reqBody);
            
            actionsHelper.updateUserProfile(reqJson, function (error, success) {
                self.clearPageLevelErrorMessage();
                self.showUpdateOCIDProgressBar("none");
                self.disableUpdateSubmitBtn(false);
                self.disableUpdateCancelBtn(false);
                if (error === '') {
                    rootViewModel.displayPopupId(constants.divTags.accountDetailsConfPopupTag);
                    popupHelper.setSuccessPopupMsg(oj.Translations.getTranslatedString('confirmPopup.accountSuccessMsg'), msgOrigin);
                    var popup = document.querySelector('#updateUserOCIDPopup');
                    popup.close();
                    //var messageContent = oj.Translations.getTranslatedString('confirmPopup.accountSuccessMsg');
                    //self.addPageLevelMessage('confirmation', 'Update User OCID', messageContent);
                    self.recheckUserProfile(true); /*redirect if valid*/
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    var messageContent = 'Error Message : ' + response.message;
                    self.addPageLevelErrorMessage('error', 'Error in updating user OCID.', messageContent);
                    var popup = document.querySelector('#updateUserOCIDPopup');
                    popup.close();
                    //popupHelper.openErrorMsg(constants.divTags.accountDetailsConfPopupTag, response.message, msgOrigin);
                }
            });
        };
        
        self.cancelUpdateUserOCID = function() {
            var popup = document.querySelector('#updateUserOCIDPopup');
            popup.close();
        };
        
        self.doneButtonClicked = function(){
          self.clearPageLevelErrorMessage();
          pageNavigationHelper.navigateToModule(constants.navModules.landingModule); 
       };
       
       self.validateButtonClicked = function(){
          self.recheckUserProfile(true);
       };
       
       self.hideUserOCID = function()
       {
           self.userOCIDShown(false);
       };
       
       self.showUserOCID = function()
       {
           self.userOCIDShown(true);    
       };
       
       self.hideTenancyOCID = function()
       {
           self.tenancyOCIDShown(false);
       };
       
       self.showTenancyOCID = function()
       {
           self.tenancyOCIDShown(true);    
       };
    }

    return infraAccountDetailsContentViewModel;
});
