/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * backup module
 */
define(['ebs/navigation/pageNavigationHelper','ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/utils/validationHelper', 'ebs/utils/progressHelper', 'ebs/utils/backupEnvironmentHelper', 
    'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojasyncvalidator-numberrange',  'ojs/ojasyncvalidator-regexp', 'ojs/ojarraydataprovider', 'ojs/ojvalidator-regexp', 'ebs/utils/lovUtils', 'ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojmessages',
    'ojs/ojoption', 'ojs/ojbutton'], 
function (pageNavigationHelper,oj, ko, actionsHelper, validationHelper, progressHelper, backupEnvironmentHelper, popupHelper, constants, AsyncNumberRangeValidator, AsyncRegExpValidator, ArrayDataProvider, RegExpValidator, LovUtils) {
    /**
     * The view model for the main content view template
     */
    function addNodeModule() {
        var self = this;
        console.log('Loading Add Node Popup View Model');
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        
        //parent zone data
        self.parentZoneData = ko.observable();

        self.shapeList = ko.observableArray([{
                'label': 'loading...',
                'value': ''
            }]);            
        self.shapeDataProvider = new ArrayDataProvider(self.shapeList, {idAttribute: 'value'});

        self.faultDomainList = ko.observableArray([{
                'label': 'loading...',
                'value': ''
            }]);
        self.faultDomainDataProvider = new ArrayDataProvider(self.faultDomainList, {idAttribute: 'value'});

        self.fileSystemList = ko.observableArray([ {'label': 'Non-Shared', 'value': 'nonsfs'},{'label': 'Shared', 'value': 'sfs'}]);
        self.fileSystemDataProvider = new ArrayDataProvider(self.fileSystemList, {idAttribute: 'value'});

        self.selectedFileSystemType = ko.observable('');
        self.baseVolumeSize = ko.observable(''); 
        self.enteredVolumeSize = ko.observable('loading'); 
        self.selectedShape = ko.observable('');
        self.selectedFaultDomain = ko.observable('');
        self.selectedAdditionalStorage = ko.observable('');
        self.addNodePopupTitle = ko.observable('Add Node');
        self.enteredAppsNodePwd = ko.observable('');
        self.enteredAppsNodePwd = ko.observable('');
        self.enteredWLSPwd = ko.observable('');
        self.showWlsAdminPwd = ko.observable(false);
        self.showProgressBar = ko.observable("none");
        self.showSubmitProgressBar = ko.observable("none");
        self.disableSubmitBtn = ko.observable(false);
        self.disableCancelBtn = ko.observable(false);

        self.addlstorageNumValidator = ko.observableArray([]);  
        self.nodeLogicalHostname = ko.observable("");
        self.showLogicalHostname = ko.observable(false);
        self.logicalHostNameValidator = [
        new RegExpValidator({
          pattern: '^(?:([a-zA-Z]|[a-zA-Z][a-zA-Z0-9]{0,28}[A-Za-z0-9]))$',
          hint: oj.Translations.getTranslatedString('validationMsgs.logicalHostNameValidationMsg'),
          messageDetail: oj.Translations.getTranslatedString('validationMsgs.logicalHostNameValidationMsg')
        })
        ];

        
        self.addInlineMessage = function (messageSeverity, messageSummary, messageDetail)
        {
            self.clearInlineMessage();
            var newPageMessageObject = new Object();
            newPageMessageObject.severity = messageSeverity;
            newPageMessageObject.summary = messageSummary;
            newPageMessageObject.detail = messageDetail;
            newPageMessageObject.closeAffordance = "none";


            var tempArray = self.inlineMessages();
            tempArray.push(newPageMessageObject);
            self.inlineMessages(tempArray);

        };
        
        self.clearInlineMessage = function()
        {
             self.inlineMessages([]);
        };
        
        self.inlineMessages = ko.observableArray([]);
        self.categoryOption = { category: 'none' };
        
        self.displayInlineMessage = ko.computed(function(){
            if(self.inlineMessages().length > 0) return true;
            else return false;
        });
        
        self.inlineMessagesDataprovider = new ArrayDataProvider(self.inlineMessages);
        
   
        self.minBlockVolume = ko.computed(function(){
            console.log("min block volume =" + self.baseVolumeSize());
        
            var validator1 = 
                new AsyncNumberRangeValidator({
                  min: parseInt(self.baseVolumeSize()) , 
                  max: 2147483647,
                  hint: { inRange: oj.Translations.getTranslatedString('validationMsgs.minimumBlockVolumeMsg')}
               });
           var validator2 = new AsyncRegExpValidator({
            pattern: '^[0-9]+$',
            messageDetail: oj.Translations.getTranslatedString('validationMsgs.numericBlockVolumeMsg')
          });
          
            self.addlstorageNumValidator([validator1, validator2]);
    
            return self.baseVolumeSize();
        });
        
    
       self.appsPwdValidationMsg = ko.observable([]);
       self.wlsPwdValidationMsg = ko.observable([]);
       
       self.pwdValidateProgressConfig = progressHelper.getProgressConfig('validateProgress', -1, 'Password validation is in progress.' , self.showProgressBar);
       self.submitProgressConfig = progressHelper.getProgressConfig('submitProgress', -1, 'Submitting request.' , self.showSubmitProgressBar);
       
        self.performServerSidePwdValidations = function()
        {
            console.log('Performing server side validations for addNode');
            self.disableSubmitBtn(true);
            self.disableCancelBtn(true);
            self.showProgressBar("");
            var inputsToValidateFromServer =
                    [
                        {"id": "credentials.environment.appsPassword", "internalId": "addNodeAppsPwd", "customMsgObject": self.appsPwdValidationMsg, "value": self.enteredAppsNodePwd()},
                    ];


            var isWlsPwdRequired = self.showWlsAdminPwd();
            if (isWlsPwdRequired)
            {
                inputsToValidateFromServer.push({"id": "credentials.environment.weblogicPassword", "internalId": "addNodeWLSPwd", "customMsgObject": self.wlsPwdValidationMsg, "value": self.enteredWLSPwd()});
            }
            
            validationHelper.validateCredentialsOnServer(rootViewModel.currentEnvName(), inputsToValidateFromServer,  self.submitAddNodeRESTRequest, self.pwdValidationFailed);
      
        }
        
        self.pwdValidationFailed = function(error)
        {
            self.disableSubmitBtn(false);
            self.disableCancelBtn(false);
            self.showProgressBar("none");  
            
            if (error != null && error != '')
            {
                if (error.status === 504)
                {
                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                    self.addInlineMessage('error', 'Error in validating add node request inputs.', messageContent);
                } else
                {
                    var errorCode = error.responseJSON.code;
                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                    {
                        errorCode = error.status;
                    }
                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                    self.addInlineMessage('error', 'Error in validating add node request inputs.', messageContent);
                }
            }
        }

        self.submitAddNode = function ()
        {
              
            var validationsFailed = self.validateAddNodeContents();
            if (validationsFailed)
            {
                return;
            }
            console.log("proceed with pwd validations");
            self.performServerSidePwdValidations();
            
        };

       self.submitAddNodeRESTRequest = function()
       {
           self.showProgressBar("none");  
           self.showSubmitProgressBar("");
              /* Add Node Post JSON Content Preparation */
            var postJsonData = {
                "credentials": {
                    "environment": {
                        "appsPassword": "",
                        "weblogicPassword": ""
                    }
                },
                "existingZones": [
                    {
                        "name": self.parentZoneData().zoneName,
                        "fileSystemType": "",
                        "nodes": [
                            {
                                "shape": "",
                                "additionalStorage": 0,
                                "faultDomain": "",
                                "storageType": "BLOCK_VOLUME",
                                "mountIP": "",
                                "mountPath": "",
                                "mountParams": "",
                                "logicalHostName": ""
                            }
                        ]
                    }
                ]
            };

            postJsonData.credentials.environment.appsPassword = self.enteredAppsNodePwd();
            postJsonData.credentials.environment.weblogicPassword = self.enteredWLSPwd();
            postJsonData.existingZones[0].nodes[0].shape = self.selectedShape();
            //postJsonData.existingZones[0].nodes[0].additionalStorage = self.selectedAdditionalStorage() ? Math.round(self.selectedAdditionalStorage()) : 0;
            postJsonData.existingZones[0].nodes[0].faultDomain = self.selectedFaultDomain();
            postJsonData.existingZones[0].fileSystemType = self.selectedFileSystemType();
            postJsonData.existingZones[0].nodes[0].logicalHostName = self.nodeLogicalHostname() ? self.nodeLogicalHostname().toLowerCase() : self.nodeLogicalHostname();
            postJsonData.existingZones[0].nodes[0].additionalStorage = self.enteredVolumeSize() - self.baseVolumeSize();
            
            var requestBodyJSON = JSON.stringify(postJsonData);

            var envName = rootViewModel.currentEnvName();
           // self.closeAddNodePopup();
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.addNodeConfirmationMsgTitle");
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.addNodeInfoMsg");
           popupHelper.openSuccessMsg(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, infoMsg, msgOrigin);
           actionsHelper.addAppNodeToAnEnvironment(envName, requestBodyJSON, function (error, success) {
                
                if (error === '') {
                    self.closeAddNodePopup();
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.addNodeConfirmationMsg", {'appNodeName': rootViewModel.currentAppNodeNameForDelete});
                    var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.addNodeConfirmationMsgTitle");
                    var context = ko.contextFor(document.getElementById(constants.divTags.envDetailsPage));
                    // Clear off global variables before going back to environments list PG.
                    // These were set when we came from list page to details pg.
                    pageNavigationHelper.clearGlobalVariablesBeforeNavigationToEnvListPG(rootViewModel);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                    popupHelper.openSuccessMsg(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, successMsg, msgOrigin);

                } else {
                    self.showSubmitProgressBar("none");
                    self.disableCancelBtn(false);
                    self.disableSubmitBtn(false);
                    
                    popupHelper.confmPopuCloseHandler(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG);
                     
                    if (error != null && error != '')
                    {
                        if (error.status === 504)
                        {
                            var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                            self.addInlineMessage('error', 'Error in submitting add node request.', messageContent);
                        } else
                        {
                            var errorCode = error.responseJSON.code;
                            if (error.responseJSON.code === null || error.responseJSON.code === '')
                            {
                                errorCode = error.status;
                            }
                            var messageContent = 'Error Message : ' + error.responseJSON.message;
                            self.addInlineMessage('error', 'Error in submitting add node request.', messageContent);
                        }
                    }
                    //popupHelper.openErrorMsg(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, response.message, msgOrigin);
                }
            });
       }


        self.validateAddNodeContents = function ()
        {
            var invalidsPresent = false;
            var shape = document.getElementById("addNodeShape");
            var faultDomain = document.getElementById('addNodeFaultDomain');
            var appsPwd = document.getElementById('addNodeAppsPwd');
            var wlsPwd = document.getElementById('addNodeWLSPwd');
            var blockVolumne = document.getElementById('baseVolumeSize');
            var logicalHostName = document.getElementById('addNodeLogicalHostname');

            if (shape.valid !== 'valid')
            {
                shape.showMessages();
                invalidsPresent = true;
            }
            if (faultDomain.valid !== 'valid')
            {
                faultDomain.showMessages();
                invalidsPresent = true;
            }
            if (appsPwd.valid !== 'valid')
            {
                appsPwd.showMessages();
                invalidsPresent = true;
            }
            if (wlsPwd && wlsPwd.valid !== 'valid')
            {
                wlsPwd.showMessages();
                invalidsPresent = true;
            }
            if (blockVolumne && blockVolumne.valid !== 'valid')
            {
                blockVolumne.showMessages();
                invalidsPresent = true;
            }
            if (self.showLogicalHostname() && logicalHostName.valid !== 'valid')
            {
                logicalHostName.showMessages();
                invalidsPresent = true;
            }
            return invalidsPresent;
        };

        self.openPopup = function (event, ui)
        {
            var detailPG = ko.dataFor(document.getElementById('envDetailsPage'));
            var profile = detailPG.networkProfileName();
            
            //get file system type from the zone 
            if(self.parentZoneData())
            {
               var fileSysMode = self.parentZoneData().appsFileSystemMode;
               self.selectedFileSystemType(fileSysMode);
               console.log("fileSystemType=" + fileSysMode);
            }

            var envName = rootViewModel.currentEnvName();

            actionsHelper.getFaultDomains(profile, function (error, faultDomains)
            {
                self.faultDomainList(faultDomains);
                self.faultDomainDataProvider = new ArrayDataProvider(self.faultDomainList, {idAttribute: 'value'});
                LovUtils.lovOptionsUpdated(self.faultDomainList(), self.selectedFaultDomain);
            });
            var popup = document.querySelector(constants.divTags.addNodePopup);
            popup.open(event.target);
        };

        self.closeAddNodePopup = function (event, ui)
        {
            var popup = document.querySelector(constants.divTags.addNodePopup);
            popup.close();
        };
        
        self.resetPopup = function(event, ui)
        {
            self.clearInlineMessage();
            self.selectedFaultDomain('');
            self.enteredAppsNodePwd('');
            self.enteredWLSPwd('');
            self.nodeLogicalHostname('');
            self.showWlsAdminPwd(false);
            self.showProgressBar("none");
            self.showSubmitProgressBar("none");
            self.disableSubmitBtn(false);
            self.disableCancelBtn(false);
            self.wlsPwdValidationMsg([]);
            self.appsPwdValidationMsg([]);
        };
        
        actionsHelper.getOCIShapes(function (error, envMetadata)
        {
            self.shapeList(envMetadata.app);
            self.shapeDataProvider = new ArrayDataProvider(self.shapeList, {idAttribute: 'value'});
            LovUtils.lovOptionsUpdated(self.shapeList(), self.selectedShape);
        });

    }
    return addNodeModule;
});
