/* For any new flows we add post provisioning, we need to implement init() and reinit() methods.*/
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ojs/ojarraytreedataprovider', 'ebs/constants', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraydataprovider', 'ebs/utils/lovUtils', 'jquery', 
    'ojs/ojinputtext', 'ojs/ojlistview', 'ojs/ojarraytabledatasource', 'ojs/ojflattenedtreetabledatasource', 'ojs/ojjsontreedatasource', 'ojs/ojswitch', 'ojs/ojrowexpander', 
    'ojs/ojselectcombobox', 'ojs/ojcollapsible'
], function (oj, ko, actionsHelper, ArrayTreeDataProvider, constants, FlattenedTreeDataProviderView, ArrayDataProvider, lovUtils) {
    /**
     * The view model for the main content view template
     */
    function PostProvisioningStepsModule() {
        var self = this;
        var loadingOption = new Array();
        loadingOption.push({
            'label': 'loading...',
            'value': 'loading...'
        });
        self.executionTemplatesList = ko.observableArray(loadingOption);
        self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
        self.executionTemplateName = ko.observable();
        lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
        self.headerType = ko.observable('create');
        self.renderSubTab = ko.observable(false);
        self.tasksGrouping = ko.observableArray([]);
        self.selectedTab = ko.observable("Tab1");
        self.nestedDataProvider = new ArrayTreeDataProvider(self.tasksGrouping, { keyAttributes: "name" });
        self.nestedDataProviderObservable = ko.observable(self.nestedDataProvider);
        self.tableDataObject = ko.observable();
        self.customTasksPresent = ko.observable(true);
        self.tableDataProvider = ko.observable();
        self._currentExpansionState = 'none';
        var ACTIONS_MENU_ID_SUFFIX = "~menu";
        self.flattenedTreeStructure = ko.observableArray();
        self.menuOptions = ko.observableArray([]);
        var addPauseOption = { id: 'addPause', label: 'Add Pause', disabled: false };
        var removePauseOption = { id: 'removePause', label: 'Remove Pause', disabled: false };
        self.tableColumnsArray = [
            { "headerText": "", "sortable": "disabled", "headerStyle": "font-weight:bold" },
            { "headerText": "Phase/Tasks", "sortable": "disabled", "headerStyle": "font-weight:bold" },
            { "headerText": "Type", "sortable": "disabled", "headerStyle": "font-weight:bold" },
            { "headerText": "Action", "sortable": "disabled", "headerStyle": "font-weight:bold" }
        ];
        self._currentTaskKey = null;
        self.parentViewModel = ko.observable();
        self.prevRunParams = ko.observableArray();

       

        self.parseExecutionPlanTemplateJSON = function (execPlanDataJSON) {
            // First level phase, second level task, third level parameters.
            var tasksGroupingLocal = new Array();
            var allPhasesAndTasks = new Array();
            for (var i = 0; i < execPlanDataJSON.length; i++) {
                var phaseLevelData = execPlanDataJSON[i];
                var UIPhaseObject = new Object();
                UIPhaseObject.attr = new Object();
                UIPhaseObject.attr.isSeeded = phaseLevelData.attr.isSeeded;
                UIPhaseObject.attr.id = phaseLevelData.attr.id;
                UIPhaseObject.attr.label = phaseLevelData.attr.label;
                UIPhaseObject.attr._actionsMenuId = phaseLevelData.attr.id + ACTIONS_MENU_ID_SUFFIX;
                UIPhaseObject.attr._paused = false;
                var pausableAttr = phaseLevelData.attr.isPausable;
                if (typeof (pausableAttr) === 'undefined' || !pausableAttr) {
                    UIPhaseObject.attr._isActionsEnabled = false;
                } else {
                    UIPhaseObject.attr._isActionsEnabled = true;
                }
                var phaseSeededAttr = phaseLevelData.attr.isSeeded;
                var isSeededPhase = true;
                if (typeof (phaseSeededAttr) !== 'undefined' && !phaseSeededAttr) {
                    isSeededPhase = false;
                }

                var taskChildren = phaseLevelData.children;
                if (typeof (taskChildren) !== 'undefined' && taskChildren.length > 0) {
                    var UITaskElements = new Array();
                    for (var j = 0; j < taskChildren.length; j++) {
                        var taskLevelData = taskChildren[j];
                        var UITaskObject = new Object();
                        UITaskObject.attr = new Object();
                        UITaskObject.attr.isSeeded = taskLevelData.attr.isSeeded;
                        UITaskObject.attr.id = taskLevelData.attr.id;
                        UITaskObject.attr.label = taskLevelData.attr.label;
                        UITaskObject.attr._actionsMenuId = taskLevelData.attr.id + ACTIONS_MENU_ID_SUFFIX;
                        UITaskObject.attr._paused = false;
                        UITaskObject.attr._isActionsEnabled = false;
                        UITaskObject.attr.description = taskLevelData.attr.description ? taskLevelData.attr.description : '';
                        UITaskElements.push(UITaskObject);
                        var paramChildren = taskLevelData.children;
                        if (typeof (paramChildren) !== 'undefined' && paramChildren.length > 0 && !isSeededPhase) {
                            var customTaskObject = new Object();
                            customTaskObject.name = taskLevelData.attr.label;
                            customTaskObject.id = taskLevelData.attr.id;
                            customTaskObject.description = taskLevelData.attr.description ? taskLevelData.attr.description : '';
                            customTaskObject.expanded = ko.observable(true);
                            customTaskObject.children = new Array();
                            for (var k = 0; k < paramChildren.length; k++) {
                                var paramObject = new Object();
                                paramObject.name = paramChildren[k].attr.name;
                                paramObject.label = paramChildren[k].attr.label;
                                paramObject.value = paramChildren[k].attr.defaultValue;
                                paramObject.isSensitive = paramChildren[k].attr.isSensitive;
                                customTaskObject.children.push(paramObject);
                            }
                            tasksGroupingLocal.push(customTaskObject);
                        }
                    }
                    UIPhaseObject.children = UITaskElements;
                    allPhasesAndTasks.push(UIPhaseObject);
                } else {
                    allPhasesAndTasks.push(UIPhaseObject);
                }
            }
            if (tasksGroupingLocal.length > 0) {
                self.customTasksPresent(true);
            } else {
                self.customTasksPresent(false);
            }
            self.tasksGrouping(tasksGroupingLocal);
            self.tableDataObject(allPhasesAndTasks);
            self.loadTableView(false);
        };
        self.loadTableView = function (preserveExpansion) {
            self.flattenedTreeStructure([]);
            var options = [];
            var options =
            {
                'rowHeader': 'id',
            };
            if (preserveExpansion) {
                var currentExpansion = self.tableDataProvider()._data.m_expandedKeys;
                console.log('Current Expansion => ' + currentExpansion);
                if (currentExpansion === '' || ((typeof (currentExpansion.length) !== 'undefined') && currentExpansion.length <= 0)) {
                    var currentExpansionState = self._currentExpansionState;
                    if (currentExpansionState === 'ExpandAll') {
                        currentExpansion = 'all';
                    }
                }
                options.expanded = currentExpansion;
            }
            self.flattenData();
            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                new oj.FlattenedTreeDataSource(
                    new oj.JsonTreeDataSource(self.tableDataObject()), options)
            ))
                ;
        };

        self.expandAllItems = function () {

            self.flattenedTreeStructure([]);
            var options = [];
            var options =
            {
                'expanded': 'all',
                'rowHeader': 'id',
            };

            self.flattenData();
            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                new oj.FlattenedTreeDataSource(
                    new oj.JsonTreeDataSource(self.tableDataObject()), options)
            ))
                ;
            self._currentExpansionState = 'ExpandAll';
        };

        self.collapseAllItems = function () {
            self.flattenedTreeStructure([]);
            var options = [];
            var options =
            {
                'expanded': '',
                'rowHeader': 'id',
            };

            self.flattenData();
            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                new oj.FlattenedTreeDataSource(
                    new oj.JsonTreeDataSource(self.tableDataObject()), options)
            ))
                ;
            self._currentExpansionState = 'CollapseAll';
        };


        self.flattenData = function () {
            var phases = self.tableDataObject().length;
            for (var i = 0; i < phases; i++) {
                var phaseElemData = self.tableDataObject()[i];
                self.flattenedTreeStructure().push(phaseElemData);
                var taskChildren = phaseElemData.children;
                if (typeof (taskChildren) !== 'undefined' && taskChildren !== null && taskChildren.length > 0) {
                    for (var k = 0; k < taskChildren.length; k++) {
                        self.flattenedTreeStructure().push(taskChildren[k]);
                    }
                }
            }
        };
        self.getTaskDataFromFlattenedArray = function (childKey) {
            var elements = self.flattenedTreeStructure();
            if (elements === null) {
                return -1;
            } else {
                for (var i = 0; i < elements.length; i++) {
                    var childElem = elements[i];
                    if (childElem.attr.id === childKey) {
                        return childElem;
                    }
                }
                return -1;
            }
        };

        self.addPause = function (taskKey, event) {
            var phaseOrTaskObject = self.findPhaseOrTaskFromTableDataObject(taskKey);
            if (phaseOrTaskObject !== null) {
                phaseOrTaskObject.attr._paused = true;
                self.loadTableView(true);
            }
        };

        self.removePause = function (taskKey, event) {
            var phaseOrTaskObject = self.findPhaseOrTaskFromTableDataObject(taskKey);
            if (phaseOrTaskObject !== null) {
                phaseOrTaskObject.attr._paused = false;
                self.loadTableView(true);
            }
        };
        self.findPhaseOrTaskFromTableDataObject = function (key) {
            for (var i = 0; i < self.tableDataObject().length; i++) {
                var phaseObject = self.tableDataObject()[i];
                var phaseObjectId = phaseObject.attr.id;
                if (phaseObjectId === key) {
                    return phaseObject;
                }
                var children = phaseObject.children;
                if (typeof (children) === 'undefined' || children === null) {

                } else {
                    for (var k = 0; k < children.length; k++) {
                        var taskObject = children[k];
                        var taskObjectId = taskObject.attr.id;
                        if (taskObjectId === key) {
                            return taskObject;
                        }
                    }
                }

            }
        };
        self.handleEventsFromMenu = function (event) {
            var eventSourceName = event.target.value;
            console.log('Handle events form menu');
            if (eventSourceName === 'addPause') {
                self.addPause(self._currentTaskKey, event);
            } else if (eventSourceName === 'removePause') {
                self.removePause(self._currentTaskKey, event);
            }
        };
        self.setupMenuOptions = function (event) {
            console.log('Setting up menu options...');
            self.menuOptions([]);
            self._currentTaskKey = null;
            var identifier = null;
            var originalEventTarget = event.detail.originalEvent.target;
            if (originalEventTarget.id === null || originalEventTarget.id === '') {
                identifier = originalEventTarget.getAttribute("aria-labelledby");
            } else {
                identifier = originalEventTarget.id;
            }
            if (originalEventTarget !== null && identifier !== '') {
                var taskKey = identifier.split('~')[0];
                self._currentTaskKey = taskKey;
                var taskOrPhaseFromFlattenedTree = self.getTaskDataFromFlattenedArray(taskKey);
                var isPaused = taskOrPhaseFromFlattenedTree.attr._paused;
                if (isPaused) {
                    self.menuOptions.push(removePauseOption);
                } else {
                    self.menuOptions.push(addPauseOption);
                }
                document.getElementById(event.target.id).refresh();
                event.detail.originalEvent.stopPropagation();
            } else {
                return;
            }
        };
        self.isFormValid = function () {
            var isValid = true;
            var tasksGrouping = self.tasksGrouping();
            if (tasksGrouping === null || tasksGrouping.length < 1) {
                return true;
            } else {
                for (var i = 0; i < tasksGrouping.length; i++) {
                    var taskElement = tasksGrouping[i];
                    var taskName = taskElement.name;
                    var parameterChildren = taskElement.children;
                    if (typeof (parameterChildren) !== 'undefined' && parameterChildren.length > 0) {
                        for (var j = 0; j < parameterChildren.length; j++) {
                            var paramChildElement = parameterChildren[j];
                            var parameterChildName = taskName + "_" + paramChildElement.name;
                            var paramElem = document.getElementById(parameterChildName);
                            if (paramElem !== null && paramElem.valid !== 'valid') {
                                paramElem.showMessages();
                                isValid = false;
                            }
                        }
                    }
                }
                if (!isValid) {
                    self.focusOnCustomTasksTab();
                    window.setTimeout(function () {
                        self.expandAllCollapsedHeaders();
                    }, 1000);
                }
                return isValid;
            }
        };

        self.getExtensibleTasksFormData = function () {
            var extensibleTasks = new Object();
            extensibleTasks.templateId = self.executionTemplateName();
            var tasksGrouping = self.tasksGrouping();
            var inputs = new Array();
            extensibleTasks.inputs = inputs;
            if (tasksGrouping === null || tasksGrouping.length < 1) {
                // Nothing to send.
            } else {
                for (var i = 0; i < tasksGrouping.length; i++) {
                    var taskElement = tasksGrouping[i];
                    var taskName = taskElement.name;
                    var taskId = taskElement.id;
                    var parameterChildren = taskElement.children;
                    if (typeof (parameterChildren) !== 'undefined' && parameterChildren.length > 0) {
                        var input = new Object();
                        input.taskId = taskId;
                        var paramsArray = new Array();
                        input.parameters = paramsArray;
                        for (var j = 0; j < parameterChildren.length; j++) {
                            var paramChildElement = parameterChildren[j];
                            var parameterChildName = taskName + "_" + paramChildElement.name;
                            var paramElem = document.getElementById(parameterChildName);
                            if (paramElem !== null) {
                                var paramValue = paramElem.value;
                                var param = new Object();
                                param.name = paramChildElement.name;
                                param.value = paramValue;
                            }
                            paramsArray.push(param);
                        }
                        inputs.push(input);
                    }
                }

            }

            return extensibleTasks;
        };

        self.getPausedTasksFormData = function () {
            var pauses = self.getAllPausedTasksOrPhaseIdentifiers();
            if (pauses.length > 0) {
                return pauses;
            } else {
                return null;
            }
        };

        self.expandAllCollapsedHeaders = function () {
            var tasksGrouping = self.tasksGrouping();
            if (tasksGrouping === null || tasksGrouping.length < 1) {
                return true;
            } else {
                for (var i = 0; i < tasksGrouping.length; i++) {
                    var taskElement = tasksGrouping[i];
                    taskElement.expanded(true);
                }
            }

        };

        self.handleExecutionPlanChange = function (event) {
            var executionPlanName = event['detail'].value;
            if (typeof (executionPlanName) === 'undefined' || executionPlanName === null || executionPlanName === '' || executionPlanName === 'loading...') {
                return;
            }
            self.renderSubTab(false);
            if (typeof (self.parentViewModel()) !== 'undefined' && self.parentViewModel() !== null && self.parentViewModel() !== '') {
                if (typeof (self.parentViewModel().disableNextBtn) !== 'undefined') {
                    self.parentViewModel().disableNextBtn(true);
                }
            }
            actionsHelper.fetchExecutionTemplateBasedOnName(executionPlanName, function (error, executionplanDataJSON) {
                self.parseExecutionPlanTemplateJSON(executionplanDataJSON);
                self.renderSubTab(true);
                self.focusOnCustomTasksTab();
                if (typeof (self.parentViewModel()) !== 'undefined' && self.parentViewModel() !== null && self.parentViewModel() !== '') {
                    if (typeof (self.parentViewModel().disableNextBtn) !== 'undefined') {
                        self.parentViewModel().disableNextBtn(false);
                    }
                }
            });
        };

        self.focusOnCustomTasksTab = function () {
            var customTasksTab = document.getElementById('customTasksListingTab');
            var customTasksDisplay = customTasksTab.style.display;
            if (customTasksDisplay === 'none') {
                document.getElementById('customTasksListingTab').style.display = '';
                document.getElementById('execPlanTab').style.display = 'none';
                self.selectedTab('Tab1');
            } else {
                self.selectedTab('Tab1');
            }
        };

        self.handleTabChange = function (event) {
            var value = event.detail.value;
            if (value === 'Tab1') {
                document.getElementById('customTasksListingTab').style.display = '';
                document.getElementById('execPlanTab').style.display = 'none';
            } else {
                document.getElementById('customTasksListingTab').style.display = 'none';
                document.getElementById('execPlanTab').style.display = '';
                document.getElementById('execPlanTable').refresh();
            }
        };

        self.getDBSystemValueFromLabel = function (label) {
            if (label === 'Compute') {
                return constants.dbTypes.computeds;
            } else if (label === 'Exadata System') {
                return constants.dbTypes.exadatadbsystem;
            } else if (label === 'VMDB System') {
                return constants.dbTypes.vmdbsystem;
            }
        };

        self.initializeModule = function (jobType, parentViewModel) {
            if (jobType === constants.actions.Create || jobType === constants.actions.Restore || jobType === constants.actions.Clone || jobType === constants.actions.CloneStandBy || jobType === constants.actions.ReleaseStandBy) {
                self.executionTemplatesList(loadingOption);
                self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
                if (jobType === constants.actions.Create) {
                    var dbVersion = parentViewModel.selectedDBReleaseValue();
                    var ebsVersion = parentViewModel.selectedEbsVerValue();
                    var installType = parentViewModel.selectedPurposeValue();
                    var serviceType = self.getDBSystemValueFromLabel(parentViewModel.dbTypeUsed());
                    actionsHelper.fetchExecutionTemplatesForCreateFlow(ebsVersion, dbVersion, serviceType, installType, function (error, listOfAllExecutionTemplates) {
                        self.executionTemplatesList(listOfAllExecutionTemplates);
                        self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
                    });
                    var prevRunParams = new Array();
                    prevRunParams.push(constants.actions.Create);
                    prevRunParams.push(ebsVersion);
                    prevRunParams.push(dbVersion);
                    prevRunParams.push(serviceType);
                    prevRunParams.push(installType);
                    self.prevRunParams(prevRunParams);
                } else if (jobType === constants.actions.Restore) {
                    var serviceType = self.getDBSystemValueFromLabel(parentViewModel.dbTypeUsed());
                    var backupIdentifier = parentViewModel.backupBucket();
                    actionsHelper.fetchExecutionTemplatesForRestoreFlow(serviceType, backupIdentifier, function (error, listOfAllExecutionTemplates) {
                        self.executionTemplatesList(listOfAllExecutionTemplates);
                        self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
                    });
                    var prevRunParams = new Array();
                    prevRunParams.push(constants.actions.Restore);
                    prevRunParams.push(serviceType);
                    prevRunParams.push(backupIdentifier);
                    self.prevRunParams(prevRunParams);
                } else if (jobType === constants.actions.Clone) {
                    var sourceName = parentViewModel.sourceEnvironmentName();
                    actionsHelper.fetchExecutionTemplatesForCloneFlow(sourceName, function (error, listOfAllExecutionTemplates) {
                        self.executionTemplatesList(listOfAllExecutionTemplates);
                        self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
                    });
                } else if (jobType === constants.actions.CloneStandBy) {
                    actionsHelper.fetchExecutionTemplatesForCloneFromStandByFlow(function (error, listOfAllExecutionTemplates) {
                        self.executionTemplatesList(listOfAllExecutionTemplates);
                        self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
                    });
                } else if (jobType === constants.actions.ReleaseStandBy) {
                    var standByName = parentViewModel.envNameInputValue();
                    actionsHelper.fetchExecutionTemplatesForReleaseStandByFlow(standByName, function (error, listOfAllExecutionTemplates) {
                        self.executionTemplatesList(listOfAllExecutionTemplates);
                        self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
                    });
                    var prevRunParams = new Array();
                    prevRunParams.push(constants.actions.ReleaseStandBy);
                    prevRunParams.push(standByName);
                    self.prevRunParams(prevRunParams);
                }
            }
            else if (jobType === constants.actions.CustomActivity) {
                actionsHelper.fetchExecutionTemplatesForLCMFlow(function (error, execTemplatesList) {
                    self.executionTemplatesList(execTemplatesList);
                    self.executionTemplatesDataProvider = new ArrayDataProvider(self.executionTemplatesList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.executionTemplatesList(), self.executionTemplateName);
                });
            }
        };

        self.getAllPausedTasksOrPhaseLabels = function () {
            var pausedTasksOrPhase = new Array();
            var tableDataProvider = self.tableDataObject();
            for (var k = 0; k < tableDataProvider.length; k++) {
                var phaseObject = tableDataProvider[k];
                var isPaused = phaseObject.attr._paused;
                if (isPaused) {
                    pausedTasksOrPhase.push(phaseObject.attr.label);
                }
                var children = phaseObject.children;
                if (typeof (children) !== 'undefined' && children !== null && children.length > 0) {
                    for (var i = 0; i < children.length; i++) {
                        var taskChild = children[i];
                        var isPausedTask = taskChild.attr._paused;
                        if (isPausedTask) {
                            pausedTasksOrPhase.push(taskChild.attr.label);
                        }
                    }
                }
            }
            return pausedTasksOrPhase;
        };

        self.getAllPausedTasksOrPhaseIdentifiers = function () {
            var pausedTasksOrPhase = new Array();
            var tableDataProvider = self.tableDataObject();
            for (var k = 0; k < tableDataProvider.length; k++) {
                var phaseObject = tableDataProvider[k];
                var isPaused = phaseObject.attr._paused;
                if (isPaused) {
                    pausedTasksOrPhase.push(phaseObject.attr.id);
                }
                var children = phaseObject.children;
                if (typeof (children) !== 'undefined' && children !== null && children.length > 0) {
                    for (var i = 0; i < children.length; i++) {
                        var taskChild = children[i];
                        var isPausedTask = taskChild.attr._paused;
                        if (isPausedTask) {
                            pausedTasksOrPhase.push(taskChild.attr.id);
                        }
                    }
                }
            }
            return pausedTasksOrPhase;
        };
        self.taskDescriptionInPopup = ko.observable('');
        self.openTaskDescription = function (event, ui) {
            var targetId = ui.currentTarget.id;
            console.log("openTaskDesc invokeed: " + targetId);
            var taskKey = targetId.substring(0, targetId.indexOf("_descIcon"));
            var task = self.getTaskDataFromFlattenedArray(taskKey);
            if (task) {
                var desc = task.attr.description;
                self.taskDescriptionInPopup(desc);
                var popup = document.getElementById("taskDescPopup");
                popup.open('#' + self.escapeId(targetId));
            }
        };

        self.escapeId = function (s) {
            return s.replace(/(:|\.|\[|\])/g, "\\$1");
        };

        self.init = function () {
            var createTrainIdentifier = document.getElementById('train');
            var volumeCloneTrain = document.getElementById('volumeCloneTrain');
            var isCreateOrRestoreFlow = createTrainIdentifier !== null && volumeCloneTrain === null;
            var cloneFromStandByTrainElement = document.getElementById('cloneStandByEnvironmentTrainElement');
            var releaseStandByTrainElement = document.getElementById('releaseStandByEnvironmentTrainElement');
            var customAcitivitySubmissionFormElement = document.getElementById('submitCustomActivitiesPage');
            if(customAcitivitySubmissionFormElement !== null){
                self.headerType('lcm'); 
            }
            if (cloneFromStandByTrainElement !== null || releaseStandByTrainElement !== null) {
                if (cloneFromStandByTrainElement !== null) {
                    self.parentViewModel(ko.dataFor(cloneFromStandByTrainElement));
                    self.initializeModule(constants.actions.CloneStandBy, ko.dataFor(cloneFromStandByTrainElement));
                } else {
                    self.parentViewModel(ko.dataFor(releaseStandByTrainElement));
                    self.initializeModule(constants.actions.ReleaseStandBy, ko.dataFor(releaseStandByTrainElement));
                }
            } else if (isCreateOrRestoreFlow) {
                var viewModelForCreateFlowMain = ko.dataFor(createTrainIdentifier);
                self.parentViewModel(viewModelForCreateFlowMain);
                var isProvisiongFromBackup = viewModelForCreateFlowMain.isProvisioningFromBackup();
                viewModelForCreateFlowMain.disableNextBtn(true);
                if ("true" === isProvisiongFromBackup) {
                    self.initializeModule(constants.actions.Restore, ko.dataFor(createTrainIdentifier));
                } else {
                    self.initializeModule(constants.actions.Create, ko.dataFor(createTrainIdentifier));
                }
                viewModelForCreateFlowMain.disableNextBtn(false);
            } else {
                if (volumeCloneTrain === null) {
                    self.initializeModule(constants.actions.CustomActivity, null);
                } else {
                    var viewModelForCloneFlowMain = ko.dataFor(volumeCloneTrain);
                    self.parentViewModel(viewModelForCloneFlowMain);
                    self.initializeModule(constants.actions.Clone, ko.dataFor(volumeCloneTrain));
                }
            }
        };

        self.reinit = function () {
            // Check if reinitialization is required. If it is then call init.
            var previousRunValues = self.prevRunParams();
            if (previousRunValues === null || previousRunValues.length === 0) {
                return;
            }
            var createTrainIdentifier = document.getElementById('train');
            var isCreateOrRestoreFlow = createTrainIdentifier !== null;

            if (isCreateOrRestoreFlow) {
                var viewModelForCreateFlowMain = ko.dataFor(createTrainIdentifier);
                var isProvisiongFromBackup = viewModelForCreateFlowMain.isProvisioningFromBackup();
                if ("true" === isProvisiongFromBackup) {
                    if (previousRunValues[0] === constants.actions.Restore) {
                        var value1 = previousRunValues[1];
                        var value2 = previousRunValues[2];
                        var backupIdentifier = viewModelForCreateFlowMain.backupBucket();
                        var serviceType = self.getDBSystemValueFromLabel(viewModelForCreateFlowMain.dbTypeUsed());
                        if (value1 === serviceType && value2 === backupIdentifier) {
                            console.log('Re Initialization of Exec template not required.');
                            return;
                        } else {
                            console.log('Re Initialization of Exec template  required.');
                            self.init();
                        }
                    } else {
                        console.log('Re Initialization of Exec template  required.');
                        self.init();
                    }
                } else {
                    if (previousRunValues[0] === constants.actions.Create) {
                        var value1 = previousRunValues[1];
                        var value2 = previousRunValues[2];
                        var value3 = previousRunValues[3];
                        var value4 = previousRunValues[4];
                        var ebsVersion = viewModelForCreateFlowMain.selectedEbsVerValue();
                        var dbVersion = viewModelForCreateFlowMain.selectedDBReleaseValue();
                        var installType = viewModelForCreateFlowMain.selectedPurposeValue();
                        var serviceType = self.getDBSystemValueFromLabel(viewModelForCreateFlowMain.dbTypeUsed());
                        if (value1 === ebsVersion && value2 === dbVersion && value3 === serviceType && value4 === installType) {
                            console.log('Re Initialization of Exec template not required.');
                            return;
                        } else {
                            console.log('Re Initialization of Exec template  required.');
                            self.init();
                        }
                    } else if (previousRunValues[0] === constants.actions.ReleaseStandBy) {
                        // For release stand by there is no need to refresh the screen.
                    } else {
                        console.log('Re Initialization of Exec template  required.');
                        self.init();
                    }
                }
            }

        };

        self.init();

    }

    return PostProvisioningStepsModule;
});
