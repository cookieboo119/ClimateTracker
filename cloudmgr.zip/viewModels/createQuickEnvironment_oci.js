/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * createQuickEvnironment module
 */
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper','ebs/navigation/pageNavigationHelper', 'ebs/utils/dateTimeHelper', 'ojs/ojvalidator-regexp',
        'ojs/ojarraydataprovider', 'ebs/utils/createCloneTrainUtils', 'ebs/utils/lovUtils', 'jquery', 'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojbutton', 'ojs/ojselectcombobox', 'ojs/ojknockout-validation', 'ojs/ojradioset', 'ojs/ojpopup'
], function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper, dateTimeHelper, RegExpValidator, ArrayDataProvider, createCloneUtils, lovUtils) {
    /**
     * The view model for the main content view template
     */
    function createQuickEnvironmentContentViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
        rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.provisionEnvPageHeader'));
        rootViewModel.currentPage('simple');
        rootViewModel.showNavTab(false);
        var appUrl = rootViewModel.url();
        
        var allDBVersions = [];
        var dbVersionsExcepteleventwofour = [];

        var bearerToken = rootViewModel.authToken();
        if (bearerToken) {
            sessionStorage.setItem('bearerToken', bearerToken);
        } else {
            bearerToken = sessionStorage.getItem('bearerToken');
        }
        if (!bearerToken) {
            oj.Router.rootInstance.go('login');
        }

        $.ajaxSetup({
            headers: {
                'Authorization': bearerToken
            },
            error: function (jxhr, event, data) {
                var status = jxhr.status;
                console.log('status ' + status);
                if (status === 401) {
                    oj.Router.rootInstance.go('login');
                }
            }
        });
        self.getDefaultEnvName = function(){
            var suffix = dateTimeHelper.getDefaultDateBasedSuffixForResourceNames();
            return 'EBS'+ suffix;
        };
        
        self.prevPage = ko.observable('Environments');
        self.confirmationMessage = ko.observable('');
        self.confirmationIcon = ko.observable('');
        self.origin = ko.observable('');
        self.confirmationCss = ko.observable('');
        
        self.envNameInputValue = ko.observable(self.getDefaultEnvName());
        self.selectedEbsVerValue = ko.observable('');
        self.selectedDBReleaseValue = ko.observable('');
        self.selectedPurposeValue = ko.observable('');
        self.ebsVerChoiceOptionsList = ko.observableArray([{'label': 'Loading....', 'value': ''}]);
        self.ebsVerChoiceDataProvider = new ArrayDataProvider(self.ebsVerChoiceOptionsList, {idAttribute: 'value'});
        self.dbVerChoiceOptionsList = ko.observableArray([{'label': 'Loading....', 'value': ''}]);
        self.dbVerChoiceDataProvider = new ArrayDataProvider(self.dbVerChoiceOptionsList, {idAttribute: 'value'});
        self.purposeChoiceOptionsList = ko.observableArray([{'label': 'Loading....', 'value': ''}]);
        self.purposeChoiceDataProvider = new ArrayDataProvider(self.purposeChoiceOptionsList, {idAttribute: 'value'});
        self.isInstallationTypeUsed = ko.observable('');
        self.ebsVersionsDataAll = ko.observable('');
        
        self.disableSubmitBtn = ko.observable(true);
        
        actionsHelper.getVersionInformation(function(error, ebsVersionsData)
        {
            self.ebsVersionsDataAll(ebsVersionsData);
            self.purposeChoiceOptionsList.removeAll();
            self.purposeChoiceDataProvider = null;
            var purposeOptions = ebsVersionsData.installtypes;
            if(purposeOptions !== null && purposeOptions.length > 0)
            {
              var purposeOptionsChoiceData = new Array();
              for(var i=0;i<purposeOptions.length;i++)
              {
                  var metaData = purposeOptions[i];
                  var optionData = new Object();
                  optionData.label = metaData.label;
                  optionData.value = metaData.value;
                  purposeOptionsChoiceData.push(optionData);
              }
             self.purposeChoiceOptionsList(purposeOptionsChoiceData); 
             self.purposeChoiceDataProvider = new ArrayDataProvider(self.purposeChoiceOptionsList, {idAttribute: 'value'});
             lovUtils.lovOptionsUpdated(self.purposeChoiceOptionsList(), self.selectedPurposeValue);
            }
        });

        
       
        
        /*actionsHelper.getEBSVersions(function (error,ebsVersions) {
            self.ebsVerChoiceOptionsList.removeAll();
            self.ebsVerChoiceOptionsList(ebsVersions);
        });
        
        actionsHelper.getDBVersions(function (error,dbVersions) {
            self.dbVerChoiceOptionsList.removeAll();
            allDBVersions = dbVersions;
            for(var i = 0; i<dbVersions.length; i++){
                if(dbVersions[i].value !== constants.dbVersion.elevent){
                    dbVersionsExcepteleventwofour.push(dbVersions[i]);
                }
            }
            var selectedEbsVersion = self.selectedEbsVerValue();
            if(selectedEbsVersion.startsWith(constants.ebsVersions.twelvetwoseven)){
                self.dbVerChoiceOptionsList(dbVersionsExcepteleventwofour); 
            }else{
                self.dbVerChoiceOptionsList(allDBVersions); 
            }
        });
        
        
        actionsHelper.getPurposeChoice(function (error,purposeChoice) {
            self.purposeChoiceOptionsList.removeAll();
            self.purposeChoiceOptionsList(purposeChoice);
        });
        
       
        self.ebsVersionChanged = function(event){
            var newEbsVersion = event['detail'].value;
            if(newEbsVersion.startsWith(constants.ebsVersions.twelvetwoseven)){
                self.dbVerChoiceOptionsList(dbVersionsExcepteleventwofour); 
            }else{
                self.dbVerChoiceOptionsList(allDBVersions); 
            }
        };
        
        */
        
        self.handleBackLink = function(event ,ui){
            var context = ko.contextFor(document.getElementById('createQuickEnv'));
            var prevModule = 'environmentsList_oci';
            context.$parent.selectedNavItem(prevModule);
            context.$parent.childRouterKO(prevModule);
        };

        self.cancel = function () {
            var context = ko.contextFor(document.getElementById(constants.divTags.createSimEnvPage));
            context.$parent.selectedNavItem(constants.navModules.envListModule);
            context.$parent.childRouterKO(constants.navModules.envListModule);
        };
        
        self.startAnimationListener = function (event,ui)
        {
            popupHelper.startAnimationListener(constants.divTags.createSimEnvPopupTag,event ,ui);
        };

        self.confirmationPopupCloseHandler = function(data,event){
            popupHelper.confmPopuCloseHandler(constants.divTags.createSimEnvPopupTag,data,event);
        };
        
        self.areFieldsValid = function(){
            var invalidsPresent = false;
            var envName = document.getElementById("envName");
            var purposeChoice = document.getElementById("purposeChoice");
            var ebsVerChoice = document.getElementById("ebsVerChoice");
            var dbVerChoice = document.getElementById("dbVerChoice");
            var tagKeyText = document.getElementById("tagKeyText0");
            if (envName.valid !== 'valid' || purposeChoice.valid !== 'valid' ||
                    ebsVerChoice.valid !== 'valid' || dbVerChoice.valid !== 'valid' ||
                    (null != tagKeyText && tagKeyText.valid !== 'valid')) {
                invalidsPresent = true;
            }
            return !invalidsPresent;
        };
        
        self.displayValidationErrorMsgs = function(){
            var envName = document.getElementById("envName");
            var purposeChoice = document.getElementById("purposeChoice");
            var ebsVerChoice = document.getElementById("ebsVerChoice");
            var dbVerChoice = document.getElementById("dbVerChoice");
            var tagKeyText = document.getElementById("tagKeyText0");
            if (envName.valid !== 'valid' || purposeChoice.valid !== 'valid' || 
                ebsVerChoice.valid !== 'valid' || dbVerChoice.valid !== 'valid' || tagKeyText.valid !== 'valid') {
                envName.showMessages();
                purposeChoice.showMessages();
                ebsVerChoice.showMessages();
                dbVerChoice.showMessages();
                tagKeyText.showMessages();
            }
            
        };
        
        self.envValueChanged = function(event){
            if(self.areFieldsValid()){
                self.disableSubmitBtn(false);
            }else{
                var envName = document.getElementById("envName");
                if (envName.valid !== 'valid'){
                    envName.showMessages();
                }
                self.disableSubmitBtn(true);
            }
        };
        
        self.purposeValueChanged = function(event)
        {
            var selectedPurpose = event['detail'].value;
            if(selectedPurpose === null || selectedPurpose === '')
              selectedPurpose = self.selectedPurposeValue();
            if(selectedPurpose === null || selectedPurpose === '')
            {
                return;
            }
            self.ebsVerChoiceOptionsList.removeAll();
            self.ebsVerChoiceDataProvider = null;
            var purposeOptions = self.ebsVersionsDataAll().installtypes;
            if(purposeOptions !== null && purposeOptions.length > 0)
            {
              for(var i=0;i<purposeOptions.length;i++)
              {
                  var valueOfInstallationTypeInMetaData = purposeOptions[i].value;
                  if(valueOfInstallationTypeInMetaData === selectedPurpose)
                  {
                     var versionsList =  purposeOptions[i].ebsversions;
                     var ebsAppsVersionListChoiceData = new Array();
                     for(var j=0;j<versionsList.length;j++)
                     {
                         var versionInMetaData = versionsList[j];
                         var optionData = new Object();
                         optionData.label = versionInMetaData.label;
                         optionData.value = versionInMetaData.value;
                         ebsAppsVersionListChoiceData.push(optionData);
                     }
                     self.ebsVerChoiceOptionsList(ebsAppsVersionListChoiceData);
                     self.ebsVerChoiceDataProvider = new ArrayDataProvider(self.ebsVerChoiceOptionsList, {idAttribute: 'value'});
                     lovUtils.lovOptionsUpdated(self.ebsVerChoiceOptionsList(), self.selectedEbsVerValue);
                     return;
                  }
              }

            } 
            if(self.areFieldsValid()){
                self.disableSubmitBtn(false);
            }else{
                self.disableSubmitBtn(true);
            }
        };
        
        self.ebsVersionValueChanged = function(event)
        {
             var newEbsVersion = event['detail'].value;
             if(newEbsVersion === null || newEbsVersion === '')
             {
                 newEbsVersion = self.selectedEbsVerValue();
             }
             if(newEbsVersion === null || newEbsVersion === '')
             {
                 return;
             }
             var selectedPurposeType = self.selectedPurposeValue();
             self.dbVerChoiceOptionsList.removeAll();
             self.dbVerChoiceDataProvider = null;
             var purposeOptions = self.ebsVersionsDataAll().installtypes;
             if(purposeOptions !== null && purposeOptions.length > 0)
             {
               for(var i=0;i<purposeOptions.length;i++)
               {
                   var valueOfInstallationTypeInMetaData = purposeOptions[i].value;
                   if(valueOfInstallationTypeInMetaData === selectedPurposeType)
                   {
                      var ebsVersionsInMetaData = purposeOptions[i].ebsversions;
                      for(var j=0;j<ebsVersionsInMetaData.length;j++)
                      {
                          var currentEbsVersionValueInMetaData = ebsVersionsInMetaData[j].value;
                          if(currentEbsVersionValueInMetaData === newEbsVersion)
                          {
                              var dbVersionsInMetaData = ebsVersionsInMetaData[j].dbversions;
                              if(dbVersionsInMetaData !== null && dbVersionsInMetaData.length > 0)
                              {
                                  var dbVersionsChoiceOptionList = new Array();
                                  for(var k=0;k<dbVersionsInMetaData.length;k++)
                                  {
                                      var optionData = new Object();
                                      optionData.label = dbVersionsInMetaData[k].label;
                                      optionData.value = dbVersionsInMetaData[k].value;
                                      dbVersionsChoiceOptionList.push(optionData);
                                  }
                                  self.dbVerChoiceOptionsList(dbVersionsChoiceOptionList);
                                  self.dbVerChoiceDataProvider = new ArrayDataProvider(self.dbVerChoiceOptionsList, {idAttribute: 'value'});
                                  lovUtils.lovOptionsUpdated(self.dbVerChoiceOptionsList(), self.selectedDBReleaseValue);
                              }
                          }
                      }
                   }
               }

             } 
             if(self.areFieldsValid()){
                self.disableSubmitBtn(false);
             }else{
                self.disableSubmitBtn(true);
             }
        };
        
        self.dbVersionValueChanged = function(event){
            if(self.areFieldsValid()){
                self.disableSubmitBtn(false);
            }else{
                self.disableSubmitBtn(true);
            }
        };
        
         self.tagKeyValueChanged = function(event){
            if(self.areFieldsValid()){
                self.disableSubmitBtn(false);
            }else{
                self.disableSubmitBtn(true);
            }
        };
        
        self.selectedTagNamespace = ko.observable('');
        self.selectedTagKeyText = ko.observable('');
        self.selectedTagKeySelect = ko.observable('');
        self.selectedTagValue = ko.observable('');
        
        self.submitEnvironmentCreation = function () {
            
            if(self.areFieldsValid()) {
                self.disableSubmitBtn(true);
                var infoMsg = oj.Translations.getTranslatedString("confirmPopup.advCreateInfoMsg", {'envName':self.envNameInputValue()});
                var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.advCreateEnvTitle");
                popupHelper.openInfoMsg(constants.divTags.createSimEnvPopupTag,infoMsg,msgOrigin);
                console.log("createQuickEnvironment.submitEnvironmentCreation  ..about to submit the flow");
                
                // Variables for tag module
                var selTagName = '';
                var selTagKeyText = '';
                var selTagKeySelect = '';
                var selFreeTagValue = '';
                var selTagValue = '';

                // Logic to set values for tag module
                if (self.selectedTagNamespace() === 'none') {
                    selFreeTagValue = self.selectedTagValue();
                    selTagKeyText = self.selectedTagKeyText();
                } else {
                    selTagName = self.selectedTagNamespace();
                    selTagKeySelect = self.selectedTagKeySelect();
                    selTagValue = self.selectedTagValue();
                }
                var simpleRequestBody =
                        {
                            "environmentName": self.envNameInputValue(),
                            "ebsVersion": self.selectedEbsVerValue(),
                            "dbVersion": self.selectedDBReleaseValue(),
                            "installType": self.selectedPurposeValue(),
                            "tags": {
                                "freeFloat": [
                                    {
                                        "key": selTagKeyText,
                                        "value": selFreeTagValue
                                    }
                                ],
                                "defined": [
                                    {
                                        "namespace": selTagName,
                                        "key": selTagKeySelect,
                                        "value": selTagValue
                                    }
                                ]
                            }
                        };
                var requestBodyJSON = JSON.stringify(simpleRequestBody);
                actionsHelper.createSimpleEnv(requestBodyJSON, function(error,success){
                    if(error === ''){
                        var context = ko.contextFor(document.getElementById(constants.divTags.createSimEnvPage));
                        rootViewModel.displayPopupId(constants.divTags.createSimEnvPopupTag);
                        var confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.advCreateSuccessEnvMsg", {'envName':self.envNameInputValue()});
                        popupHelper.setSuccessPopupMsg(confirmationSuccessMsg,msgOrigin);
                        pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                    }else{
                        self.disableSubmitBtn(false);
                        var responseText = error.responseText;
                        var response = JSON.parse(responseText);
                        popupHelper.openErrorMsg(constants.divTags.createAdvEnvPopupTag,response.message,msgOrigin);
                    }
                });
            }
        };
        
        var loading = oj.Translations.getTranslatedString('info.loading');
        self.tagNamespaceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
        self.tagNamespaceOptionsDataProvider = new ArrayDataProvider(self.tagNamespaceOptionsList, {idAttribute: 'value'});
        self.tagKeyOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
        self.tagKeyList = ko.observableArray([{'label': loading, 'value': ''}]);
        self.tagValueOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);

        // Retrieve tag namespace options 
        actionsHelper.getTagNamespaceForSingleVM(function (error, tagDetails) {
            self.tagNamespaceOptionsList.removeAll();
            self.tagNamespaceOptionsDataProvider = null;
            var tagDetailsLen = tagDetails.length;
            if (null !== tagDetails && tagDetailsLen > 0) {
                var tagOptions = new Array();
                var optionData = new Object();
                optionData.label = 'None (add a free-form tag)';
                optionData.value = 'none';
                tagOptions.push(optionData);
                for (var i = 0; i < tagDetailsLen; i++) {
                    var metaData = tagDetails[i];
                    if (null !== metaData.label && metaData.label.length > 0) {
                        var optionData = new Object();
                        optionData.label = metaData.label;
                        optionData.value = metaData.value;
                        tagOptions.push(optionData);
                    }
                }
                self.tagNamespaceOptionsList(tagOptions);
                self.tagNamespaceOptionsDataProvider = new ArrayDataProvider(self.tagNamespaceOptionsList, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.tagNamespaceOptionsList(), self.selectedTagNamespace);
                self.tagKeyList(tagDetails);
            }
        });

        // Observable variable to show and hide tag key as textfield or combobox
        self.showTagText = ko.observable(true);
        self.showTagTextValue = ko.observable(true);

        // On change of tag namespace
        self.changeTagNamespace = function (event, current) {
            self.tagKeyOptionsList([]);
            if (self.tagKeyList().length > 0) {
                var returnKeysValues = createCloneUtils.changeTagNamespace(event, current, self.tagKeyList());
                if (returnKeysValues === "textfield") {
                    self.showTagText(true);
                } else {
                    self.showTagText(false);
                    self.tagKeyOptionsList(returnKeysValues);
                    // Set default value as first option of the options
                    self.selectedTagKeySelect(self.tagKeyOptionsList()[0].value);
                }
            }
        };
    
        // On change of tag key
        self.changeTagKey = function (event, current) {
            self.selectedTagValue('');
            if (self.tagKeyOptionsList().length > 0) {
                var returnKeysValues = createCloneUtils.changeTagKey(event, self.tagKeyOptionsList());
                if (returnKeysValues === "textfield") {
                    self.showTagTextValue(true);
                } else {
                    self.showTagTextValue(false);
                    self.tagValueOptionsList(returnKeysValues);
                    self.selectedTagValue(self.tagValueOptionsList()[0].value);
                }
            }
        }

        //remove white space for tag value
        self.changeTagValue = function (event, current) {
           self.selectedTagValue(event.detail.value ? event.detail.value.trim() : event.detail.value);
        };
        
        // Env name validation
        self.quickEnvNameValidator = ko.observableArray(
                [new RegExpValidator(
                    {pattern: '^[a-zA-Z]([a-zA-Z0-9]){1,19}$',
                     label: 'IPv4CIDR',
                     messageDetail: oj.Translations.getTranslatedString("validationMsgs.quickEnvNameMsg")})]
        );
    }
    return createQuickEnvironmentContentViewModel;
});
