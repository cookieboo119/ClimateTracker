/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * environmentsList module
 */
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/utils/dateTimeHelper',
    'ebs/utils/userRole', 'ebs/utils/networkProfileHelper', 'ebs/utils/lcmUtils', 'ojs/ojarraydataprovider', 'ojs/ojcollectiondataprovider', 'ojs/ojmessages', 'jquery', 'ojs/ojknockout', '', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojrouter', 'ojs/ojpopup', 'ojs/ojlistview', 'ojs/ojcollapsible',
    'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojoffcanvas', 'ojs/ojmodule', 'ojs/ojtrain', 'ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojselectcombobox', 'ojs/ojdialog',
    'ojs/ojinputtext', 'ojs/ojselectcombobox', 'ojs/ojoffcanvas', 'ojs/ojjsontreedatasource', 'ojs/ojformlayout', 'ebs/utils/compartmentsLov',  'ojs/ojlistitemlayout', 'ojs/ojinputsearch',  'ojs/ojlistitemlayout', "ojs/ojprogress-circle"
], function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper, dateTimeHelper, userRole, networkProfileHelper, lcmUtils, ArrayDataProvider, CollectionDataProvider)
{    /**
 * The view model for the main content view template
 */


    function environmentsListContentViewModel() {

        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.envListPageHeader'));
        rootViewModel.showContextHeader(false);
        rootViewModel.showNavTab(true);
        self.tenancyId = rootViewModel.tenancyOCID();

        var currentState = oj.Router.rootInstance.currentState();
        self.isAdminUser = userRole.isAdminUser();
        self.messages = ko.observableArray([]);


        var globalChildRouter = currentState._router._childRouters[2];

        var envName;
        var dbServiceType;
        var envNameDbServiceTypeMap = new Object();
        var envNameEbsVersionMap = new Object();
        self.selectedNavItem = ko.observable(constants.navModules.envListModule);
        var popupDiv = document.querySelector(constants.divTags.delConfirmPopupOverlay);
        if (popupDiv !== null) {
            popupDiv.parentNode.removeChild(popupDiv);
        }
        self.selectHandler = function (event)
        {
            if ('menu' === event.target.id && event.detail.originalEvent)
            {
                // router takes care of changing the selection
                event.preventDefault();
                self.selectedNavItem(event.detail.key);
                self.childRouterKO(event.detail.key);
            }
        };
        self.buildNavListData = function () {
            var jsonData = [];
            globalChildRouter.states.forEach(function (state) {


                jsonData.push({
                    'attr': {
                        id: state.id,
                        label: state.label,
                        href: "?root=" + state.id
                    }
                });
            });
            return jsonData;
        };

        networkProfileHelper.fetchNetworkProfilesForUser();
        networkProfileHelper.calDBSubnetLengthAssociatedWithNetworkProfile();

        self.envListPageNavData = new oj.JsonTreeDataSource(self.buildNavListData());
        self.gotoEnvDetails = function (env)
        {
            console.log("details for env " + env.name);
            rootViewModel.currentEnvName(env.name);
            rootViewModel.isDetailPG(true);

            console.log('From Object ->' + env.ebsVersion);
            var ebsVersion = env.ebsVersion;
            rootViewModel.currentEnvVersion(ebsVersion);
            console.log('Saving Env Version ' + ebsVersion + ' in root');

            console.log('Saving DB Version in root');
            var dbVersion = env.dbVersion;
            rootViewModel.currentDbVersion(dbVersion);

            var isProvisionedUsingSingleVM = env.deploymentType === constants.deploymentType.singleVM ? true : false;
            rootViewModel.disableAdministrationTabForEnvionment(isProvisionedUsingSingleVM);
            
            if("standby" === env.environmentType)
              rootViewModel.isStandbyEnv(true);
            else
              rootViewModel.isStandbyEnv(false);

            rootViewModel.envDetailsParentPage(constants.navModules.envListPage);
            var context = ko.contextFor(document.getElementById(constants.divTags.envListPage));
            pageNavigationHelper.navigateToPage(context, constants.navModules.envDetailsModule, '', false);
        };

        self.gotoJobDetails = function (env) {
            console.log("details for job " + env.jobId);
            oj.Router.rootInstance.store(env.jobId);
            rootViewModel.activityDetailsParentPage(constants.navModules.envListModule);
            var context = ko.contextFor(document.getElementById(constants.divTags.envListPage));
            pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, '', false);
        };


        self.showEnvSubmissionMsg = ko.observable('none');
        self.successfulEnvSubmMsg = ko.observable('');
        self.confirmationMessage = ko.observable('');
        self.confirmationIcon = ko.observable('');
        self.origin = ko.observable('');
        self.confirmationCss = ko.observable('');


        self.dataSource = ko.observable();


        /**
         * Translatable strings
         */
        self.searchEnvPlaceHolder = ko.observable(oj.Translations.getTranslatedString('labels.searchEnvName'));
        self.provEnvBtnLabel = ko.observable(oj.Translations.getTranslatedString('labels.provisionEnv'));
        self.summaryLabel = ko.observable(oj.Translations.getTranslatedString('labels.summary'));
        self.envsLabel = ko.observable('');
        self.exaSystemInstsLabel = ko.observable('');
        self.dbSystemInstsLabel = ko.observable('');
        self.dbComputeInstsLabel = ko.observable('');
        self.appsTierSummaryLabel = ko.observable('');

        self.dbServiceTypeLabel = ko.observable(oj.Translations.getTranslatedString('labels.dbServiceType'));
        self.appTierLabel = ko.observable(oj.Translations.getTranslatedString('labels.appTiers'));
        self.ebsVersionLabel = ko.observable(oj.Translations.getTranslatedString('labels.ebsVersion'));
        self.dbNameLabel = ko.observable(oj.Translations.getTranslatedString('labels.dbName'));
        self.provStatusLabel = ko.observable(oj.Translations.getTranslatedString('labels.lastActivityStatus'));
        self.createdOnLabel = ko.observable(oj.Translations.getTranslatedString('labels.createdOn'));
        self.dbVersionLabel = ko.observable(oj.Translations.getTranslatedString('labels.dbVersion'));
        self.compartmentNameLabel = ko.observable(oj.Translations.getTranslatedString('labels.compartmentName'));
        self.networkProfileNameLabel = ko.observable(oj.Translations.getTranslatedString('labels.networkProfileName'));
        self.pdbNameLabel = ko.observable(oj.Translations.getTranslatedString('labels.pdbName'));
        self.totalSingleVMEnvironmentsLabel = ko.observable('');

        self.envListLoaded = ko.observable(false);
        $(document).ready(function () {
            var displayPopupId = rootViewModel.displayPopupId();
            if (displayPopupId !== '') {
                $(constants.divTags.envListConfPopupTag).ojPopup('open', constants.divTags.rootBodyDivTag);
                rootViewModel.displayPopupId('');
            }
        });
        self.selectedListItem = ko.observable();
        self.confirmDeleteMsg = ko.observable();
        //19c upgrade
        self.confirmUpgradeMsg = ko.observable();
        self.showClone = ko.observable(false);

        self.envActionsMenuItemsWithCloneAndBackup = [
            {id: constants.contextMenu.clone, label: oj.Translations.getTranslatedString('contextMenu.clone'), disabled: false},
            {id: constants.contextMenu.backup, label: oj.Translations.getTranslatedString('contextMenu.backup'), disabled: false},
            {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: false}
        ];
        self.envActionsMenuItemsWithoutCloneAndBackup = [
            {id: constants.contextMenu.clone, label: oj.Translations.getTranslatedString('contextMenu.clone'), disabled: true},
            {id: constants.contextMenu.backup, label: oj.Translations.getTranslatedString('contextMenu.backup'), disabled: true},
            {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: false}
        ];
        self.envActionsMenuItemsWithCloneAndWithoutBackup = [
            {id: constants.contextMenu.clone, label: oj.Translations.getTranslatedString('contextMenu.clone'), disabled: false},
            {id: constants.contextMenu.backup, label: oj.Translations.getTranslatedString('contextMenu.backup'), disabled: true},
            {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: false}
        ];
        self.envActionsMenuItemsWithoutCloneAndWithBackup = [
            {id: constants.contextMenu.clone, label: oj.Translations.getTranslatedString('contextMenu.clone'), disabled: true},
            {id: constants.contextMenu.backup, label: oj.Translations.getTranslatedString('contextMenu.backup'), disabled: false},
            {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: false}
        ];

        self.envActionsMenuItemsWithoutDelete = [
            {id: constants.contextMenu.clone, label: oj.Translations.getTranslatedString('contextMenu.clone'), disabled: true},
            {id: constants.contextMenu.backup, label: oj.Translations.getTranslatedString('contextMenu.backup'), disabled: true},
            {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: true}
        ];

        //19c upgrade
        self.envDBUpgradeActionMenuItem = {id: constants.contextMenu.upgrade, label: oj.Translations.getTranslatedString('contextMenu.upgrade'), disabled: false};

        self.createEnvMenuItems = [
            {id: constants.contextMenu.quickCreate, label: oj.Translations.getTranslatedString('contextMenu.quickCreate'), disabled: false},
            {id: constants.contextMenu.advancedCreate, label: oj.Translations.getTranslatedString('contextMenu.advancedCreate'), disabled: false}
        ];

        // dynamic menu   
        self.menuOptions = ko.observableArray([]);
        self.currentMenuEnvName = ko.observable();
        // This is called before-menu-open so you can gather data from selected item.
        self.setupMenuOptions = function (event) {
            var target = event.detail.originalEvent.target;
            var context = document.getElementById('listview').getContextByNode(target);
            var key = null; //key: envName, we use this to lookup the environment for correct menu options
            var index = -1; //index: row index in listview
            if (context) {
                index = context.index;
                key = context.key;
                self.currentMenuEnvName(key);
            }
            self.getMenuItems(index, key);
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        }

        // This is called from inside of the setupMenuOptions method to actually build the menu options from the data
        self.getMenuItems = function (index, envName) {
            $.each(self.environments(), function (i, value) {
                var envData = value;
                if (envData.name === envName) {
                    var actionsMenu = null;
                    if (rootViewModel.lcmActivityFromREST && envData.allowedLCMActivities_env)
                    {
                        actionsMenu = lcmUtils.getEnvLcmActionsMenuFromREST(envData.environmentType, envData.allowedLCMActivities_env)
                    } else
                    {
                       // actionsMenu = lcmUtils.getLcmActionsMenuByType(envData.envActionMenuType);
                    }
                    if (actionsMenu)
                        self.menuOptions(actionsMenu);

                    return false; //break the loop
                }
            });

            return;
        }



        self.createEnvActionsHandler = function (event, ui)
        {
            var createEnvOption = event.target.value;
            var context = ko.contextFor(document.getElementById(constants.divTags.envListPage));
            context.$parent.showNavTab(false);
            rootViewModel.isDetailPG(false);
            if (createEnvOption === constants.contextMenu.advancedCreate) {
                pageNavigationHelper.navigateToPage(context, constants.navModules.createEnvironmentModule, '', false);
            } else {
                pageNavigationHelper.navigateToPage(context, constants.navModules.createQuickEnvironmentModule, '', false);
            }
        };

        self.beforeEnvContextOpen = function (event, ui)
        {
            var target = event.detail.originalEvent.target;
            var context = document.getElementById("listview").getContextByNode(target);
            if (context !== null)
            {
                console.log("Triggering context menu for " + context["key"]);
            }
        };

        //19c upgrade
        self.envActionMenuHandler = function (event, ui) {
            //always get currentMenuEnvName as this is the envName for the
            //last opened menu. 
            //Note: selectedListItem is not reliable, as user can open the 
            //menu without selecting listview item.
            rootViewModel.isDetailPG(false);
            var localEnvName = self.currentMenuEnvName();
            if (!localEnvName)
                localEnvName = self.selectedListItem()[0];
            envName = localEnvName ? localEnvName : envName;
            dbServiceType = envNameDbServiceTypeMap[envName];
            var ebsVersion = envNameEbsVersionMap[envName];
            console.dir("env actions " + event);
            var actionTriggered = event.srcElement.id;
            console.log('Env name --' + envName + ' Action Triggered --' + actionTriggered);
            if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.delete) {
                console.log('Triggering delete action..');
                self.confirmDeleteMsg(oj.Translations.getTranslatedString("confirmPopup.deleteAssertMsg", {envName: envName}));
                var popup = document.querySelector(constants.divTags.envListDelPopupTag);
                popup.open(event.target);
            } else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.clone) {
                console.log('Triggering clone action..');
                var context = ko.contextFor(document.getElementById(constants.divTags.envListPage));
                var envType = null;
                // Fetch current network name based on the selected environment
                $.each(self.environments(), function (index, value) {
                    if (value.name === envName) {
                        rootViewModel.currentNetworkName(value.networkProfile);
                        envType = value.environmentType;
                    }
                });
                if (envType === 'standby') {
                    rootViewModel.standByEnvironmentName(envName);
                    rootViewModel.showCloneWlsAdminPwd(ebsVersion === constants.ebsVersions.twelveone ? 'No' : 'Yes');
                    pageNavigationHelper.navigateToPage(context, constants.navModules.cloneStandByEnvironmentTrainModule, '', false);
                } else {
                    rootViewModel.cloneSourceEnv(envName);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.volumeCloneTrainModule, '', false);
                    rootViewModel.showCloneWlsAdminPwd(ebsVersion === constants.ebsVersions.twelveone ? 'No' : 'Yes');
                }
            } else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.backup) {
                var viewModelOfPopupModule = ko.dataFor(document.getElementById('backupPopupRoot'));
                viewModelOfPopupModule.handleBackupMenuClickEvent(envName, ebsVersion, event, ui, dbServiceType);
            } //19c upgrade POC
            else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.upgrade) {
                console.log('Triggering upgrade db action..');
                var upgradePopupModule = ko.dataFor(document.getElementById('upgradePopupRoot'));
                upgradePopupModule.handleDBUpgradeClick(self, envName, ebsVersion, event, ui);
            } else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.scheduleBackup) {
                var viewModelOfPopupModule = ko.dataFor(document.getElementById('backupPopupRoot'));
                viewModelOfPopupModule.handleScheduleBackupMenuClickEvent(envName, ebsVersion, event, ui, dbServiceType);
            } else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.releaseStandByEnvironment) {
                rootViewModel.standByEnvironmentName(envName);
                rootViewModel.showCloneWlsAdminPwd(ebsVersion === constants.ebsVersions.twelveone ? 'No' : 'Yes'); // using the same root variable name to determine if we need to show wls pwd field.
                var context = ko.contextFor(document.getElementById(constants.divTags.envListPage));
                pageNavigationHelper.navigateToPage(context, constants.navModules.releaseStandByEnvironmentTrainModule, '', false);
            }


        };

        self.selectionChanged = function (event, ui) {
            var currentEnvName = self.selectedListItem()[0];
            envName = currentEnvName ? currentEnvName : envName;
        };

        self.envs = ko.observable('-');
        self.summaryItems = ko.observableArray();
        self.totaldbCSServices = ko.observable('-');
        self.totalexaCSServices = ko.observable('-');
        self.totalcompInsts = ko.observable('-');
        self.totalAppInstsInCompute = ko.observable('-');
        self.totalOcpus = ko.observable();
        self.totalMemValue = ko.observable();
        self.totalMemUnits = ko.observable();
        self.totalStorageValue = ko.observable();
        self.totalStorageUnits = ko.observable();
        self.totalPublicIPs = ko.observable();
        self.totalSingleVMEnvironments = ko.observable();

        self.environments = ko.observableArray([]);
        self.networkProfileName = ko.observable('');

        self.loadData = function (compartmentIdentifier) {
            if (document.getElementById('filterEnvId') !== null)
            {
                document.getElementById('filterEnvId').value = '';
            }
            self.envListLoaded(false);
            self.environments.removeAll();
            actionsHelper.getInfraSummary(function (error, envSummary) {
                var envsValue = envSummary.noOfEBSEnvr;
                self.envsLabel(oj.Translations.getTranslatedString(envsValue === 1 ? 'labels.environment' : 'labels.environments'));
                var dbSystemInstsValue = envSummary.dbTier.noOfDatabaseInstancesInDBSystem;
                self.dbSystemInstsLabel(oj.Translations.getTranslatedString(dbSystemInstsValue === 1 ? 'labels.dbSystemDB' : 'labels.dbSystemDBs'));
                var exaSystemInstsValue = envSummary.dbTier.noOfDatabaseInstancesInExaSystem;
                self.exaSystemInstsLabel(oj.Translations.getTranslatedString(exaSystemInstsValue === 1 ? 'labels.exadataDbSystem' : 'labels.exadataDbSystems'));
                var dbComputeInstsValue = envSummary.dbTier.noOfDatabaseInstancesInCompute;
                self.dbComputeInstsLabel(oj.Translations.getTranslatedString(dbComputeInstsValue === 1 ? 'labels.dbOnCompute' : 'labels.dbsOnCompute'));
                var appsTierValue = envSummary.appTier.noOfAppsTierVMInstancesInCompute;
                self.appsTierSummaryLabel(oj.Translations.getTranslatedString(appsTierValue === 1 ? 'labels.appTierOnCompute' : 'labels.appTiersOnCompute'));
                self.envs(envSummary.noOfEBSEnvr);
                self.totaldbCSServices(envSummary.dbTier.noOfDatabaseInstancesInDBSystem);
                self.totalexaCSServices(envSummary.dbTier.noOfDatabaseInstancesInExaSystem);
                self.totalcompInsts(envSummary.dbTier.noOfDatabaseInstancesInCompute);
                self.totalAppInstsInCompute(envSummary.appTier.noOfAppsTierVMInstancesInCompute);
                var totalNumberofSingleVMEnvironments = envSummary.singlevm.noOfInstancesInCompute;
                self.totalSingleVMEnvironments(totalNumberofSingleVMEnvironments);
                self.totalSingleVMEnvironmentsLabel(oj.Translations.getTranslatedString('labels.singlevmenvironments'));
            });

            // Fetch image, title and alt based on provisioning status
            self.getProvisioningStatusBasedImage = function (env, envProvisioningStatus, envType) {
                if("standby" === envType)
                {
                   var lastActivity = env.lastActivityName;
                   switch (envProvisioningStatus) {
                      case 'Successful':
                          env.altImage = 'Successful';
                          env.titleImage = 'Standby Provisioning Successful';
                          env.envImage = "images/ebsIcon-standby-success.svg";
                          break;
                      case 'Failed':
                          env.altImage = 'Failed';
                          env.titleImage = 'Standby Provisioning Failed';
                          env.envImage = "images/ebsIcon-standby-failure.svg";
                          break;
                      case 'Input Validation In Progress':
                      case 'In Progress':
                          env.altImage = 'In Progress';
                          env.titleImage = 'Standby Provisioning In Progress';
                          env.envImage = "images/ebsIcon-standby-in-progress-2-of-3.svg";
                          if("create-ebs-vms" === lastActivity)
                            env.envImage = "images/ebsIcon-standby-in-progress-1-of-3.svg";
                          else if("validate-standby-network" === lastActivity)
                            env.envImage = "images/ebsIcon-standby-in-progress-2-of-3.svg";
                          else if("setup-standby" === lastActivity)
                            env.envImage = "images/ebsIcon-standby-in-progress-3-of-3.svg";
                          break;
                      case 'Pending Network Validation':
                          env.altImage = 'Pending Network Validation';
                          env.titleImage = 'Standby Provisioning In Progress';
                          env.envImage = "images/ebsIcon-standby-in-progress-2-of-3.svg";
                          break;
                      case 'Pending Setup':
                          env.altImage = 'Pending Setup';
                          env.titleImage = 'Standby Provisioning In Progress';
                          env.envImage = "images/ebsIcon-standby-in-progress-3-of-3.svg";
                          break;
                      case 'Input Validation In Progress':
                          env.altImage = 'In Progress';
                          env.titleImage = 'Standby Provisioning In Progress';
                          env.envImage = "images/ebsIcon-standby-in-progress-2-of-3.svg";
                          break;
                      case 'Aborted':
                          env.altImage = 'Aborted';
                          env.titleImage = 'Standby Provisioning Aborted';
                          env.envImage = "images/ebsIcon-standby-failure.svg";
                          break;
                      case 'Scheduled':
                          env.altImage = 'Scheduled';
                          env.titleImage = 'Standby Provisioning Scheduled';
                          env.envImage = "images/ebsIcon-standby-in-progress-2-of-3.svg";
                          if("create-ebs-vms" === lastActivity)
                            env.envImage = "images/ebsIcon-standby-in-progress-1-of-3.svg";
                          else if("validate-standby-network" === lastActivity)
                            env.envImage = "images/ebsIcon-standby-in-progress-2-of-3.svg";
                          else if("setup-standby" === lastActivity)
                            env.envImage = "images/ebsIcon-standby-in-progress-3-of-3.svg";
                          break;
                      case 'Paused':
                          env.altImage = 'Paused';
                          env.titleImage = 'Standby Environment Paused';
                          env.envImage = "images/ebsIcon-standby-paused.svg";
                          break;
                      default:
                          //If none of the above status, show below default image
                          env.altImage = 'Default';
                          env.titleImage = 'Standby Default';
                          env.envImage = 'images/ebsCloudIconBlue_72.svg';
                  }
                }
                else
                {
                    switch (envProvisioningStatus) {
                        case 'Successful':
                            env.altImage = 'Successful';
                            env.titleImage = 'Provisioning Successful';
                            env.envImage = "images/ebsIcon-success.svg";
                            break;
                        case 'Failed':
                            env.altImage = 'Failed';
                            env.titleImage = 'Provisioning Failed';
                            env.envImage = "images/ebsIcon-failure.svg";
                            break;
                        case 'In Progress':
                            env.altImage = 'In Progress';
                            env.titleImage = 'Provisioning In Progress';
                            env.envImage = "images/ebsIcon-in-progress.svg";
                            break;
                        case 'Input Validation In Progress':
                            env.altImage = 'In Progress';
                            env.titleImage = 'Provisioning In Progress';
                            env.envImage = "images/ebsIcon-in-progress.svg";
                            break;
                        case 'Aborted':
                            env.altImage = 'Aborted';
                            env.titleImage = 'Provisioning Aborted';
                            env.envImage = "images/ebsIcon-failure.svg";
                            break;
                        case 'Scheduled':
                            env.altImage = 'Scheduled';
                            env.titleImage = 'Provisioning Scheduled';
                            env.envImage = "images/ebsIcon-in-progress.svg";
                            break;
                        case 'Paused':
                            env.altImage = 'Paused';
                            env.titleImage = 'Environment Paused';
                            env.envImage = "images/ebsIcon-paused.svg";
                            break;
                        default:
                            //If none of the above status, show below default image
                            env.altImage = 'Default';
                            env.titleImage = 'Default';
                            env.envImage = 'images/ebsCloudIconBlue_72.svg';
                    }
                }
                return env;
            };

            //19c upgrade
            self.isDBUpgrade19cAllowed = function (environmentInfo)
            {
                var ebsVer = environmentInfo.ebsVersion;
                var dbVer = environmentInfo.dbVersion;
                var allow19cUpgrade = false;
                if (ebsVer && ebsVer.trim().startsWith("12.2") && dbVer && dbVer.trim().startsWith("12."))
                    allow19cUpgrade = true;

                return allow19cUpgrade;
            };

            /**
             * Environment details
             */


            actionsHelper.getEnvSummary(compartmentIdentifier, function (error, environments) {

                if (error !== null && error !== '')

                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        var msgOrigin = "Retrieving Environment Summary";
                        popupHelper.openErrorMsg(constants.divTags.envListConfPopupTag, messageContent, msgOrigin);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        var msgOrigin = "Retrieving Environment Summary";
                        popupHelper.openErrorMsg(constants.divTags.envListConfPopupTag, messageContent, msgOrigin);
                    }

                }

                $.each(environments, function () {
                    envNameDbServiceTypeMap[this.name] = this.dbTier.serviceType.value;
                    envNameEbsVersionMap[this.name] = this.ebsVersion;
                    var disableClone = true;

                    var disableBackup = true;
                    var name = this.name;
                    var serviceType = this.dbTier.serviceType.value;
                    if (serviceType === constants.dbTypes.computeds && this.provisioning.status === constants.provStatus.success) {
                        disableClone = false;
                    }

                    if (this.provisioning.status === constants.provStatus.success) {
                        var isProvisionedUsingSingleVM = this.deploymentType === constants.deploymentType.singleVM ? true : false;
                        if (!isProvisionedUsingSingleVM)
                            disableBackup = false;
                    }

                    var environment = {
                        id: this.name,
                        compartmentName: this.compartmentName,
                        networkProfile: this.networkProfile,
                        lastActivityName: this.lastActivity.name,
                        lastActivityStatus: this.lastActivity.status,
                        environmentType: this.type,
                        ebsVersion: this.ebsVersion,
                        dbVersion: this.dbVersion,
                        name: this.name,
                        databaseName: this.dbTier.databaseName,
                        dbServiceType: this.dbTier.serviceType.label,
                        dbServiceTypeValue: serviceType,
                        pdbName: this.dbTier.pdbName,
                        appNodes: this.appTier.noOfNodes,
                        createdOn: dateTimeHelper.convertToUTC(this.createdOn),
                        createdBy: this.createdBy,
                        jobId: this.lastActivity.jobId,
                        disableClone: disableClone,
                        disableBackup: disableBackup,
                        provisioningStatus: this.provisioning.status,
                        deploymentType: this.deploymentType,
                        isLastActivityCleanUp: false,
                        envActionMenuType: '1'   /* Defaulting to no actions */,
                        activityPerformedOnCloudMgrVersion1931AndAbove: false /* Defaulting to false */,
                        allowDBVersionUpgrade19c: false, //19c upgarde
                        allowedLCMActivities_env: this.allowedLCMActivities
                    };

                    var cloudMgrVersionAttr = this.lastActivity.cloudManagerVersion;
                    if (cloudMgrVersionAttr !== null && typeof (cloudMgrVersionAttr) !== 'undefined' && cloudMgrVersionAttr !== '' && cloudMgrVersionAttr !== null)
                    {
                        environment.activityPerformedOnCloudMgrVersion1931AndAbove = true;
                    }

                    //Set image
                    environment = self.getProvisioningStatusBasedImage(environment, environment.provisioningStatus, environment.environmentType);
                    environment.envActionMenuType = lcmUtils.getLcmActionsMenuTypeByLastActivity(environment);

                    //19c upgrade: check if upgrade to 19c is allowed
                    environment.allowDBVersionUpgrade19c = self.isDBUpgrade19cAllowed(environment);

                    if (environment.lastActivityName !== null && environment.lastActivityName === 'cleanup')
                    {
                        environment.isLastActivityCleanUp = true;
                    }
                    self.environments.push(environment);
                  //  self.envDataSource = new oj.ArrayTableDataSource(
                    self.envDataSource = new ArrayDataProvider(
                            self.environments,
                            {idAttribute: 'name'}
                    );
                    self.dataSource(self.envDataSource);
                });
                self.envListLoaded(true);
            });
        };

        var lastSelectedCompartment = sessionStorage.getItem('lastSelectedCompartmentId');
        if (lastSelectedCompartment !== null)
        {
            self.loadData(lastSelectedCompartment);
        } else
            self.loadData('All');






        self.flattenArrayDS = function (data) {
            var collection = new oj.Collection();
            for (var i = 0; i < data.length; i++) {
                collection.add(data[i]);
            }
            return collection;
        };

        self.nameFilter = function (model, attr, value) {
            var name = model.get('name');
            return (name.toLowerCase().indexOf(value.toLowerCase()) > -1);
        };

        // Check if the model is null or undefined
        // If valid return true
        self.checkIfModelIsValid = function (model, attr) {
            return model.get(attr) !== null && model.get(attr) !== undefined;
        };

        // Check if the entered value is present in model
        self.ifValuePresentInModel = function (model, attr, value) {
            return model.get(attr).toLowerCase().indexOf(value.toLowerCase()) > -1;
        };

        // Combine last activity name and last activity status and check if present
        self.combinedLastActivityNameStatus = function (model, value, attr1, attr2) {
            if (self.checkIfModelIsValid(model, attr1) && self.checkIfModelIsValid(model, attr2)) {
                var lastActivityNameStatus = model.get(attr1) + '(' + model.get(attr2) + ')';
                return lastActivityNameStatus.toLowerCase().indexOf(value.toLowerCase().split(' ').join('')) > -1;
            } else {
                return false;
            }
        }

        self.genericFilter = function (model, attr, value) {
            var name = self.checkIfModelIsValid(model, 'name') ? self.ifValuePresentInModel(model, 'name', value) : false;
            var networkName = self.checkIfModelIsValid(model, 'networkProfile') ? self.ifValuePresentInModel(model, 'networkProfile', value) : false;
            var ebsComp = self.checkIfModelIsValid(model, 'compartmentName') ? self.ifValuePresentInModel(model, 'compartmentName', value) : false;
            var dbType = self.checkIfModelIsValid(model, 'dbServiceType') ? self.ifValuePresentInModel(model, 'dbServiceType', value) : false;
            var dbName = self.checkIfModelIsValid(model, 'databaseName') ? self.ifValuePresentInModel(model, 'databaseName', value) : false;
            var dbVersion = self.checkIfModelIsValid(model, 'dbVersion') ? self.ifValuePresentInModel(model, 'dbVersion', value) : false;
            var pdbName = self.checkIfModelIsValid(model, 'pdbName') ? self.ifValuePresentInModel(model, 'pdbName', value) : false;
            var ebsVersion = self.checkIfModelIsValid(model, 'ebsVersion') ? self.ifValuePresentInModel(model, 'ebsVersion', value) : false;
            var createdOn = self.checkIfModelIsValid(model, 'createdOn') ? self.ifValuePresentInModel(model, 'createdOn', value) : false;
            var lastActivityName = self.checkIfModelIsValid(model, 'lastActivityName') ? self.ifValuePresentInModel(model, 'lastActivityName', value) : false;
            var lastActivityStatus = self.checkIfModelIsValid(model, 'lastActivityStatus') ? self.ifValuePresentInModel(model, 'lastActivityStatus', value) : false;
            var lastActivityNameStatus = self.combinedLastActivityNameStatus(model, value, 'lastActivityName', 'lastActivityStatus');

            return (name ||
                    networkName ||
                    ebsComp ||
                    dbType ||
                    dbName ||
                    dbVersion ||
                    ebsVersion ||
                    pdbName ||
                    createdOn ||
                    lastActivityName ||
                    lastActivityStatus ||
                    lastActivityNameStatus);
        };

        self.searchText = ko.observable('');
        self.handleSearchTextChange = function (event, ui)
        {
            event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleSearchCriteria(event, ui);
            }
        }

        self.handleSearchCriteria = function (event) {
            console.log('Handling Search');
            //var filter = event.detail.value;
            var filter = self.searchText();
            if (filter.length === 0) {
                console.log('Setting it to Env Data without filtering');
                self.dataSource(self.envDataSource);
            } else {

                self.collection = self.flattenArrayDS(self.environments());
                self.filteredCollection = self.collection.clone();
                self.filteredDataSource = new CollectionDataProvider(self.filteredCollection);

                for (var i = 0; i < self.collection.models.length; i++)
                {
                    console.log('Input Collection object @ ' + i + ' is ::' + self.collection.models[i].id);
                }
                var ret = self.collection.where({name: {value: filter, comparator: self.genericFilter}});

                for (var i = 0; i < ret.length; i++)
                {
                    console.log('Filterd Collection object @ ' + i + ' is ::' + ret[i].id);
                }
                self.filteredCollection.reset(ret);

                console.log('Updating with new data source ..');
                self.dataSource(self.filteredDataSource);

            }

        };


        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.envListDelPopupTag);
            popup.close();
        };


        self.startAnimationListener = function (event, ui)
        {
            popupHelper.startAnimationListener(constants.divTags.envListConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.envListConfPopupTag, data, event);
        };

        self.deleteEnv = function (event, ui) {
            var popup = document.querySelector(constants.divTags.envListDelPopupTag);
            popup.close();
            self.selectedListItem([]);
            var envType = null;
            $.each(self.environments(), function (index, value) {
                if (value.name === envName) {
                    envType = value.environmentType;
                }
            });
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteInfoMsg", {'envName': envName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.delEnvTitle");
            popupHelper.openInfoMsg(constants.divTags.envListConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.deleteEnv(envName, dbServiceType, function (error, success) {
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteConfirmMsg", {'envName': envName});
                    popupHelper.openSuccessMsg(constants.divTags.envListConfPopupTag, successMsg, msgOrigin);
                    self.loadData(rootViewModel.selectedCompartment());
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.envListConfPopupTag, response.message, msgOrigin);
                }
            }, envType);
        };

    }
    return environmentsListContentViewModel;
});
