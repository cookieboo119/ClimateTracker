/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * GetData - This class submits a getdata request by specifying
 * the instruments and fields for the request parameters.
 * This is followed by retrieve getdata request, to get the values for the fields.
 */
package com.bloomberg.datalic.dlws;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.BvalSnapshot;
import com.bloomberg.datalic.dlws.stubs.Fields;
import com.bloomberg.datalic.dlws.stubs.GetDataHeaders;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentData;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataResponse;

public class GetData {

    public void run(ProgramFlag programFlag) {
        PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

        // Setting headers
        GetDataHeaders headers = new GetDataHeaders();
        headers.setProgramflag(programFlag);
        headers.setPricing(Boolean.TRUE);
        headers.setClosingvalues(Boolean.TRUE);
        headers.setSecmaster(Boolean.TRUE);
        headers.setDerived(Boolean.TRUE);

        // Submit request and retrieve response
        RetrieveGetDataResponse rtvGetDataResp = submitAndRetrieve(ps, headers);

        // Display data
        if (rtvGetDataResp != null) {
            if (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve getdata request successful for responseId: "
                        + rtvGetDataResp.getResponseId());
                display(rtvGetDataResp);
            } else if (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }
        }
    }

    // Submit non-recurring getdata request and retrieve response
    public static RetrieveGetDataResponse submitAndRetrieve(PerSecurityWS ps, GetDataHeaders headers) {
        RetrieveGetDataResponse rtvGetDataResp = null;
        try {
            // Setting instruments
            Instrument ticker = new Instrument();
            ticker.setId("IBM US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.EQUITY);

            Instrument bbUniqueId = new Instrument();
            bbUniqueId.setId("EQ0000000002815382");
            bbUniqueId.setType(InstrumentType.BB_UNIQUE);

            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);
            instruments.getInstrument().add(bbUniqueId);

            // Setting fields
            Fields fields = new Fields();
            fields.getField().add("TICKER");
            fields.getField().add("PX_LAST");
            fields.getField().add("ID_BB_UNIQUE");
            fields.getField().add("PX_ASK");
            fields.getField().add("PX_BID");

            // Construct and submit getdata request
            System.out.println("Sending submit getdata request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetDataRequest(headers, null, fields, instruments, statusCode, requestId,
                    responseId);
            System.out.println("Submit getdata request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve getdata
            RetrieveGetDataRequest rtvGetDataReq = new RetrieveGetDataRequest();
            rtvGetDataReq.setResponseId(responseId.value);
            System.out.println("Sending retrieve getdata request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetDataResp = ps.retrieveGetDataResponse(rtvGetDataReq);
            } while (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return rtvGetDataResp;
    }

    // Submit a recurring getdata request and retrieve response
    public static RetrieveGetDataResponse submitRecurringGetDataRequest(PerSecurityWS ps) {
        // Setting headers
        GetDataHeaders headers = new GetDataHeaders();
        headers.setPricing(Boolean.TRUE);
        headers.setClosingvalues(Boolean.TRUE);
        headers.setSecmaster(Boolean.TRUE);
        headers.setDerived(Boolean.TRUE);
        headers.setProgramflag(ProgramFlag.fromValue("daily"));
        // Setting time and date for running the scheduled request
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat timeFormatter = new SimpleDateFormat("HHmm");
        Calendar runDate = Calendar.getInstance();
        Calendar runTime = (Calendar) runDate.clone();
        runTime.add(Calendar.HOUR_OF_DAY, -1);
        headers.setRundate(dateFormatter.format(runDate.getTime()));
        headers.setTime(timeFormatter.format(runTime.getTime()));

        return submitAndRetrieve(ps, headers);
    }

    // Submit a bvalsnapshot getdata request. Don't retrieve response as that
    // may not arrive until some time in the future (depending on the bval
    // snapshot selected).
    // Return responseId on success, null otherwise
    public static String submitBvalSnapshotGetDataRequest(PerSecurityWS ps, ProgramFlag programFlag) {
        // Setting headers
        GetDataHeaders headers = new GetDataHeaders();
        headers.setProgramflag(programFlag);
        headers.setSecmaster(Boolean.TRUE);
        headers.setDerived(Boolean.TRUE);
        headers.setBvaltier(Integer.valueOf(1));
        headers.setBvalsnapshot(BvalSnapshot.NY_3_PM);

        // Setting instruments
        Instrument instrument = new Instrument();
        instrument.setId("BBG0009P1SC8");
        instrument.setType(InstrumentType.BB_GLOBAL);
        Instruments instruments = new Instruments();
        instruments.getInstrument().add(instrument);

        // Setting fields
        Fields fields = new Fields();
        fields.getField().add("BVAL_BEEM");
        fields.getField().add("BVAL_SNAPSHOT");

        // Construct and submit getdata request
        System.out.println("Sending submit getdata request with bval snapshot header");
        Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
        Holder<String> requestId = new Holder<String>();
        Holder<String> responseId = new Holder<String>();
        ps.submitGetDataRequest(headers, null, fields, instruments, statusCode, requestId,
                responseId);

        if (statusCode.value.getCode() == PerSecurity.SUCCESS) {
            System.out.println("Submit getdata request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);
            return responseId.value;
        }

        System.out.println("Error in the submit getdata request.");
        return null;
    }

    // Display RetrieveGetDataResponse object
    public static void display(RetrieveGetDataResponse rtvGetDataResp) {
        for (InstrumentData instrumentData : rtvGetDataResp.getInstrumentDatas()
                .getInstrumentData()) {
            String yellowKey = "";
            if (instrumentData.getInstrument().getYellowkey() != null) {
                yellowKey = " " + instrumentData.getInstrument().getYellowkey().toString();
            }
            System.out.println("Data for " + instrumentData.getInstrument().getId() + yellowKey
                    + ":");
            for (int i = 0; i < instrumentData.getData().size(); i++) {
                System.out.println("  " + rtvGetDataResp.getFields().getField().get(i) + ": "
                        + instrumentData.getData().get(i).getValue());
            }
        }
    }

}
