/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * zone module changed.
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/utils/backupEnvironmentHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojconverter-number', 'ojs/ojvalidator-regexp', 'ojs/ojarraydataprovider', 'ebs/utils/lovUtils', 'ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojmenu',
    'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojarraydataprovider', 'ojs/ojselectcombobox', 'ojs/ojcheckboxset', 'ojs/ojtable', 'ojs/ojdatacollection-utils', 'ojs/ojvalidation-number', 'ojs/ojmessages', 'ojs/ojradioset'],
        function (oj, ko, actionsHelper, backupEnvironmentHelper, popupHelper, constants, NumberConverter, RegExpValidator, ArrayDataProvider, lovUtils) {
            /**
             * The view model for the main content view template
             */
            function zoneModuleViewModel() {
                var self = this;
                console.log('Loading Zone Module View Model');
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.parentViewModel = ko.dataFor(document.getElementById("topology-form-container"));
                self.baseTrain = ko.observable('');
                var trainElementViewModel = ko.dataFor(document.getElementById("train"));
                self.baseTrain(trainElementViewModel.myName());
                self.zoneName = ko.observable('');
                self.defaultedZoneName = ko.observable('');
                self.sequence = ko.observable('');
                self.type = ko.observable('');
                self.mode = ko.observable(''); //CREATE, EDIT, CLONE
                self.selectedZoneType = ko.observable('');
                var internalPlusExternalZones = new Array();
                var onlyInternalZone = [
                  { value: "Internal", label: "Internal" }
                ];
                var internalPlusExternalZones = [
                  { value: "Internal", label: "Internal" },
                  { value: "External", label: "External" }
                ];
                self.zoneTypeList = ko.observableArray(internalPlusExternalZones);
                self.zoneTypeDataProvider = new ArrayDataProvider(self.zoneTypeList, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.zoneTypeList(), self.selectedZoneType);
                self.portValidationCustomMsg = ko.observable();

                var ZoneModuleNameValidator = function ()
                {};
                oj.Object.createSubclass(ZoneModuleNameValidator, oj.Validator, "ZoneModuleNameValidator");
                self.zoneModuleNameValidator = [new ZoneModuleNameValidator()];
                var PortNumberValidator = function ()
                {};
                oj.Object.createSubclass(PortNumberValidator, oj.Validator, "PortNumberValidator");
                self.portNumberValidator = [new PortNumberValidator()];

                /* var HostNameValidator = function ()
                 {};
                 oj.Object.createSubclass(HostNameValidator, oj.Validator, "HostNameValidator");
                 self.zoneModuleHostNameValidator = [new HostNameValidator()]; */

                /*var DomainNameValidator = function ()
                 {};
                 oj.Object.createSubclass(DomainNameValidator, oj.Validator, "DomainNameValidator");
                 self.zoneModuleDomainNameValidator = [new DomainNameValidator()]; */

                self.isPrimaryInternalZone = ko.observable(false);
                self.isPrimaryExternalZone = ko.observable(false);
                self.isZoneTypeReadOnly = ko.observable(false);
                self.fileSystemModeReadOnly = ko.observable(false);
                self.zoneEditDone = ko.observable(false);
                self.allowExternalZoneCreation = ko.observable(true);
                self.protocolReadOnly = ko.observable(false);

                self.loadBalancerOptionEnabled = ko.observable(true);
                self.lbaasOptionValue = ko.observable('DEPLOY_NEW');
                self.defaultLbaasOptions = ko.observableArray([{'label': constants.webEntryTypeLookups.NewLBaaS, 'value': 'DEPLOY_NEW'}, {'label': constants.webEntryTypeLookups.UserLoadBalancer, 'value': 'USE_EXISTING'}, {'label': constants.webEntryTypeLookups.AppTierWebEntry, 'value': 'NO_LOAD_BALANCER'}]);          
                self.lbaasOptions = ko.observableArray([{'label': constants.webEntryTypeLookups.NewLBaaS, 'value': 'DEPLOY_NEW'}, {'label': constants.webEntryTypeLookups.UserLoadBalancer, 'value': 'USE_EXISTING'}, {'label': constants.webEntryTypeLookups.AppTierWebEntry, 'value': 'NO_LOAD_BALANCER'}]);          
                self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});

                self.lbaasSelectedOptionLabel = ko.observable('');
                var loading = oj.Translations.getTranslatedString('info.loading');
                self.lbShapes = ko.observableArray([{'label': loading, 'value': ''}]);
                self.lbShapesDataProvider = new ArrayDataProvider(self.lbShapes, {idAttribute: 'value'});
                self.lbaasShape = ko.observable('');
                lovUtils.lovOptionsUpdated(self.lbShapes(), self.lbaasShape);
                self.webEntryProtocolInputValue = ko.observable();
                self.webEntryProtocols = ko.observableArray([
                    {
                        label: oj.Translations.getTranslatedString('webentryProtocol.http'),
                        value: constants.webentryProtocol.http
                    },
                    {
                        label: oj.Translations.getTranslatedString('webentryProtocol.https'),
                        value: constants.webentryProtocol.https
                    }]);
                self.webEntryProtocolsDataProvider = new ArrayDataProvider(self.webEntryProtocols, {idAttribute: 'value'});
                if (!self.parentViewModel.isCloneEnvFlow()) //clone flow protocol will be populated based on source env
                    lovUtils.lovOptionsUpdated(self.webEntryProtocols(), self.webEntryProtocolInputValue);
                self.webEntryHostname = ko.observable('');
                self.webEntryDomain = ko.observable('');
                self.webEntryPort = ko.observable(constants.webentryProtocol.port);

                //logical hostname and domain
                self.logicalHostOptionSelection = ko.observable('auto');
                self.appsLogicalHostPrefixValue = ko.observable('');
                self.appsLogicalDomainValue = ko.observable('');
                self.isLogicalHostPrefix = ko.computed(function () {
                    return self.logicalHostOptionSelection() === 'auto';
                });
                self.logicalHostNameValidationMsg = ko.observableArray([]);
                self.logicalHostNamePrefixValidationMsg = ko.observableArray([]);
                self.logicalDomainNameValidationMsg = ko.observableArray([]);

                /* var LogicalHostNameValidator = function ()
                 {};
                 oj.Object.createSubclass(LogicalHostNameValidator, oj.Validator, "LogicalHostNameValidator");
                 self.logicalHostNameValidator = [new LogicalHostNameValidator()];  */

                var bypassHostnameValidation = rootViewModel.properties.has("hostname_validation_enabled") ?
                        (rootViewModel.properties.get("hostname_validation_enabled") === false) : false;

                var LogicalHostDuplicateValidator = function ()
                {};
                oj.Object.createSubclass(LogicalHostDuplicateValidator, oj.Validator, "LogicalHostDuplicateValidator");

                var LogicalHostPrefixDuplicateValidator = function ()
                {};
                oj.Object.createSubclass(LogicalHostPrefixDuplicateValidator, oj.Validator, "LogicalHostPrefixDuplicateValidator");

                var LogicalHostNamePrefixValidator = function ()
                {};
                oj.Object.createSubclass(LogicalHostNamePrefixValidator, oj.Validator, "LogicalHostNamePrefixValidator");
                //self.logicalHostNamePrefixValidator = [new LogicalHostNamePrefixValidator()];

                self.handleLogicalHostNameInputChange = function (value)
                {
                    console.log(value);
                }

                self.setAppsLogicalDomainForAllZones = function (value)
                {
                    var zones = self.parentViewModel.zones();
                    var total = self.parentViewModel.sequence();
                    if (total > 1)
                    {
                        for (var k = 1 + 1; k <= total; k++)
                        {
                            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                            if (detailChildElemRoot !== null)
                            {
                                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                if (detailModuleElemViewModel !== null)
                                {
                                    detailModuleElemViewModel.appsLogicalDomainValue(value);
                                }
                            }
                        }
                    }
                };

                self.setAppsLogicalHostForAllAppNodes = function (value)
                {
                    console.log("zoneModule setAppsLogicalHostForAllAppNodes invoked");
                    var appNodesInCurrentViewModel = self.nodesObservableArray();
                    if (self.logicalHostOptionSelection() === 'auto')
                    {
                        var nodeCnt = 0;
                        var prefixValue = value ? value.toLowerCase() : self.appsLogicalHostPrefixValue();
                        var currSequence = self.sequence();

                        if (currSequence > 1)
                        {
                            //current zone is not primary zone, then it must be user
                            //is adding/deleting node in none primary zone
                            //find out the previous zones node count
                            for (var k = 1; k < currSequence; k++)
                            {
                                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                                if (detailChildElemRoot !== null)
                                {
                                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                    if (detailModuleElemViewModel !== null)
                                    {
                                        nodeCnt += detailModuleElemViewModel.nodesObservableArray().length;
                                    }
                                }
                            }
                        }
                        //first set for current zone
                        if (appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                        {
                            for (var j = 0; j < appNodesInCurrentViewModel.length; j++)
                            {
                                var appNodeData = appNodesInCurrentViewModel[j];
                                if (!prefixValue || prefixValue === '')
                                    appNodeData.logicalHostname('');
                                else
                                {
                                    console.log("setAppsLogicalHostForAllAppNodes: NodeId: " + appNodeData.NodeId + "; set hostname:" + prefixValue + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                    appNodeData.logicalHostname(prefixValue.toLowerCase() + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                }
                                nodeCnt++;
                            }
                        }
                        //second set for all subsequent zones
                        //var total = zones.length;
                        var total = self.parentViewModel.sequence();
                        if (total > currSequence)
                        {
                            console.log("zone count=" + total);
                            for (var k = currSequence + 1; k <= total; k++)
                            {
                                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                                if (detailChildElemRoot !== null)
                                {
                                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                    if (detailModuleElemViewModel !== null)
                                    {
                                        detailModuleElemViewModel.logicalHostOptionSelection('auto');
                                        detailModuleElemViewModel.appsLogicalHostPrefixValue(prefixValue ? prefixValue.toLowerCase() : prefixValue);
                                        // App Nodes
                                        var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                                        var appNodeArray = detailModuleElemViewModel.nodesObservableArray();
                                        for (var j = 0; j < appNodeCount; j++)
                                        {
                                            var appNodeData = appNodeArray[j];
                                            if (!prefixValue || prefixValue === '')
                                                appNodeData.logicalHostname('');
                                            else
                                            {
                                                console.log("setAppsLogicalHostForAllAppNodes: NodeId:" + appNodeData.NodeId + "; set hostname:" + prefixValue + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                                appNodeData.logicalHostname(prefixValue.toLowerCase() + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                            }
                                            nodeCnt++;
                                        }
                                    }
                                }
                            }
                        }
                    }

                };

                self.selectedLogicalHostOptionValueBeforeConfirm = ko.observable();
                self.prevSelectedLogicalHostOptionValue = ko.observable();
                self.logicalHostOptionResetValue = ko.observable(false);

                self.handleLogicalhostOptionChange = function (event, ui)
                {
                    if (self.logicalHostOptionResetValue())
                    {
                        self.logicalHostOptionResetValue(false);
                        return;
                    }
                    self.selectedLogicalHostOptionValueBeforeConfirm('');
                    self.prevSelectedLogicalHostOptionValue('');
                    var selectedOptionValue = event['detail'].value;
                    var prevValue = event['detail'].previousValue;
                    var zones = self.parentViewModel.zones();
                    var sequence = self.parentViewModel.sequence();
                    if (sequence <= 1)
                    {
                        self.handleLogicalhostOptionChangeConfirm(selectedOptionValue);
                        return;
                    } else
                    {
                        self.selectedLogicalHostOptionValueBeforeConfirm(selectedOptionValue);
                        self.prevSelectedLogicalHostOptionValue(prevValue);
                        self.parentViewModel.openConfirmationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.logicalHostOptionAppliedAcrossWarning'),
                                self.handleLogicalhostOptionChangeConfirm,
                                self.handleLogicalhostOptionChangeCancel);
                    }
                    event.stopPropagation();
                };

                self.handleLogicalhostOptionChangeCancel = function ()
                {
                    self.logicalHostOptionResetValue(true);
                    self.logicalHostOptionSelection(self.prevSelectedLogicalHostOptionValue());
                };

                self.handleLogicalhostOptionChangeConfirm = function (value)
                {
                    var appNodesInCurrentViewModel = self.nodesObservableArray();
                    if (!value)
                    {
                        value = self.selectedLogicalHostOptionValueBeforeConfirm();
                    }

                    if (value === 'auto') //auto mode
                    {
                        var nodeCnt = 0;
                        var prefixValue = '';
                        //first set for current zone
                        if (appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                        {
                            for (var j = 0; j < appNodesInCurrentViewModel.length; j++)
                            {
                                var appNodeData = appNodesInCurrentViewModel[j];
                                prefixValue = self.appsLogicalHostPrefixValue();
                                if (!prefixValue || prefixValue === '')
                                    appNodeData.logicalHostname('');
                                else
                                {
                                    console.log("handleLogicalhostOptionChange: set hostname: NodeId: " + appNodeData.NodeId + "; prefixValue " + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                    appNodeData.logicalHostname(prefixValue.toLowerCase() + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                }
                                nodeCnt++;
                            }
                        }

                        //second set for all rest zones
                        var zones = self.parentViewModel.zones();
                        var sequence = self.parentViewModel.sequence();
                        if (sequence > 1)
                        {
                            console.log("zone count=" + sequence);
                            for (var k = 2; k <= sequence + 1; k++)
                            {
                                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                                if (detailChildElemRoot !== null)
                                {
                                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                    if (detailModuleElemViewModel !== null)
                                    {
                                        detailModuleElemViewModel.logicalHostOptionSelection('auto');
                                        detailModuleElemViewModel.appsLogicalHostPrefixValue(prefixValue ? prefixValue.toLowerCase() : prefixValue);
                                        // App Nodes
                                        var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                                        var appNodeArray = detailModuleElemViewModel.nodesObservableArray();
                                        for (var j = 0; j < appNodeCount; j++)
                                        {
                                            var appNodeData = appNodeArray[j];
                                            if (!prefixValue || prefixValue === '')
                                                appNodeData.logicalHostname('');
                                            else
                                            {
                                                console.log("handleLogicalhostOptionChange: set hostname: NodeId: " + appNodeData.NodeId + "; prefixValue " + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                                appNodeData.logicalHostname(prefixValue.toLowerCase() + (nodeCnt + 1 < 10 ? "0" + (nodeCnt + 1) : nodeCnt + 1));
                                            }
                                            nodeCnt++;
                                        }
                                    }
                                }
                            }
                        }
                    } else // manual mode
                    {
                        if (appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                        {
                            for (var j = 0; j < appNodesInCurrentViewModel.length; j++)
                            {
                                var appNodeData = appNodesInCurrentViewModel[j];
                                //Need to run the scenario to see whether it's better to clear the 
                                //existing value or not - for now, do not clear
                                // appNodeData.logicalHostname('');
                            }
                        }
                    }
                }

                self.handleLogicalHostPrefixChangeEvent = function (event, ui)
                {
                    var newValue = event['detail'].value;
                    if (newValue)
                        newValue = newValue.toLowerCase();
                    self.appsLogicalHostPrefixValue(newValue);
                    //trigger duplicate validation on app nodes logical host
                    if (self.validatelogicalHostInAllZones(newValue))
                        self.setAppsLogicalHostForAllAppNodes(newValue);
                    event.stopPropagation();

                };

                self.validatelogicalHostInAllZones = function (newValue)
                {
                    if (!newValue || self.logicalHostOptionSelection() !== 'auto')
                        return true;
                    var domain = self.appsLogicalDomainValue();
                    var dbPrefix = self.parentViewModel.getDBTierLogicalHostPrefix();
                    var total = self.parentViewModel.sequence();
                    if (total === 0)
                        total = 1; //this could be due to the first time provisioning
                    var totalNodeCnt = 0;
                    for (var k = 1; k <= total; k++)
                    {
                        var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                        if (detailChildElemRoot !== null)
                        {
                            var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                            if (detailModuleElemViewModel !== null)
                            {
                                // App Nodes
                                var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                                var appNodeArray = detailModuleElemViewModel.nodesObservableArray();
                                for (var j = 0; j < appNodeCount; j++)
                                {
                                    var nodeValue = newValue.toLowerCase() + ((totalNodeCnt + 1 < 10) ? "0" + (totalNodeCnt + 1) : totalNodeCnt + 1);
                                    if (nodeValue === dbPrefix.toLowerCase())
                                    {
                                        var errorMessages = new Array();
                                        var errorMsg = oj.Translations.getTranslatedString('validationMsgs.logicalHostAppPrefixCauseDuplicateMsg');
                                        var validationCustomMsg = {summary: errorMsg,
                                            detail: errorMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        errorMessages.push(validationCustomMsg);
                                        self.logicalHostNamePrefixValidationMsg(errorMessages);
                                        //throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostAppPrefixCauseDuplicateMsg')); 
                                        return false;
                                    }

                                    //verify if logical hostname contains the logical domain, if so we need to throw error
                                    if (domain && domain !== "")
                                    {
                                        if (nodeValue.indexOf(domain.toLowerCase()) > -1)
                                        {
                                            var errorMessages = new Array();
                                            var errorMsg = oj.Translations.getTranslatedString('validationMsgs.logicalHostNameNotContainDomainMsg');
                                            var validationCustomMsg = {summary: errorMsg,
                                                detail: errorMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                            errorMessages.push(validationCustomMsg);
                                            self.logicalHostNamePrefixValidationMsg(errorMessages);
                                            return false;

                                        }
                                    }

                                    totalNodeCnt++;

                                }
                            }
                        }
                    }
                    //no error, then reset the custom error msg
                    self.logicalHostNamePrefixValidationMsg([]);
                    self.logicalDomainNameValidationMsg([]);
                    
                    return true;
                };

                self.validatelogicalDomainInAllZones = function (newValue)
                {
                    if (!newValue || newValue === "")
                        return true;
                    var total = self.parentViewModel.sequence();
                    if (total === 0)
                        total = 1; //this could be due to the first time provisioning
                    for (var k = 1; k <= total; k++)
                    {
                        var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                        if (detailChildElemRoot !== null)
                        {
                            var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                            if (detailModuleElemViewModel !== null)
                            {
                                // App Nodes
                                var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                                var appNodeArray = detailModuleElemViewModel.nodesObservableArray();
                                for (var j = 0; j < appNodeCount; j++)
                                {
                                    var appNodeData = appNodeArray[j];
                                    var hostName = appNodeData.logicalHostname();
                                    if (hostName && (hostName.toLowerCase()).indexOf(newValue.toLowerCase()) > -1)
                                    {
                                        var errorMessages = new Array();
                                        var errorMsg = oj.Translations.getTranslatedString('validationMsgs.logicalHostNameNotContainDomainMsg');
                                        var validationCustomMsg = {summary: errorMsg,
                                            detail: errorMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        errorMessages.push(validationCustomMsg);
                                        self.logicalDomainNameValidationMsg(errorMessages);
                                        return false;
                                    }
                                }
                            }
                        } 
                    }
                    //no error, then reset the custom validation msg
                    self.logicalHostNamePrefixValidationMsg([]);
                    self.logicalDomainNameValidationMsg([]);
                    return true;
                };

                self.handleLogicalDomainChangeEvent = function (event, ui)
                {
                    var newValue = event['detail'].value;
                    if (newValue)
                        newValue = newValue.toLowerCase();
                    self.appsLogicalDomainValue(newValue);
                    if (self.validatelogicalDomainInAllZones(newValue))
                        self.setAppsLogicalDomainForAllZones(newValue);
                    event.stopPropagation();
                };

                self.appTierShapesList = ko.observableArray();
                self.appTierShapesDataProvider = new ArrayDataProvider(self.appTierShapesList, {idAttribute: 'value'});
                self.appNodesDataProvider = null;
                self.columnArray = [{"headerText": "Logical Hostname",
                        "field": "logicalHostname",
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                        "template": "logicalHostTemplate"},
                    {"headerText": "Logical FQDN",
                        "field": "logicalFQDN",
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                        "template": "logicalFQDNemplate"},
                    {"headerText": "Shape",
                        "field": "Shape",
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                        "template": "ShapeTemplate"},
                    {"headerText": "Block Volume Storage (GB)",
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                        "field": "Storage",
                        "template": "StorageTemplate"},
                    {"headerText": "Fault Domain",
                        "field": "FaultDomain",
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                        "template": "FaultDomainTemplate"},
                    {"headerText": "Delete",
                        "field": "DeleteNode",
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                        "template": "DeleteNodeTemplate"}];
                self.faultDomainsList = ko.observableArray();
                self.faultDomainsDataProvider = new ArrayDataProvider(self.faultDomainsList, {idAttribute: 'value'});
                self.appNodeSequence = ko.observable(1);
                self.fileSystemModes = ko.observableArray([{'label': 'Non-Shared', 'value': 'nonsfs'}, {'label': 'Shared', 'value': 'sfs'}]);
                self.fileSystemModesDataProvider = new ArrayDataProvider(self.fileSystemModes, {idAttribute: 'value'});
                self.disableFileSystemMode = ko.observable(true);
                self.fileSystemModeSelected = ko.observable('');
                lovUtils.lovOptionsUpdated(self.fileSystemModes(), self.fileSystemModeSelected);
                self.timeOutForAppNodeTable = '';
                self.zoneNameInstructionMsg = ko.observable(oj.Translations.getTranslatedString('validationMsgs.zoneNameValidationMsg'));
                self.minimumStorageForRestore = ko.observable(0);
                self.hostNameValidationMsg = ko.observable();
                self.domainNameValidationMsg = ko.observable();

                self.initializeModuleFromGlobalVariables = function ()
                {
                    console.log('Root View Model Data - ' + 'sequence : ' + rootViewModel.zoneSequence + ' loadBalancerEnabled: ' + rootViewModel.loadBalancerEnabled + ' load Balancer Option Value: ' + rootViewModel.loadBalancerOptionValue + ' Storage : ' + rootViewModel.storagePerNode);
                    self.zoneName('InternalZone' + rootViewModel.zoneSequence);

                    self.defaultedZoneName('InternalZone' + rootViewModel.zoneSequence);
                    self.sequence(rootViewModel.zoneSequence);
                    self.type('Internal');

                    self.loadBalancerOptionEnabled(rootViewModel.loadBalancerEnabled);
                    self.lbaasOptionValue(rootViewModel.loadBalancerOptionValue);
                    self.lbShapes(rootViewModel.loadBalancerShapesList);
                    self.lbShapesDataProvider = new ArrayDataProvider(self.lbShapes, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.lbShapes(), self.lbaasShape);
                    self.appTierShapesList(rootViewModel.appTierShapesList);
                    self.appTierShapesDataProvider = new ArrayDataProvider(self.appTierShapesList, {idAttribute: 'value'});
                    self.faultDomainsList(rootViewModel.faultDomains);
                    self.faultDomainsDataProvider = new ArrayDataProvider(self.faultDomainsList, {idAttribute: 'value'});
                    var rawValue = rootViewModel.storagePerNode ? rootViewModel.storagePerNode.substring(0, rootViewModel.storagePerNode.length - 3) : 0;
                    var nodes = [];
                    if (self.parentViewModel.isCreateEnvFlow())
                    {
                        self.mode("CREATE");
                        if (self.sequence() === 1)
                        {
                            var newNode = {NodeId: self.appNodeSequence(),
                                logicalHostname: ko.observable(''),
                                logicalFQDN: '',
                                Storage: ko.observable(parseInt(rawValue)),
                                Shape: ko.observable(''),
                                FaultDomain: ko.observable(self.faultDomainsList()[0].value),
                                DeleteNode: 'No',
                                FileSystemMode: ko.observable('nonsfs'),
                                FileSystemOptionsRendered: 'Yes',
                                IsPrimaryNode: true};
                            lovUtils.lovOptionsUpdated(self.appTierShapesList(), newNode.Shape);
                            newNode.logicalFQDN = ko.computed(function () {
                                return (newNode.logicalHostname() ? newNode.logicalHostname().toLowerCase() : newNode.logicalHostname()) + "." + (self.appsLogicalDomainValue() ? self.appsLogicalDomainValue().toLowerCase() : self.appsLogicalDomainValue());
                            });

                            if (self.baseTrain() === 'release-standby') {
                                var appNodeShape = trainElementViewModel.appTierShapeOfStandbyNode();
                                if (typeof (appNodeShape) !== 'undefined' && appNodeShape !== null && appNodeShape !== '') {
                                    newNode.Shape(appNodeShape);
                                }
                            }
                            nodes.push(newNode);

                        } else
                        {
                            self.mode("CLONE");
                            // From 2nd zone onwards for the first node storage should be set as per the first zone's storage type.
                            var zoneData = self.parentViewModel.zones();
                            var zoneInfo = zoneData[0];
                            var fileSystemTypeOfFirstZone = zoneInfo.fileSystemType();
                            var initialStorage = 0;
                            if (fileSystemTypeOfFirstZone === 'sfs') {
                                initialStorage = 0;
                            } else {
                                initialStorage = parseInt(rawValue);
                            }

                            var newNode = {NodeId: self.appNodeSequence(),
                                logicalHostname: ko.observable(''),
                                logicalFQDN: '',
                                Storage: ko.observable(initialStorage),
                                Shape: ko.observable(''),
                                FaultDomain: ko.observable(self.faultDomainsList()[0].value),
                                DeleteNode: 'Yes',
                                FileSystemMode: ko.observable('nonsfs'),
                                FileSystemOptionsRendered: 'Yes',
                                IsPrimaryNode: false};
                            lovUtils.lovOptionsUpdated(self.appTierShapesList(), newNode.Shape);
                            newNode.logicalFQDN = ko.computed(function () {
                                return (newNode.logicalHostname() ? newNode.logicalHostname().toLowerCase() : newNode.logicalHostname()) + "." + (self.appsLogicalDomainValue() ? self.appsLogicalDomainValue().toLowerCase() : self.appsLogicalDomainValue());
                            });
                            nodes.push(newNode);

                        }
                    } else //clone flow nodes are pre-populated
                    {
                        var curZoneName = self.parentViewModel.currentZoneName();
                        self.zoneName(self.parentViewModel.currentZoneName());
                        self.type(self.parentViewModel.currentZoneType());
                        self.selectedZoneType(self.parentViewModel.currentZoneType());
                        var appNodesData = self.parentViewModel.currentZoneAppNodes();
                        nodes = [];
                        for (var i = 0; i < appNodesData.length; i++)
                        {
                            var nodeData = appNodesData[i];
                            var newNode = {NodeId: i,
                                logicalHostname: ko.observable(nodeData.logicalHostname),
                                logicalFQDN: '',
                                Storage: ko.observable(nodeData.Storage),
                                Shape: ko.observable(nodeData.Shape),
                                OrigShape: nodeData.OrigShape,
                                FaultDomain: ko.observable(nodeData.FaultDomain),
                                DeleteNode: 'No',
                                FileSystemMode: ko.observable(nodeData.FileSystemMode),
                                FileSystemOptionsRendered: 'No'};

                            var logicalDomain = self.parentViewModel.parentContainerViewModel().appsLogicalDomainName();

                            if (!self.parentViewModel.parentContainerViewModel().appsLogicalHostConfigured())
                            {
                                newNode.logicalFQDN = constants.logicalHost.notAvailable;
                            } else if (!nodeData.logicalHostname || nodeData.logicalHostname === '' || !logicalDomain || logicalDomain === '')
                            {
                                newNode.logicalFQDN = constants.logicalHost.notAvailable;
                            } else
                            {
                                newNode.logicalFQDN = ko.computed(function () {
                                    return (nodeData.logicalHostname.toLowerCase() + "." + logicalDomain.toLowerCase());
                                });
                            }
                            nodes.push(newNode);

                        }

                        self.columnArray = [];
                        //if(self.parentViewModel.parentContainerViewModel().appsLogicalHostConfigured())
                        self.columnArray.push({"headerText": "Logical FQDN",
                            "field": "logicalFQDN",
                            "template": "logicalFQDNTemplate"});
                        self.columnArray.push({"headerText": "Shape",
                            "field": "Shape",
                            "template": "ShapeTemplate"});
                        self.columnArray.push({"headerText": "Storage",
                            "field": "Storage",
                            "template": "StorageTemplate"});
                        self.columnArray.push({"headerText": "Fault Domain",
                            "field": "FaultDomain",
                            "template": "FaultDomainTemplate"});
                    }



                    self.nodesObservableArray = ko.observableArray(nodes);
                    self.appNodesDataProvider = new ArrayDataProvider(self.nodesObservableArray, {idAttribute: 'NodeId'});

                    self.minimumStorageForRestore(parseInt(rawValue));

                    if (self.sequence() === 1) {
                        self.protocolReadOnly(false);
                    } else {
                        self.protocolReadOnly(true);
                        self.initializeProtocolFromFirstZoneData();
                        self.initializeLogicalHostInfo();
                        if (!self.parentViewModel.isCloneEnvFlow())
                            self.setAppsLogicalHostForAllAppNodes(self.appsLogicalHostPrefixValue());
                    }

                };

                self.initializeProtocolFromFirstZoneData = function () {
                    var zonesInfo = self.parentViewModel.zones();
                    if (zonesInfo.length < 1) {
                        return;
                    }
                    var zoneInfo = zonesInfo[0];
                    var protocolName = zoneInfo.protocol();
                    if ((!protocolName || protocolName === '') && self.parentViewModel.isCloneEnvFlow())
                    {
                        //for clone flow, if non-primary zone is accessed first
                        //then protocol is first defaultd to 'https'; later on
                        //when primary zone is accessed, the protocol will be set 
                        //accordingly
                        protocolName = constants.webentryProtocol.https;
                    }
                    self.webEntryProtocolInputValue(protocolName);
                    if (self.mode() === 'CREATE' || self.mode() === 'CLONE') {
                        // only when the new zone is created then we need to update the port based on protocol.
                        // If the user has already edited the port, then we should not be touching the port.
                        self.changeWebEntryPortBasedOnProtocol(protocolName);
                    }
                };

                self.initializeLogicalHostInfo = function () {
                    var zonesInfo = self.parentViewModel.zones();
                    if (zonesInfo.length < 1 || self.parentViewModel.isCloneEnvFlow()) {
                        return;
                    }
                    var zoneInfo = zonesInfo[0];
                    var option = zoneInfo.logicalHostOption();
                    var logicalDomain = zoneInfo.logicalDomain();
                    var logicalHostPrefix = zoneInfo.logicalHostnamePrefix();
                    self.appsLogicalDomainValue(logicalDomain);
                    self.appsLogicalHostPrefixValue(logicalHostPrefix ? logicalHostPrefix.toLowerCase() : logicalHostPrefix);
                    self.logicalHostOptionSelection(option);
                }

                self.isDefaultLoadBalancerTypeUsed = function (loadBalancerOptionSelected) {
                    for (var i = 0; i < self.defaultLbaasOptions().length; i++) {
                        var option = self.defaultLbaasOptions()[i];
                        var value = option.value;
                        if (value === loadBalancerOptionSelected) {
                            return true;
                        }
                    }
                    return false;
                };

                /**
                 *   Usecase : You could edit all non primary zones and then finally come to primary zone and change 
                 *   port number to one of the port numbers from the other reUsed zone. So validate primary zone when edit
                 *   is clicked on primary zone.
                 *   
                 */

                self.validatePrimaryInternalLBaasPort = function (value) {
                    var zonesInfo = self.parentViewModel.zones();
                    var portValidationMsg = oj.Translations.getTranslatedString('validationMsgs.portNumberInUse', {portNum: value});
                    if (zonesInfo.length <= 1) {
                        return true;
                    }
                    for (var k = 0; k < zonesInfo.length; k++) {
                        var zoneInfo = zonesInfo[k];
                        var zoneType = zoneInfo.type();
                        var zoneLBaaSValue = zoneInfo.lbaasOptionValue();
                        if (zoneType === 'Internal' && !self.isDefaultLoadBalancerTypeUsed(zoneLBaaSValue)) {
                            var port = zoneInfo.port();
                            if (port === value) {
                                throw new Error(portValidationMsg);
                            }
                        }
                    }
                };

                /**
                 *   Usecase : You could edit all non primary zones and then finally come to primary zone and change 
                 *   port number to one of the port numbers from the other reUsed zone. So validate primary zone when edit
                 *   is clicked on primary zone.
                 *   
                 */

                self.validatePrimaryExternalLBaasPort = function (value) {
                    var zonesInfo = self.parentViewModel.zones();
                    var portValidationMsg = oj.Translations.getTranslatedString('validationMsgs.portNumberInUse', {portNum: value});
                    if (zonesInfo.length <= 1) {
                        return true;
                    }
                    for (var k = 0; k < zonesInfo.length; k++) {
                        var zoneInfo = zonesInfo[k];
                        var zoneType = zoneInfo.type();
                        var zoneLBaaSValue = zoneInfo.lbaasOptionValue();
                        if (zoneType === 'External' && !self.isDefaultLoadBalancerTypeUsed(zoneLBaaSValue)) {
                            var port = zoneInfo.port();
                            if (port === value) {
                                throw new Error(portValidationMsg);
                            }
                        }
                    }
                };

                PortNumberValidator.prototype.validate = function (value) {
                    var lbaasOptionValue = self.lbaasOptionValue();
                    var portValidationMsg = oj.Translations.getTranslatedString('validationMsgs.portNumberInUse', {portNum: value});
                    if (lbaasOptionValue === null || lbaasOptionValue === '') {
                        return true;
                    }
                    if (self.isPrimaryInternalZone()) {
                        return self.validatePrimaryInternalLBaasPort(value);
                    } else if (self.isPrimaryExternalZone()) {
                        return self.validatePrimaryExternalLBaasPort(value);
                    }

                    var isDefaultLbOption = self.isDefaultLoadBalancerTypeUsed(lbaasOptionValue);
                    if (isDefaultLbOption) {
                        return true;
                    }
                    if (self.selectedZoneType() === 'Internal') {
                        var zoneData = self.parentViewModel.zones();
                        for (var i = 0; i < zoneData.length; i++) {
                            var zoneInfo = zoneData[i];
                            var zoneType = zoneInfo.type();
                            var zoneLBaaSValue = zoneInfo.lbaasOptionValue();
                            if (zoneType === 'Internal') {
                                if (i === 0) { // This is primary internal zone. Dont check for type.
                                    var port = zoneInfo.port();
                                    if (port === value) {
                                        throw new Error(portValidationMsg);
                                    }
                                } else {
                                    if (self.mode() === 'EDIT' && self.sequence() === (i + 1)) { // In Edit mode, same node should be skipped.
                                        continue;
                                    }
                                    if (!self.isDefaultLoadBalancerTypeUsed(zoneLBaaSValue)) {
                                        var port = zoneInfo.port(); // Not a primary node, reused lbaas so check the port.
                                        if (port === value) {
                                            throw new Error(portValidationMsg);
                                        }
                                    }
                                }
                            }
                        }

                    } else {
                        var zoneData = self.parentViewModel.zones();
                        for (var i = 0; i < zoneData.length; i++) {
                            var zoneInfo = zoneData[i];
                            var zoneType = zoneInfo.type();
                            var zoneLBaaSValue = zoneInfo.lbaasOptionValue();
                            if (zoneType === 'External') {
                                if (i === (self.getPrimaryExternalZoneSequence() - 1)) { // This is primary external zone. Dont check for type.
                                    var port = zoneInfo.port();
                                    if (port === value) {
                                        throw new Error(portValidationMsg);
                                    }
                                } else {
                                    if (self.mode() === 'EDIT' && self.sequence() === (i + 1)) { // In Edit mode, same node should be skipped.
                                        continue;
                                    }
                                    if (!self.isDefaultLoadBalancerTypeUsed(zoneLBaaSValue)) {
                                        var port = zoneInfo.port(); // Not a primary node, reused lbaas so check the port.
                                        if (port === value) {
                                            throw new Error(portValidationMsg);
                                        }
                                    }
                                }
                            }
                        }
                    }
                };

                /** This function will get the zone information from the parent view model based
                 *  on the sequence. This will account for the deleted zones in between and get the correct
                 *  zone object.
                 *  Parent View Model zone object's identifier === zoneSequence.
                 */
                self.getZoneInformationFromParentViewModel = function (zoneSequence) {
                    var zoneData = self.parentViewModel.zones();
                    for (var y = 0; y < zoneData.length; y++) {
                        var data = zoneData[y];
                        var identifier = data.identifier;
                        if (identifier === zoneSequence) {
                            return data;
                        }
                    }
                };

                ZoneModuleNameValidator.prototype.validate = function (value)
                {
                    var zoneData = self.parentViewModel.zones();
                    var uniqueZoneNameMsg = oj.Translations.getTranslatedString('validationMsgs.uniqueZoneNameMsg');
                    var zoneNameValidationMsg = oj.Translations.getTranslatedString('validationMsgs.zoneNameValidationMsg');
                    var regularExp = new RegExp("^([A-Za-z][a-zA-Z0-9]{0,14})$");
                    if (zoneData === null || zoneData.length < 1)
                    {
                        if (regularExp.test(value))
                        {
                            return true;
                        } else
                        {
                            throw new Error(zoneNameValidationMsg);
                        }
                    } else
                    {
                        var zoneSeq = self.sequence();
                        if (self.mode() === 'EDIT') {
                            var zoneInfo = self.getZoneInformationFromParentViewModel(zoneSeq);
                            if (zoneInfo !== null) {
                                var zoneNameInBasePG = zoneInfo.name();
                                if (zoneNameInBasePG === value) {
                                    return true; // While editing the zone , if the current zone name = zone name in the base page then it is not a duplicate name.
                                }
                            }
                        }
                        var errored = false;
                        for (var y = 0; y < zoneData.length; y++) {
                            //in clone flow do not check against self
                            if (self.parentViewModel.isCloneEnvFlow() && (zoneSeq - 1 === y))
                                continue;
                            var zoneInfo = zoneData[y];
                            var zoneName = zoneInfo.name();
                            var zoneNameInUpperCase = zoneName.toUpperCase();
                            var valueInUpperCase = value.toUpperCase();
                            if (zoneNameInUpperCase === valueInUpperCase) {
                                errored = true;
                                throw new Error(uniqueZoneNameMsg);
                            }
                        }
                        if (!errored) {
                            if (regularExp.test(value))
                            {
                                return true;
                            } else
                            {
                                throw new Error(zoneNameValidationMsg);
                            }
                        }
                    }

                    return true;
                };

                var zoneHostDomainOverallLengthValidator = function ()
                {};
                oj.Object.createSubclass(zoneHostDomainOverallLengthValidator, oj.Validator, "zoneHostDomainOverallLengthValidator");
                zoneHostDomainOverallLengthValidator.prototype.validate = function (value)
                {
                    if (!value || value === '')
                        return true;

                    if (value.indexOf(" ") >= 0)
                    {
                        var domainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameContainsWhiteSpaceMsg');
                        throw new Error(domainCustomMsg);
                    }

                    //not start or end with dot (.)
                    if (value.indexOf(".") === 0 || value.indexOf(".") === (value.length - 1))
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }

                    var segments = value.split(".");
                    for (var i = 0; i < segments.length; i++)
                    {
                        var segment = segments[i];
                        if (segment)
                        {
                            if (segment.length > 63)
                            {
                                var domainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentExceedsMaxLengthMsg');
                                throw new Error(domainCustomMsg);
                            }
                            if ((segment.indexOf("-") === 0) ||
                                    (segment.indexOf("-") === (segment.length - 1)))
                            {
                                var domainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentNotStartEndWithHyphenMsg');
                                throw new Error(domainCustomMsg);
                            }
                            //check for special charactors
                            var pattern = new RegExp('^(?:([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[A-Za-z0-9]))$');
                            if (!pattern.test(segment))
                            {
                                var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                                self.displayDomainNameError(logicalDomainCustomMsg);
                                return false;
                            }
                        }
                    }

                    var totalLength = value.length;
                    if (self.webEntryHostname())
                        totalLength += self.webEntryHostname.length;
                    if (totalLength > 255)
                    {
                        var domainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameExceedsMaxLengthMsg');
                        throw new Error(domainCustomMsg);
                    }

                    return true;
                };

                var logicalHostNameOverallLengthValidator = function ()
                {};
                oj.Object.createSubclass(logicalHostNameOverallLengthValidator, oj.Validator, "logicalHostNameOverallLengthValidator");
                logicalHostNameOverallLengthValidator.prototype.validate = function (value)
                {
                    if (self.isPrimaryInternalZone() || self.isLogicalHostPrefix())
                        return true;

                    if (!value || value === '')
                        return true;
                    var totalLength = value.length;
                    totalLength += self.appsLogicalDomainValue().length;
                    if (totalLength > 255)
                    {
                        var errorMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameExceedsMaxLengthMsg');
                        //throw new Error(logicalDomainCustomMsg);
                        self.displayHostnameError(errorMsg, value, true);
                        return false;
                    }

                };

                var logicalHostDomainOverallLengthValidator = function ()
                {};
                oj.Object.createSubclass(logicalHostDomainOverallLengthValidator, oj.Validator, "logicalHostDomainOverallLengthValidator");
                logicalHostDomainOverallLengthValidator.prototype.validate = function (value)
                {
                    if (!value || value === '')
                        return true;

                    if (value.indexOf(" ") >= 0)
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameContainsWhiteSpaceMsg');
                        //throw new Error(logicalDomainCustomMsg);
                        self.displayDomainNameError(logicalDomainCustomMsg);
                        return false;
                    }

                    //not start or end with dot (.)
                    if (value.indexOf(".") === 0 || value.indexOf(".") === (value.length - 1))
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }
                    
                    //max domain value length is 128
                    if(value.length > 128)
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameLengthValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }
                        
                    //last character of domain value cannot be number               
                    if(!isNaN(value.charAt(value.length -1)))
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameLastCharacterValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }
                    
                    var segments = value.split(".");
                    for (var i = 0; i < segments.length; i++)
                    {
                        var segment = segments[i];
                        if (segment)
                        {
                            if (segment.length > 63)
                            {
                                var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentExceedsMaxLengthMsg');
                                //throw new Error(logicalDomainCustomMsg);
                                self.displayDomainNameError(logicalDomainCustomMsg);
                                return false;
                            }
                            if ((segment.indexOf("-") === 0) ||
                                    (segment.indexOf("-") === (segment.length - 1)))
                            {
                                var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentNotStartEndWithHyphenMsg');
                                //throw new Error(logicalDomainCustomMsg);
                                self.displayDomainNameError(logicalDomainCustomMsg);
                                return false;
                            }

                            //check for special charactors
                            var pattern = new RegExp('^(?:([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[A-Za-z0-9]))$');
                            if (!pattern.test(segment))
                            {
                                var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                                self.displayDomainNameError(logicalDomainCustomMsg);
                                return false;
                            }

                        }
                    }

                    var totalLength = value.length;

                    if (self.isLogicalHostPrefix())
                    {
                        if (self.appsLogicalHostPrefixValue())
                            totalLength += self.appsLogicalHostPrefixValue().length;
                        if (totalLength > 253) //255 - 2(sequence characters)
                        {
                            var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameExceedsMaxLengthMsg');
                            //throw new Error(logicalDomainCustomMsg);
                            self.displayDomainNameError(logicalDomainCustomMsg);
                            return false;
                        }
                    } else
                    {
                        //have to go thru each of the appNodes' hostname
                        var appNodesInCurrentViewModel = self.nodesObservableArray();
                        if (appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                        {
                            for (var j = 0; j < appNodesInCurrentViewModel.length; j++)
                            {
                                totalLength = value.length;
                                var appNodeData = appNodesInCurrentViewModel[j];
                                var hostname = appNodeData.logicalHostname();
                                if (hostname)
                                    totalLength += hostname.length;
                                if (totalLength > 255)
                                {
                                    var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameExceedsMaxLengthMsg');
                                    //throw new Error(logicalDomainCustomMsg);
                                    self.displayDomainNameError(logicalDomainCustomMsg);
                                    return false;
                                }
                            }
                        }

                    }

                    return true;
                };

                LogicalHostPrefixDuplicateValidator.prototype.validate = function (value)
                {
                    //compare against DB tier logical host prefix
                    var dbPrefix = self.parentViewModel.getDBTierLogicalHostPrefix();
                    if (!value || value === '')
                        return true;

                    value = value.toLowerCase();
                    if (dbPrefix && dbPrefix !== '')
                    {
                        dbPrefix = dbPrefix.toLowerCase();
                        if (dbPrefix.indexOf("*") > 0)
                        {
                            //RAC scenario
                            dbPrefix = dbPrefix.replace("*", "");
                        }

                        if (value === dbPrefix)
                        {
                            throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostAppPrefixDuplicateMsg'));
                        }
                    }

                    return true;
                };

                self.addInlineMessage = function (messageSeverity, messageSummary, messageDetail)
                {
                    self.clearInlineMessage();
                    var newPageMessageObject = new Object();
                    newPageMessageObject.severity = messageSeverity;
                    newPageMessageObject.summary = messageSummary;
                    newPageMessageObject.detail = messageDetail;
                    newPageMessageObject.closeAffordance = "none";

                    var tempArray = self.inlineMessages();
                    tempArray.push(newPageMessageObject);
                    self.inlineMessages(tempArray);

                };

                self.clearInlineMessage = function ()
                {
                    self.inlineMessages([]);
                };

                self.inlineMessages = ko.observableArray([]);
                self.categoryOption = {category: 'none'};

                self.displayinlineMessage = ko.computed(function () {
                    if (self.inlineMessages().length > 0)
                        return true;
                    else
                        return false;
                });

                self.inlineMessagesDataprovider = new ArrayDataProvider(self.inlineMessages);

                self.displayHostnameError = function (errorMsg, value, displayErrorAsIs)
                {
                    if (self.logicalHostOptionSelection() === 'auto')
                    {
                        //read only field - need to display error under the hostname prefix
                        if (self.isPrimaryInternalZone())
                        {
                            if (!displayErrorAsIs)
                            {
                                errorMsg = oj.Translations.getTranslatedString('validationMsgs.logicalHostAppPrefixCauseDuplicateMsg');
                            }
                            var errorMessages = new Array();
                            var validationCustomMsg = {summary: errorMsg,
                                detail: errorMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};
                            errorMessages.push(validationCustomMsg);
                            self.logicalHostNamePrefixValidationMsg(errorMessages);
                        } else
                        {
                            if (!displayErrorAsIs)
                            {
                                errorMsg = oj.Translations.getTranslatedString('validationMsgs.logicalHostAppPrefixCauseNodeDuplicateMsg', {value: value});
                            }
                            self.addInlineMessage('error', 'Error', errorMsg);
                        }
                        throw new Error(errorMsg);
                    } else
                    {
                        //editable field
                        throw new Error(errorMsg);
                    }
                }

                self.displayDomainNameError = function (errorMsg)
                {
                    if (!self.isPrimaryInternalZone())
                    {
                        self.addInlineMessage('error', 'Error', errorMsg);
                    }
                    throw new Error(errorMsg);
                }


                LogicalHostDuplicateValidator.prototype.validate = function (value)
                {
                    //first, compare against DB tier logical host prefix
                    //depending on node count, derive the db node logical hostname
                    var dbPrefix = self.parentViewModel.getDBTierLogicalHostPrefix();
                    if (!value || value === '')
                        return true;

                    value = value.toLowerCase();
                    if (dbPrefix && dbPrefix !== '')
                    {
                        dbPrefix = dbPrefix.toLowerCase();
                        if (dbPrefix.indexOf("*") > 0)
                        {
                            //RAC scenario
                            var dbHost1 = dbPrefix.replace("*", "01");
                            var dbHost2 = dbPrefix.replace("*", "02");
                            if (value === dbHost1.toLowerCase() || value === dbHost2.toLowerCase())
                            {
                                self.displayHostnameError(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameDBTierDuplicateMsg'), value);
                                // throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameDBTierDuplicateMsg'));
                                return false;
                            }
                        } else
                        {  //single db node
                            if (value === dbPrefix.toLowerCase())
                            {
                                self.displayHostnameError(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameDBTierDuplicateMsg'), value);
                                //throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameDBTierDuplicateMsg'));
                                return false;
                            }
                        }
                    }

                    //Due to a rapid clone bug, logical hostname cannot be equal to or contain the logical domain name
                    //check if logical hostname contains logical domain
                    var domain = self.appsLogicalDomainValue();
                    if (domain && domain !== "")
                    {
                        if (value.indexOf(domain.toLowerCase()) > -1)
                        {
                            self.displayHostnameError(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameNotContainDomainMsg'), value, true);
                            return false;
                        }
                    }

                    //second, compare against current zone nodes' logical host
                    var appNodesInCurrentViewModel = self.nodesObservableArray();
                    var cnt = 0;
                    if (appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                    {
                        for (var i = 0; i < appNodesInCurrentViewModel.length; i++)
                        {
                            var appNodeData = appNodesInCurrentViewModel[i];
                            var appNodeLogicalHost = appNodeData.logicalHostname() ? appNodeData.logicalHostname().toLowerCase() : '';
                            if (value === appNodeLogicalHost)
                            {
                                cnt++;
                                if (cnt > 1)
                                {
                                    self.displayHostnameError(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'), value);
                                    //throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'));
                                    return false;
                                }
                            }
                        }
                    }


                    //third, compare against existing app tier node logical host
                    var currZoneSequence = self.sequence();
                    var totalZoneCount = self.parentViewModel.sequence();
                    if (totalZoneCount >= 1)
                    {
                        for (var i = 1; i < currZoneSequence; i++)
                        {
                            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + i);
                            if (detailChildElemRoot !== null)
                            {
                                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                if (detailModuleElemViewModel !== null)
                                {
                                    // App Nodes
                                    var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                                    var appNodeArray = detailModuleElemViewModel.nodesObservableArray();
                                    for (var j = 0; j < appNodeCount; j++)
                                    {
                                        var appNodeData = appNodeArray[j];
                                        var appNodeLogicalHost = appNodeData.logicalHostname() ? appNodeData.logicalHostname().toLowerCase() : '';
                                        if (value === appNodeLogicalHost)
                                        {
                                            self.displayHostnameError(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'), value);
                                            //throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'));
                                            return false;
                                        }
                                    }
                                }
                            }
                        }

                        var startSequence = currZoneSequence < totalZoneCount ? currZoneSequence + 1 : currZoneSequence;
                        for (var i = startSequence; i <= totalZoneCount; i++)
                        {
                            if (currZoneSequence === startSequence)
                                continue;
                            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + i);
                            if (detailChildElemRoot !== null)
                            {
                                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                if (detailModuleElemViewModel !== null)
                                {
                                    // App Nodes
                                    var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                                    var appNodeArray = detailModuleElemViewModel.nodesObservableArray();
                                    for (var j = 0; j < appNodeCount; j++)
                                    {
                                        var appNodeData = appNodeArray[j];
                                        var appNodeLogicalHost = appNodeData.logicalHostname() ? appNodeData.logicalHostname().toLowerCase() : '';
                                        if (value === appNodeLogicalHost)
                                        {
                                            self.displayHostnameError(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'), value);
                                            //throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'));
                                            return false;
                                        }
                                    }
                                }
                            }
                        }

                    }
                    return true;
                };

                self.logicalHostNamePrefixValidator = [
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^(?:([a-zA-Z]|[a-zA-Z][a-zA-Z0-9]{0,26}[A-Za-z0-9]))$',
                                hint: oj.Translations.getTranslatedString('validationMsgs.logicalHostPrefixValidationMsg'),
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.logicalHostPrefixValidationMsg')
                            })),
                    new LogicalHostPrefixDuplicateValidator()
                ];


                self.logicalHostNameValidator = [
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^(?:([a-zA-Z]|[a-zA-Z][a-zA-Z0-9]{0,28}[A-Za-z0-9]))$',
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.logicalHostNameValidationMsg')
                            })),
                    new LogicalHostDuplicateValidator(),
                    (bypassHostnameValidation ? '' : new logicalHostNameOverallLengthValidator())
                ];

                self.logicalDomainNameValidator = [
                    (bypassHostnameValidation ? '' : new logicalHostDomainOverallLengthValidator())
                ];

                self.zoneModuleDomainNameValidator = [
                    (bypassHostnameValidation ? '' : new zoneHostDomainOverallLengthValidator()),
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^((?!(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)).*$)',
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.hostDomainNameNonIPMsg'),
                                hint: oj.Translations.getTranslatedString('validationMsgs.hostDomainNameNonIPMsg')
                            }))
                ];

                self.zoneModuleHostNameValidator = [
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^(?:([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[A-Za-z0-9]))$',
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.hostNameValidationMsg'),
                                hint: oj.Translations.getTranslatedString('validationMsgs.hostNameValidationMsg')
                            }))
                ];


                self.addAppNode = function ()
                {
                    var nextNodeId = self.appNodeSequence() + 1;
                    self.appNodeSequence(nextNodeId);
                    var storage = 0;
                    if (self.fileSystemModeSelected() === 'sfs') {
                        storage = 0;
                    } else {
                        storage = self.minimumStorageForRestore();
                    }
                    var node = {IsPrimaryNode: false,
                        NodeId: nextNodeId,
                        logicalHostname: ko.observable(''),
                        logicalFQDN: '',
                        Storage: ko.observable(storage),
                        Shape: ko.observable(''),
                        FaultDomain: ko.observable(self.faultDomainsList()[0].value), DeleteNode: 'Yes', FileSystemMode: ko.observable('nonsfs'), FileSystemOptionsRendered: 'No'};
                    
                    lovUtils.lovOptionsUpdated(self.appTierShapesList(), node.Shape);
                    node.logicalFQDN = ko.computed(function () {
                        return (node.logicalHostname() ? node.logicalHostname().toLowerCase() : node.logicalHostname()) + "." + (self.appsLogicalDomainValue() ? self.appsLogicalDomainValue().toLowerCase() : self.appsLogicalDomainValue());
                    });

                    self.nodesObservableArray.push(node);
                    self.initializeFaultDomainForAllAppNodes();
                    self.setAppsLogicalHostForAllAppNodes(self.appsLogicalHostPrefixValue());

                };
                self.removeAppNode = function (event)
                {
                    var targetElem = event.target;
                    if (targetElem !== null && typeof (targetElem.id) !== 'undefined' && targetElem.id !== null)
                    {
                        var tokens = targetElem.id.split('_');
                        var index = tokens[1];
                        var rowIndex = self.getCorrectRowIndexFromSequence(parseInt(index));
                        self.nodesObservableArray.splice(rowIndex, 1);
                        self.initializeFaultDomainForAllAppNodes();
                        self.setAppsLogicalHostForAllAppNodes(self.appsLogicalHostPrefixValue());
                    }
                };
                self.getCorrectRowIndexFromSequence = function (sequence) {
                    for (var i = 0; i < self.nodesObservableArray().length; i++) {
                        var node = self.nodesObservableArray()[i];
                        var nodeSeq = node.NodeId;
                        if (nodeSeq === sequence) {
                            return i;
                        }
                    }
                    return -1;
                };

                self.initializeFaultDomainForAllAppNodes = function ()
                {
                    for (var y = 0; y < self.nodesObservableArray().length; y++)
                    {
                        var appNode = self.nodesObservableArray()[y];
                        appNode.FaultDomain(self.faultDomainsList()[y % self.faultDomainsList().length].value);
                    }
                };
                self.getPrimaryExternalZoneSequence = function ()
                {
                    var zoneData = self.parentViewModel.zones();
                    if (zoneData === null || zoneData.length < 2)
                    {
                        return -1;
                    } else
                    {
                        for (var i = 0; i < zoneData.length; i++)
                        {
                            var zoneInfo = zoneData[i];
                            var type = zoneInfo.type();
                            if (type === 'External')
                            {
                                return (i + 1);
                            }
                        }
                        return -1;
                    }
                };

                self.duplicateDefaultOptionsList = function () {
                    var newList = new Array();
                    for (var i = 0; i < self.defaultLbaasOptions().length; i++) {
                        newList.push(self.defaultLbaasOptions()[i]);
                    }
                    return newList;
                };


                self.updateLoadBalancerOptions = function (event, isFromInitModule)
                {
                    self.lbaasOptions([]);
                    self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                    var zoneType = null;
                    if (isFromInitModule)
                    {
                        zoneType = self.selectedZoneType();
                    } else
                    {
                        // From type change event handler.
                        zoneType = event['detail'].value;
                    }

                    if (zoneType === 'Internal')
                    {
                        if (self.isPrimaryInternalZone())
                        {
                            if (self.baseTrain() === 'clone' && self.nodesObservableArray().length > 1) {
                                var newList = self.duplicateDefaultOptionsList();
                                newList.pop();
                                self.lbaasOptions(newList);
                                self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                            } else {
                                self.lbaasOptions(self.defaultLbaasOptions());
                                self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                            }
                            lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                        } else
                        {
                            var defaultOptions = self.defaultLbaasOptions();
                            if (self.parentViewModel.zones().length === 0)
                            {
                                self.lbaasOptions(self.defaultLbaasOptions());
                                self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                                return;
                            }
                            var firstPrimaryInternalZoneObject = self.parentViewModel.zones()[0];
                            var lbaasOptionValueForInternalPrimaryZone = firstPrimaryInternalZoneObject.lbaasOptionValue();
                            if (lbaasOptionValueForInternalPrimaryZone === 'DEPLOY_NEW')
                            {
                                var additionalOption = new Object();
                                additionalOption.label = 'Reuse ' + firstPrimaryInternalZoneObject.name() + ' load balancer';
                                additionalOption.value = firstPrimaryInternalZoneObject.name();
                                var customOptions = new Array();
                                for (var j = 0; j < defaultOptions.length; j++)
                                {
                                    var value = defaultOptions[j].value;
                                    if (value === 'NO_LOAD_BALANCER') {
                                        continue;
                                    }
                                    customOptions.push(defaultOptions[j]);
                                }
                                customOptions.push(additionalOption);
                                self.lbaasOptions(customOptions);
                                self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                            } else
                            {
                                var newList = self.duplicateDefaultOptionsList();
                                newList.pop();
                                self.lbaasOptions(newList);
                                self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                            }
                        }
                    } else
                    {
                        if (self.isPrimaryExternalZone())
                        {
                            var newList = self.duplicateDefaultOptionsList();
                            newList.pop();
                            self.lbaasOptions(newList);
                            self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                        } else
                        {
                            var defaultOptions = self.defaultLbaasOptions();
                            var firstPrimaryExternalZoneObject = self.getPrimaryExternalZoneDataObject();
                            if (firstPrimaryExternalZoneObject === null)
                            {
                                console.log('Inconsistent data. Without primary external zone we are in an external zone looking for primary external zone.');
                                var newList = self.duplicateDefaultOptionsList();
                                newList.pop();
                                self.lbaasOptions(newList);
                                self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                            } else
                            {
                                var lbaasOptionValueForExternalPrimaryZone = firstPrimaryExternalZoneObject.lbaasOptionValue();
                                if (lbaasOptionValueForExternalPrimaryZone === 'DEPLOY_NEW')
                                {
                                    var additionalOption = new Object();
                                    additionalOption.label = 'Reuse ' + firstPrimaryExternalZoneObject.name() + ' load balancer';
                                    additionalOption.value = firstPrimaryExternalZoneObject.name();
                                    var customOptions = new Array();
                                    for (var j = 0; j < defaultOptions.length; j++)
                                    {
                                        var value = defaultOptions[j].value;
                                        if (value === 'NO_LOAD_BALANCER') {
                                            continue;
                                        }
                                        customOptions.push(defaultOptions[j]);
                                    }
                                    customOptions.push(additionalOption);
                                    self.lbaasOptions(customOptions);
                                    self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                                    lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                                } else
                                {
                                    var newList = self.duplicateDefaultOptionsList();
                                    newList.pop();
                                    self.lbaasOptions(newList);
                                    self.lbaasOptionsDataProvider = new ArrayDataProvider(self.lbaasOptions, {idAttribute: 'value'});
                                    lovUtils.lovOptionsUpdated(self.lbaasOptions(), self.lbaasOptionValue);
                                }
                            }
                        }
                    }

                };
                self.initializeExternalPrimaryZoneFlag = function (event)
                {
                    var value = event['detail'].value;
                    var externalPrimaryCompartmentSequence = self.getPrimaryExternalZoneSequence();
                    if (externalPrimaryCompartmentSequence === -1)
                    {
                        if (value === 'External')
                        {
                            self.isPrimaryExternalZone(true);
                        } else
                        {
                            self.isPrimaryExternalZone(false);
                        }
                    }

                };
                self.handleZoneTypeChangeEvent = function (event)
                {
                    if (self.parentViewModel.isCloneEnvFlow() || self.isZoneTypeReadOnly())
                        return;
                    var zoneTypeSelected = event['detail'].value;
                    var firstPrimaryExternalZoneSeq = self.getPrimaryExternalZoneSequence();

                    var defaultValueofZoneName = self.defaultedZoneName();
                    if (zoneTypeSelected === 'External' && defaultValueofZoneName === self.zoneName())
                    {
                        var existingName = self.zoneName();
                        var newName = existingName.replace('Internal', 'External');
                        self.zoneName(newName);
                        self.defaultedZoneName(newName);
                    }
                    if (zoneTypeSelected === 'Internal' && defaultValueofZoneName === self.zoneName())
                    {
                        var existingName = self.zoneName();
                        var newName = existingName.replace('External', 'Internal');
                        self.zoneName(newName);
                        self.defaultedZoneName(newName);
                    }

                    self.initializeExternalPrimaryZoneFlag(event);
                    self.updateLoadBalancerOptions(event, false);
                };
                self.getPrimaryExternalZoneDataObject = function ()
                {
                    var firstPrimaryExternalZoneSeq = self.getPrimaryExternalZoneSequence();
                    if (firstPrimaryExternalZoneSeq === -1)
                    {
                        console.log('Incosistent data. We still dont have primary external data object but we are requesting that information.');
                        return null;
                    } else
                    {
                        var zonesDO = self.parentViewModel.zones();
                        for (var i = 0; i < zonesDO.length; i++)
                        {
                            if ((i + 1) === firstPrimaryExternalZoneSeq)
                            {
                                return zonesDO[i];
                            }
                        }
                    }
                    return null;
                };
                self.handleFileSystemModeChangeEvent = function (event)
                {
                    if (self.parentViewModel.isCloneEnvFlow() || self.fileSystemModeReadOnly())
                        return;
                    var zoneData = self.parentViewModel.zones();
                    if (self.sequence() !== 1)
                    {
                        return;
                    }
                    var prevValue = event['detail'].previousValue;
                    var newValue = event['detail'].value;
                    if (zoneData === null || zoneData.length < 2)
                    {
                        self.initializeStorageForAllAppNodes(newValue);
                        return;
                    } else
                    {
                        self.parentViewModel.openConfirmationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.fileSystemShallBeAppliedAcrossWarning'),
                                function () {

                                    var currentSequenceNum = self.parentViewModel.sequence();
                                    for (var k = 1; k <= currentSequenceNum; k++)
                                    {
                                        var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                                        if (detailChildElemRoot !== null)
                                        {
                                            var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                            if (detailModuleElemViewModel !== null)
                                            {
                                                detailModuleElemViewModel.fileSystemModeSelected(newValue);
                                            }
                                        }
                                    }

                                    for (var i = 0; i < zoneData.length; i++)
                                    {
                                        zoneData[i].fileSystemType(newValue)
                                    }
                                    self.initializeStorageForAllAppNodes(newValue);

                                }, function () {
                            event.stopPropagation();
                            self.fileSystemModeSelected(prevValue);
                            return false;
                        });
                    }
                };

                self.initializeStorageForAllAppNodes = function (fileSystemModeSelected)
                {
                    if (self.parentViewModel.isCloneEnvFlow())
                        return;

                    // If we are using a shared file system, then for the primary node, local storage = requiredStorageValue + additionalStorageValue
                    // for all the other nodes, local storage = 0.
                    if (fileSystemModeSelected === 'sfs')
                    {
                        var storageForPrimaryNode = self.minimumStorageForRestore();
                        var storageForNonPrimaryNode = 0;

                        // Update the app nodes in the detail viewmodels added so far.
                        // This will not include the current zone if they are creating new.
                        var currentSequenceNum = self.parentViewModel.sequence();
                        for (var k = 1; k <= currentSequenceNum; k++)
                        {
                            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                            if (detailChildElemRoot !== null)
                            {
                                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                if (detailModuleElemViewModel !== null)
                                {
                                    var appNodesData = detailModuleElemViewModel.nodesObservableArray();
                                    if (appNodesData !== null && appNodesData.length > 0)
                                    {
                                        for (var j = 0; j < appNodesData.length; j++)
                                        {
                                            var appNodeData = appNodesData[j];
                                            if (k === 1 && j === 0) // Primary app node
                                            {
                                                appNodeData.Storage(storageForPrimaryNode);
                                            } else
                                            {
                                                appNodeData.Storage(storageForNonPrimaryNode);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Update the self object for newly created zone.
                        var appNodesInCurrentViewModel = self.nodesObservableArray();
                        if (appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                        {
                            for (var j = 0; j < appNodesInCurrentViewModel.length; j++)
                            {
                                var appNodeData = appNodesInCurrentViewModel[j];
                                if (self.sequence() === 1 && j === 0) // Primary app node
                                {
                                    appNodeData.Storage(storageForPrimaryNode);
                                } else
                                {
                                    appNodeData.Storage(storageForNonPrimaryNode);
                                }
                            }
                        }


                    }
                    // If we are using a non shared file system, then for all nodes, local storage = requiredStorageValue + additionalStorageValue
                    else if (fileSystemModeSelected === 'nonsfs')
                    {
                        var storageForAllNodes = self.minimumStorageForRestore();


                        // Update the app nodes in the detail viewmodels added so far.
                        // This will also include the current zone if they are creating new.
                        var currentSequenceNum = self.parentViewModel.sequence();
                        for (var k = 1; k <= currentSequenceNum; k++)
                        {
                            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                            if (detailChildElemRoot !== null)
                            {
                                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                if (detailModuleElemViewModel !== null)
                                {
                                    var appNodesData = detailModuleElemViewModel.nodesObservableArray();
                                    if (appNodesData !== null && appNodesData.length > 0)
                                    {
                                        for (var j = 0; j < appNodesData.length; j++)
                                        {
                                            var appNodeData = appNodesData[j];
                                            appNodeData.Storage(storageForAllNodes);
                                        }
                                    }
                                }
                            }
                        }

                        // Update the self object for newly created zone.
                        var appNodesInCurrentViewModel = self.nodesObservableArray();
                        if (appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                        {
                            for (var j = 0; j < appNodesInCurrentViewModel.length; j++)
                            {
                                var appNodeData = appNodesInCurrentViewModel[j];
                                appNodeData.Storage(storageForAllNodes);

                            }
                        }


                    }



                };

                self.openZoneDetailModule = function (event, mode)
                {
                    var module = document.getElementById('zoneModuleRoot_' + self.sequence());
                    if (module === null)
                    {
                        console.log('Error : Could not find the zone module element DOM for this sequence.');
                        return;
                    }
                    self.mode(mode);
                    if (self.sequence() === 1)
                    {
                        self.isPrimaryInternalZone(true);
                        self.isZoneTypeReadOnly(true);
                        self.selectedZoneType('Internal');
                        self.protocolReadOnly(false);
                    } else
                    {
                        self.isPrimaryInternalZone(false);
                        self.isZoneTypeReadOnly(false);
                        self.protocolReadOnly(true);
                        self.initializeProtocolFromFirstZoneData();
                        self.initializeLogicalHostInfo();
                    }
                    if (mode === "CLONE")
                    {
                        self.isZoneTypeReadOnly(true);
                        self.selectedZoneType(self.type());
                        self.fileSystemModeReadOnly(true);
                    }


                    if (mode === "CREATE" || mode === "EDIT")
                    {
                        var isExternalZoneAllowed = rootViewModel.isExternalZoneAllowed;
                        if (isExternalZoneAllowed !== null && isExternalZoneAllowed !== '' && !isExternalZoneAllowed)
                        {
                            self.zoneTypeList(onlyInternalZone);
                        } else
                        {
                            self.zoneTypeList(internalPlusExternalZones);
                        }
                        self.zoneTypeDataProvider = new ArrayDataProvider(self.zoneTypeList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.zoneTypeList(), self.selectedZoneType);
                    }

                    var primaryExternalZoneSequence = self.getPrimaryExternalZoneSequence();
                    if (primaryExternalZoneSequence !== -1)
                    {
                        if (self.sequence() === primaryExternalZoneSequence)
                        {
                            self.isPrimaryExternalZone(true);
                        }
                    } else
                    {
                        self.isPrimaryExternalZone(false);
                    }

                    self.updateLoadBalancerOptions(null, true);
                    if (self.isPrimaryInternalZone() && (mode !== "CLONE"))
                    {
                        self.fileSystemModeReadOnly(false);
                    } else
                    {
                        var zoneData = self.parentViewModel.zones();
                        if (mode === "CLONE")
                        {
                            if (zoneData !== null && zoneData.length > 0)
                            {
                                var fileSystemType = zoneData[self.sequence() - 1].fileSystemType();
                                self.fileSystemModeSelected(fileSystemType);
                            }
                        } else if (zoneData !== null && zoneData.length > 0)
                        {
                            var fileSystemType = zoneData[0].fileSystemType();
                            self.fileSystemModeSelected(fileSystemType);
                        }
                        self.fileSystemModeReadOnly(true);
                    }

                    module.style.display = '';
                    //Important: need the following code to notify JET of the zone 
                    //module displayed; without this the table would not render properly
                    oj.Components.subtreeShown(module);
                };


                self.backToListPage = function ()
                {

                    if (self.nodesObservableArray().length === 0)
                    {
                        self.parentViewModel.openConfirmationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.noAppNodesInThisZoneWarning'),
                                function () {

                                    self.closeZoneDetailModule();
                                    // Remove the zone from the base page.
                                    var basePopupHolderElemViewModel = ko.dataFor(document.getElementById('BasePageModuleHolder:' + self.sequence()));
                                    basePopupHolderElemViewModel.removeZoneFromDetailContainer(self.sequence());
                                }, function () {
                            return;
                        });
                    } else
                    {
                        if (self.validateZoneDetails())
                        {
                            self.closeZoneDetailModule();
                        } else
                        {
                            return;
                        }
                    }
                };

                self.cancelCreateZone = function ()
                {
                    self.closeZoneDetailModule();
                    // Remove the zone from the base page.
                    var basePopupHolderElemViewModel = ko.dataFor(document.getElementById('BasePageModuleHolder:' + self.sequence()));
                    basePopupHolderElemViewModel.removeZoneFromDetailContainer(self.sequence());
                };

                self.validateZoneDetails = function ()
                {
                    var isValid = true;
                    var fieldsToValidate = new Array();
                    fieldsToValidate.push('zoneName_' + self.sequence());
                    fieldsToValidate.push('webEntryPort_' + self.sequence());
                    for (var i = 0; i < fieldsToValidate.length; i++)
                    {
                        var htmlElement = document.getElementById(fieldsToValidate[i]);
                        if (htmlElement !== null)
                            htmlElement.validate();
                        if (htmlElement !== null && htmlElement.valid !== 'valid')
                        {
                            isValid = false;
                            htmlElement.showMessages();
                        }
                    }

                    //logical hostname validation
                    var logicalFields = new Array();
                    logicalFields.push('webEntryHostName_' + self.sequence());
                    logicalFields.push('webEntryDomain_' + self.sequence());
                    if (self.isLogicalHostPrefix())
                        logicalFields.push('appsLogicalHostPrefix_' + self.sequence());
                    logicalFields.push('appsLogicalDomain_' + self.sequence());

                    for (var i = 0; i < logicalFields.length; i++)
                    {
                        var htmlElement = document.getElementById(logicalFields[i]);
                        if (htmlElement !== null)
                            htmlElement.validate();
                        if (htmlElement !== null && htmlElement.valid !== 'valid')
                        {
                            isValid = false;
                            // htmlElement.showMessages();
                        }
                    }

                    //For primary zone do a final check 
                    if (self.isPrimaryInternalZone() && self.parentViewModel.isCreateEnvFlow())
                    {
                        if (!self.validatelogicalHostInAllZones(self.appsLogicalHostPrefixValue()))
                            isValid = false;

                        if (!self.validatelogicalDomainInAllZones(self.appsLogicalDomainValue()))
                            isValid = false;

                    }


                    if (self.parentViewModel.isCreateEnvFlow()) {
                        var nodes = self.nodesObservableArray();
                        if (nodes !== null && nodes.length > 0) {
                            for (var i = 0; i < nodes.length; i++) {
                                var fullIDOfStorageField = 'appNodeTable_' + self.sequence() + '_' + (i + 1);
                                var storageField = document.getElementById(fullIDOfStorageField);
                                if (storageField !== null) {
                                    var storageFieldInput = document.getElementById(fullIDOfStorageField + "|input");
                                    if (storageFieldInput !== null) {
                                        var storageFieldValue = parseInt(storageFieldInput.value);
                                        if (storageFieldValue < self.minimumStorageForRestore()) {
                                            isValid = false;
                                        }
                                    }
                                }

                                //logical host validation
                                var logicalhn = document.getElementById("appNodeTable_logicalHostname_" + self.sequence() + '_' + (i + 1));
                                if (logicalhn)
                                    logicalhn.validate();
                                if (logicalhn && (('' === logicalhn.value) || (logicalhn.valid !== 'valid')))
                                {
                                    //logicalhn.showMessages();
                                    isValid = false;
                                }
                            }
                        }
                    }

                    if (self.webEntryPort() === 443 && self.webEntryProtocolInputValue() === 'http') {
                        var translatedErrorMsg = oj.Translations.getTranslatedString("validationMsgs.port443InvalidForHttpProtocolMsg");
                        var validationCustomMsgForPorthttp = {summary: translatedErrorMsg,
                            detail: translatedErrorMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};
                        self.portValidationCustomMsg([validationCustomMsgForPorthttp]);
                        isValid = false;
                    } else if (self.webEntryPort() === 80 && self.webEntryProtocolInputValue() === 'https') {
                        var translatedErrorMsg = oj.Translations.getTranslatedString("validationMsgs.port80InvalidForHttpsProtocolMsg");
                        var validationCustomMsgForPorthttps = {summary: translatedErrorMsg,
                            detail: translatedErrorMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};
                        self.portValidationCustomMsg([validationCustomMsgForPorthttps]);
                        isValid = false;
                    }

                    return isValid;
                };
                self.closeZoneDetailModule = function (event)
                {
                    var basePopupHolderElemViewModel = ko.dataFor(document.getElementById('BasePageModuleHolder:' + self.sequence()));
                    if (basePopupHolderElemViewModel === null)
                    {
                        console.log('Error : Could not find the base page module holder element for this sequence.');
                        return;
                    }
                    basePopupHolderElemViewModel.clearGlobalVariablesBeforeClosingZonePopup();
                    var module = document.getElementById('zoneModuleRoot_' + self.sequence());
                    if (module === null)
                    {
                        console.log('Error : Could not find the zone module element DOM for this sequence.');
                        return;
                    }
                    module.style.display = 'none';
                    self.zoneEditDone(true); //mark the zone as been 
                    console.log('Success : Closed the zone module successfully.');
                    basePopupHolderElemViewModel.showZonesListView(true);
                    self.updateLoadBalancerSelectedOptionLabel();
                    basePopupHolderElemViewModel.updateListViewWithZoneDetailInformation(self);
                };

                self.updateLoadBalancerSelectedOptionLabel = function () {
                    var selectedValue = self.lbaasOptionValue();
                    for (var i = 0; i < self.lbaasOptions().length; i++) {
                        var lbaasOptionValue = self.lbaasOptions()[i].value;
                        if (lbaasOptionValue === selectedValue) {
                            var label = self.lbaasOptions()[i].label;
                            self.lbaasSelectedOptionLabel(label);
                            return label;
                        }
                    }
                };

                self.handleZoneNameChangeEvent = function (event)
                {
                    var newName = event['detail'].value;
                    var isPrimaryInternalOrExternal = self.isPrimaryExternalZone() || self.isPrimaryInternalZone();
                    var sequenceNumOfPrimaryExternalZone = self.getPrimaryExternalZoneSequence();
                    if (!isPrimaryInternalOrExternal)
                    {
                        return;
                    } else
                    {
                        var defaultOptionValues = new Array();
                        for (var k = 0; k < self.defaultLbaasOptions().length; k++)
                        {
                            var lbaasObj = self.defaultLbaasOptions()[k];
                            defaultOptionValues.push(lbaasObj.value);
                        }
                        var zoneData = self.parentViewModel.zones();
                        if (zoneData === null || zoneData.length < 2)
                        {
                            // skip.
                        } else
                        {
                            for (var j = 0; j < zoneData.length; j++)
                            {
                                var zoneInfo = zoneData[j];
                                var zoneTypeInZoneInfo = zoneInfo.type();
                                var lbaasTypeInZoneInfo = zoneInfo.lbaasOptionValue();
                                var sequenceNum = zoneInfo.identifier;
                                if (defaultOptionValues.includes(lbaasTypeInZoneInfo))
                                {
                                    continue;
                                } else
                                {
                                    if (self.isPrimaryInternalZone())
                                    {
                                        if (sequenceNum === 1)
                                        {
                                            continue; // Do not update for the primary internal zone.
                                        }
                                        if (zoneTypeInZoneInfo === 'Internal')
                                        {
                                            zoneData[j].lbaasOptionValue(newName);
                                        }
                                    } else if (self.isPrimaryExternalZone())
                                    {
                                        if (sequenceNum === sequenceNumOfPrimaryExternalZone)
                                        {
                                            continue; // Do not update for the primary external zone.
                                        }
                                        if (zoneTypeInZoneInfo === 'External')
                                        {
                                            zoneData[j].lbaasOptionValue(newName);
                                        }
                                    }
                                }
                            }

                            var currentSequenceNum = self.parentViewModel.sequence();
                            for (var k = 1; k <= currentSequenceNum; k++)
                            {
                                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                                if (detailChildElemRoot !== null)
                                {
                                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                    if (detailModuleElemViewModel !== null)
                                    {
                                        var sequenceNum = detailModuleElemViewModel.sequence();
                                        var detailViewModelZoneType = detailModuleElemViewModel.selectedZoneType();
                                        if (defaultOptionValues.includes(lbaasTypeInZoneInfo))
                                        {
                                            continue;
                                        } else
                                        {
                                            if (self.isPrimaryInternalZone())
                                            {
                                                if (sequenceNum === 1)
                                                {
                                                    continue; // Do not update for the primary internal zone.
                                                }
                                                if (detailViewModelZoneType === 'Internal')
                                                {
                                                    var defaultOptions = self.defaultLbaasOptions();
                                                    detailModuleElemViewModel.lbaasOptions([]);
                                                    var additionalOption = new Object();
                                                    additionalOption.label = 'Reuse ' + newName + ' load balancer';
                                                    additionalOption.value = newName;
                                                    var customOptions = new Array();
                                                    for (var j = 0; j < defaultOptions.length; j++)
                                                    {
                                                        customOptions.push(defaultOptions[j]);
                                                    }
                                                    customOptions.push(additionalOption);
                                                    detailModuleElemViewModel.lbaasOptions(customOptions);
                                                    detailModuleElemViewModel.lbaasOptionValue(newName);
                                                }
                                            } else if (self.isPrimaryExternalZone())
                                            {
                                                if (sequenceNum === sequenceNumOfPrimaryExternalZone)
                                                {
                                                    continue; // Do not update for the primary internal zone.
                                                }
                                                if (detailViewModelZoneType === 'External')
                                                {
                                                    var defaultOptions = self.defaultLbaasOptions();
                                                    detailModuleElemViewModel.lbaasOptions([]);
                                                    var additionalOption = new Object();
                                                    additionalOption.label = 'Reuse ' + newName + ' load balancer';
                                                    additionalOption.value = newName;
                                                    var customOptions = new Array();
                                                    for (var j = 0; j < defaultOptions.length; j++)
                                                    {
                                                        customOptions.push(defaultOptions[j]);
                                                    }
                                                    customOptions.push(additionalOption);
                                                    detailModuleElemViewModel.lbaasOptions(customOptions);
                                                    detailModuleElemViewModel.lbaasOptionValue(newName);
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }
                };
                self.lbaasSelectionChanged = function (event, ui)
                {
                    var newValue = event['detail'].value;
                    var prevValue = event['detail'].previousValue;
                    if (prevValue === 'DEPLOY_NEW' && newValue === 'DEPLOY_NEW')
                    {
                        return;
                    }

                    var defaultOptionValues = new Array();
                    for (var k = 0; k < self.defaultLbaasOptions().length; k++)
                    {
                        var lbaasObj = self.defaultLbaasOptions()[k];
                        defaultOptionValues.push(lbaasObj.value);
                    }

                    if (prevValue === 'DEPLOY_NEW' && (self.isPrimaryExternalZone() || self.isPrimaryInternalZone()))
                    {
                        var zoneType = self.selectedZoneType();
                        var isThereDependentZones = false;
                        var zoneData = self.parentViewModel.zones();
                        if (zoneData === null || zoneData.length < 2)
                        {
                            // skip.
                        } else
                        {
                            for (var j = 0; j < zoneData.length; j++)
                            {
                                var zoneInfo = zoneData[j];
                                // Check the zone type. It should match the one that raised the event.
                                var zoneTypeInZoneInfo = zoneInfo.type();
                                if (zoneTypeInZoneInfo === zoneType)
                                {
                                    // Check the sequence. It could be that of the current node.
                                    var zoneSequenceInZoneInfo = zoneInfo.identifier;
                                    if (self.sequence() === zoneSequenceInZoneInfo)
                                    {
                                        continue;
                                    } else
                                    {
                                        var lbaasTypeInZoneInfo = zoneInfo.lbaasOptionValue();
                                        if (defaultOptionValues.includes(lbaasTypeInZoneInfo))
                                        {
                                            continue;
                                        } else
                                        {
                                            isThereDependentZones = true;
                                            break;
                                        }
                                    }
                                } else
                                {
                                    continue;
                                }
                            }

                            if (isThereDependentZones)
                            {
                                self.parentViewModel.openInformationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.dependentZonesPresentInformationMsg'),
                                        function () {
                                            event.stopPropagation();
                                            self.lbaasOptionValue(prevValue);
                                            return false;
                                        });
                                return;
                            }
                        }
                    }

                    if (newValue === 'NO_LOAD_BALANCER')
                    {
                        if (self.parentViewModel.zones().length > 1)
                        {
                            self.parentViewModel.openInformationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.appTierAsWebEntryMultipleZonesPresentWarningMsg'),
                                    function () {
                                        event.stopPropagation();
                                        self.lbaasOptionValue(prevValue);
                                        return false;
                                    });
                            return;
                        }

                        var noOfAppNodesEntry = self.nodesObservableArray().length;
                        if (noOfAppNodesEntry > 1)
                        {
                            self.parentViewModel.openConfirmationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.appTierWebEntryOnlyOneNodeAllowedWarning'),
                                    function () {

                                        var firstNode = self.nodesObservableArray()[0];
                                        var nodes = new Array();
                                        nodes.push(firstNode);
                                        self.nodesObservableArray(nodes);
                                        self.initializeFaultDomainForAllAppNodes();
                                    }, function () {
                                event.stopPropagation();
                                self.lbaasOptionValue(prevValue);
                                return false;
                            });
                        }
                    }

                    // Default the protocol to Https only for the primary zone lbaas selection change.
                    // For other zones the protocol will be based on the 1st zone selection.
                    if (self.isPrimaryInternalZone()) {
                        self.webEntryProtocolInputValue('https');
                        if (document.getElementById('webEntryPort_' + self.sequence()) !== null)
                            document.getElementById('webEntryPort_' + self.sequence()).reset();
                    }
                };

                self._ignoreOnce = false;

                self.webEntryProtocolChanged = function (event)
                {
                    var prevValue = event['detail'].previousValue;
                    var newValue = event['detail'].value;

                    if (typeof (prevValue) === 'undefined' || prevValue === null || prevValue === '') {
                        self.changeWebEntryPortBasedOnProtocol(newValue);
                        return;
                    }

                    // This should be handled only from the primary zone.
                    if (self.sequence() !== 1) {
                        return;
                    }
                    // If there are more than 1 zone then we do this.
                    var zonesInfo = self.parentViewModel.zones();
                    if (zonesInfo.length <= 1 || self._ignoreOnce) {
                        self._ignoreOnce = false;
                        self.changeWebEntryPortBasedOnProtocol(newValue);
                        return;
                    }

                    self.parentViewModel.openConfirmationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.warnAboutProtocolChange'),
                            function () {
                                self.changeWebEntryPortBasedOnProtocol(newValue);
                                // Update the table in the base page.
                                var zonesInfo = self.parentViewModel.zones();
                                if (zonesInfo.length <= 1) {
                                    // skip.
                                }
                                var lbaasReuseCounter = 0;
                                var zoneNameOfFirstZone = zonesInfo[0].name();
                                for (var i = 0; i < zonesInfo.length; i++) {
                                    zonesInfo[i].protocol(newValue);
                                    // For Zone with index =0; primary internal zone, no reuse case.
                                    if (i === 0) {
                                        zonesInfo[i].port(self.getDefaultPortValueForProtocol(newValue));
                                    } else {
                                        // For other zones, check if it reuses zone1 LBaaS , if so , then port number will be default Port Number + lbaasReuseCounter.
                                        var lbaasOptionValue = zonesInfo[i].lbaasOptionValue();
                                        if (lbaasOptionValue !== null && lbaasOptionValue !== '' && lbaasOptionValue === zoneNameOfFirstZone) {
                                            lbaasReuseCounter++;
                                            var firstZoneAssignedPortNumber = self.getDefaultPortValueForProtocol(newValue);
                                            var newPortNumberForThisZone = firstZoneAssignedPortNumber + lbaasReuseCounter;
                                            zonesInfo[i].port(newPortNumberForThisZone);
                                        } else {
                                            zonesInfo[i].port(self.getDefaultPortValueForProtocol(newValue));
                                        }
                                    }
                                    zonesInfo[i].webEntryURL(self.parentViewModel.getWebEntryURLforZone(zonesInfo[i]));
                                }
                                // Update the detail view model for each zone.
                                var currentSequenceNum = self.parentViewModel.sequence();
                                lbaasReuseCounter = 0;
                                for (var k = 1; k <= currentSequenceNum; k++)
                                {
                                    var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                                    if (detailChildElemRoot !== null)
                                    {
                                        var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                        if (detailModuleElemViewModel !== null)
                                        {
                                            detailModuleElemViewModel.webEntryProtocolInputValue(newValue);
                                            var lbaasOptionValue = detailModuleElemViewModel.lbaasOptionValue();
                                            if (lbaasOptionValue !== null && lbaasOptionValue !== '' && lbaasOptionValue === zoneNameOfFirstZone) {
                                                lbaasReuseCounter++;
                                                var firstZoneAssignedPortNumber = self.getDefaultPortValueForProtocol(newValue);
                                                var newPortNumberForThisZone = firstZoneAssignedPortNumber + lbaasReuseCounter;
                                                detailModuleElemViewModel.webEntryPort(newPortNumberForThisZone);
                                            } else {
                                                detailModuleElemViewModel.changeWebEntryPortBasedOnProtocol(newValue);
                                            }

                                        }
                                    }
                                }


                            }, function () {
                        event.stopPropagation();
                        self._ignoreOnce = true;
                        self.webEntryProtocolInputValue(prevValue);
                        return false;
                    });

                };

                self.getDefaultPortValueForProtocol = function (value) {
                    if (value === 'http')
                    {
                        return 80;
                    } else
                    {
                        return 443;
                    }
                };

                self.changeWebEntryPortBasedOnProtocol = function (value) {
                    var defaultPort = self.getDefaultPortValueForProtocol(value);
                    self.webEntryPort(defaultPort);
                };

                self.initializeModuleFromGlobalVariables();

                self.groupingRemover = new NumberConverter.IntlNumberConverter({
                    useGrouping: false
                });

                self.cloneShapeOptionResetValue = ko.observable(false);
                self.currentShapeChangeNodeId = ko.observable(-1);
                self.handleCloneShapeOptionChange = function (event, ui)
                {
                    if (self.cloneShapeOptionResetValue())
                    {
                        self.cloneShapeOptionResetValue(false);
                        return;
                    }
                    var appNodesInCurrentViewModel = self.nodesObservableArray();

                    var prevValue = event['detail'].previousValue;
                    var value = event['detail'].value;
                    var nodeId = -1;
                    var origShapeValue = '';
                    if (event !== null && typeof (event.target) !== 'undefined' && typeof (event.target.id) !== 'undefined')
                    {
                        var temp = event.target.id.split('_');
                        nodeId = Number.parseInt(temp[temp.length - 1]);
                        self.currentShapeChangeNodeId(nodeId);
                    }

                    if (nodeId > -1 && appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                    {
                        var appNodeData = appNodesInCurrentViewModel[nodeId];
                        if (appNodeData)
                        {
                            origShapeValue = appNodeData.OrigShape;
                        }
                    }

                    if ((value != origShapeValue) && (origShapeValue === prevValue))
                    {

                        self.parentViewModel.openConfirmationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.appNodeShapeChangedInCloneWarning'),
                                self.handleCloneShapeOptionChangeConfirm,
                                self.handleCloneShapeOptionChangeCancel);
                    }
                    event.stopPropagation();
                };
                self.handleCloneShapeOptionChangeCancel = function ()
                {
                    self.cloneShapeOptionResetValue(true);
                    var nodeId = self.currentShapeChangeNodeId();
                    self.currentShapeChangeNodeId(-1);
                    var appNodesInCurrentViewModel = self.nodesObservableArray();
                    if (nodeId > -1 && appNodesInCurrentViewModel !== null && appNodesInCurrentViewModel.length > 0)
                    {
                        var appNodeData = appNodesInCurrentViewModel[nodeId];
                        if (appNodeData)
                        {
                            appNodeData.Shape(appNodeData.OrigShape); //reset back to orig shape value
                        }
                    }
                };

                self.handleCloneShapeOptionChangeConfirm = function (value)
                {
                    self.currentShapeChangeNodeId(-1);
                };

            }
            ;



            return zoneModuleViewModel;
        });
