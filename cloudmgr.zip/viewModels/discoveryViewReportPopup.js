/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * task log module
 */
define(['ojs/ojcore', 'jquery', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojarraydataprovider', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojtable'], 
function (oj, $, ko, actionsHelper, popupHelper, constants, ArrayDataProvider) {
    /**
     * The view model for the main content view template
     */
    function discoveryViewReportPopupViewModel()
    {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.discoveryData = ko.observable('');

        self.summaryText = oj.Translations.getTranslatedString("confirmPopup.discoveryReportSummaryText");
        self.isLoading = ko.observable(true);
        self.reportNotReady = ko.observable(false);
        self.envTableDisplay = ko.observable('none');
        self.envColumnDataArray = ko.observableArray([]);
        self.envDataprovider = new ArrayDataProvider(self.envColumnDataArray, { idAttribute: 'id' });
        self.appTierColumnDataArray = ko.observableArray([]);
        self.appTierDataprovider = new ArrayDataProvider(self.appTierColumnDataArray, { idAttribute: 'id' });
        self.appNodesColumnDataArray = ko.observableArray([]);
        self.appNodesDataprovider = new ArrayDataProvider(self.appNodesColumnDataArray, { idAttribute: 'id' });
        self.dbTierColumnDataArray = ko.observableArray([]);
        self.dbTierDataprovider = new ArrayDataProvider(self.dbTierColumnDataArray, { idAttribute: 'id' });
        self.dbNodesColumnDataArray = ko.observableArray([]);
        self.dbNodesDataprovider = new ArrayDataProvider(self.dbNodesColumnDataArray, { idAttribute: 'id' });             
        self.environmentLabel = ko.observable('Environment');
        self.appTierLabel = ko.observable('Application Tier');
        self.dbTierLabel = ko.observable('Database Tier');
        self.dbServiceType = ko.observable('');
        
        self.discoveryId = ko.computed(function() {
               return self.discoveryData().id;
                 }, this);
        self.discoveryName = ko.computed(function() {
               return self.discoveryData().name;
                 }, this);
        self.envName =  ko.computed(function() {
               return self.discoveryData().envName;
                 }, this);
        self.isCompliant = ko.computed(function() {
               return self.discoveryData().isCompliant? "Yes" : "No";
                 }, this);
        self.dbIp = ko.computed(function() {
               return self.discoveryData().DBIp;
                 }, this);
        self.contextFile = ko.computed(function() {
               return self.discoveryData().dbContextFile;
                 }, this);
        self.createdOn = ko.computed(function() {
               return self.discoveryData().creationDate;
                 }, this);
        
        self.reportColumnArray = [{headerText: "Standard", 
                                 field: "label",
                                 headerStyle: "text-align: center; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em",
                                 style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;"},
                                 {headerText: "Expected",
                                 field: "expected",
                                 headerStyle: "text-align: center; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em",
                                 style: "white-space:normal;word-wrap:break-word; text-align: center;vertical-align: middle;"},
                                 {headerText: "Actual",
                                 field: "actual",
                                 headerStyle: "text-align: center; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em",
                                 style: "white-space:normal;word-wrap:break-word; text-align: center;vertical-align: middle;"},
                                {headerText: "Status",
                                 field: "compliant",
                                 template: "compliantTemplate",
                                 headerStyle: "text-align: center; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em",
                                 style: "white-space:normal;word-wrap:break-word; text-align: center;vertical-align: middle;"},
                                 {headerText: "Reason",
                                  field: "message",
                                  headerStyle: "text-align: center; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em",
                                  style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;"}];

        
        self.getComplianceArray = function(compliances)
        {
            var array = new Array();
            $.each(compliances, function () {
                        var item = {
                        id: this.id,
                        label: this.label,
                        actual: this.actual? this.actual : '',
                        expected: this.expected? this.expected : '',
                        message: this.message? this.message : '',
                        compliant: this.compliant,
                        description: this.description? this.description : ''
                        };
                        array.push(item);
                    });
             return array; 
        }
        
        self.fetchDiscoveryReport = function (discoveryId)
        {
            actionsHelper.getDiscoveryReportContent(discoveryId, function (error, response)
            {
                if ((error === null || error === '') && response)
                {
                    var report = response;
                    self.reportNotReady(false);
                    var env = report.environment;
                    if(env && env.compliances)
                    {
                        var array = self.getComplianceArray(env.compliances);
                        self.envColumnDataArray(array);
                        self.envTableDisplay('');
                    }
                     
                    var appTier = report.appTier;
                    if(appTier && appTier.compliances)
                    {
                        var array = self.getComplianceArray(appTier.compliances);
                        self.appTierColumnDataArray(array);
                    }
                    
                    //appTier nodes
                    if(appTier && appTier.nodes)
                    {
                       var nodesCompliances = [];
                       var i=1;
                       appTier.nodes.forEach(function (node) {
                          var nodeIp = node.ip;
                          if(node.compliances)
                          {
                            var array = self.getComplianceArray(node.compliances);
                          }
                          var nodeArray = ko.observableArray(array);
                          var nodeDataProvider = new ArrayDataProvider(nodeArray);
                          nodesCompliances.push({
                              index: i++,
                              ip: nodeIp, 
                              compTable: nodeDataProvider });
                       });
                       self.appNodesColumnDataArray(nodesCompliances);
                    }
                    
                    var dbTier = report.dbTier;
                    if(dbTier)
                    {
                        self.dbServiceType(dbTier.serviceType);
                        if(dbTier.compliances)
                        {
                           var array = self.getComplianceArray(dbTier.compliances);
                           self.dbTierColumnDataArray(array);
                        }
                                       
                        if(dbTier.nodes)
                        {
                           var nodesCompliances = [];
                           var i=1;
                           dbTier.nodes.forEach(function (node) {
                              var nodeIp = node.ip;
                              if(node.compliances)
                              {
                                var array = self.getComplianceArray(node.compliances);
                              }
                              var nodeArray = ko.observableArray(array);
                              var nodeDataProvider = new ArrayDataProvider(nodeArray);
                              nodesCompliances.push({
                                  index: i++,
                                  ip: nodeIp, 
                                  compTable: nodeDataProvider });
                           });
                           self.dbNodesColumnDataArray(nodesCompliances);
                    }
                    }
                    
                    setTimeout(function () {
                        var reportContent = document.getElementById('reportContent');
                        reportContent.focus();

                    }, 200);

                } else
                {
                    self.reportNotReady(true);  
                }
              
                self.isLoading(false);
            });

        };

        self.closePopup = function ()
        {
            self.discoveryData('');
            var popup = document.querySelector(constants.divTags.discoveryReportPopupTag);
            popup.close();
        };

        self.openPopup = function (event, ui)
        {
            self.envColumnDataArray.removeAll();
            self.appTierColumnDataArray.removeAll();
            self.appNodesColumnDataArray.removeAll();
            self.dbTierColumnDataArray.removeAll();
            self.dbNodesColumnDataArray.removeAll();
            self.envTableDisplay('none');
            self.isLoading(true);
            var popup = document.querySelector(constants.divTags.discoveryReportPopupTag);
            popup.open(event.target);
            self.fetchDiscoveryReport(self.discoveryId());
        };
        
        self.printReport = function (event, ui)
        {
                          
            var htmlHead = "<head>\n" + 
            "        <title>Discovery Report Summary</title>\n" + 
            "        <meta charset=\"UTF-8\">\n" + 
            "        <meta http-equiv=\"x-ua-compatible\" content=\"IE=edge\">\n" + 
            "        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n" + 
            "        <link href=\"css/ebscloudmgrlogin.css\" rel=\"stylesheet\" type=\"text/css\">\n" + 
            "        <link href=\"css/libs/oj/v10.0.0/redwood/oj-redwood-min.css\" rel=\"stylesheet\" type=\"text/css\">\n" + 
            "        <link rel=\"stylesheet\" href=\"css/ebscustom.css\" type=\"text/css\"> \n" + 
            "        <link rel=\"stylesheet\" href=\"css/ebscloudmanager.css\" type=\"text/css\">\n" + 
            "        <script type=\"text/javascript\" src=\"js/libs/require/require.js\"></script>\n" + 
            "        <script type=\"text/javascript\" src=\"js/main.js\"></script>\n" ;  

            var mywindow = window.open('', 'PRINT', 'height=600,width=1000');

            mywindow.document.write(htmlHead);
            mywindow.document.write('<body>');
            mywindow.document.write(document.getElementById("reportContent").outerHTML);
            mywindow.document.write('</body></html>');

            setTimeout(function(){  
                $(mywindow.document).ready(function(){
                mywindow.document.close(); // necessary for IE >= 10
                mywindow.focus(); // necessary for IE >= 10*/
                mywindow.print();
                mywindow.close();
             });
            },1000);
            
            return true;

        };
        
     }
    return discoveryViewReportPopupViewModel;
});
