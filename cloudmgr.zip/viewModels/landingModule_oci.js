/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * landingModule module
 */
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/utils/userRole', 'ebs/actions/actionsHelper', 'ebs/utils/helpMenu', 'ojs/ojarraydataprovider', 'ojs/ojarraytreedataprovider', 'ojs/ojkeyset', 'ebs/utils/lovUtils', 'ojs/ojnavigationlist', 'ojs/ojjsontreedatasource', 'ojs/ojoffcanvas', 'ebs/utils/compartmentsLov', 'ojs/ojselectcombobox', 'ojs/ojselectsingle', "jet-composites/compartment-lov/loader", "ojs/ojprogress-circle"
], function (oj, ko, constants, userRole, actionsHelper, helpMenu, ArrayDataProvider, ArrayTreeDataProvider, keySet, lovUtils) {
    /**
     * The view model for the main content view template
     */
    function landingModuleContentViewModel() {
        var self = this;

        var currentState = oj.Router.rootInstance.currentState();
        var globalChildRouter = currentState._router._childRouters[2];
        var administrationChildRouter = currentState._router._childRouters[3];
        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
        self.itemOnly = function (context) {
            return context.leaf;
        };
        self.expanded = new keySet.ExpandedKeySet(['Administration']);
        self.compartmentsObservable = ko.observableArray([]);
        /*self.compartments = new ArrayTreeDataProvider(
                self.compartmentsObservable, {keyAttributes: 'value', childrenAttribute: 'children'}
        );*/
        self.compartments = new ArrayDataProvider(
                self.compartmentsObservable, {keyAttributes: 'value'}
        );
        
        // self.compartmentDP = new ArrayTreeDataProvider(self.compartments, {keyAttributes: 'value'});
        self.selectedNavItem = ko.observable();
        self.selectedCompartment = ko.observable('');
        self.compartmentValueReset = ko.observable(false);
        self.showNavTab = ko.observable(true);
        self.displayNavigationMenu = ko.observable('');
        var compartmentFilteredModules = [constants.navModules.envListModule,
            constants.navModules.envActivitiesModule,
            constants.navModules.envBackupsModule,
            constants.navModules.networkProfileListModule,
            constants.navModules.discoveryModule,
            constants.navModules.policyListingPG];
        self.showCompartmentLov = ko.computed(function () {
            var curr = self.selectedNavItem();
            if (curr)
            {
                if (compartmentFilteredModules.indexOf(curr) > -1)
                    return true;
            }
            return false;
        });

        var isDiscoveryEnabled = rootViewModel.properties.has("discovery_enabled") ?
                (rootViewModel.properties.get("discovery_enabled") === true) : false;

        self.handleCompartmentFilterChange = function (event, ui)
        {
            if (event === null)
            {
                return;
            }
            var compartmentOCIDSelected = event.detail.value;
            var previouslySelectedCompartmentIdentifier = event.detail.previousValue;
            if (compartmentOCIDSelected == null || compartmentOCIDSelected === '')
            {
                return;
            }

            //Page first load scenario
            if (previouslySelectedCompartmentIdentifier === null || previouslySelectedCompartmentIdentifier === "")
            {
                //to avoid double loading on environment list, compare with the existing
                //value saved to the session
                var sessionValue = sessionStorage.getItem('lastSelectedCompartmentId');
                if (sessionValue === null)
                {
                    //default scenario, do nothing
                    //sessionStorage.setItem('lastSelectedCompartmentId', 'All');
                    return;
                } else if (sessionValue === compartmentOCIDSelected)
                {
                    return;
                } 
                /*else if (compartmentOCIDSelected === "All" && !self.compartmentValueReset())
                {
                    return;
                }*/
            } else if ((compartmentOCIDSelected === previouslySelectedCompartmentIdentifier) ||
                    compartmentOCIDSelected === rootViewModel.selectedCompartment())
            {
                return;
            }

            sessionStorage.setItem('lastSelectedCompartmentId', compartmentOCIDSelected);
            rootViewModel.selectedCompartment(compartmentOCIDSelected);

            //for EnvList Page - reload environment list if the selection has changed
            if (document.getElementById('filterEnvId|input') != null)
            {
                document.getElementById('filterEnvId|input').value = '';

            }

            //determine current module
            var currModule = self.selectedNavItem();
            if (constants.navModules.envListModule === currModule)
            {
                var envListViewModel = ko.dataFor(document.getElementById(constants.divTags.envListPage));
                envListViewModel.loadData(compartmentOCIDSelected);
            } else if (constants.navModules.envBackupsModule === currModule)
            {
                var backupViewModel = ko.dataFor(document.getElementById(constants.divTags.backupsPage));
                backupViewModel.loadData(compartmentOCIDSelected);
            } else if (constants.navModules.networkProfileListModule === currModule)
            {
                var networkProfileViewModel = ko.dataFor(document.getElementById(constants.divTags.networkProfilesListPage));
                networkProfileViewModel.loadNetworks(compartmentOCIDSelected);
            } else if (constants.navModules.envActivitiesModule === currModule)
            {
                var activitiesViewModel = ko.dataFor(document.getElementById(constants.divTags.activitiesPage));
                activitiesViewModel.loadJobs(compartmentOCIDSelected);
            } else if (constants.navModules.discoveryModule === currModule)
            {
                var discoveryViewModel = ko.dataFor(document.getElementById(constants.divTags.discoveryPage));
                discoveryViewModel.loadDiscoveryJobs(compartmentOCIDSelected);
            } else if (constants.navModules.policyListingPG === currModule)
            {
                var policyListingViewModel = ko.dataFor(document.getElementById("policyListingPG"));
                policyListingViewModel.loadPolicies(compartmentOCIDSelected);
            }

        };


        var isAdminUserRawSessionValue = userRole.getRawSessionValue();

        if (isAdminUserRawSessionValue === null || isAdminUserRawSessionValue === '')
        {
            // We need to update the user profile again. As Login.js did not kick in.
            // we were redirected from account details page.

            console.log('Read User Profile again as the session value is null or empty.');
            actionsHelper.getUserProfile(function (error, userprofile) {
                if (error === '') {
                    rootViewModel.tenancyNameValue(userprofile.tenancyName);
                    rootViewModel.tenancyOCID(userprofile.tenancyOCID);
                    rootViewModel.selectedRegionValue(userprofile.region);
                    rootViewModel.userOCID(userprofile.userOCID);
                    rootViewModel.fingerprint(userprofile.fingerprint);
                    //rootViewModel.apiKeySet(userprofile.apiKeySet);
                    rootViewModel.isKeyValid(userprofile.isSSHKeysValid);
                    rootViewModel.username(userprofile.username);
                    var isAdmin = (userprofile.isAdmin === null || userprofile.isAdmin === '') ? false : JSON.stringify(userprofile.isAdmin);
                    console.log("isAdmin(Landing Module) ::--" + isAdmin);
                    sessionStorage.setItem('cmAdmin', isAdmin);
                }

            });

        }

        self.prepareCompartmentList = function ()
        {
            actionsHelper.getCompartmentListForTenancy(function (error, compartmentsList) {
                self.compartmentValueReset(false);
                if (error != null && error != '') {
                    console.log('Error in fetching Compartment List for tenancy =>' + error);
                } else {
                    var flatList = getFlatListFromHierarchicalLov(compartmentsList, rootViewModel.tenancyOCID());
                    // self.compartmentsObservable(flatList);
                    //var hierarchialList = getCompartmentLOVHierarchy(compartmentsList, rootViewModel.tenancyOCID());

                    var newCompartmentsList = new Array();
                    var allOption = {
                        'label': 'All',
                        'value': 'All'
                    };
                    newCompartmentsList.push(allOption);
                    for (var y = 0; y < flatList.length; y++)
                    {
                        newCompartmentsList.push(flatList[y]);
                    }
                    self.compartmentsObservable(newCompartmentsList);
                    
                    var lastSelectedCompartment = sessionStorage.getItem('lastSelectedCompartmentId');
                    if (lastSelectedCompartment)
                        rootViewModel.selectedCompartment(lastSelectedCompartment);

                    //check if the last selected compartment is still valid
                    var isValueStillValid = false;
                    if (lastSelectedCompartment !== null)
                    {
                        if (compartmentsList)
                        {
                            //const matches = compartmentsList.filter(compartment => compartment.label === lastSelectedCompartment);
                            const matches = compartmentsList.filter(function (compartment) {
                                return (compartment.label === lastSelectedCompartment);
                            });

                            if (matches && matches.length > 0)
                            {
                                isValueStillValid = true;
                            }
                        }
                    }
                    if (!isValueStillValid)
                    {
                        self.compartmentValueReset(true);
                    }
                    if (!isValueStillValid || (lastSelectedCompartment === null))
                    {
                        //default to first item in the list
                        lovUtils.lovOptionsUpdated(self.compartmentsObservable(), self.selectedCompartment);
                    }
                    else
                    {
                        self.selectedCompartment(lastSelectedCompartment);
                    }

                }
            });
        };

        var tenancyOCID = rootViewModel.tenancyOCID();
        if (typeof tenancyOCID === 'undefined') {
            actionsHelper.getUserProfile(function (error, userprofile) {
                if (error === '') {
                    if (userprofile.isSSHKeysValid) {
                        rootViewModel.tenancyNameValue(userprofile.tenancyName);
                        rootViewModel.tenancyOCID(userprofile.tenancyOCID);
                        rootViewModel.selectedRegionValue(userprofile.region);
                    }
                }

                self.prepareCompartmentList();
            });
        } else
        {
            self.prepareCompartmentList();
        }

        var bearerToken = rootViewModel.authToken();
        var currentState = oj.Router.rootInstance.currentState();
        var globalChildRouter = currentState._router._childRouters[2];
        var lastSelectedChildRouter = sessionStorage.getItem('lastSelectedChildRouterFromLandingPage');
        // If we were redirected from the account details page and then we are coming to landing module, user should 
        // ideally be in Environments page. In case of multi user logging in the same browser scenario, if the other user clicked 
        // on one of the tabs and the current user is redirected from account details page he might be landing in network profiles tab depending on the prev user
        // activity. So child router ko is set to Network profiles tab while the above REST call is still going on. To avoid such timings issue, we should always take the 
        // user to environments page.
        if (isAdminUserRawSessionValue === null || isAdminUserRawSessionValue === '')
        {
            lastSelectedChildRouter = null;
        }

        console.log("Job id from deep linking in landing page :" + localStorage.getItem("jobIdParam"));
        console.log("initialPageParam from deep linking in landing page :" + localStorage.getItem("initialPageParam"));
        console.log("initialTabParam from deep linking in landing page :" + localStorage.getItem("initialTabParam"));
        console.log("standByNameParam from deep linking in landing page :" + localStorage.getItem("standByNameParam"));

        // Changes for Deep Linking
        // Checking if initialPage param is present then navigating based on other params
        if (localStorage.getItem("initialPageParam") !== 'undefined' && localStorage.getItem("initialPageParam") !== null) {

            if (localStorage.getItem("initialPageParam") === constants.navModules.activityDetailsModule
                    || localStorage.getItem("initialPageParam") === constants.navModules.envDetailsModule) {

                lastSelectedChildRouter = localStorage.getItem("initialPageParam");

                if (localStorage.getItem("jobIdParam") === 'undefined') {
                    rootViewModel.currentEnvName(localStorage.getItem("standByNameParam"));
                    oj.Router.rootInstance.store(localStorage.getItem("standByNameParam"));
                    sessionStorage.setItem('isLastVisitedEnvStandby', "true");

                    if (localStorage.getItem("initialTabParam") === constants.navModules.standbyEnvSyncDetailsModule) {
                        sessionStorage.setItem('lastVisitedDetailTab', constants.navModules.standbyEnvSyncDetailsModule);
                    }
                } else {
                    oj.Router.rootInstance.store(localStorage.getItem("jobIdParam"));
                }
            }

            localStorage.removeItem('jobIdParam');
            localStorage.removeItem('initialPageParam');
            localStorage.removeItem('initialTabParam');
            localStorage.removeItem('standByNameParam');
        }

        var childRouterName = lastSelectedChildRouter ? lastSelectedChildRouter : globalChildRouter.states[0].id;
        helpMenu.addElementAndRemoveDuplicate(childRouterName);
        self.childRouterKO = ko.observable(childRouterName);
        if (bearerToken) {
            sessionStorage.setItem('bearerToken', bearerToken);
        } else {
            bearerToken = sessionStorage.getItem('bearerToken');
        }
        self.selectedNavItem(childRouterName);
        self.selectHandler = function (event, ui)
        {
            if ('menu' === event.target.id && event.detail.originalEvent)
            {
                // router takes care of changing the selection
                sessionStorage.setItem('lastSelectedChildRouterFromLandingPage', event.detail.key);
                var nextPage = event.detail.key;
                helpMenu.addElementAndRemoveDuplicate(nextPage);
                event.preventDefault();
                self.selectedNavItem(nextPage);
                self.childRouterKO(nextPage);
                self.toggleMenu();
            }


        };

        self.createOption = function (id, desc, childNodes) {
            return {
                value: id,
                label: desc,
                children: childNodes || null
            };
        }
        self.buildNavListData = function () {
            var jsonData = [];
            var isCMAdmin = userRole.isAdminUser();
            globalChildRouter.states.forEach(function (state) {
                //sub menu for Administration
                if ("cloudManagerAdministration" === state.id)
                {
                    var childrenData = [];
                    administrationChildRouter.states.forEach(function (c_state) {
                        if ("discovery" === c_state.id)
                        {
                            if (isDiscoveryEnabled)
                            {
                                childrenData.push({
                                    'attr': {
                                        id: c_state.id,
                                        label: c_state.label,
                                        href: "?root=" + c_state.id
                                    }
                                });
                            }
                        } else if (("executionFramework" !== c_state.id) || isCMAdmin)
                        {
                            childrenData.push({
                                'attr': {
                                    id: c_state.id,
                                    label: c_state.label,
                                    href: "?root=" + c_state.id
                                }
                            });
                        }
                    });
                    jsonData.push({
                        'attr': {
                            id: state.id,
                            label: state.label,
                            href: "?root=" + state.id
                        },
                        'children': childrenData
                    });
                } else
                {

                    jsonData.push({
                        'attr': {
                            id: state.id,
                            label: state.label,
                            href: "?root=" + state.id
                        }
                    });
                }

            });
            return jsonData;
        };

        self.envListPageNavData = new oj.JsonTreeDataSource(self.buildNavListData());

        self.menuDrawer =
                {
                    //  displayMode: 'push',
                    selector: '#menuDrawer',
                    content: '#mainContentCompartment',
                    //autoDismiss: 'none',
                    displayMode: 'overlay'
                };

        /* self.toggleMenu = function ()
         {
         $('#mainContentCompartment').toggleClass('ebs-content-panel-compress');
         if ($('#mainContentCompartment').hasClass('ebs-content-panel-compress'))
         {
         sessionStorage.setItem('isMenuInOpenState', 'Y');
         } else
         {
         sessionStorage.removeItem('isMenuInOpenState');
         }
         return oj.OffcanvasUtils.toggle(self.menuDrawer);
         };*/

        self.toggleMenu = function () {
            return oj.OffcanvasUtils.toggle(self.menuDrawer);
        };

        $(function () {
            /* var isMenuOpen = sessionStorage.getItem('isMenuInOpenState');
             if (isMenuOpen === 'Y')
             {
             self.toggleMenu();
             }  */

        });
    }
    ;

    return landingModuleContentViewModel;
});
