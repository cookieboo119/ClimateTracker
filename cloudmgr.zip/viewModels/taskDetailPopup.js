define(['ojs/ojcore', 'knockout', 'jquery', 'ebs/actions/actionsHelper', 'ebs/utils/backupEnvironmentHelper', 'ebs/popup/popupHelper',
    'ebs/constants', 'ojs/ojvalidator-regexp', 'ebs/navigation/pageNavigationHelper', 'ojs/ojarraydataprovider', 'ojs/ojinputtext', 'ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojfilepicker', 'ojs/ojtable', 'ojs/ojswitch'],
        function (oj, ko, $, actionsHelper, backupEnvironmentHelper, popupHelper, constants, RegExpValidator, pageNavigationHelper, ArrayDataProvider) {

            function TaskDetailsViewModel() {
                var self = this;
                console.log('Loading Task Details Popup View Model');
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.taskPopupTitle = ko.observable('Task Details');
                self.taskName = ko.observable();
                self.taskIdentifier = ko.observable();
                self.isSeededTask = ko.observable(false);
                self.taskDescription = ko.observable('');
                self.scriptToExecute = ko.observable();
                self.executeOnNodeSelected = ko.observable();
                self.isLCMActivity = ko.observable(false);
                self.uploadedFileName = ko.observable('');
                var params = new Array();
                self.nodesObservableArray = ko.observableArray(params);
                self.InputParametersDataProvider = new ArrayDataProvider(self.nodesObservableArray, {idAttribute: 'ParamName'});
                self.columnArray = [{"headerText": " Name",
                        "field": "ParamName",
                        "template": "ParamNameTemplate",
                        "headerStyle": "font-weight: bold"},
                    {"headerText": "Label",
                        "field": "ParamLabel",
                        "template": "ParamLabelTemplate",
                        "headerStyle": "font-weight: bold"},
                    {"headerText": "Sensitive",
                        "field": "ParamSensitive",
                        "template": "ParamSensitiveTemplate",
                        "headerStyle": "font-weight: bold"},
                    {"headerText": "Default Value",
                        "field": "ParamDefaultValue",
                        "template": "ParamDefaultValueTemplate",
                        "headerStyle": "font-weight: bold"}];

                self.openPopup = function (taskName,taskIdentifier, event) {
                    self.taskPopupTitle(taskName + " details");
                    self.taskIdentifier(taskIdentifier);
                    var popup = document.querySelector(constants.divTags.taskDetailPopupTag);
                    popup.open(event.target);
                    actionsHelper.getTaskDetail(taskIdentifier, function (error, taskDetail) {
                        if (error === null || error === '') {
                            self.taskName(taskDetail.name);
                            self.isSeededTask(taskDetail.type === 'Seeded');
                            self.taskDescription(taskDetail.label);
                            self.scriptToExecute(taskDetail.executableName);
                            self.isLCMActivity(taskDetail.isLCMActivity);
                            self.executeOnNodeSelected(taskDetail.executeOn);
                            self.uploadedFileName(taskDetail.libraryName);

                            var parameters = taskDetail.parameters;
                            for (var i = 0; i < parameters.length; i++) {
                                var node = new Object();
                                node.ParamName = parameters[i].name;
                                node.ParamLabel = parameters[i].label;
                                node.ParamSensitive = parameters[i].isSensitive;
                                node.ParamDefaultValue = parameters[i].defaultValue;
                                self.nodesObservableArray.push(node);
                            }
                        }
                    });
                };

                self.downloadSoftwareLibrary = function () {
                    actionsHelper.downloadSoftwareLibrary(self.uploadedFileName(), self.taskIdentifier(), function (error, downloadStatus) {
                        console.log('Download completed!');
                    });
                };

                self.closePopup = function () {
                    self.cleanUpViewModel();
                };

                self.cleanUpViewModel = function () {
                    self.taskName();
                    self.taskDescription('');
                    self.scriptToExecute();
                    self.isLCMActivity(false);
                    self.executeOnNodeSelected();
                    self.uploadedFileName('');
                    self.nodesObservableArray([]);
                };

            }

            return TaskDetailsViewModel;
        });
