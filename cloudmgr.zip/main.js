/**
 * Copyright (c) 2020, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
'use strict';
/**
 * Example of Require.js boostrap javascript
 */
 
/* global requirejs:false, define:false, Promise:false */
(function () {
 
  function _ojIsIE11() {
    var nAgt = navigator.userAgent;
    return nAgt.indexOf('MSIE') !== -1 || !!nAgt.match(/Trident.*rv:11./);
  };
  var _ojNeedsES5 = _ojIsIE11();
 
  requirejs.config({
      baseUrl: 'js',
    // Path mappings for the logical module names
    paths: 
       //injector:mainReleasePaths
       {
      'knockout': 'libs/knockout/knockout-3.5.1',
      'jquery': 'libs/jquery/jquery-3.5.1.min',
      'jqueryui-amd': 'libs/jquery/jqueryui-amd-1.12.1.min',
      'ojs': 'libs/oj/v10.0.0/debug' + (_ojNeedsES5 ? '_es5' : ''),
      'ojL10n': 'libs/oj/v10.0.0/ojL10n',
      'ojtranslations': 'libs/oj/v10.0.0/resources',
      'text': 'libs/require/text',
      'hammerjs': 'libs/hammer/hammer-2.0.8.min',
      'signals': 'libs/js-signals/signals.min',
      'ojdnd': 'libs/dnd-polyfill/dnd-polyfill-1.0.2.min',
      'css': 'libs/require-css/css.min',
      'customElements': 'libs/webcomponents/custom-elements.min',
      'proj4': 'libs/proj4js/dist/proj4',
      'touchr': 'libs/touchr/touchr',
      'corejs': 'libs/corejs/shim.min',
      'regenerator-runtime': 'libs/regenerator-runtime/runtime',
      'ebs': 'libs/ebs/v1.0.0',
      'cmconfig':'../ebscmui_properties'
    },
    //endinjector 
    // Shim configurations for modules that do not expose AMD
    shim: {
      jquery: {
        exports: ['jQuery', '$']
      }
    },
 
    // This section configures the i18n plugin. It is merging the Oracle JET built-in translation
    // resources with a custom translation file.
    // Any resource file added, must be placed under a directory named "nls". You can use a path mapping or you can define
    // a path that is relative to the location of this main.js file.
    config: {
      ojL10n: {
        merge: {
           'ojtranslations/nls/ojtranslations': 'ebs/resources/nls/translations'
        }
      },
      text: {
        // Override for the requirejs text plugin XHR call for loading text resources on CORS configured servers
        // eslint-disable-next-line no-unused-vars
        useXhr: function (url, protocol, hostname, port) {
          // Override function for determining if XHR should be used.
          // url: the URL being requested
          // protocol: protocol of page text.js is running on
          // hostname: hostname of page text.js is running on
          // port: port of page text.js is running on
          // Use protocol, hostname, and port to compare against the url being requested.
          // Return true or false. true means "use xhr", false means "fetch the .js version of this resource".
          return true;
        }
      }
    }
  });
 
 
  if (_ojNeedsES5) {
    define('polyfills', ['corejs', 'regenerator-runtime']);
  } else {
    define('polyfills', []);
  };
 
  define('promise', ['polyfills'], function () {
    Promise.polyfill = function () {};
    return Promise;
  });
}());

 
/**
 * A top-level require call executed by the Application.
 * Although 'ojcore' and 'knockout' would be loaded in any case (they are specified as dependencies
 * by the modules themselves), we are listing them explicitly to get the references to the 'oj' and 'ko'
 * objects in the callback
 */
require(['ojs/ojcore', 'knockout', 'appController', 'text!cmconfig.json', 'ojs/ojknockout', 'jquery', 
  'ojs/ojmodule', 'ojs/ojrouter', 'ojs/ojnavigationlist', 'ojs/ojbutton', 'ojs/ojtoolbar', "ojs/ojprogress-circle"],
  function (oj, ko, app, cmconfig) { // this callback gets executed when all required modules are loaded
 
    $(function() {
 
      function init() {
 
        oj.Router.sync().then(
          function () {
            
           /**
            * Proeprties file to control CM UI features
            */
           app.properties = new Map();
           try{
                if(cmconfig && cmconfig !== '')
                {
                    console.log('UI properties file detected: ' + cmconfig);
                    var properties = JSON.parse(cmconfig);
                    console.log(properties);
                    for(var key in properties)
                    {
                        app.properties.set(key, properties[key]);
                    }
                }
            }
            catch(e)
            {
                 oj.Logger.error('Error parsing UI properties file: ' + e);
            }
            
            console.log('Initializing the application Module..');
            app.username = ko.observable("");
            app.password = ko.observable("");
            app.provider = ko.observable("");
            app.tenancyNameValue = ko.observable();
            app.displayLoadingGif = ko.observable('block');
            app.tenancyOCID = ko.observable();
 
            app.userOCID = ko.observable();
            app.swiftPassword = ko.observable();
            app.apiKey = ko.observable();
            app.fingerprint = ko.observable();
            app.selectedRegionValue = ko.observable();
 
            app.fingerprint = ko.observable();
            app.apiKeySet = ko.observable();
            app.isKeyValid = ko.observable();
            app.copyrightInfo = ko.observable('Copyright &copy; 2020 Oracle and/or its affiliates. All rights reserved.');
            app.backupName = ko.observable('');
            app.showClone = ko.observable('');
            app.showBackup = ko.observable('');
            app.showDelete = ko.observable('');
            app.showCloneWlsAdminPwd = ko.observable('');
            app.currentPageHeader = ko.observable('Environments');
            app.currentPage = ko.observable('');
            app.activityDetailsParentPage = ko.observable('');
            app.envDetailsParentPage = ko.observable('');
            app.confirmationPopupTimeout = ko.observable(3000);
            app.displayPopupId = ko.observable('');
            app.displayConfirmMsg = ko.observable('');
            app.confirmationMsgorigin = ko.observable('');
            app.confirmationMsgCss = ko.observable('');
            app.confirmationMsgIcon = ko.observable('');
            app.showContextHeader = ko.observable(false);
            app.showNavTab = ko.observable(true);
            app.authToken = ko.observable("");
            app.prevEnvDetailsNavItem = ko.observable();    
            app.confirmRestartPage = ko.observable();
            app.currentEnvName = ko.observable();
            app.currentEnvVersion = ko.observable();
            app.cloneSourceEnv = ko.observable();
            app.isDetailPG = ko.observable(false);
            app.currentDbVersion = ko.observable();
            app.disableAdministrationTabForEnvionment = ko.observable(false);
            app.aboutMsg = ko.observable("The EBS Cloud Manager allows you to create, manage and configure Oracle E-Business Suite environments on Oracle Cloud. It is also used with the EBS Cloud Backup Utility to lift and shift environments from on-premises to Oracle Cloud.");
            app.currentNetworkName = ko.observable();
            app.prevNetworkDetailsNavItem = ko.observable();
            app.updateNetworkProfileFlow = ko.observable(false);
            app.networkProfileDetailsPGReadOnly = ko.observable(false);
            app.isDefaultNetworkProfile = ko.observable(false);
            app.standByEnvironmentName = ko.observable('');
            app.isStandbyEnv = ko.observable(); //do not default a value here
            
            //compartment
            app.selectedCompartment = ko.observable('All');
 
            //'true', read LCM activities from REST
            //'false', UI derives LCM activities
            app.lcmActivityFromREST = true;
            // Context for each page
            app.selectedContextPage = ko.observable();
            // Help doc from REST call
            app.helpDocument = ko.observable();
            // Help doc parsed
            app.helpFlatFile = ko.observable();
            
            var baseUrl = document.location.origin + "/";
            app.url = ko.observable(baseUrl);
            // Use this while testing locally.
            app.url = ko.observable("http://localhost:8000/"); 
            // Bind your ViewModel for the content of the whole page body.
            //ko            app.applyBindings(app, document.getElementById('mainBody'));
            ko.applyBindings(app);
          },
          function (error) {
            oj.Logger.error('Error in root start: ' + error.message);
          }
        );
      }
 
      // If running in a hybrid (e.g. Cordova) environment, we need to wait for the deviceready 
      // event before executing any code that might interact with Cordova APIs or plugins.
      if ($(document.body).hasClass('oj-hybrid')) {
        document.addEventListener("deviceready", init);
      } else {
        init();
      }
 
    });
 
  }
);
