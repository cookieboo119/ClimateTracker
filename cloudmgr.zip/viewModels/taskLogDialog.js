/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * task log module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton'], function (oj, ko, actionsHelper, popupHelper, constants) {
    /**
     * The view model for the main content view template
     */
    function taskLogContentViewModel()
    {
        var self = this;
        console.log('Loading Task Log Content Popup View Model');
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.taskHdrName = ko.observable('');
        self.isLoading = ko.observable(true);
        self.noLogFileFound = ko.observable(false);
        self.logFileContents = ko.observable('');


        self.fetchLogFile = function (taskIdentifier, taskName, jobId,stage)
        {
            var minHt = null;
            var safariBrowser = navigator.userAgent.indexOf("Safari");
            if(safariBrowser > 0)
            {
                var dialogContentElement = null;
                var childElem = document.getElementById('taskLogDialogBody');
                
                for(var i=0;i<5;i++)
                {
                    var parentElem = childElem.parentElement;
                    var className = parentElem.className;
                    if(className.indexOf('oj-dialog-content') >= 0)
                    {
                        dialogContentElement = parentElem;
                        break;
                    }
                    childElem = parentElem;
                }
                
                if(dialogContentElement !== null)
                {
                    var offsetHtOfContent = parseInt(dialogContentElement.offsetHeight);
                    var htOfTextContent = offsetHtOfContent - 35;
                    minHt = htOfTextContent + 'px';
                }
                
            }
            
            var keyOfTheRowSelected = taskIdentifier;
            self.taskHdrName(taskName);
            
            console.log('Key used to get the log file : ' + keyOfTheRowSelected);
            actionsHelper.getJobLogFile(stage, jobId, keyOfTheRowSelected, function (error, jobLog)
            {
                if (error === '')
                {
                    self.noLogFileFound(false);
                    self.logFileContents(jobLog);
                   

                    setTimeout(function () {
                        var logFileContentDOM = document.getElementById('textarea');
                        logFileContentDOM.focus();

                        if (!safariBrowser && typeof(logFileContentDOM.selectionStart) === 'number' && jobLog !== '')
                        {
                            logFileContentDOM.setSelectionRange(jobLog.length, jobLog.length);
                            console.log('Selection Start :: ' + document.getElementById('textarea').selectionStart);
                            console.log('Selection End :: ' + document.getElementById('textarea').selectionEnd);
                        }
                        else
                        {
                            logFileContentDOM.scrollTop = logFileContentDOM.scrollHeight;
                        }
                    }, 200);

                } else
                {
                    self.noLogFileFound(true);
                }
                self.isLoading(false);
                 if(minHt !== null)
                       document.getElementById('textarea').style.minHeight = minHt;
            });

        };

        self.handleTaskLogPopupClose = function ()
        {
            self.logFileContents('');
            var popup = document.querySelector(constants.divTags.taskLogPopupTag);
            popup.close();
        };

        self.handleTaskLogPopupOpen = function (event, ui, taskIdentifier, taskName, jobId,stage)
        {
            self.logFileContents('');
            self.isLoading(true);
            var popup = document.querySelector(constants.divTags.taskLogPopupTag);
            popup.open(event.target);
            self.fetchLogFile(taskIdentifier, taskName, jobId,stage);
        };

    }

    return taskLogContentViewModel;
});
