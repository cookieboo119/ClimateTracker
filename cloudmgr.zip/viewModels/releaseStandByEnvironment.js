define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper',
    'ebs/navigation/pageNavigationHelper', 'ebs/utils/dateTimeHelper', 'ebs/utils/networkProfileHelper',
    'ojs/ojarraydataprovider', 'ebs/utils/helpMenu', 'ojs/ojvalidator-regexp', 'ebs/utils/versionUtils',
    'ebs/utils/createCloneTrainUtils', 'viewModels/baseStandbyTrainViewModel', 'ojs/ojasyncvalidator-numberrange', 'jquery', 'ojs/ojmenu', 'ojs/ojpopup', 'ojs/ojtoolbar', 'ojs/ojnavigationlist',
    'ojs/ojselectcombobox', 'ojs/ojinputtext', 'ojs/ojknockout-validation', 'ojs/ojradioset', 'ojs/ojknockout',
    'ojs/ojtrain', 'ojs/ojmodule', 'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojcheckboxset', 'ojs/ojmessages', 'ojs/ojtable', 'ojs/ojvalidationgroup'],
        function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper, dateTimeHelper,
                networkProfileHelper, arrayDataProvider, helpMenu, RegExpValidator, versionUtils, createCloneUtils, baseViewModel)
        {

            function ReleaseStandByEnvironmentTrainViewModel()
            {
                var self = this;
                var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
                var envName = rootViewModel.standByEnvironmentName();
                rootViewModel.showNavTab(false);
                var actionName = 'release-standby';
                baseViewModel.call(self, actionName);
                self.title = ko.observable('Promote Standby Environment ' + envName);
                self.traincontext = ko.observable(actionName);

                self.stepArray()[0].label = oj.Translations.getTranslatedString('pageHeader.releaseStandByEnvTrainStepLabel');
                self.envNameInputValue(envName);
                self.dbSIDInputValue()

                self.handleBackLink = function (event, ui)
                {
                    self.handleBackLinkBaseFunction(event, ui, "releaseStandByEnvironmentTrainElement");
                };
                self.myName = function () {
                    return "release-standby";
                };


                self.cancel = function () {
                    self.handleBackLinkBaseFunction("releaseStandByEnvironmentTrainElement");
                };

                self.submitReleaseFromStandByRequest = function () {
                    self.disableSubmitBtn(true);
                    var infoMsg = oj.Translations.getTranslatedString("confirmPopup.releaseStandbyInfoMsg", {'envName': envName});
                    var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.releaseStandbyEnvTitle");
                    popupHelper.openInfoMsg(constants.divTags.releaseStandByEnvPopupTag, infoMsg, msgOrigin);
                    var activeDatabaseAdminPwd = self.activeDatabaseAdminPwd();
                    var activeDatabaseWalletPwd = self.activeDatabaseWalletPwd();
                    var standByEnvDatabaseAdminPwd = self.backupReEnterAdminPwd();
                    var standByEnvAppsPwd = self.appsPassword();
                    var standByEnvWLSPwd = self.weblogicPassword();
                    var selTagName = '';
                    var selTagKeyText = '';
                    var selTagKeySelect = '';
                    var selFreeTagValue = '';
                    var selTagValue = '';

                    var initialPageViewModel = ko.dataFor(document.getElementById(constants.divTags.envClonePage));


                    // Logic to set values for tag module
                    if (initialPageViewModel.selectedTagNamespace() === 'none') {
                        selFreeTagValue = initialPageViewModel.selectedTagValue();
                        selTagKeyText = initialPageViewModel.selectedTagKeyText();
                    } else {
                        selTagName = initialPageViewModel.selectedTagNamespace();
                        selTagKeySelect = initialPageViewModel.selectedTagKeySelect();
                        selTagValue = initialPageViewModel.selectedTagValue();
                    }
                    var requestBody =
                            {
                                "credentials": {
                                    "source": {
                                        "environment": {
                                            "sysUserPassword": activeDatabaseAdminPwd,
                                            "tdeWalletPassword": activeDatabaseWalletPwd
                                        }
                                    }
                                    ,
                                    "target": {
                                        "environment": {
                                            "databaseAdminPassword": standByEnvDatabaseAdminPwd,
                                            "appsPassword": standByEnvAppsPwd,
                                            "weblogicPassword": standByEnvWLSPwd
                                        },
                                        "ssh": {
                                            "appTier": [

                                            ],
                                            "dbTier": [

                                            ]
                                        }
                                    }
                                },
                                "target": {
                                    "environment": {
                                        "dbTier": {
                                            "compute": {
                                                "databaseName": self.dbSIDInputValue(),
                                                "logicalDomainName": self.dbLogicalDomainName() ? self.dbLogicalDomainName().toLowerCase() : self.dbLogicalDomainName(),
                                                "logicalHostName": (self.dbLogicalHostNamePrefixValue() ? self.dbLogicalHostNamePrefixValue().toLowerCase() : self.dbLogicalHostNamePrefixValue())
                                            }
                                        },
                                        "appTier": {
                                            "logicalDomainName": "",
                                            "primaryZone": {
                                                "webEntry": {

                                                },
                                                "primaryNode": {

                                                },
                                                "additionalNodes": [

                                                ]
                                            },
                                            "zones": [

                                            ]
                                        },
                                        "tags": {
                                            "freeFloat": [
                                                {
                                                    "key": selTagKeyText,
                                                    "value": selFreeTagValue
                                                }
                                            ],
                                            "defined": [
                                                {
                                                    "namespace": selTagName,
                                                    "key": selTagKeySelect,
                                                    "value": selTagValue
                                                }
                                            ]
                                        }
                                    }
                                }

                            };
                    
                    if(self.isDB19Cminimum()){
                        requestBody.target.environment.dbTier.compute.pdbName = self.computePDBName();
                    }

                    var appTierSSHKeys = createCloneUtils.getFormDataForAppTierSSHKeys();
                    if (appTierSSHKeys !== null && appTierSSHKeys.length > 0) {
                        requestBody.target.credentials.ssh.appTier = appTierSSHKeys;
                    }
                    var dbTierSSHKeys = createCloneUtils.getFormDataForDBTierSSHKeys();
                    if (dbTierSSHKeys !== null && dbTierSSHKeys.length > 0) {
                        requestBody.target.credentials.ssh.dbTier = dbTierSSHKeys;
                    }

                    var applicationTierGroups = requestBody.target.environment.appTier.zones;
                    var topologyDetailsViewModel = ko.dataFor(document.getElementById('zonesListView'));
                    var appLogicalDomain = topologyDetailsViewModel.getAppsLogicalDomain();
                    requestBody.target.environment.appTier.logicalDomainName = appLogicalDomain ? appLogicalDomain.toLowerCase() : appLogicalDomain;
                    var zonesPostInformation = topologyDetailsViewModel.getZonePostData();
                    if (zonesPostInformation !== null && zonesPostInformation.length > 0)
                    {
                        // First Zone.
                        var firstZoneInformation = zonesPostInformation[0];
                        requestBody.target.environment.appTier.primaryZone.name = firstZoneInformation.name;
                        requestBody.target.environment.appTier.primaryZone.fileSystemType = firstZoneInformation.fileSystemType;
                        requestBody.target.environment.appTier.primaryZone.webEntry.type = firstZoneInformation.webEntry.type;
                        requestBody.target.environment.appTier.primaryZone.webEntry.domain = firstZoneInformation.webEntry.domain;
                        requestBody.target.environment.appTier.primaryZone.webEntry.host = firstZoneInformation.webEntry.host;
                        requestBody.target.environment.appTier.primaryZone.webEntry.port = firstZoneInformation.webEntry.port;
                        requestBody.target.environment.appTier.primaryZone.webEntry.protocol = firstZoneInformation.webEntry.protocol;
                        if (typeof (firstZoneInformation.webEntry.newLBaaS) !== 'undefined') {
                            requestBody.target.environment.appTier.primaryZone.webEntry.newLBaaS = firstZoneInformation.webEntry.newLBaaS;
                        }
                        requestBody.target.environment.appTier.primaryZone.primaryNode.logicalHostName = firstZoneInformation.nodes[0].logicalHostName;
                        var nodesArray = firstZoneInformation.nodes;
                        nodesArray.shift();
                        requestBody.target.environment.appTier.primaryZone.additionalNodes = nodesArray;

                        // Rest of the Zones. 
                        for (var i = 1; i < zonesPostInformation.length; i++)
                        {
                            applicationTierGroups.push(zonesPostInformation[i]);
                        }
                    }

                    var executionFrameworkPGViewModel = ko.dataFor(document.getElementById('customTasksListingTab'));
                    if (typeof (executionFrameworkPGViewModel) !== 'undefined') {
                        var formDataForSubmit = executionFrameworkPGViewModel.getExtensibleTasksFormData();
                        requestBody.target.environment.extensibleTasks = formDataForSubmit;
                        var pausedTasks = executionFrameworkPGViewModel.getPausedTasksFormData();
                        if (pausedTasks !== null) {
                            requestBody.target.environment.pauseAt = pausedTasks;
                        }
                    }


                    var requestBodyJSON = JSON.stringify(requestBody);
                    actionsHelper.promoteStandByEnv(envName,requestBodyJSON, function (error, success)
                    {
                        if (error === '')
                        {
                            self.disableSubmitBtn(false);
                            var context = ko.contextFor(document.getElementById("releaseStandByEnvironmentTrainElement"));
                            rootViewModel.displayPopupId(constants.divTags.releaseStandByEnvPopupTag);
                            var confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.releaseStandbySuccessMsg", {'envName': envName});
                            popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);
                            pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                        } else
                        {
                            self.disableSubmitBtn(false);
                            var responseText = error.responseText;
                            var response = JSON.parse(responseText);
                            popupHelper.openErrorMsg(constants.divTags.releaseStandByEnvPopupTag, response.message, msgOrigin);
                        }
                    });
                };

            }

            return ReleaseStandByEnvironmentTrainViewModel;
        });
