define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper',
    'ebs/navigation/pageNavigationHelper', 'ebs/utils/dateTimeHelper', 'ebs/utils/networkProfileHelper',
    'ojs/ojarraydataprovider', 'ebs/utils/helpMenu', 'ojs/ojvalidator-regexp', 'ebs/utils/versionUtils',
    'ebs/utils/createCloneTrainUtils', 'viewModels/baseStandbyTrainViewModel', 'ojs/ojasyncvalidator-numberrange', 'jquery', 'ojs/ojmenu', 'ojs/ojpopup', 'ojs/ojtoolbar', 'ojs/ojnavigationlist',
    'ojs/ojselectcombobox', 'ojs/ojinputtext', 'ojs/ojknockout-validation', 'ojs/ojradioset', 'ojs/ojknockout',
    'ojs/ojtrain', 'ojs/ojmodule', 'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojcheckboxset', 'ojs/ojmessages', 'ojs/ojtable', 'ojs/ojvalidationgroup'],
        function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper, dateTimeHelper,
                networkProfileHelper, arrayDataProvider, helpMenu, RegExpValidator, versionUtils, createCloneUtils, baseViewModel)
        {

            function CloneStandByEnvironmentTrainViewModel()
            {
                var self = this;
                var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
                var envName = rootViewModel.standByEnvironmentName();
                var actionName = 'clone-standby';
                baseViewModel.call(self, actionName);
                self.title = ko.observable('Clone Standby Environment ' + envName);
                self.traincontext = ko.observable(actionName);

                self.handleBackLink = function (event, ui) {
                    self.handleBackLinkBaseFunction(event, ui, "cloneStandByEnvironmentTrainElement");
                };

                self.myName = function () {
                    return "clone-standby";
                };


                self.cancel = function () {
                    self.cancelBaseFunction("cloneStandByEnvironmentTrainElement");
                };


                self.submitCloneFromStandByRequest = function () {
                    var infoMsg = oj.Translations.getTranslatedString("confirmPopup.cloneStandbyInfoMsg", {'envName': envName});
                    var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.cloneStandbyEnvTitle");
                    popupHelper.openInfoMsg(constants.divTags.cloneStandByEnvPopupTag, infoMsg, msgOrigin);
                    var requestBody =
                            {
                                "environment": {
                                    "name": envName
                                },
                                "advanced": {
                                    "rman": {

                                    }
                                }
                            };
                    var requestBodyJSON = JSON.stringify(requestBody);
                    actionsHelper.cloneStandbyEnv(requestBodyJSON, function (error, success)
                    {
                        if (error === '')
                        {
                            var context = ko.contextFor(document.getElementById("cloneStandByEnvironmentTrainElement"));
                            rootViewModel.displayPopupId(constants.divTags.cloneStandByEnvPopupTag);
                            var confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.cloneStandbySuccessMsg", {'envName': envName});
                            popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);
                            pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                        } else
                        {
                            self.disableSubmitBtn(false);
                            var responseText = error.responseText;
                            var response = JSON.parse(responseText);
                            popupHelper.openErrorMsg(constants.divTags.cloneStandByEnvPopupTag, response.message, msgOrigin);
                        }
                    });
                };

            }

            return CloneStandByEnvironmentTrainViewModel;
        });
