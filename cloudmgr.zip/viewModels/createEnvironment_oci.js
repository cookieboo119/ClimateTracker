
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper',
    'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper',
    'ebs/utils/dateTimeHelper', 'ebs/utils/networkProfileHelper', 'ojs/ojarraydataprovider',
    'ebs/utils/helpMenu', 'ojs/ojvalidator-regexp', 'ojs/ojasyncvalidator-numberrange',
    'ebs/utils/versionUtils', 'ebs/utils/createCloneTrainUtils', 'ebs/utils/lovUtils', 'jquery', 'ojs/ojmenu',
    'ojs/ojpopup', 'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojselectcombobox', 'ojs/ojinputtext',
    'ojs/ojknockout-validation', 'ojs/ojradioset', 'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojmodule',
    'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojcheckboxset', 'ojs/ojmessages',
    'ojs/ojtable', 'ojs/ojvalidationgroup', 'ojs/ojvalidator', "jet-composites/compartment-lov/loader" ],
        function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper,
                dateTimeHelper, networkProfileHelper, ArrayDataProvider,
                helpMenu, RegExpValidator, AsyncNumberRangeValidator, versionUtils, createCloneUtils, lovUtils)
        {

            function createEnvironmentViewModel()
            {
                var self = this;
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.provisionEnvPageHeader'));
                rootViewModel.currentPage('advanced');
                rootViewModel.showNavTab(false);
                var appUrl = rootViewModel.url();
                var backupName = rootViewModel.backupName();
                var isDetailPG = rootViewModel.isDetailPG();
                var dbEditionsMap = new Object();
                self.traincontext = ko.observable('create');
                self.disableNextBtn = ko.observable(false);
                self.disablePrevBtn = ko.observable(false);
                var VIS_SID = constants.dbSids.vis;
                var PRD_SID = constants.dbSids.prd;
                var NEW_INSTALLATION = constants.installationTypes.freshInstallation;
                var FROM_BACKUP = constants.installationTypes.backup;
                var loadingOption = new Object();
                loadingOption.label = 'loading...';
                loadingOption.value = '';
                var loadingOptionList = new Array();
                loadingOptionList[0] = loadingOption;
                var emptyOption = new Object();
                emptyOption.label = '';
                emptyOption.value = '';
                var emptyOptionList = new Array();
                emptyOptionList[0] = emptyOption;
                var loading = oj.Translations.getTranslatedString('info.loading');
                var passwdMismatchMsg = oj.Translations.getTranslatedString('validationMsgs.passwordMismatch');
                var licenseTypeChanged = false;
                self.isExternalZoneAllowed = ko.observable(true);
                // Error Messages.

                self.pageLevelMessages = ko.observableArray([]);
                self.isProvisioningFromBackup = ko.observable('false');
                self.isProvisioningFromTDEEnabledBackup = ko.observable('false');
                self.backupAdminPwd = ko.observable('');
                self.backupReEnterAdminPwd = ko.observable('');
                self.renderTDECheckBox = ko.observable('false');
                self.renderBackupAdminPwdFields = ko.observable('false');
                self.TDECheckBoxOptionValue = ko.observableArray(['N']);
                self.exaDataDBPSUValidationTimer = null;
                self.vmDBPSUValidationTimer = null;
                var allDBVersions = [];
                var dbVersionsExcepteleventwofour = [];
                var softwareEditionValueLabelMap = [];
                self.useInternalValueForValidation = false;
                self.getDefaultEnvName = function ()
                {
                    var defaultSuffix = dateTimeHelper.getDefaultDateBasedSuffixForResourceNames();
                    var envName = 'env' + defaultSuffix;
                    return envName;
                };
                self.selected = ko.observable(constants.navModules.installationDetailsModule);
                self.currentStep = ko.observable(constants.navModules.installationDetailsModule);
                self.tracker = ko.observable();
                self.focusListItemInReviewPage = ko.observable(false);
                self.prevPage = ko.observable(oj.Translations.getTranslatedString('pageHeader.envListPageHeader'));
                self.currentModule = ko.observable(self.currentStep());
                self.sshKeyChoiceOptionsList = ko.observableArray();
                self.lbIPResList = ko.observableArray();
                self.appTierIPResList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.dbTierIPResList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.stepArray = ko.observableArray([
                    {label: oj.Translations.getTranslatedString('pageHeader.installationDetails'), id: constants.navModules.installationDetailsModule, rank: 0, disabled: false},
                    {label: oj.Translations.getTranslatedString('pageHeader.dbTier'), id: constants.navModules.dbTierDetailsModule, rank: 1, disabled: false},
                    {label: oj.Translations.getTranslatedString('pageHeader.topology'), id: constants.navModules.topologyDetailsModule, rank: 2, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.postProvisioningOptions'), id: constants.navModules.postProvisioningStepsModule, rank: 3, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.uploadKeys'), id: constants.navModules.uploadKeysModule, rank: 4, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.review'), id: constants.navModules.reviewModule, rank: 5, disabled: true}
                ]);
                self.nameToRankMap = new Map();
                for (var i = 0; i < self.stepArray().length; i++)
                {
                    self.nameToRankMap.set(self.stepArray()[i].id, self.stepArray()[i].rank);
                }

                self.showComputeSetDB = ko.observable('inline');
                self.showExaSetDB = ko.observable('none');
                self.showNewInstallationPrompts = ko.observable('inline');
                self.showBackupInstallationPrompts = ko.observable('none');
                self.showCloneInstallationPrompts = ko.observable('none');
                self.purposeChoiceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.purposeChoiceOptionsDataProvider = new ArrayDataProvider(self.purposeChoiceOptionsList, {idAttribute: 'value'});
                self.ebsVerChoiceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.ebsVerChoiceOptionsDataProvider = new ArrayDataProvider(self.ebsVerChoiceOptionsList, {idAttribute: 'value'});
                self.ebsVersionsDataAll = ko.observable('');
                self.dbVerChoiceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.dbVerChoiceOptionsDataProvider = new ArrayDataProvider(self.dbVerChoiceOptionsList, {idAttribute: 'value'});
                self.envChoiceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.envValue = ko.observable('');
                self.networkProfileList = ko.observableArray([]);
                self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
                self.selectedNetworkProfileName = ko.observable('');
                //Default Options

                self.envNameInputValue = ko.observable('');
                self.vcnValue = ko.observable('');
                self.selectedPurposeValue = ko.observable('');
                self.freshEBSVerValue = ko.observable('');
                self.freshDBReleaseValue = ko.observable('');
                self.backupEBSVerValue = ko.observable('');
                self.backupDBReleaseValue = ko.observable('');
                self.selectedEbsVerValue = ko.observable('');
                self.selectedDBReleaseValue = ko.observable('');
                self.dataBaseNameInputValue = ko.observable(VIS_SID);
                self.dbcsSelectedShapeValue = ko.observable();
                self.databaseTypeUsed = ko.observable('Compute');
                self.selectedLoadBalancerShapeValue = ko.observable('');
                self.dbCompSelectedShapeValue = ko.observable('');
                self.plugDataBaseInputValue = ko.observable('');
                self.selectedBackUpValue = ko.observable('');
                self.exaDBSystemPSU = ko.observable('');
                self.faultDomainSelectionCompute = ko.observable('Auto');
                self.faultDomainSelectionVMDB = ko.observable('Auto');
                self.faultDomainSelectionAppTier = ko.observable('Auto');
                self.networkProfileDisabled = ko.observable(true);
                self.networkProfileNameValidationMsg = ko.observableArray([]);
                self.dbLogicalDomainCustomMsg = ko.observableArray([]);

                //logical host/domain feature
                var bypassHostnameValidation = rootViewModel.properties.has("hostname_validation_enabled") ?
                        (rootViewModel.properties.get("hostname_validation_enabled") === false) : false;
                self.dbLogicalHostNamePrefixValue = ko.observable('');
                self.dbLogicalDomainName = ko.observable('');
                self.vmdbLogicalHostNamePrefixValue = ko.observable('');
                self.vmdbLogicalDomainName = ko.observable('');
                var DBLogicalHostDomainOverallLengthValidator = function ()
                {};
                oj.Object.createSubclass(DBLogicalHostDomainOverallLengthValidator, oj.Validator, "DBLogicalHostDomainOverallLengthValidator");
                DBLogicalHostDomainOverallLengthValidator.prototype.validate = function (value)
                {
                    if (!value || value === '')
                        return true;
                    
                   if(value.indexOf(" ") >= 0)
                   {
                       var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameContainsWhiteSpaceMsg');
                       throw new Error(dbLogicalDomainCustomMsg);
                   }
                   
                   //not start or end with dot (.)
                   if(value.indexOf(".") === 0 || value.indexOf(".") === (value.length - 1))
                   {
                       var logicalDomainCustomMsg =  oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                       throw new Error(logicalDomainCustomMsg);
                   }
                   
                   //max domain value length is 128
                    if(value.length > 128)
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameLengthValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }

                    //last character of domain value cannot be number               
                    if(!isNaN(value.charAt(value.length -1)))
                    {
                        var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameLastCharacterValidationMsg')
                        throw new Error(logicalDomainCustomMsg);
                    }
                   
                   var segments = value.split(".");
                   for(var i=0; i<segments.length ; i++)
                   {
                       var segment = segments[i];
                       if(segment)
                       {
                           if(segment.length > 63)
                           {
                              var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentExceedsMaxLengthMsg');
                              throw new Error(dbLogicalDomainCustomMsg);
                           }
                           
                            if ((segment.indexOf("-") === 0) ||
                                    (segment.indexOf("-") === (segment.length - 1)))
                            {
                                var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameSegmentNotStartEndWithHyphenMsg');
                                throw new Error(dbLogicalDomainCustomMsg);
                            }
                            //check for special charactors
                            var pattern = new RegExp('^(?:([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[A-Za-z0-9]))$');
                            if (!pattern.test(segment))
                            {
                                var logicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainNameValidationMsg')
                                throw new Error(logicalDomainCustomMsg);
                            }
                        }
                    }

                    var totalLength = value.length;
                    if (self.dbLogicalHostNamePrefixValue())
                        totalLength += self.dbLogicalHostNamePrefixValue().length;
                    if (totalLength > 255)
                    {
                        var dbLogicalDomainCustomMsg = oj.Translations.getTranslatedString('validationMsgs.logicalDomainHostNameExceedsMaxLengthMsg');
                        throw new Error(dbLogicalDomainCustomMsg);
                    }

                    return true;
                };

                var DBLogicalHostDuplicateValidator = function ()
                {};
                oj.Object.createSubclass(DBLogicalHostDuplicateValidator, oj.Validator, "DBLogicalHostDuplicateValidator");
                DBLogicalHostDuplicateValidator.prototype.validate = function (value)
                {
                    //compare against DB tier logical host prefix
                    if (!value || value === '')
                        return true;

                    var dbType = self.dbTypeUsed();
                    var topologyDetailsViewModel = ko.dataFor(document.getElementById('zonesListView'));
                    if (topologyDetailsViewModel)
                    {
                        var appsLHNArray = topologyDetailsViewModel.getAllAppsLogicalHostname();
                        if (appsLHNArray && appsLHNArray.length > 0)
                        {
                            if (dbType === 'Compute')
                            {
                                if (self.isDuplicateLogicalHostNameValue(appsLHNArray, value))
                                    throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'));
                            } else if (dbType === 'VMDB System')
                            {
                                //comment out following code as logical host is not yet supported in vmdb
                                /*dbPrefix =  self.vmdbLogicalHostNamePrefixValue();
                                 if(self.dbNodesObservableArray().length > 1)
                                 {
                                 if(self.isDuplicateLogicalHostNameValue(appsLHNArray, value+"01", value+"02"))
                                 throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg'));
                                 }
                                 else
                                 {
                                 if(self.isDuplicateLogicalHostNameValue(appsLHNArray, value))
                                 throw new Error(oj.Translations.getTranslatedString('validationMsgs.logicalHostNameAppTierDuplicateMsg')); 
                                 }*/
                            }
                        }
                    }

                    return true;
                };

                self.isDuplicateLogicalHostNameValue = function (appsLHNArray, dbLHN, dbLHN1)
                {
                    var isDuplicate = false;
                    for (var i = 0; i < appsLHNArray.length; i++)
                    {
                        var appNodeCount = appsLHNArray[i].length;
                        outterloop:
                                for (var j = 0; j < appNodeCount; j++)
                        {
                            var appNodeLogicalHost = appsLHNArray[i][j];
                            if ((dbLHN.toLowerCase() === appNodeLogicalHost.toLowerCase()) ||
                                    (dbLHN1 && dbLHN1.toLowerCase() === appNodeLogicalHost.toLowerCase()))
                            {
                                isDuplicate = true;
                                break outterloop;
                            }
                        }


                    }
                    return isDuplicate;
                };

                self.dbLogicalHostNamePrefixValidator = [
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^(?:([a-zA-Z]|[a-zA-Z][a-zA-Z0-9]{0,26}[A-Za-z0-9]))$',
                                hint: oj.Translations.getTranslatedString('validationMsgs.logicalHostPrefixValidationMsg'),
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.logicalHostPrefixValidationMsg')
                            })),
                    new DBLogicalHostDuplicateValidator()
                ];


                self.dbLogicalHostNameValidator = [
                    (bypassHostnameValidation ? '' :
                            new RegExpValidator({
                                pattern: '^(?:([a-zA-Z]|[a-zA-Z][a-zA-Z0-9]{0,28}[A-Za-z0-9]))$',
                                hint: oj.Translations.getTranslatedString('validationMsgs.logicalHostNameValidationMsg'),
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.logicalHostNameValidationMsg')
                            })),
                    new DBLogicalHostDuplicateValidator()
                ];

                self.dbLogicalDomainNameValidator = [
                    (bypassHostnameValidation ? '' : new DBLogicalHostDomainOverallLengthValidator())
                ];

                self.compartmentList = ko.observableArray([{
                        'label': loading,
                        'value': ''
                    }]);
              /*  self.compartmentList.subscribe(function(changes)
                {
                    console.log("compartmentList is changed");
                    var firstItem = self.compartmentList()[0];
                    if (firstItem !== null && typeof (firstItem) !== 'undefined' && firstItem !== '')
                    {
                      var value = firstItem['value']
                      self.selectedCompartment(firstItem['value']);
                      console.log("set value to " + value)
                    }
                    
                }); */
            
                self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, {idAttribute: 'value'});
                
                self.selectedBackupRestoreCompartment = ko.observable('Loading...');
                self.nonHierarchicalCompList = ko.observableArray([]);
                self.selectedCompartment = ko.observable('');
                self.selectedRestoreCompartment = ko.observable('');
                self.backupCompartmentReadOnly = ko.observable(false);
                self.displayBackupCompartment = ko.computed(function ()
                {
                    return  self.backupCompartmentReadOnly() ? '' : 'none';
                });
                self.displayCompartment = ko.computed(function ()
                {
                    return  self.backupCompartmentReadOnly() ? 'none' : '';
                });
                actionsHelper.getCompartmentListForTenancy(function (error, compartmentsList) {
                    if (error !== null && error !== '') {
                        console.log('Error in fetching Compartment List for tenancy =>' + error);
                    } else {
                        self.compartmentList.removeAll();
                        self.compartmentDataProvider = null;
                        self.nonHierarchicalCompList.removeAll();
                        //var hierarchialList = getCompartmentLOVHierarchy(compartmentsList, rootViewModel.tenancyOCID());
                        var flatList =  getFlatListFromHierarchicalLov(compartmentsList, rootViewModel.tenancyOCID());
                        var nonHierarchicalList = getCompartmentLOVHierarchy(compartmentsList);
                        //self.compartmentList(hierarchialList);
                        self.compartmentList(flatList);
                        self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.compartmentList(), self.selectedCompartment);
                        lovUtils.lovOptionsUpdated(self.compartmentList(), self.selectedRestoreCompartment);
                        self.nonHierarchicalCompList(nonHierarchicalList);

                    }
                    console.log('Compartment List after the fetch -' + self.compartmentList());
                });

                self.populateNetworkProfileList = function (networkProfileList)
                {
                    self.networkProfileList.removeAll();
                    self.networkProfileDataProvider = null;
                    var list = new Array();
                    for (var i = 0; i < networkProfileList.length; i++)
                    {
                        var profileName = networkProfileList[i];
                        var listEntry = new Object();
                        listEntry.label = profileName;
                        listEntry.value = profileName;
                        list[i] = listEntry;
                    }
                    if (list.length > 0)
                    {
                        self.networkProfileList(list);
                        self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.networkProfileList(), self.selectedNetworkProfileName);
                    } else
                    {
                        self.networkProfileList([{'label': '', 'value': 'LOADING'}]);
                        self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.networkProfileList(), self.selectedNetworkProfileName);
                        var networkProfileNameValidationCustomMsg = oj.Translations.getTranslatedString('validationMsgs.lovValueNotFoundMsg', {lovName: 'network profile'});
                        var validationMsg = {summary: networkProfileNameValidationCustomMsg,
                            detail: networkProfileNameValidationCustomMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                        self.networkProfileNameValidationMsg([validationMsg]);
                    }
                }

                self.compartmentValueHandler = function (event, ui)
                {
                    var value = event['detail'].value;
                    if (!value || value === '')
                        return;
                    //enable network profile input
                    self.networkProfileDisabled(false);
                    self.networkProfileNameValidationMsg([]);
                    self.networkProfileList([{'label': loading, 'value': 'LOADING'}]);
                    self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.networkProfileList(), self.selectedNetworkProfileName);
                    actionsHelper.getNetworkProfilesForUser(value, function (error, networkProfileList)
                    {
                        if (!error || error === '') {
                            self.populateNetworkProfileList(networkProfileList);
                        } else {
                            console.log('Caught error for getting network profile list: error code =' + error.status);
                        }
                    });
                }

                /**
                 * Installation Details
                 */
                self.backupBucketFullList = ko.observableArray([]);
                self.backupBucketList = ko.observableArray([]);
                self.backupBucketDataProvider = new ArrayDataProvider(self.backupBucketList, {idAttribute: 'value'});
                self.backupBucket = ko.observable(backupName);
                self.backupBucketName = ko.observable(loading);
                self.backupBucketDisabled = ko.observable(backupName !== '' ? false : true);
                self.backupBucketValidationMsg = ko.observableArray([]);
                self.backupPassword = ko.observable('');
                self.backupAppsPassword = ko.observable('');
                self.backupWeblogicPassword = ko.observable('');
                self.showBackupWlsAdminPwd = ko.observable(false);
                self.sourceWalletPassword = ko.observable('')
                self.showSourceWalletPassword = ko.observable(false);
                self.isMultiTenant = ko.observable(false);
                self.backupPwdValidationMsg = ko.observable();
                self.backupAppsPwdValidationMsg = ko.observable();
                self.srcWalletPwdValidationMsg = ko.observable();
                self.wlsPwdValidationMsg = ko.observable();
                self._failedPwdValidations_Backups = new Array();
                /**
                 * DB Tier details
                 */
                self.previousInputParamsForVMDBPSU = new Array();
                self.previousInputParamsForExaDataPSU = new Array();
                self.vmdbPSUList = ko.observableArray();
                self.vmdbPSUList(loadingOptionList);
                self.vmdbPSUDataProvider = new ArrayDataProvider(self.vmdbPSUList, {idAttribute: 'value'});
                self.vmDBSystemPSU = ko.observable('');
                lovUtils.lovOptionsUpdated(self.vmdbPSUList(), self.vmDBSystemPSU);
                self.vmDBLatestPatchValidationMsg = ko.observable();
                self.TDEEnablementMsg = ko.observable();
                self.exaDBSystemInputValue = ko.observable('');
                self.exaDBSystemAdminPassword = ko.observable('');
                self.exaDBSystemAdminConfirmedPassword = ko.observable('');
                self.newDBSystemName = ko.observable('');
                self.dbSystemShapeChoiceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.exadataLatestPatchValidationMsg = ko.observable();
                self.exaDBSystemUnavailableMsg = ko.observable();
                self.dbSIDInputValue = ko.observable();
                self.diskRedundancySelected = ko.observable();
                self.diskRedundancyChoiceOptionsList = ko.observableArray();
                self.exaDBName = ko.observable();
                self.exaDBPDBName = ko.observable();
                self.showPDBPrompt = ko.observable('Yes');
                self.showPDBPromptForCompute = ko.observable('No');
                self.computePDBName = ko.observable('');
                self.exaSelectedBackupChannelCount = ko.observable(constants.rman.defaultChannelCountForExa);
                self.advancedOptionsDisplayed_Exa = ko.observable(false);

                self.vmdbSelectedBackupChannelCount = ko.observable();
                self.advancedOptionsDisplayed_vmdb = ko.observable(false);

                self.computeSelectedBackupChannelCount = ko.observable();
                self.advancedOptionsDisplayed_compute = ko.observable(false);

                self.SHOW_ADVANCED_OPTIONS_TEXT = "Show Advanced Options";
                self.HIDE_ADVANCED_OPTIONS_TEXT = "Hide Advanced Options";
                self.advancedOptionsAnchorText_compute = ko.observable(self.SHOW_ADVANCED_OPTIONS_TEXT);
                self.advancedOptionsAnchorText_vmdb = ko.observable(self.SHOW_ADVANCED_OPTIONS_TEXT);
                self.advancedOptionsAnchorText_exa = ko.observable(self.SHOW_ADVANCED_OPTIONS_TEXT);

                var ExaDBPasswdvalidator = function ()
                {};
                oj.Object.createSubclass(ExaDBPasswdvalidator, oj.Validator, "ExaDBPasswdvalidator");
                self.exaDBPasswdvalidator = [new ExaDBPasswdvalidator()];
                var VMDBPasswdvalidator = function ()
                {};
                oj.Object.createSubclass(VMDBPasswdvalidator, oj.Validator, "VMDBPasswdvalidator");
                self.vmDBPasswdvalidator = [new VMDBPasswdvalidator()];
                var DBSystemPasswdvalidator = function ()
                {};
                var VMDBCharacterPasswdvalidator = function ()
                {};
                oj.Object.createSubclass(VMDBCharacterPasswdvalidator, oj.Validator, "VMDBCharacterPasswdvalidator");
                self.vmDBCharacterPasswdvalidator = [new VMDBCharacterPasswdvalidator()];
                oj.Object.createSubclass(DBSystemPasswdvalidator, oj.Validator, "DBSystemPasswdvalidator");
                self.dbSystemPasswdvalidator = [new DBSystemPasswdvalidator()];
                var DBPasswdCharactervalidator = function ()
                {};
                oj.Object.createSubclass(DBPasswdCharactervalidator, oj.Validator, "DBPasswdCharactervalidator");
                self.dbPasswdCharactervalidator = [new DBPasswdCharactervalidator()];
                var PDBNameValidator = function ()
                {};
                oj.Object.createSubclass(PDBNameValidator, oj.Validator, "PDBNameValidator");
                var ExaDBCharacterPasswdvalidator = function ()
                {};
                oj.Object.createSubclass(ExaDBCharacterPasswdvalidator, oj.Validator, "ExaDBCharacterPasswdvalidator");
                self.exaDBPasswdCharactervalidator = [new ExaDBCharacterPasswdvalidator()];
                self.pdbNameValidator = [new PDBNameValidator()];
                self.softEditionDispValue = ko.observable('');
                var ExaDBPDBNameValidator = function ()
                {};
                oj.Object.createSubclass(ExaDBPDBNameValidator, oj.Validator, "ExaDBPDBNameValidator");
                self.exaDBPDBNameValidator = [new ExaDBPDBNameValidator()];
                var ComputePDBNameValidator = function ()
                {};
                oj.Object.createSubclass(ComputePDBNameValidator, oj.Validator, "ComputePDBNameValidator");
                self.computePdbNameValidator = [new ComputePDBNameValidator()];
                var EnvNameValidator = function ()
                {};
                oj.Object.createSubclass(EnvNameValidator, oj.Validator, "EnvNameValidator");
                self.envNameValidator = [new EnvNameValidator()];
                var BackupPasswordValidator = function ()
                {};
                oj.Object.createSubclass(BackupPasswordValidator, oj.Validator, "BackupPasswordValidator");
                self.backupPasswordValidator = [new BackupPasswordValidator()];
                //VMDB Details

                self.vmDBSystemAdminPassword = ko.observable('');
                self.vmDBSystemAdminConfirmedPassword = ko.observable('');
                self.vmDBName = ko.observable();
                self.vmDBPDBName = ko.observable();
                self.vmdbSelectedShapeValue = ko.observable();
                self.vmDBSoftwareEdition = ko.observable();
                self.vmdbLicenseType = ko.observable('LICENSE_INCLUDED');
                self.vmdbShapeList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.vmdbShapeListDataProvider = new ArrayDataProvider(self.vmdbShapeList, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.vmdbShapeList(), self.vmdbSelectedShapeValue);
                self.vmdbEditions = ko.observableArray([{'label': loading, 'value': ''}]);
                self.vmdbEditionsDataProvider = new ArrayDataProvider(self.vmdbEditions, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.vmdbEditions(), self.vmDBSoftwareEdition);
                self.vmdbNodeCountList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.vmdbNodeCountDataProvider = new ArrayDataProvider(self.vmdbNodeCountList, {idAttribute: 'value'});
                self.vmdbNodeCount = ko.observable();
                lovUtils.lovOptionsUpdated(self.vmdbNodeCountList(), self.vmdbNodeCount);
                self.clusterName = ko.observable();
                self.showClusterName = ko.observable('No');
                self.totalStorage = ko.observable('');
                /**
                 * App Tier details
                 */
                self.appSelectedShapeValue = ko.observable('');
                self.faultDomainChoiceList = ko.observableArray();
                self.faultDomainChoiceDataProvider = new ArrayDataProvider(self.faultDomainChoiceList, {idAttribute: 'value'});
                var appNodesArray = [{RowId: ko.observable(1), faultDomain: ko.observable('')}];
                self.appNodesObservableArray = ko.observableArray(appNodesArray);
                self.appNodesDataProvider = new ArrayDataProvider(self.appNodesObservableArray, {keyAttributes: 'RowId'});
                var dbNodesArray = [{RowId: ko.observable(1), faultDomain: ko.observable(''), faultDomainChoiceList: self.faultDomainChoiceDataProvider}];
                self.dbNodesObservableArray = ko.observableArray(dbNodesArray);
                self.dbNodesDataProvider = new ArrayDataProvider(self.dbNodesObservableArray, {keyAttributes: 'RowId'});
                self.computeSelectedFaultDomain = ko.observable('');
                /**
                 *Web Entry details 
                 */

                self.webEntryProtocolInputValue = ko.observable();
                self.webEntryProtocols = ko.observableArray([
                    {
                        label: oj.Translations.getTranslatedString('webentryProtocol.https'),
                        value: constants.webentryProtocol.https
                    },
                    {
                        label: oj.Translations.getTranslatedString('webentryProtocol.http'),
                        value: constants.webentryProtocol.http
                    }]);
                self.webEntryHostname = ko.observable('');
                self.webEntryDomain = ko.observable('');
                self.webEntryPort = ko.observable(constants.webentryProtocol.port);
                self.lbaasOptions = ko.observableArray([{'label': constants.webEntryTypeLookups.NewLBaaS, 'value': 'DEPLOY_NEW'}, {'label': constants.webEntryTypeLookups.UserLoadBalancer, 'value': 'USE_EXISTING'}, {'label': constants.webEntryTypeLookups.AppTierWebEntry, 'value': 'NO_LOAD_BALANCER'}]);
                self.lbaasOptionValue = ko.observable('DEPLOY_NEW');
                self.webEntryTypeLabel = ko.observable('');
                /**
                 * LBAAS related details
                 */



                self.lbShapes = ko.observableArray([{'label': loading, 'value': ''}]);
                self.lbaasShape = ko.observable('');
                self.loadBalancerOptionEnabled = ko.observable(true);
                self.sshKeyValue = ko.observable('');
                self.loadBalancerChoiceOptionsList = ko.observableArray([]);
                self.loadBalancerIPResValue = ko.observable('');
                self.appTierIPResValue = ko.observable('');
                self.dbTierIPResValue = ko.observable('');
                self.fileSystemModeDisabled = ko.observable(true);
                self.isLogicalHostNameUsed = ko.observable('No');
                self.logicalHostDomainInputValue = ko.observable('');
                self.logicalHostDisabled = ko.observable();
                self.logicalHostDomainDisabled = ko.observable();
                self.logicalHostDisabledDB = ko.observable();
                self.isLogicalHostRequiredDB = ko.observable();
                self.logicalHostInputValueDB = ko.observable('');
                self.logicalHostDomainInputValueDB = ko.observable('');
                self.isLogicalHostNamePrefixRequired = ko.observable(true);
                self.isLogicalDomainRequired = ko.observable(true);
                self.numberOfNodesToCreateInputValue = ko.observable(1);
                self.fileSystemModeValue = ko.observable(constants.filesystemMode.nonSharedLabel);
                self.appTier1ChoiceOptionsList = ko.observableArray([]);
                self.appTier1Value = ko.observable('');
                self.appTier2ChoiceOptionsList = ko.observableArray([]);
                self.appTier2Value = ko.observable();
                self.dbTierOptionsList = ko.observableArray([]);
                self.dbTierValue = ko.observable('');
                self.IPReservationsValue = ko.observable('N');
                self.IPReservationsDisabled = ko.observable(true);
                self.InstallationTypeUsed = ko.observable('');
                self.isInstallationTypeUsed = ko.observable(NEW_INSTALLATION);
                self.dbTypeUsed = ko.observable('Compute');
                // This is required in SSH keys step to identify single or multi vm
                self.deploymentType = ko.observable('');
                self.existingDBSystem = ko.observable('YesExistingDBSystem');
                self.selectedDBSystemName = ko.observable('');
                self.clusterNameInputValue = ko.observable('');
                self.exaPasswordInputValue = ko.observable('');
                self.vmipAdd1InputValue = ko.observable('');
                self.vmipAdd2InputValue = ko.observable('');
                self.plugDataBaseInputValue1 = ko.observable();
                self.dbSystemCPUCount = ko.observable(10);
                self.isLNameUsedDB = ko.observable('No');
                self.identifyDomainInputValue = ko.observable('');
                self.systemNameInputValue = ko.observable('');
                self.exaUsernameInputValue = ko.observable('');
                self.compSelectedShapeLabel = ko.observable('');
                self.appShapeChoiceOptionsList = ko.observableArray();
                self.dbCompShapeChoiceOptionsList = ko.observableArray();
                self.dbCompShapeChoiceOptionsDataProvider = new ArrayDataProvider(self.dbCompShapeChoiceOptionsList, {idAttribute: 'value'});
                self.isracOptionUsedDB = ko.observable('N');
                self.racOptionDisabledDB = ko.observable(false);
                self.adminPasswdInputValue = ko.observable();
                self.readminPasswdInputValue = ko.observable();
                self.versionSelectedValue = ko.observable('');
                self.editionChoiceOptionsList = ko.observableArray();
                self.backUpContChoiceOptionsList = ko.observableArray();
                self.securityListChoiceList = ko.observableArray([]);
                self.existingDBSystemsArray = ko.observableArray();
                self.exadataDBSystemValue = ko.observableArray([{'label': loading, 'value': ''}]);
                self.exadataDBSystemValueDataProvider = new ArrayDataProvider(self.exadataDBSystemValue, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.exadataDBSystemValue(), self.exaDBSystemInputValue);
                self.psuList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.psuDataProvider = new ArrayDataProvider(self.psuList, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.psuList(), self.exaDBSystemPSU);
                self.disableSubmitBtn = ko.observable(false);
                self.storagePerAppNode = ko.observable('');
                self.additionalStoragePerAppNode = ko.observable(0);
                self.enableTDEFlagForComputeInReviewScreen = ko.observable(false);
                if (backupName !== '')
                {
                    self.showBackupInstallationPrompts('inline');
                    self.backupBucketList.removeAll();
                    self.backupBucketDataProvider = null;
                    self.backupBucket(backupName);
                    self.backupBucketList([{'label': loading, 'value': 'LOADING'}]);
                    self.backupBucketDataProvider = new ArrayDataProvider(self.backupBucketList, {idAttribute: 'value'});
                    self.isInstallationTypeUsed(FROM_BACKUP);
                    self.showNewInstallationPrompts('none');
                    self.backupCompartmentReadOnly(true);
                    rootViewModel.backupName('');
                    self.prevPage(oj.Translations.getTranslatedString('pageHeader.backups'));
                }

                self.myName = function () {
                    return "create";
                };


                window.handleAdvancedOptionChange_Exa = function () {
                    if (self.advancedOptionsDisplayed_Exa()) {
                        self.advancedOptionsDisplayed_Exa(false);
                        self.advancedOptionsAnchorText_exa(self.SHOW_ADVANCED_OPTIONS_TEXT);
                    } else {
                        self.advancedOptionsDisplayed_Exa(true);
                        self.advancedOptionsAnchorText_exa(self.HIDE_ADVANCED_OPTIONS_TEXT);
                    }

                };

                window.handleAdvancedOptionChange_vmdb = function () {
                    if (self.advancedOptionsDisplayed_vmdb()) {
                        self.advancedOptionsDisplayed_vmdb(false);
                        self.advancedOptionsAnchorText_vmdb(self.SHOW_ADVANCED_OPTIONS_TEXT);
                    } else {
                        self.advancedOptionsDisplayed_vmdb(true);
                        self.advancedOptionsAnchorText_vmdb(self.HIDE_ADVANCED_OPTIONS_TEXT);
                    }

                };

                window.handleAdvancedOptionChange_compute = function () {
                    if (self.advancedOptionsDisplayed_compute()) {
                        self.advancedOptionsDisplayed_compute(false);
                        self.advancedOptionsAnchorText_compute(self.SHOW_ADVANCED_OPTIONS_TEXT);
                    } else {
                        self.advancedOptionsDisplayed_compute(true);
                        self.advancedOptionsAnchorText_compute(self.HIDE_ADVANCED_OPTIONS_TEXT);
                    }

                };
                self.initializeBackUpChannelCountForAllDBTypes = function (computeShapeValue, vmdbShapeValue) {
                    self.initializeBackUpChannelCountForCompute(computeShapeValue);
                    self.initializeBackUpChannelCountForvmdb(vmdbShapeValue);
                };

                self.initializeBackUpChannelCountForCompute = function (shapeValue) {
                    actionsHelper.getBackupChannelCountForRestore(constants.dbTypes.computeds, shapeValue, function (error, computeChannelCountResponse) {
                        if (error !== null && error !== '') {
                            console.log('Error in getting back up channel count for restore(compute) :' + error);
                        } else {
                            self.computeSelectedBackupChannelCount(computeChannelCountResponse.default);
                        }
                    });
                };

                self.initializeBackUpChannelCountForvmdb = function (shapeValue) {
                    actionsHelper.getBackupChannelCountForRestore(constants.dbTypes.vmdbsystem, shapeValue, function (error, vmdbChannelCountResponse) {
                        if (error !== null && error !== '') {
                            console.log('Error in getting back up channel count (vmdb) :' + error);
                        } else {
                            self.vmdbSelectedBackupChannelCount(vmdbChannelCountResponse.default);
                        }
                    });
                };


                self.showVMDB = ko.computed(function ()
                {
                    if (self.dbTypeUsed() === 'VMDB System')
                    {
                        return "inline";
                    }
                    return "none";
                });
                self.noOfZonesEntered = ko.observable(0);
                self.zoneSequence = ko.observable(-1);
                actionsHelper.getVersionInformation(function (error, ebsVersionsData)
                {
                    self.ebsVersionsDataAll(ebsVersionsData);
                    self.purposeChoiceOptionsList.removeAll();
                    self.purposeChoiceOptionsDataProvider = null;
                    var purposeOptions = ebsVersionsData.installtypes;
                    if (purposeOptions !== null && purposeOptions.length > 0)
                    {
                        var purposeOptionsChoiceData = new Array();
                        for (var i = 0; i < purposeOptions.length; i++)
                        {
                            var metaData = purposeOptions[i];
                            var optionData = new Object();
                            optionData.label = metaData.label;
                            optionData.value = metaData.value;
                            purposeOptionsChoiceData.push(optionData);
                        }
                        self.purposeChoiceOptionsList(purposeOptionsChoiceData);
                        self.purposeChoiceOptionsDataProvider = new ArrayDataProvider(self.purposeChoiceOptionsList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.purposeChoiceOptionsList(), self.selectedPurposeValue);
                    }
                });
                self.envPurposeChanged = function (event)
                {
                    var selectedPurpose = event['detail'].value;
                    var oldPurposeValue = event['detail'].previousValue;
                    self.envPurposeChanged_Handler(event);
                };

                self.envPurposeChanged_Handler = function (event) {
                    var selectedPurpose = event['detail'].value;
                    if (selectedPurpose === null || selectedPurpose === '')
                        selectedPurpose = self.selectedPurposeValue();
                    if (selectedPurpose === null || selectedPurpose === '')
                    {
                        return;
                    }
                    self.ebsVerChoiceOptionsList.removeAll();
                    self.ebsVerChoiceOptionsDataProvider = null;
                    var purposeOptions = self.ebsVersionsDataAll().installtypes;
                    if (purposeOptions !== null && purposeOptions.length > 0)
                    {
                        for (var i = 0; i < purposeOptions.length; i++)
                        {
                            var valueOfInstallationTypeInMetaData = purposeOptions[i].value;
                            if (valueOfInstallationTypeInMetaData === selectedPurpose)
                            {
                                var versionsList = purposeOptions[i].ebsversions;
                                var ebsAppsVersionListChoiceData = new Array();
                                for (var j = 0; j < versionsList.length; j++)
                                {
                                    var versionInMetaData = versionsList[j];
                                    var optionData = new Object();
                                    optionData.label = versionInMetaData.label;
                                    optionData.value = versionInMetaData.value;
                                    ebsAppsVersionListChoiceData.push(optionData);
                                }
                                self.ebsVerChoiceOptionsList(ebsAppsVersionListChoiceData);
                                self.ebsVerChoiceOptionsDataProvider = new ArrayDataProvider(self.ebsVerChoiceOptionsList, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.ebsVerChoiceOptionsList(), self.freshEBSVerValue);
                                return;
                            }
                        }

                    }
                }

                self.tdeEnablementChanged = function (event)
                {
                    var newValue = event['detail'].value;
                    if (newValue.length > 0 && newValue[0] === 'Y')
                    {
                        var translatedMsgForTDEEnablement = oj.Translations.getTranslatedString("validationMsgs.TDELicensingMsg");
                        var validationCustomMsgForTDEEnablement = {summary: translatedMsgForTDEEnablement,
                            detail: translatedMsgForTDEEnablement, severity: oj.Message.SEVERITY_TYPE.INFO};
                        self.TDEEnablementMsg([validationCustomMsgForTDEEnablement]);
                    } else
                    {
                        self.TDEEnablementMsg([]);
                    }
                };

                self.dbVersionChanged = function (event) {
                    var newDBVersion = event['detail'].value;
                };

                self.ebsVersionChanged = function (event)
                {
                    var newEbsVersion = event['detail'].value;
                    if (newEbsVersion === null || newEbsVersion === '')
                    {
                        newEbsVersion = self.selectedEbsVerValue();
                    }
                    if (newEbsVersion === null || newEbsVersion === '')
                    {
                        return;
                    }
                    var selectedPurposeType = self.selectedPurposeValue();
                    self.dbVerChoiceOptionsList.removeAll();
                    self.dbVerChoiceOptionsDataProvider = null;
                    var purposeOptions = self.ebsVersionsDataAll().installtypes;
                    if (purposeOptions !== null && purposeOptions.length > 0)
                    {
                        for (var i = 0; i < purposeOptions.length; i++)
                        {
                            var valueOfInstallationTypeInMetaData = purposeOptions[i].value;
                            if (valueOfInstallationTypeInMetaData === selectedPurposeType)
                            {
                                var ebsVersionsInMetaData = purposeOptions[i].ebsversions;
                                for (var j = 0; j < ebsVersionsInMetaData.length; j++)
                                {
                                    var currentEbsVersionValueInMetaData = ebsVersionsInMetaData[j].value;
                                    if (currentEbsVersionValueInMetaData === newEbsVersion)
                                    {
                                        var dbVersionsInMetaData = ebsVersionsInMetaData[j].dbversions;
                                        if (dbVersionsInMetaData !== null && dbVersionsInMetaData.length > 0)
                                        {
                                            var dbVersionsChoiceOptionList = new Array();
                                            for (var k = 0; k < dbVersionsInMetaData.length; k++)
                                            {
                                                var optionData = new Object();
                                                optionData.label = dbVersionsInMetaData[k].label;
                                                optionData.value = dbVersionsInMetaData[k].value;
                                                dbVersionsChoiceOptionList.push(optionData);
                                            }
                                            self.dbVerChoiceOptionsList(dbVersionsChoiceOptionList);
                                            self.dbVerChoiceOptionsDataProvider = new ArrayDataProvider(self.dbVerChoiceOptionsList, {idAttribute: 'value'});
                                            lovUtils.lovOptionsUpdated(self.dbVerChoiceOptionsList(), self.freshDBReleaseValue);
                                        }
                                    }
                                }
                            }
                        }

                    }
                };
                self.addAppNode = function (event, ui)
                {
                    var currentElementLength = self.appNodesObservableArray().length;
                    var node = {
                        'RowId': ko.observable(currentElementLength + 1),
                        'faultDomain': ko.observable(''),
                    };
                    self.appNodesObservableArray.push(node);
                };

                self.deleteAppNode = function (event, ui)
                {
                    self.appNodesObservableArray.splice(self.appNodesObservableArray().length - 1, 1);
                };
                self.addDbNode = function (event, ui)
                {
                    var currentElementLength = self.dbNodesObservableArray().length;
                    var node = {
                        'RowId': ko.observable(currentElementLength + 1),
                        'faultDomain': ko.observable(''),
                        'faultDomainChoiceList': self.faultDomainChoiceList,
                    };
                    self.dbNodesObservableArray.push(node);
                };
                self.deleteDbNode = function (event, ui)
                {
                    self.dbNodesObservableArray.splice(self.dbNodesObservableArray().length - 1, 1);
                };
                actionsHelper.getOCIShapes(function (error, envMetadata)
                {
                    if (error !== null && error !== '')
                    {
                        if (error.status === 504)
                        {
                            var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                            self.addPageLevelMessage('Installation', 'error', 'Error in fetching OCI Shapes.', messageContent);
                        } else
                        {
                            var errorCode = error.responseJSON.code;
                            if (error.responseJSON.code === null || error.responseJSON.code === '')
                            {
                                errorCode = error.status;
                            }
                            var messageContent = 'Error Message : ' + error.responseJSON.message;
                            self.addPageLevelMessage('Installation', 'error', 'Error in fetching OCI Shapes', messageContent);
                        }
                        return;
                    }
                    self.dbCompShapeChoiceOptionsList(envMetadata.computeds);
                    self.dbCompShapeChoiceOptionsDataProvider = new ArrayDataProvider(self.dbCompShapeChoiceOptionsList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.dbCompShapeChoiceOptionsList(), self.dbCompSelectedShapeValue);
                    self.dbSystemShapeChoiceOptionsList(envMetadata.dbsystem);
                    self.vmdbShapeList(envMetadata.vmdbsystem);
                    self.vmdbShapeListDataProvider = new ArrayDataProvider(self.vmdbShapeList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.vmdbShapeList(), self.vmdbSelectedShapeValue);
                    self.vmdbNodeCountList(envMetadata.vmdbsystem[0].supportedNodeCount);
                    self.vmdbNodeCountDataProvider = new ArrayDataProvider(self.vmdbNodeCountList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.vmdbNodeCountList(), self.vmdbNodeCount);
                    self.appShapeChoiceOptionsList(envMetadata.app);
                    self.lbShapes(envMetadata.lb);
                    self.lbaasShape(self.lbShapes()[0].value);
                    self.populateDBEditions();
                });

                self.initialbackupCompartmentDefault = false;
                actionsHelper.getBackupsForLov(function (error, backups)
                {
                    if (backupName !== '')
                    {
                        self.backupBucketList.removeAll();
                        self.backupBucketDataProvider = null;
                        $.each(backups, function (index, value)
                        {
                            if (backupName === value.value)
                            {
                                //self.backupBucketList([{'label': backupName, 'value': value}]);
                                self.backupBucketList(new Array(value));
                                self.backupBucketDataProvider = new ArrayDataProvider(self.backupBucketList, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.backupBucketList(), self.backupBucket);
                                self.backupBucket(backupName);
                                self.backupBucketName(value.label);
                                self.backupEBSVerValue(value.ebsVersion);
                                self.backupDBReleaseValue(value.dbVersion);
                                //need to lookup the compartment Id based on the
                                //compartment name from the backup
                                var compList = self.nonHierarchicalCompList();
                                var compartmentId = '';
                                const matches = compList.filter(function (item) {
                                    return (item.label === value.compartmentName);
                                });
                                if (matches && matches.length > 0)
                                {
                                    compartmentId = matches[0].value;
                                }
                                self.selectedRestoreCompartment(compartmentId);
                                self.selectedBackupRestoreCompartment(value.compartmentName);
                                self.initialBackupCompartDefault = true;
                                if (value.ebsVersion === constants.ebsVersions.twelveone)
                                {
                                    self.showBackupWlsAdminPwd(false);
                                } else
                                {
                                    self.showBackupWlsAdminPwd(true);
                                }
                                var isTdeEnabled = value.tdeEnabled;
                                if (isTdeEnabled === true)
                                {
                                    self.showSourceWalletPassword(true);
                                } else
                                {
                                    self.showSourceWalletPassword(false);
                                }
                                self.isMultiTenant(value.multiTenant);

                                return false;
                            }

                        });
                    }
                    self.backupBucketFullList(backups);
                });

                self.compartmentRestoreValueHandler = function (event, ui)
                {
                    if (self.backupCompartmentReadOnly())
                        return;
                    var value = event['detail'].value;
                    if (!value || value === '')
                        return;

                    //value is the compartment OCID, need to get compartment name 
                    //from the value
                    var compList = self.nonHierarchicalCompList();
                    var compartmentName = '';
                    const matches = compList.filter(function (item) {
                        return (item.value === value);
                    });
                    if (matches && matches.length > 0)
                    {
                        compartmentName = matches[0].label;
                    }

                    //enable network profile input
                    self.backupBucketDisabled(false);
                    self.backupBucketValidationMsg([]);
                    self.backupBucketList.removeAll();
                    self.backupBucketDataProvider = null;
                    if (backupName === '' || !self.initialBackupCompartDefault) {
                        self.backupBucketList([{'label': loading, 'value': 'LOADING'}]);
                        self.backupBucketDataProvider = new ArrayDataProvider(self.backupBucketList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.backupBucketList(), self.backupBucket);
                    }
                    //filter bucket list based on compartment
                    var fullLists = self.backupBucketFullList();

                    if ((backupName === '') && (!fullLists || fullLists.length === 0))
                    {
                        actionsHelper.getBackupsForLov(function (error, backups)
                        {
                            self.backupBucketFullList(backups);
                            self.filterBackupByCompartment(compartmentName, backups);
                        });
                    } else
                    {
                        self.filterBackupByCompartment(compartmentName, fullLists);

                        if (backupName !== '' && self.initialBackupCompartDefault)
                        {
                            self.backupBucket(backupName);
                            self.initialBackupCompartDefault = false;
                        }
                    }
                };

                self.filterBackupByCompartment = function (compartment, fullLists)
                {
                    const matches = fullLists.filter(function (backup) {
                        return (backup.compartmentName === compartment);
                    });
                    if (matches && matches.length > 0)
                    {
                        self.backupBucketList(matches);
                        self.backupBucketDataProvider = new ArrayDataProvider(self.backupBucketList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.backupBucketList(), self.backupBucket);
                    } else
                    {
                        //display warning msg
                        self.backupBucketList([{'label': '', 'value': 'LOADING'}]);
                        self.backupBucketDataProvider = new ArrayDataProvider(self.backupBucketList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.backupBucketList(), self.backupBucket);
                        var backupBucketValidationCustomMsg = oj.Translations.getTranslatedString('validationMsgs.lovValueNotFoundMsg', {lovName: 'backup bucket'});
                        var validationMsg = {summary: backupBucketValidationCustomMsg,
                            detail: backupBucketValidationCustomMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                        self.backupBucketValidationMsg([validationMsg]);
                        var backupBucket = document.getElementById("backupBucket");
                        backupBucket.showMessages();
                    }
                }

                self.startAnimationListener = function (event, ui)
                {
                    popupHelper.startAnimationListener(constants.divTags.createAdvEnvPopupTag, event, ui);
                };
                self.confirmationPopupCloseHandler = function (data, event)
                {
                    popupHelper.confmPopuCloseHandler(constants.divTags.createAdvEnvPopupTag, data, event);
                };
                self.handleBackLink = function (event, ui)
                {
                    var context = ko.contextFor(document.getElementById('advancedInstallationDetails'));
                    var prevModule = (isDetailPG !== '' && isDetailPG) ? constants.navModules.envDetailsModule : (backupName !== '' ? constants.navModules.envBackupsModule : constants.navModules.envListModule);
                    if (prevModule === constants.navModules.envDetailsModule)
                    {
                        rootViewModel.prevEnvDetailsNavItem(constants.navModules.envAdministrationModule);
                    }
                    pageNavigationHelper.navigateToPage(context, prevModule, prevModule, true)
                };
                self.handleComputeDBTDEInitialization = function (event, ui)
                {
                    var isProvisioningFromBackup = (self.isProvisioningFromBackup() === 'true');
                    if (isProvisioningFromBackup)
                    {
                        var isTDEEnabledBackupChosen = (self.isProvisioningFromTDEEnabledBackup() === 'true');
                        if (isTDEEnabledBackupChosen)
                        {
                            self.renderTDECheckBox('false');
                            self.renderBackupAdminPwdFields('true');
                        } else
                        {
                            self.renderTDECheckBox('true')
                            self.renderBackupAdminPwdFields('true');
                        }
                    } else
                    {
                        self.renderTDECheckBox('true')
                        self.renderBackupAdminPwdFields('true');
                    }

                };
                self.handleVMDBSystemPatchLevelInitialization = function (event, ui)
                {
                    var skipInitialization = false;
                    var isProvisioningFromBackup = (self.isProvisioningFromBackup() === 'true');
                    var dbVersion = self.selectedDBReleaseValue();
                    var ebsVersion = self.selectedEbsVerValue();
                    var installType = self.selectedPurposeValue();
                    var choosenBackup = self.backupBucket();
                    var previousInputsUsedForInitialization = self.previousInputParamsForVMDBPSU;
                    if (isProvisioningFromBackup)
                    {
                        if (choosenBackup !== '')
                        {
                            var currentInputs = new Array();
                            currentInputs.push(choosenBackup);
                            if (previousInputsUsedForInitialization !== null)
                            {
                                if (previousInputsUsedForInitialization.length === currentInputs.length)
                                {
                                    var sizeOfInputs = currentInputs.length;
                                    var noOfMatchingElements = 0;
                                    for (var j = 0; j < sizeOfInputs; j++)
                                    {
                                        var inputValSaved = previousInputsUsedForInitialization[j];
                                        var currentInputValue = currentInputs[j];
                                        if (inputValSaved !== null && currentInputValue !== null && inputValSaved === currentInputValue)
                                        {
                                            noOfMatchingElements++;
                                        }
                                    }
                                    if (noOfMatchingElements === sizeOfInputs)
                                    {
                                        skipInitialization = true;
                                    }
                                }
                            }

                        }
                    } else
                    {
                        var currentInputs = new Array();
                        currentInputs.push(ebsVersion);
                        currentInputs.push(dbVersion);
                        currentInputs.push(installType);
                        if (previousInputsUsedForInitialization !== null)
                        {
                            if (previousInputsUsedForInitialization.length === currentInputs.length)
                            {
                                var sizeOfInputs = currentInputs.length;
                                var noOfMatchingElements = 0;
                                for (var j = 0; j < sizeOfInputs; j++)
                                {
                                    var inputValSaved = previousInputsUsedForInitialization[j];
                                    var currentInputValue = currentInputs[j];
                                    if (inputValSaved !== null && currentInputValue !== null && inputValSaved === currentInputValue)
                                    {
                                        noOfMatchingElements++;
                                    }
                                }
                                if (noOfMatchingElements === sizeOfInputs)
                                {
                                    skipInitialization = true;
                                }
                            }
                        }
                    }

                    if (skipInitialization)
                    {
                        return;
                    }


                    // If we are in a new installation flow and if the public PSU patch levels
                    // are not yet loaded, then load the public PSU patch levels.

                    // If we are in a back up flow, then pass the back up Identifier and then get
                    // the PSU patch levels.
                    self.vmdbPSUList([]);
                    self.vmdbPSUDataProvider = new ArrayDataProvider(self.vmdbPSUList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.vmdbPSUList(), self.vmDBSystemPSU);
                    self.vmDBSystemPSU('');
                    self.vmDBLatestPatchValidationMsg([]);
                    if (isProvisioningFromBackup)
                    {

                        if (choosenBackup !== '')
                        {
                            self.vmdbPSUList(loadingOptionList);
                            self.vmdbPSUDataProvider = new ArrayDataProvider(self.vmdbPSUList, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.vmdbPSUList(), self.vmDBSystemPSU);
                            var inputs = new Array();
                            inputs.push(choosenBackup);
                            self.previousInputParamsForVMDBPSU = inputs;
                            actionsHelper.getPSUListForBackup(choosenBackup, constants.dbTypes.vmdbsystem, function (error, psuList)
                            {
                                if (error === '')
                                {
                                    self.vmdbPSUList(psuList);
                                    self.vmdbPSUDataProvider = new ArrayDataProvider(self.vmdbPSUList, {idAttribute: 'value'});
                                    lovUtils.lovOptionsUpdated(self.vmdbPSUList(), self.vmDBSystemPSU);
                                    if (psuList.length === 0)
                                    {
                                        var messageContent = oj.Translations.getTranslatedString("validationMsgs.dbPatchValidationMsg", {'choosenBackup': choosenBackup});
                                        var validationCustomMsg = {summary: messageContent,
                                            detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                    }

                                } else
                                {
                                    if (error.status === 504)
                                    {
                                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                        var validationCustomMsg = {summary: messageContent,
                                            detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                    } else
                                    {
                                        var errorCode = error.responseJSON.code;
                                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                                        {
                                            errorCode = error.status;
                                        }
                                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                                        var validationCustomMsg = {summary: messageContent,
                                            detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                    }
                                }
                            });
                        }
                    } else
                    {

                        self.vmdbPSUList(loadingOptionList);
                        self.vmdbPSUDataProvider = new ArrayDataProvider(self.vmdbPSUList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.vmdbPSUList(), self.vmDBSystemPSU);
                        var inputs = new Array();
                        inputs.push(ebsVersion);
                        inputs.push(dbVersion);
                        inputs.push(installType);
                        self.previousInputParamsForVMDBPSU = inputs;
                        actionsHelper.getPSUListForDBVersion(ebsVersion, dbVersion, constants.dbTypes.vmdbsystem, installType, function (error, psuList)
                        {
                            if (error === '')
                            {
                                self.vmdbPSUList(psuList);
                                self.vmdbPSUDataProvider = new ArrayDataProvider(self.vmdbPSUList, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.vmdbPSUList(), self.vmDBSystemPSU);
                                if (psuList.length === 0)
                                {
                                    var messageContent = oj.Translations.getTranslatedString("validationMsgs.dbPatchVersionValidationMsg", {'ebsVersion': ebsVersion, 'dbVersion': dbVersion});
                                    var validationCustomMsg = {summary: messageContent,
                                        detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                    self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                }

                            } else
                            {
                                if (error.status === 504)
                                {
                                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                    var validationCustomMsg = {summary: messageContent,
                                        detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                    self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                } else
                                {
                                    var errorCode = error.responseJSON.code;
                                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                                    {
                                        errorCode = error.status;
                                    }
                                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                                    var validationCustomMsg = {summary: messageContent,
                                        detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                    self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                }
                            }
                        });
                    }
                };
                self.initializeLoadBalancerOption = function (event, ui)
                {
                    var newnetworkProfileName = event['detail'].value;
                    var prevnetworkProfileName = event['detail'].previousValue;
                    var hasExternalZoneSupportPrevValue = self.isExternalZoneAllowed();
                    if (newnetworkProfileName === null || newnetworkProfileName === '' || newnetworkProfileName === 'LOADING')
                    {
                        return;
                    }
                    actionsHelper.getNetworkProfileDetails(newnetworkProfileName, function (error, details)
                    {
                        var lbaasSection = details.lbaas;
                        if (lbaasSection === null || typeof (lbaasSection) === 'undefined' || lbaasSection === '')
                        {
                            console.log('Disabling LBAAS');
                            self.loadBalancerOptionEnabled(false);
                            self.lbaasOptionValue("USE_EXISTING");
                        }


                        var hasExternalZoneSupport = false;
                        if (typeof (lbaasSection.external) !== 'undefined' && lbaasSection.external !== '' &&
                                typeof (lbaasSection.external.subnetOCID) !== 'undefined' && lbaasSection.external.subnetOCID !== ''
                                )
                        {
                            hasExternalZoneSupport = true;
                        }

                        if (hasExternalZoneSupportPrevValue && !hasExternalZoneSupport)
                        {
                            var hasExternalZones = false;
                            // Check if the user created any external zones already.
                            for (var k = 1; k <= 10; k++)
                            {
                                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                                if (detailChildElemRoot !== null)
                                {
                                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                                    if (detailModuleElemViewModel !== null)
                                    {
                                        var typeofZone = detailModuleElemViewModel.selectedZoneType();
                                        if (typeofZone === 'External')
                                        {
                                            hasExternalZones = true;
                                        }
                                    }
                                }
                            }

                            if (hasExternalZones)
                            {
                                self.openInformationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.networkProfileHasExternalZones'),
                                        function () {
                                            event.stopPropagation();
                                            console.log('Setting the old network profile again =>' + prevnetworkProfileName);
                                            self.selectedNetworkProfileName(prevnetworkProfileName);
                                            return false;
                                        });
                            }
                        }


                        var lbaasSubnetOCID = lbaasSection.internal.subnetOCID;
                        if (lbaasSubnetOCID === null || typeof (lbaasSubnetOCID) === 'undefined' || lbaasSubnetOCID === '')
                        {
                            self.loadBalancerOptionEnabled(false);
                            console.log('Disabling LBAAS');
                            self.lbaasOptionValue("USE_EXISTING");
                        } else
                        {
                            self.loadBalancerOptionEnabled(true);
                            console.log('Enabling LBAAS');
                            self.lbaasOptionValue("DEPLOY_NEW");
                        }

                        if (!hasExternalZoneSupport)
                        {
                            self.isExternalZoneAllowed(false);
                        } else
                        {
                            self.isExternalZoneAllowed(true);
                        }
                        // Calling validation on env name
                        self.validateOnNetworkProfileChanged();
                        actionsHelper.getFaultDomains(newnetworkProfileName, function (error, faultDomains)
                        {
                            self.faultDomainChoiceList(faultDomains);
                            self.faultDomainChoiceDataProvider = new ArrayDataProvider(self.faultDomainChoiceList, {idAttribute: 'value'});
                        });
                        // Retrieve tag namespace options 
                        actionsHelper.getTagNamespaceInformation(newnetworkProfileName, function (error, tagDetails) {
                            self.tagNamespaceOptionsList.removeAll();
                            self.tagNamespaceOptionsDataProvider = null;
                            var tagDetailsLen = tagDetails.length;
                            if (null !== tagDetails && tagDetailsLen > 0) {
                                var tagOptions = new Array();
                                var optionData = new Object();
                                optionData.label = 'None (add a free-form tag)';
                                optionData.value = 'none';
                                tagOptions.push(optionData);
                                for (var i = 0; i < tagDetailsLen; i++) {
                                    var metaData = tagDetails[i];
                                    if (null !== metaData.label && metaData.label.length > 0) {
                                        var optionData = new Object();
                                        optionData.label = metaData.label;
                                        optionData.value = metaData.value;
                                        tagOptions.push(optionData);
                                    }
                                }
                                self.tagNamespaceOptionsList(tagOptions);
                                self.tagNamespaceOptionsDataProvider = new ArrayDataProvider(self.tagNamespaceOptionsList, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.tagNamespaceOptionsList(), self.selectedTagNamespace);
                                self.tagKeyList(tagDetails);
                            }
                        });
                    });
                };


                self.confirmationDialogText = ko.observable('');
                self.confirmationCallBackFunctionSuccess = null;
                self.confirmationCallBackFunctionFailure = null;
                self.isNoButtonRendered = ko.observable(true);
                self.confirmationDialogTitle = ko.observable('Confirm');
                self.yesButtonText = ko.observable('Yes');
                self.noButtonText = ko.observable('No');


                self.okConfirmationDialog = function ()
                {
                    document.getElementById('confirmDialog_createFlow').close();
                    self.confirmationCallBackFunctionSuccess();
                };
                self.NotokConfirmationDialog = function ()
                {
                    document.getElementById('confirmDialog_createFlow').close();
                    self.confirmationCallBackFunctionFailure();
                };

                self.openConfirmationDialog = function (questionaireText, callbackFunctionSuccess, callbackFunctionFailure)
                {
                    self.confirmationCallBackFunctionSuccess = callbackFunctionSuccess;
                    self.confirmationCallBackFunctionFailure = callbackFunctionFailure;
                    self.confirmationDialogText(questionaireText);
                    self.isNoButtonRendered(true);
                    self.yesButtonText('Yes');
                    self.noButtonText('No');
                    self.confirmationDialogTitle('Confirm');
                    document.getElementById('confirmDialog_createFlow').open();
                };

                self.openInformationDialog = function (content, callBackFunc)
                {
                    self.confirmationCallBackFunctionSuccess = callBackFunc;
                    self.confirmationDialogText(content);
                    self.isNoButtonRendered(false);
                    self.yesButtonText('OK');
                    self.confirmationDialogTitle('Warning');
                    document.getElementById('confirmDialog_createFlow').open();
                };



                self.handleexadataDBSystemPatchLevelInitialization = function (event, ui)
                {
                    var skipInitialization = false;
                    var isProvisioningFromBackup = (self.isProvisioningFromBackup() === 'true');
                    var dbVersion = self.selectedDBReleaseValue();
                    var ebsVersion = self.selectedEbsVerValue();
                    var installType = self.selectedPurposeValue();
                    var choosenBackup = self.backupBucket();
                    var previousInputsUsedForInitialization = self.previousInputParamsForExaDataPSU;
                    if (isProvisioningFromBackup)
                    {
                        if (choosenBackup !== '')
                        {
                            var currentInputs = new Array();
                            currentInputs.push(choosenBackup);
                            if (previousInputsUsedForInitialization !== null)
                            {
                                if (previousInputsUsedForInitialization.length === currentInputs.length)
                                {
                                    var sizeOfInputs = currentInputs.length;
                                    var noOfMatchingElements = 0;
                                    for (var j = 0; j < sizeOfInputs; j++)
                                    {
                                        var inputValSaved = previousInputsUsedForInitialization[j];
                                        var currentInputValue = currentInputs[j];
                                        if (inputValSaved !== null && currentInputValue !== null && inputValSaved === currentInputValue)
                                        {
                                            noOfMatchingElements++;
                                        }
                                    }
                                    if (noOfMatchingElements === sizeOfInputs)
                                    {
                                        skipInitialization = true;
                                    }
                                }
                            }

                        }
                    } else
                    {
                        var currentInputs = new Array();
                        currentInputs.push(ebsVersion);
                        currentInputs.push(dbVersion);
                        currentInputs.push(installType);
                        if (previousInputsUsedForInitialization !== null)
                        {
                            if (previousInputsUsedForInitialization.length === currentInputs.length)
                            {
                                var sizeOfInputs = currentInputs.length;
                                var noOfMatchingElements = 0;
                                for (var j = 0; j < sizeOfInputs; j++)
                                {
                                    var inputValSaved = previousInputsUsedForInitialization[j];
                                    var currentInputValue = currentInputs[j];
                                    if (inputValSaved !== null && currentInputValue !== null && inputValSaved === currentInputValue)
                                    {
                                        noOfMatchingElements++;
                                    }
                                }
                                if (noOfMatchingElements === sizeOfInputs)
                                {
                                    skipInitialization = true;
                                }
                            }
                        }
                    }

                    if (skipInitialization)
                    {
                        console.log('Exa Data Flow - Skipping Initilization.');
                        return;
                    }
                    // If we are in a new installation flow and if the public PSU patch levels
                    // are not yet loaded, then load the public PSU patch levels.

                    // If we are in a back up flow, then pass the back up Identifier and then get
                    // the PSU patch levels.
                    self.psuList([]);
                    self.psuDataProvider = new ArrayDataProvider(self.psuList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.psuList(), self.exaDBSystemPSU);
                    self.exaDBSystemPSU('');
                    self.exadataLatestPatchValidationMsg([]);
                    if (isProvisioningFromBackup)
                    {

                        if (choosenBackup !== '')
                        {
                            var inputs = new Array();
                            inputs.push(choosenBackup);
                            self.previousInputParamsForExaDataPSU = inputs;
                            self.psuList(loadingOptionList);
                            self.psuDataProvider = new ArrayDataProvider(self.psuList, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.psuList(), self.exaDBSystemPSU);
                            actionsHelper.getPSUListForBackup(choosenBackup, constants.dbTypes.exadatadbsystem, function (error, psuList)
                            {
                                if (error === '')
                                {
                                    self.psuList(psuList);
                                    self.psuDataProvider = new ArrayDataProvider(self.psuList, {idAttribute: 'value'});
                                    lovUtils.lovOptionsUpdated(self.psuList(), self.exaDBSystemPSU);
                                    if (psuList.length === 0)
                                    {
                                        var messageContent = oj.Translations.getTranslatedString("validationMsgs.dbPatchValidationMsg", {'choosenBackup': choosenBackup});
                                        var validationCustomMsg = {summary: messageContent,
                                            detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                    }

                                } else
                                {

                                    if (error.status === 504)
                                    {
                                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                        var validationCustomMsg = {summary: messageContent,
                                            detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        self.exadataLatestPatchValidationMsg([validationCustomMsg]);
                                    } else
                                    {
                                        var errorCode = error.responseJSON.code;
                                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                                        {
                                            errorCode = error.status;
                                        }
                                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                                        var validationCustomMsg = {summary: messageContent,
                                            detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                        self.exadataLatestPatchValidationMsg([validationCustomMsg]);
                                    }
                                }
                            });
                        }
                    } else
                    {

                        self.psuList(loadingOptionList);
                        self.psuDataProvider = new ArrayDataProvider(self.psuList, {idAttribute: 'value'});
                        lovUtils.lovOptionsUpdated(self.psuList(), self.exaDBSystemPSU);
                        var inputs = new Array();
                        inputs.push(ebsVersion);
                        inputs.push(dbVersion);
                        inputs.push(installType);
                        self.previousInputParamsForExaDataPSU = inputs;
                        actionsHelper.getPSUListForDBVersion(ebsVersion, dbVersion, constants.dbTypes.exadatadbsystem, installType, function (error, psuList)
                        {
                            if (error === '')
                            {
                                self.psuList(psuList);
                                self.psuDataProvider = new ArrayDataProvider(self.psuList, {idAttribute: 'value'});
                                lovUtils.lovOptionsUpdated(self.psuList(), self.exaDBSystemPSU);
                                if (psuList.length === 0)
                                {
                                    var messageContent = oj.Translations.getTranslatedString("validationMsgs.dbPatchVersionValidationMsg", {'ebsVersion': ebsVersion, 'dbVersion': dbVersion});

                                    var validationCustomMsg = {summary: messageContent,
                                        detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                    self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                                }

                            } else
                            {
                                if (error.status === 504)
                                {
                                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                    var validationCustomMsg = {summary: messageContent,
                                        detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                    self.exadataLatestPatchValidationMsg([validationCustomMsg]);
                                } else
                                {
                                    var errorCode = error.responseJSON.code;
                                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                                    {
                                        errorCode = error.status;
                                    }
                                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                                    var validationCustomMsg = {summary: messageContent,
                                        detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                    self.exadataLatestPatchValidationMsg([validationCustomMsg]);
                                }
                            }
                        });
                    }
                };
                self.vmDBPSUChangeListener = function (event, ui)
                {
                    var newValue = event['detail'].value;
                    self.validateVMDBPSUSelectedValue(newValue);
                };
                self.validateVMDBPSUSelectedValue = function (valueSelectedByUser)
                {
                    if (valueSelectedByUser === null || valueSelectedByUser === '' || valueSelectedByUser === 'Loading' || valueSelectedByUser === 'loading' || valueSelectedByUser === 'Loading...')
                    {
                        return;
                    }
                    var firstOptionValueInList = self.vmdbPSUList()[0].value;
                    if (valueSelectedByUser !== '' && firstOptionValueInList !== '' && firstOptionValueInList !== valueSelectedByUser)
                    {
                        var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.vmDBOldPSUWarningMsg");
                        var validationCustomMsg = {summary: translatedMsg,
                            detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                        self.vmDBLatestPatchValidationMsg([validationCustomMsg]);
                    } else
                    {
                        self.vmDBLatestPatchValidationMsg([]);
                    }
                };
                self.exadataDBPSUChangeListener = function (event, ui)
                {
                    var newValue = event['detail'].value;
                    self.validateExaDBPSUSelectedValue(newValue);
                };
                self.validateExaDBPSUSelectedValue = function (valueSelectedByUser)
                {
                    if (valueSelectedByUser === null || valueSelectedByUser === '' || valueSelectedByUser === 'Loading' || valueSelectedByUser === 'loading' || valueSelectedByUser === 'Loading...')
                    {
                        return;
                    }
                    var firstOptionValueInList = self.psuList()[0].value;
                    if (valueSelectedByUser !== '' && firstOptionValueInList !== '' && firstOptionValueInList !== valueSelectedByUser)
                    {
                        var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.vmDBOldPSUWarningMsg");
                        var validationCustomMsg = {summary: translatedMsg,
                            detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                        self.exadataLatestPatchValidationMsg([validationCustomMsg]);
                    } else
                    {
                        self.exadataLatestPatchValidationMsg([]);
                    }
                };
                self.openNetworkProfileDetail = function (event)
                {
                    var selectedNtwkProfileName = self.selectedNetworkProfileName();
                    if (selectedNtwkProfileName === '' || selectedNtwkProfileName === null || selectedNtwkProfileName === "Loading..." || selectedNtwkProfileName === "loading..." || selectedNtwkProfileName === "LOADING")
                    {
                        return;
                    }
                    var viewModelOfPopupModule = ko.dataFor(document.getElementById('networkProfileDetailRoot'));
                    viewModelOfPopupModule.popupOpen(self.selectedNetworkProfileName(), event);
                };
                self.populateDBSystems = function ()
                {
                    self.exaDBSystemUnavailableMsg([]);
                    self.exadataDBSystemValue(loadingOptionList);
                    self.exadataDBSystemValueDataProvider = new ArrayDataProvider(self.exadataDBSystemValue, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.exadataDBSystemValue(), self.exaDBSystemInputValue);
                    var networkProfileNameSelected = self.selectedNetworkProfileName();
                    var dbVersion = self.selectedDBReleaseValue();
                    var ebsVersion = self.selectedEbsVerValue();
                    var installType = self.selectedPurposeValue();
                    actionsHelper.getDBSystems(networkProfileNameSelected, dbVersion, function (error, dbSystems)
                    {
                        if (error === '')
                        {
                            if (dbSystems === null || dbSystems === '' || dbSystems.length < 1)
                            {
                                dbSystems = emptyOptionList;
                                var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.exaDBSystemUnavailableMsg", {networkProfileName: networkProfileNameSelected, dbVersion: dbVersion});
                                var validationCustomMsg = {summary: translatedMsg,
                                    detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                                self.exaDBSystemUnavailableMsg([validationCustomMsg]);
                            }

                            self.exadataDBSystemValue(dbSystems);
                            self.exadataDBSystemValueDataProvider = new ArrayDataProvider(self.exadataDBSystemValue, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.exadataDBSystemValue(), self.exaDBSystemInputValue);
                        } else
                        {
                            self.exadataDBSystemValue(emptyOptionList);
                            self.exadataDBSystemValueDataProvider = new ArrayDataProvider(self.exadataDBSystemValue, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.exadataDBSystemValue(), self.exaDBSystemInputValue);
                            var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.exaDBSystemUnavailableMsg", {networkProfileName: networkProfileNameSelected, dbVersion: dbVersion});
                            var validationCustomMsg = {summary: translatedMsg,
                                detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                            self.exaDBSystemUnavailableMsg([validationCustomMsg]);

                            if (error.status === 504)
                            {
                                var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                self.addPageLevelMessage('DB', 'error', 'Error in fetching DB Systems for ExaData System with network profile ' + networkProfileNameSelected, messageContent);
                            } else
                            {
                                var messageContent = 'Error Message : ' + error.responseJSON ? error.responseJSON.message : "Unexpected Error";
                                self.addPageLevelMessage('DB', 'error', 'Error in fetching DB Systems for ExaData System with network profile ' + networkProfileNameSelected, messageContent);
                            }
                        }

                    });
                };

                self.validateOnNetworkProfileChanged = function () {
                    var envName = document.getElementById('envName');
                    if (envName === null) {
                        return;
                    }

                    self.fetchMaxLengthValidation();
                    if (envName.childNodes !== null && envName.childNodes.length > 0) {
                        //Call EnvNameValidator
                        if (envName.childNodes[0].value && envName.childNodes[0].value !== '') {
                            envName.validate();
                        }
                    }
                };
                self.envLenValidationMsg = ko.observable();
                self.envHintMsg = ko.observable();
                var maxLen = constants.installationDetails.envNameLength;
                self.fetchMaxLengthValidation = function () {
                    if (null === sessionStorage.getItem('sessionNetworkList')) {
                        console.log('network list not in session');
                        networkProfileHelper.fetchNetworkProfilesForUser();
                    }

                    if (null === sessionStorage.getItem('sessionDbSubnetMap')) {
                        console.log('subnet name length not in session');
                        networkProfileHelper.calDBSubnetLengthAssociatedWithNetworkProfile();
                    }

                    var subnetMaxLen = 0;
                    var dbSubnetMap = sessionStorage.getItem('sessionDbSubnetMap');
                    var obj = JSON.parse(dbSubnetMap);
                    var len = null !== obj ? obj.length : 0;
                    for (var i = 0; i < len; i++) {
                        if (obj[i].networkName === self.selectedNetworkProfileName()) {
                            subnetMaxLen = obj[i].dbSubnetNameLen;
                            break;
                        }
                    }
                    console.log('Selected Network ProfileName() : ' + self.selectedNetworkProfileName());
                    subnetMaxLen = constants.installationDetails.networkServiceNameLength - subnetMaxLen;
                    if (subnetMaxLen < constants.installationDetails.envNameLength)
                        maxLen = subnetMaxLen;
                    else
                        maxLen = constants.installationDetails.envNameLength;
                    console.log('MaxLen : ' + maxLen);
                    self.envHintMsg(oj.Translations.getTranslatedString('validationMsgs.envName', {'maxLen': maxLen}));
                };
                /**
                 * Find the db subnet length of the selected network profile
                 * Subtract db subnet length from network Service Name Length (which is 55 now)
                 * Based on above, max length of env name is determined and passed dynamically
                 */
                this.EnvNameValidator = ko.computed(function () {

                    self.fetchMaxLengthValidation();
                    var patternMaxLen = maxLen - 1;
                    var re = new RegExp('^[a-zA-Z]{1}$');
                    if (patternMaxLen > 1)
                        re = new RegExp('^[a-zA-Z]([a-zA-Z0-9]){0,' + patternMaxLen + '}$');
                    var temp = self.envNameInputValue();
                    // If max len is zero or less 
                    if (patternMaxLen <= 0) {
                        // TODO validation msg to be modified once QA confirms
                        var validationCustomMsg = {summary: oj.Translations.getTranslatedString('validationMsgs.envName', {'maxLen': maxLen}),
                            detail: oj.Translations.getTranslatedString('validationMsgs.envName', {'maxLen': maxLen}), severity: oj.Message.SEVERITY_TYPE.ERROR};
                        self.envLenValidationMsg([validationCustomMsg]);
                    } else
                    if (null !== temp && temp.length > 0 && !re.test(temp)) {
                        var validationCustomMsg = {summary: oj.Translations.getTranslatedString('validationMsgs.envName', {'maxLen': maxLen}),
                            detail: oj.Translations.getTranslatedString('validationMsgs.envName', {'maxLen': maxLen}), severity: oj.Message.SEVERITY_TYPE.ERROR};
                        self.envLenValidationMsg([validationCustomMsg]);
                    }
                });
                self.populateDBEditions = function ()
                {
                    var dbVersion = self.selectedDBReleaseValue();
                    if (dbVersion !== '')
                    {
                        actionsHelper.getDBEditions(dbVersion, function (error, dbEditionsList)
                        {
                            self.vmdbEditions.removeAll();
                            self.vmdbEditionsDataProvider = null;
                            lovUtils.lovOptionsUpdated(self.vmdbEditions(), self.vmDBSoftwareEdition);
                            var currentNodeCountVal = self.vmdbNodeCount();
                            var dbEditions = [];
                            for (var i = 0; i < dbEditionsList.length; i++)
                            {
                                var dbEdition = dbEditionsList[i];
                                if (currentNodeCountVal > 1)
                                {
                                    if (dbEdition.availableFor.rac)
                                    {
                                        var labelValue = {'label': dbEdition.label, 'value': dbEdition.value};
                                        dbEditions.push(labelValue);
                                    }
                                } else
                                {
                                    if (dbEdition.availableFor.nonRac)
                                    {
                                        var labelValue = {'label': dbEdition.label, 'value': dbEdition.value};
                                        dbEditions.push(labelValue);
                                    }
                                }
                                softwareEditionValueLabelMap[dbEdition.value] = dbEdition.label;
                            }
                            self.vmdbEditions(dbEditions);
                            self.vmdbEditionsDataProvider = new ArrayDataProvider(self.vmdbEditions, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.vmdbEditions(), self.vmDBSoftwareEdition);
                        });
                    }
                };
                self.clearBackupRelatedFields = function (event)
                {
                    self.backupPassword('');
                    self.backupPwdValidationMsg([]);
                    self.backupAppsPassword('');
                    self.backupAppsPwdValidationMsg([]);
                    self.sourceWalletPassword('');
                    self.srcWalletPwdValidationMsg([]);
                    self.backupWeblogicPassword('');
                    self.wlsPwdValidationMsg([]);
                };
                self.backupBucketChanged = function (event)
                {
                    self._failedPwdValidations_Backups = new Array();
                    var newBackupBucket = event['detail'].value;
                    if (newBackupBucket === "LOADING")
                        return;
                    self.clearBackupRelatedFields(event);
                    for (var i = 0; i < self.backupBucketList().length; i++)
                    {
                        var bucketName = self.backupBucketList()[i].value;
                        if (newBackupBucket === bucketName)
                        {
                            self.backupEBSVerValue(self.backupBucketList()[i].ebsVersion);
                            self.backupDBReleaseValue(self.backupBucketList()[i].dbVersion);
                            var ebsVersion = self.backupBucketList()[i].ebsVersion;
                            if (ebsVersion === constants.ebsVersions.twelveone)
                            {
                                self.showBackupWlsAdminPwd(false);
                            } else
                            {
                                self.showBackupWlsAdminPwd(true);
                            }

                            var isTdeEnabled = self.backupBucketList()[i].tdeEnabled;
                            if (isTdeEnabled === true)
                            {
                                self.showSourceWalletPassword(true);
                            } else
                            {
                                self.showSourceWalletPassword(false);
                            }
                            self.isMultiTenant(self.backupBucketList()[i].multiTenant);
                            break;
                        }
                    }
                };

                /*
                 * This will handle DB Tier page which tab to be displayed and highlighted
                 * self.backupDBReleaseValue() - Define dbVersion for the selected backup
                 * isMultiTenant : return from REST flow for each backup
                 */
                self.showComputeRadioSelection = function () {
                    var isDBMajorVersion12OrBelow = versionUtils.isDBMajorVersionLessThanOrEqualToTwelve(self.backupDBReleaseValue());
                    if (self.isMultiTenant() === true && self.isInstallationTypeUsed() === FROM_BACKUP && isDBMajorVersion12OrBelow) {
                        if (self.showComputeSetDB() === 'inline' || self.showComputeSetDB()._latestValue === 'inline') {
                            self.showComputeSetDB('none');
                        }
                        if (self.dbTypeUsed() === 'Compute' || self.dbTypeUsed()._latestValue === 'Compute') {
                            self.dbTypeUsed('VMDB System');
                        }
                        return 'none';
                    } else if (self.isInstallationTypeUsed() === NEW_INSTALLATION) {
                        return 'inline';
                    }

                    // If backup selected, but doesnot satify other conditions like isMultiTenant or isDBMajorVersion12OrBelow then setting default
                    // If dbTypeUsed not set then VM DB is highlighted with compute form
                    self.dbTypeUsed('Compute');
                    // If showComputeSetDB not set then its going none and Compute form is not visible
                    self.showComputeSetDB('inline');
                };

                self.vmdbShapeChangeListener = function (event)
                {
                    var newValue = event['detail'].value;
                    for (var i = 0; i < self.vmdbShapeList().length; i++)
                    {
                        var shape = self.vmdbShapeList()[i].value;
                        if (shape === newValue)
                        {
                            self.vmdbNodeCountList(self.vmdbShapeList()[i].supportedNodeCount);
                            self.vmdbNodeCountDataProvider = new ArrayDataProvider(self.vmdbNodeCountList, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.vmdbNodeCountList(), self.vmdbNodeCount);
                            break;
                        }
                    }
                    self.initializeBackUpChannelCountForvmdb(newValue);
                };
                self.computeShapeChangeListener = function (event) {
                    var newValue = event['detail'].value;
                    self.initializeBackUpChannelCountForCompute(newValue);
                };
                self.initializeStorageRequiredPerAppNode = function (callback)
                {
                    var serviceType = null;
                    if (self.dbTypeUsed() === 'Compute')
                    {
                        serviceType = constants.dbTypes.computeds;
                    } else if (self.dbTypeUsed() === 'Exadata System')
                    {
                        serviceType = constants.dbTypes.exadatadbsystem;
                    } else if (self.dbTypeUsed() === 'VMDB System')
                    {
                        serviceType = constants.dbTypes.vmdbsystem;
                    }
                    if (self.isInstallationTypeUsed() === NEW_INSTALLATION)
                    {
                        actionsHelper.getAppTierStorageForFreshInstall(self.freshEBSVerValue(), self.freshDBReleaseValue(), serviceType, self.selectedPurposeValue(), function (error, totalStorage)
                        {
                            if (error !== null && error !== '')
                            {
                                if (error.status === 504)
                                {
                                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                    self.addPageLevelMessage('Installation', 'error', 'Error in getting storage required for App Tier.', messageContent);
                                } else
                                {
                                    var errorCode = error.responseJSON.code;
                                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                                    {
                                        errorCode = error.status;
                                    }
                                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                                    self.addPageLevelMessage('Installation', 'error', 'Error in getting storage required for App Tier.', messageContent);
                                }
                                return;
                            }
                            if (error === '')
                            {
                                self.storagePerAppNode(totalStorage.value);
                                if (typeof (callback) !== 'undefined' && callback !== null)
                                    callback();
                            }
                        });
                    } else
                    {
                        actionsHelper.getAppTierTotalStorageForBackup(self.backupBucket(), function (error, totalStorage)
                        {
                            if (error !== null && error !== '')
                            {
                                if (error.status === 504)
                                {
                                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                    self.addPageLevelMessage('Installation', 'error', 'Error in getting storage required for Backup ' + self.backupBucket(), messageContent);
                                } else
                                {
                                    var errorCode = error.responseJSON.code;
                                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                                    {
                                        errorCode = error.status;
                                    }
                                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                                    self.addPageLevelMessage('Installation', 'error', 'Error in getting storage required for Backup ' + self.backupBucket(), messageContent);
                                }
                                return;
                            }
                            if (error === '')
                            {
                                self.storagePerAppNode(totalStorage.value);
                                if (typeof (callback) !== 'undefined' && callback !== null)
                                    callback();
                            }
                        });
                    }
                };

                self.canSkipServerSideValidationsForBackup = function () {
                    var backupIdentifier = self.backupBucket();
                    for (var k = 0; k < self._failedPwdValidations_Backups.length; k++) {
                        if (backupIdentifier === self._failedPwdValidations_Backups[k]) {
                            return true;
                        }
                    }
                    return false;

                };
                self.webEntryProtocolChanged = function (event)
                {
                    var newValue = event['detail'].value;
                    if (newValue === 'http')
                    {
                        self.webEntryPort(80);
                    } else
                    {
                        self.webEntryPort(443);
                    }
                };
                self.numberOfNodesOptionChanged = function (event, ui, forceAValue)
                {
                    var newValNum = -1;
                    if (forceAValue === null || typeof (forceAValue) === 'undefined' || typeof (forceAValue) !== 'number')
                    {
                        var newVal = event['detail'].value;
                        newValNum = parseInt(newVal);
                    } else
                    {
                        newValNum = forceAValue;
                    }
                    if (newValNum > 1)
                    {
                        self.fileSystemModeDisabled(false);
                    } else
                    {
                        self.fileSystemModeDisabled(true);
                    }

                    var existingNumOfNodesInTbl = self.appNodesObservableArray().length;
                    if (newValNum > existingNumOfNodesInTbl)
                    {
                        var totalDiff = newValNum - existingNumOfNodesInTbl;
                        for (var i = 0; i < totalDiff; i++)
                        {
                            self.addAppNode(event, ui);
                        }
                    } else
                    {
                        var totalDiff = existingNumOfNodesInTbl - newValNum;
                        for (var i = 0; i < totalDiff; i++)
                        {
                            self.deleteAppNode(event, ui);
                        }
                    }
                    self.initializeFaultDomainForAllAppNodes();
                };
                self.purposeChangeHandler = function (event, ui)
                {
                };
                self.licenseTypeChanged = function (event, ui)
                {
                    console.log('dbtype ' + self.dbTypeUsed());
                    event.preventDefault();
                };
                self.vmdbRadiosetValueChanged = function (event, ui)
                {
                    event.preventDefault();
                    if (self.dbTypeUsed() === null)
                    {
                        self.dbTypeUsed('VMDB System');
                    }
                };
                self.dbTypeChanged = function (event)
                {
                    self.dbTypeUsed(event.detail.value);
                    if (self.dbTypeUsed() === 'Compute')
                    {
                        self.databaseTypeUsed('Compute');
                        self.showComputeSetDB('inline');
                        self.showExaSetDB('none');
                    } else if (self.dbTypeUsed() === 'Exadata System')
                    {
                        self.databaseTypeUsed('Exadata CS');
                        self.showComputeSetDB('none');
                        self.showExaSetDB('inline');
                    } else if (self.dbTypeUsed() === 'VMDB System')
                    {
                        self.databaseTypeUsed('VMDB System');
                        self.showComputeSetDB('none');
                        self.showExaSetDB('none');
                        self.populateDBEditions();
                    }
                };
                //Below code is inherited and requires refactoring with 19c support
                self.InstallationTypeChangeHandler = function (event)
                {
                    self.isInstallationTypeUsed(event.detail.value);
                    console.log('INSTALLL');
                    console.log('value of insta --' + self.isInstallationTypeUsed());
                    if (self.isInstallationTypeUsed() === NEW_INSTALLATION)
                    {
                        console.log('value of insta IN FFIF--' + self.isInstallationTypeUsed());
                        self.InstallationTypeUsed(NEW_INSTALLATION);
                        self.dbTypeUsed('Compute');
                        self.databaseTypeUsed('Compute');
                        self.showNewInstallationPrompts('inline');
                        self.showBackupInstallationPrompts('none');
                        self.showCloneInstallationPrompts('none');
                        self.showComputeSetDB('inline');
                    } else if (self.isInstallationTypeUsed() === FROM_BACKUP)
                    {
                        self.InstallationTypeUsed('Provision From Storage Cloud Backup');
                        self.dbTypeUsed('VMDB System'); //need refactor with 19c
                        self.databaseTypeUsed('DBCS');
                        self.showNewInstallationPrompts('none');
                        self.showBackupInstallationPrompts('inline');
                        self.showCloneInstallationPrompts('none');
                        self.showComputeRadioSelection();
                    } else if (self.isInstallationTypeUsed() === 'YesClone')
                    {
                        self.InstallationTypeUsed('Clone from an existing environment');
                        self.databaseTypeUsed('Exadata CS');
                        self.showNewInstallationPrompts('none');
                        self.showBackupInstallationPrompts('none');
                        self.showCloneInstallationPrompts('inline');
                    }
                };
                self.lbaasSelectionChanged = function (event, ui) {
                    console.log("inside lbaas selection changed " + event);
                    self.webEntryProtocolInputValue('https');
                    var newOptionSelected = event.detail.value;
                    if (newOptionSelected === 'NO_LOAD_BALANCER')
                    {
                        self.numberOfNodesOptionChanged(event, ui, 1);
                    } else
                    {
                        self.numberOfNodesOptionChanged(event, ui, self.numberOfNodesToCreateInputValue());
                    }
                };
                self.instTypeMap = function (type)
                {
                    if (type !== null && type === FROM_BACKUP)
                    {
                        return 'Provision From Storage Clound Backup';
                    }
                    if (type !== null && type === FROM_BACKUP)
                    {
                        return 'Provision From Storage Clound Backup';
                    }
                    if (type !== null && type === FROM_BACKUP)
                    {
                        return 'Provision From Storage Clound Backup';
                    }
                };
                self.modulePath = ko.pureComputed(function ()
                {
                    console.log('Getting Module Path..');
                    createCloneUtils.disableTrainSteps(self.currentModule(), self.stepArray());
                    helpMenu.addElementAndRemoveDuplicate(self.currentModule());
                    return (constants.navModules.createEnvironmentModule + '/' + self.currentModule());
                });
                self.vmdbNodeCountChanged = function (event)
                {
                    var newNodeCount = event['detail'].value;
                    if (newNodeCount !== 1)
                    {
                        self.showClusterName('Yes');
                    } else
                    {
                        self.showClusterName('No');
                        self.clusterName('');
                    }
                    self.populateDBEditions();
                    var existingNumOfNodesInTbl = self.dbNodesObservableArray().length;
                    if (newNodeCount > existingNumOfNodesInTbl)
                    {
                        var totalDiff = newNodeCount - existingNumOfNodesInTbl;
                        for (var i = 0; i < totalDiff; i++)
                        {
                            self.addDbNode(event, null);
                        }
                    } else
                    {
                        var totalDiff = existingNumOfNodesInTbl - newNodeCount;
                        for (var i = 0; i < totalDiff; i++)
                        {
                            self.deleteDbNode(event, null);
                        }
                    }
                    self.initializeFaultDomainForAllVMDBNodes();
                };
                self.initializeFaultDomainForAllVMDBNodes = function ()
                {
                    var noOfNodes = self.dbNodesObservableArray().length;
                    var noOfAvailableFaultDomains = self.faultDomainChoiceList().length;
                    if (noOfAvailableFaultDomains === 0)
                    {
                        return;
                    }
                    if (noOfAvailableFaultDomains === 1)
                    {
                        for (var i = 0; i < noOfNodes; i++)
                        {
                            self.dbNodesObservableArray()[i].faultDomain(self.faultDomainChoiceList()[0].value);
                        }
                    } else
                    {
                        for (var i = 0; i < noOfNodes; i++)
                        {
                            self.dbNodesObservableArray()[i].faultDomain(self.faultDomainChoiceList()[i % noOfAvailableFaultDomains].value);
                        }
                    }

                };
                self.initializeFaultDomainForAllAppNodes = function ()
                {
                    var noOfNodes = self.appNodesObservableArray().length;
                    var noOfAvailableFaultDomains = self.faultDomainChoiceList().length;
                    if (noOfAvailableFaultDomains === 0)
                    {
                        return;
                    }
                    if (noOfAvailableFaultDomains === 1)
                    {
                        for (var i = 0; i < noOfNodes; i++)
                        {
                            self.appNodesObservableArray()[i].faultDomain(self.faultDomainChoiceList()[0].value);
                        }
                    } else
                    {
                        for (var i = 0; i < noOfNodes; i++)
                        {
                            self.appNodesObservableArray()[i].faultDomain(self.faultDomainChoiceList()[i % noOfAvailableFaultDomains].value);
                        }
                    }

                };
                self.optionChangeHandler = function (event, ui)
                {
                    var toStep = event.detail.toStep;
                    var fromStep = event.detail.fromStep;
                    var newOption = toStep.id;
                    var newOptionRank = toStep.rank;
                    var previousOption = event.detail.fromStep.id;
                    var previousOptionRank = fromStep.rank;
                    if (newOptionRank > previousOptionRank)
                    {

                        self.validateAndGotoNextStep(previousOption, newOption, event);
                    } else
                    {
                        self.clearPageLevelMessagesOnNavigation();
                        self.selected(newOption);
                        self.currentStep(newOption);
                        self.currentModule(self.currentStep());
                    }
                };
                self.postOptionChangeHandler = function (event, ui)
                {
                    if (event.detail.toStep && event.detail.toStep.id === "DBTierDetails_oci")
                    {
                        self.populateDBSystems();
                        self.handleComputeDBTDEInitialization();
                        self.handleVMDBSystemPatchLevelInitialization();
                        self.handleexadataDBSystemPatchLevelInitialization();
                    }
                };

                self.prevStep = function ()
                {
                    var prev = $('#train').ojTrain('previousSelectableStep');
                    if (prev !== null)
                    {
                        self.selected(prev);
                        self.currentStep(prev);
                        console.log('current step in the train (prev clicked)' + self.selected());
                        createCloneUtils.disableTrainSteps(self.selected(), self.stepArray());
                        if (self.selected() === 'DBTierDetails_oci')
                        {
                            self.startExaDataDbSystemPatchLevelValidationTimerFunction();
                            self.startvmDbSystemPatchLevelValidationTimerFunction();
                        } else
                        {
                            self.endExaDataDbSystemPatchLevelValidationTimerFunction();
                            self.endvmDbSystemPatchLevelValidationTimerFunction();
                        }
                        self.currentModule(self.currentStep());
                    }
                };
                self.finalizeErrors = function (trackerObj)
                {
                    console.log('Tracker Obj --' + trackerObj + '  Tracker --' + self.tracker());
                    var invalidsPresent = false;
                    trackerObj.showMessages();
                    if (trackerObj.focusOnFirstInvalid())
                    {
                        invalidsPresent = true;
                    }
                    return !invalidsPresent;
                };
                ExaDBPasswdvalidator.prototype.validate = function (value)
                {
                    var compareTo = self.exaDBSystemAdminPassword();
                    if (!value && !compareTo)
                    {
                        return true;
                    } else if (value !== compareTo)
                    {
                        throw new Error(passwdMismatchMsg);
                    }
                    return true;
                };
                VMDBPasswdvalidator.prototype.validate = function (value)
                {
                    var compareTo = self.vmDBSystemAdminPassword();
                    if (!value && !compareTo)
                    {
                        return true;
                    } else if (compareTo && !value)
                    {
                        return false;
                    } else if (value !== compareTo)
                    {
                        throw new Error(passwdMismatchMsg);
                    }
                    self.dbTypeUsed('VMDB System');
                    return true;
                };
                VMDBCharacterPasswdvalidator.prototype.validate = function (value)
                {
                    if (!value)
                        return false;
                    var re = new RegExp("^(?=.*?[0-9].*?[0-9])(?=.*?[\-_#].*?[\-_#])(?=.*?[a-z].*?[a-z])(?=.*?[A-Z].*?[A-Z]).{9,30}$");
                    if (!re.test(value))
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPassword'));
                    } else
                    {
                        for (var i = 0; i < value.length; i++)
                        {
                            var asciiVal = value.charCodeAt(i);
                            if ((asciiVal < 65 || asciiVal > 90) && (asciiVal < 97 || asciiVal > 122) &&
                                    (asciiVal < 48 || asciiVal > 57) &&
                                    (asciiVal !== 35) && (asciiVal !== 95) && (asciiVal !== 45))
                            {
                                throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPassword'));
                            }
                        }
                    }

                    if (value.toLowerCase().indexOf('sys') > -1)
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPasswordUserName'));
                    } else if (value.toLowerCase().indexOf('oracle') > -1)
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPasswordOracle'));
                    }
                    var dbName = document.getElementById('vmDBName|input') ? document.getElementById('vmDBName|input').value : '';
                    if ((dbName !== null) && (dbName !== '') && (dbName === value))
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPasswordDBName'));
                    }


                    var reEnterAdminPwdFieldValue = document.getElementById('reenterVMdbAdminPwd|input').value;
                    if (reEnterAdminPwdFieldValue !== null && reEnterAdminPwdFieldValue !== '')
                    {
                        if (value === reEnterAdminPwdFieldValue)
                        {
                            /* User entered re-enter admin pwd value first and then enter admin pwd value , they are matching, so clear the error from
                             * re enter admin pwd field.
                             */
                            document.getElementById('reenterVMdbAdminPwd').reset();
                            self.vmDBSystemAdminConfirmedPassword(value);
                        } else
                        {
                            self.useInternalValueForValidation = true;
                            document.getElementById('reenterVMdbAdminPwd').validate();
                        }
                    }

                    return true;
                };
                DBSystemPasswdvalidator.prototype.validate = function (value)
                {
                    var compareTo = self.adminPasswdInputValue();
                    if (!value && !compareTo)
                    {
                        return true;
                    } else if (value !== compareTo)
                    {
                        throw new Error(passwdMismatchMsg);
                    }
                    return true;
                };
                DBPasswdCharactervalidator.prototype.validate = function (value)
                {
                    return createCloneUtils.validateDBPasswordCharacter(self, value);
                };
                BackupPasswordValidator.prototype.validate = function (value)
                {
                    return createCloneUtils.validateBackupPassword(self, value);
                };
                ExaDBCharacterPasswdvalidator.prototype.validate = function (value)
                {
                    if (!value)
                        return false;
                    var re = new RegExp("^(?=.*?[0-9].*?[0-9])(?=.*?[\-_#].*?[\-_#])(?=.*?[a-z].*?[a-z])(?=.*?[A-Z].*?[A-Z]).{9,30}$");
                    if (!re.test(value))
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPassword'));
                    } else
                    {
                        for (var i = 0; i < value.length; i++)
                        {
                            var asciiVal = value.charCodeAt(i);
                            if ((asciiVal < 65 || asciiVal > 90) && (asciiVal < 97 || asciiVal > 122) &&
                                    (asciiVal < 48 || asciiVal > 57) &&
                                    (asciiVal !== 35) && (asciiVal !== 95) && (asciiVal !== 45))
                            {
                                throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPassword'));
                            }
                        }
                    }

                    if (value.toLowerCase().indexOf('sys') > -1)
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPasswordUserName'));
                    } else if (value.toLowerCase().indexOf('oracle') > -1)
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPasswordOracle'));
                    }
                    var dbName = document.getElementById('exaDBName|input') ? document.getElementById('exaDBName|input').value : '';
                    if ((dbName !== null) && (dbName !== '') && (dbName === value))
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPasswordDBName'));
                    }
                    var reEnterAdminPwdFieldValue = document.getElementById('reenterExadbAdminPwd|input').value;
                    if (reEnterAdminPwdFieldValue !== null && reEnterAdminPwdFieldValue !== '')
                    {
                        if (value === reEnterAdminPwdFieldValue)
                        {
                            /* User entered re-enter admin pwd value first and then enter admin pwd value , they are matching, so clear the error from
                             * re enter admin pwd field.
                             */
                            document.getElementById('reenterExadbAdminPwd').reset();
                            self.backupReEnterAdminPwd(value);
                        } else
                        {
                            self.useInternalValueForValidation = true;
                            document.getElementById('reenterExadbAdminPwd').validate();
                        }
                    }

                    return true;
                };
                PDBNameValidator.prototype.validate = function (value)
                {
                    var dbName = document.getElementById('vmDBName').value;
                    var re = new RegExp("^[A-Za-z][a-zA-Z0-9]{0,7}$");
                    if (!value)
                    {
                        return false;
                    }
                    if (!re.test(value))
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPdbName'));
                    }

                    if (typeof value !== 'undefined' && typeof dbName !== 'undefined' && value !== null && dbName !== null && value.toLowerCase() === dbName.toLowerCase())
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.samePdbDbName'));
                    }
                    if (value.toUpperCase() === 'PDB1')
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.pdbNameIsPDB1', {'pdbName': value}));
                    }
                    return true;
                };

                /*
                 * Called on tab out of vmDBName field
                 * This function call pdbName validation as DB name and PDB name cannot be same.
                 */
                self.validateOnVmDBNameChanged = function () {
                    var pdbName = document.getElementById('vmDBPDBName');
                    if (pdbName === null) {
                        return;
                    }

                    if (pdbName.childNodes !== null && pdbName.childNodes.length > 0) {
                        var pdbNameVal = document.getElementById('vmDBPDBName').value;
                        // Call PDBNameValidator
                        if (pdbName.childNodes[0].value !== '' && null !== pdbNameVal)
                            pdbName.validate();
                    }
                };
                ExaDBPDBNameValidator.prototype.validate = function (value)
                {
                    if (!value)
                    {
                        return false;
                    }
                    var dbName = document.getElementById('exaDBName').value;
                    var re = new RegExp("^[A-Za-z][a-zA-Z0-9]{0,7}$");
                    if (!re.test(value))
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.weakPdbName'));
                    }
                    if (typeof value !== 'undefined' && typeof dbName !== 'undefined' && value !== null && dbName !== null && value.toLowerCase() === dbName.toLowerCase())
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.sameExaPdbDbName'));
                    }
                    if (value.toUpperCase() === 'PDB1')
                    {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.pdbNameIsPDB1', {'pdbName': value}));
                    }
                    return true;
                };

                ComputePDBNameValidator.prototype.validate = function (value)
                {
                    return createCloneUtils.validateComputePDBName(value);
                };

                // Called on tab out of exaDBName field
                self.validateOnExaDBNameChanged = function ()
                {
                    var exaPdbName = document.getElementById('exaDBPDBName');
                    if (exaPdbName.childNodes !== null && exaPdbName.childNodes.length > 0)
                    {
                        //Call ExaDBPDBNameValidator
                        if (exaPdbName.childNodes[0].value !== '')
                            exaPdbName.validate();
                    }
                };
                self.populateAvailableStorage = function ()
                {
                    if (self.dbTypeUsed() === 'VMDB System')
                    {
                        if (self.isInstallationTypeUsed() === NEW_INSTALLATION)
                        {
                            actionsHelper.getTotalStorageForFreshInstall(self.freshEBSVerValue(), self.freshDBReleaseValue(), constants.dbTypes.vmdbsystem, self.selectedPurposeValue(), self.vmdbNodeCount(), function (error, totalStorage)
                            {
                                if (error === '')
                                {
                                    self.totalStorage(totalStorage.value);
                                }
                            });
                        } else
                        {
                            actionsHelper.getTotalStorageForBackup(self.backupBucket(), self.vmdbNodeCount(), function (error, totalStorage)
                            {
                                if (error === '')
                                {
                                    self.totalStorage(totalStorage.value);
                                }
                            });
                        }
                    }
                };

                self.installationDetailsPageValid = function ()
                {
                    var envName = document.getElementById("envName");
                    var networkProfileName = document.getElementById("networkProfileName");
                    var purposeChoice = document.getElementById("purposeChoice");
                    var ebsVerChoice = document.getElementById("ebsVerChoice");
                    var dbVerChoice = document.getElementById("dbVerChoice");
                    var backupBucket = document.getElementById("backupBucket");
                    var backupPassword = document.getElementById("backupPassword");
                    var backupAppsPassword = document.getElementById("backupAppsPassword");
                    var wlsPassword = document.getElementById("wlsPassword");
                    var wltPassword = document.getElementById("sourceWalletPassword");
                    // Currently we have one textfield, so added id as tagKeyText0,
                    // in future, when we have dynamic row concept, need to loop
                    var tagKeyText = document.getElementById("tagKeyText0");
                    self.networkProfileNameValidationMsg([]);
                    self.backupBucketValidationMsg([]);

                    var invalidsPresent = false;
                    if (envName.valid !== 'valid')
                    {
                        envName.showMessages();
                        invalidsPresent = true;
                    }
                    if (networkProfileName.valid !== 'valid')
                    {
                        networkProfileName.showMessages();
                        invalidsPresent = true;
                    }

                    if (networkProfileName.value === "LOADING")
                    {

                        var networkProfileNameValidationCustomMsg = oj.Translations.getTranslatedString('validationMsgs.lovValueNotSelectedMsg', {lovName: 'network profile'});
                        var validationMsg = {summary: networkProfileNameValidationCustomMsg,
                            detail: networkProfileNameValidationCustomMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};

                        self.networkProfileNameValidationMsg([validationMsg]);
                        invalidsPresent = true;
                    }

                    if (null !== tagKeyText && tagKeyText.valid !== 'valid') {
                        tagKeyText.showMessages();
                        invalidsPresent = true;
                    }
                    if (self.isInstallationTypeUsed() === NEW_INSTALLATION)
                    {
                        if (purposeChoice.valid !== 'valid' || ebsVerChoice.valid !== 'valid' || dbVerChoice.valid !== 'valid')
                        {
                            purposeChoice.showMessages();
                            ebsVerChoice.showMessages();
                            dbVerChoice.showMessages();
                            invalidsPresent = true;
                        }
                    } else if (self.isInstallationTypeUsed() === FROM_BACKUP)
                    {
                        // When restore from private backup, that time setting purpose type as PROD
                        // purposeOptions[0] is Demo and purposeOptions[1] is PROD
                        // Doing at validation time as while changing radio button, 
                        // sometime purposetype is not loaded and showing undefined
                        var purposeOptions = self.ebsVersionsDataAll().installtypes;
                        if (purposeOptions !== null && purposeOptions !== undefined && purposeOptions.length > 0) {
                            purposeChoice.value = purposeOptions[1].value;
                        }

                        if (self.showBackupWlsAdminPwd() && wlsPassword.valid !== 'valid')
                        {
                            wlsPassword.showMessages();
                            invalidsPresent = true;
                        }
                        if (self.showSourceWalletPassword() && wltPassword.valid !== 'valid')
                        {
                            wltPassword.showMessages();
                            invalidsPresent = true;
                        }
                        if (backupBucket.valid !== 'valid'
                                || backupPassword.valid !== 'valid' || backupAppsPassword.valid !== 'valid')
                        {
                            backupBucket.showMessages();
                            backupPassword.showMessages();
                            backupAppsPassword.showMessages();
                            invalidsPresent = true;
                        }

                        if (backupBucket.value === "LOADING")
                        {
                            var backupBucketValidationCustomMsg = oj.Translations.getTranslatedString('validationMsgs.lovValueNotSelectedMsg', {lovName: 'backup bucket'});
                            var validationMsg = {summary: backupBucketValidationCustomMsg,
                                detail: backupBucketValidationCustomMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};
                            self.backupBucketValidationMsg([validationMsg]);
                            invalidsPresent = true;
                        }
                    }
                    return !invalidsPresent;
                };
                self.dbTierPageValid = function ()
                {

                    var invalidsPresent = false;
                    console.log("DB Type Used: " + self.dbTypeUsed());
                    if (self.dbTypeUsed() === 'Compute')
                    {
                        var vmShape = document.getElementById("vmShape");
                        var dbsid = document.getElementById("dbsid");
                        if (vmShape.valid !== 'valid' || dbsid.valid !== 'valid')
                        {
                            dbsid.showMessages();
                            vmShape.showMessages();
                            invalidsPresent = true;
                        }


                        var adminPwd = document.getElementById('backupAdminPwd');
                        var reEnterAdminPwd = document.getElementById('backupReEnterAdminPwd');
                        if (adminPwd.valid !== 'valid' || reEnterAdminPwd.valid !== 'valid')
                        {
                            adminPwd.showMessages();
                            reEnterAdminPwd.showMessages();
                            invalidsPresent = true;
                        }

                        if (self.backupAdminPwd() !== self.backupReEnterAdminPwd())
                        {
                            reEnterAdminPwd.validate();
                            invalidsPresent = true;
                        }

                        if (self.showPDBPromptForCompute() === 'Yes')
                        {
                            var computePDBPrompt = document.getElementById('computePDBName');
                            if (computePDBPrompt.valid !== 'valid')
                            {
                                computePDBPrompt.showMessages();
                                invalidsPresent = true;
                            }
                        }

                        //logical hostname validation
                        var logicalFields = new Array();
                        logicalFields.push('dbLogicalHostPrefix');
                        logicalFields.push('dbLogicalDomain');
                        for (var i = 0; i < logicalFields.length; i++)
                        {
                            var htmlElement = document.getElementById(logicalFields[i]);
                            if (htmlElement !== null)
                                htmlElement.validate();
                            if (htmlElement !== null && htmlElement.valid !== 'valid')
                            {
                                invalidsPresent = true;
                                // htmlElement.showMessages();
                            }
                        }


                    } else if (self.dbTypeUsed() === 'VMDB System')
                    {
                        console.log("db version " + self.selectedDBReleaseValue());
                        var vmDBName = document.getElementById("vmDBName");
                        var vmShape = document.getElementById("vmShape");
                        var vmDBSofEdition = document.getElementById("vmDBSofEdition");
                        var vmdbAdminPwd = document.getElementById("vmdbAdminPwd");
                        var reenterVMdbAdminPwd = document.getElementById("reenterVMdbAdminPwd");
                        var vmDBPDBName = document.getElementById("vmDBPDBName");
                        var nodeCount = document.getElementById("vmDBNodeCount");
                        var dbPatchLevel = document.getElementById("vmdbPSU");
                        if (vmDBName.valid !== 'valid' || dbPatchLevel.valid !== 'valid' || vmDBSofEdition.valid !== 'valid' ||
                                vmdbAdminPwd.valid !== 'valid' || reenterVMdbAdminPwd.valid !== 'valid' || nodeCount.valid !== 'valid' ||
                                (vmDBPDBName && vmDBPDBName.valid !== 'valid'))
                        {
                            vmDBName.showMessages();
                            vmDBPDBName.showMessages();
                            vmDBSofEdition.showMessages();
                            vmdbAdminPwd.showMessages();
                            reenterVMdbAdminPwd.showMessages();
                            dbPatchLevel.showMessages();
                            nodeCount.showMessages();
                            invalidsPresent = true;
                        }

                        if (self.vmDBSystemAdminPassword() !== self.vmDBSystemAdminConfirmedPassword())
                        {
                            reenterVMdbAdminPwd.validate();
                            invalidsPresent = true;
                        }

                        //logical hostname validation
                        //comment out following code as for now logical host is not supported in vmdb
                        var logicalFields = new Array();
                        //logicalFields.push('vmdbLogicalhostPrefix');
                        //logicalFields.push('vmdbLogicalDomain');
                        for (var i = 0; i < logicalFields.length; i++)
                        {
                            var htmlElement = document.getElementById(logicalFields[i]);
                            if (htmlElement !== null)
                                htmlElement.validate();
                            if (htmlElement !== null && htmlElement.valid !== 'valid')
                            {
                                invalidsPresent = true;
                                // htmlElement.showMessages();
                            }
                        }

                    } else if (self.dbTypeUsed() === 'Exadata System')
                    {
                        var exaDBName = document.getElementById("exaDBName");
                        var dbSystemName = document.getElementById("dbSystemName");
                        var dbPSU = document.getElementById("dbPSU");
                        var exaDBPDBName = document.getElementById("exaDBPDBName");
                        var exadbAdminPwd = document.getElementById("exadbAdminPwd");
                        var reenterExadbAdminPwd = document.getElementById("reenterExadbAdminPwd");
                        if (exaDBName.valid !== 'valid' ||
                                dbSystemName.valid !== 'valid' ||
                                dbPSU.valid !== 'valid' ||
                                exadbAdminPwd.valid !== 'valid' ||
                                reenterExadbAdminPwd.valid !== 'valid')
                        {
                            exaDBName.showMessages();
                            dbPSU.showMessages();
                            dbSystemName.showMessages();
                            exadbAdminPwd.showMessages();
                            reenterExadbAdminPwd.showMessages();
                            invalidsPresent = true;
                        }
                        if (self.selectedDBReleaseValue() === constants.dbVersion.twelve && exaDBPDBName.valid !== 'valid')
                        {
                            exaDBPDBName.showMessages();
                            invalidsPresent = true;
                        }
                        if (self.exaDBSystemAdminPassword() !== self.exaDBSystemAdminConfirmedPassword())
                        {
                            reenterExadbAdminPwd.validate();
                            invalidsPresent = true;
                        }
                    }
                    return !invalidsPresent;
                };
                self.topologyPageValid = function ()
                {
                    var zonesListViewElement = document.getElementById('zonesListView');
                    var viewModuleOfTopologyPG = ko.dataFor(zonesListViewElement);
                    return viewModuleOfTopologyPG.isTopologyValid();
                };
                self.startExaDataDbSystemPatchLevelValidationTimerFunction = function ()
                {
                    console.log('Start Timer - - Exadata DB PSU Timer');
                    self.exaDataDBPSUValidationTimer = setInterval(function () {
                        //console.log('Timer Function Executing - Exadata.');
                        self.validateExaDBPSUSelectedValue(self.exaDBSystemPSU());
                    }, 250);
                };
                self.endExaDataDbSystemPatchLevelValidationTimerFunction = function ()
                {
                    if (self.exaDataDBPSUValidationTimer !== null)
                    {
                        console.log('End Timer - Exadata DB PSU Timer');
                        clearInterval(self.exaDataDBPSUValidationTimer);
                    }
                };
                self.startvmDbSystemPatchLevelValidationTimerFunction = function ()
                {
                    console.log('Start Timer - VMDB PSU Timer ');
                    self.vmDBPSUValidationTimer = setInterval(function () {
                        self.validateVMDBPSUSelectedValue(self.vmDBSystemPSU());
                    }, 250);
                };
                self.endvmDbSystemPatchLevelValidationTimerFunction = function ()
                {
                    if (self.vmDBPSUValidationTimer !== null)
                    {
                        console.log('End Timer - VMDB PSU Timer');
                        clearInterval(self.vmDBPSUValidationTimer);
                    }
                };
                self.nextStep = function ()
                {

                    var next = $('#train').ojTrain('nextSelectableStep');
                    self.selected(next);
                };
                self.validateAndGotoNextStep = function (previousStep, nextStep, trainSelectionEvent)
                {
                    var invalid = false;
                    if (nextStep !== null)
                    {
                        createCloneUtils.disableTrainSteps(self.selected(), self.stepArray());
                        if (previousStep === constants.navModules.installationDetailsModule && !this.installationDetailsPageValid())
                        {
                            console.log('Errors found ..');
                            invalid = true;
                        } else if (previousStep === constants.navModules.installationDetailsModule)
                        {
                            self.isProvisioningFromBackup('false');
                            self.isProvisioningFromTDEEnabledBackup('false');
                            self.envNameInputValue();
                            if (self.isInstallationTypeUsed() === NEW_INSTALLATION)
                            {
                                self.selectedEbsVerValue(self.freshEBSVerValue());
                                self.selectedDBReleaseValue(self.freshDBReleaseValue());
                            } else
                            {
                                self.selectedEbsVerValue(self.backupEBSVerValue());
                                self.selectedDBReleaseValue(self.backupDBReleaseValue());
                                self.isProvisioningFromBackup('true');
                                self.isProvisioningFromTDEEnabledBackup('false');
                                var selectedBackUpOption = self.backupBucket();
                                if (selectedBackUpOption !== null && selectedBackUpOption !== '')
                                {
                                    var listOfBackupBuckets = self.backupBucketList();
                                    for (var i = 0; i < listOfBackupBuckets.length; i++)
                                    {
                                        var currentBucket = listOfBackupBuckets[i];
                                        var currentBucketVal = currentBucket.value;
                                        if (currentBucketVal === selectedBackUpOption)
                                        {
                                            var currentBackupTDEFlag = currentBucket.tdeEnabled;
                                            if (currentBackupTDEFlag)
                                            {
                                                self.isProvisioningFromTDEEnabledBackup('true');
                                            }
                                            break;
                                        }
                                    }
                                }

                            }
                            self.editionChoiceOptionsList(dbEditionsMap[self.selectedDBReleaseValue()]);
                            var isDBMajorVersion12AndAbove = versionUtils.isDBMajorVersionGreaterThanOrEqualToTwelve(self.selectedDBReleaseValue());

                            if (isDBMajorVersion12AndAbove)

                            {
                                self.showPDBPrompt('Yes');
                            } else
                            {
                                self.showPDBPrompt('No');
                            }

                            var isDBMajorVersion19AndAbove = versionUtils.isDBMajorVersionGreaterThanOrEqualToNineteen(self.selectedDBReleaseValue());
                            if (isDBMajorVersion19AndAbove)
                            {
                                self.showPDBPromptForCompute('Yes');
                            } else
                            {
                                self.showPDBPromptForCompute('No');
                            }

                            self.stepArray()[2].disabled = false;
                        }
                        if (previousStep === constants.navModules.dbTierDetailsModule && !this.dbTierPageValid())
                        {
                            invalid = true;
                        } else if (previousStep === constants.navModules.dbTierDetailsModule)
                        {

                            self.softEditionDispValue(softwareEditionValueLabelMap[self.vmDBSoftwareEdition()]);
                            self.stepArray()[3].disabled = false;
                            self.stepArray()[4].disabled = false;
                            self.stepArray()[5].disabled = false;
                            self.populateAvailableStorage();
                            self.initializeStorageRequiredPerAppNode();
                        }

                        if (previousStep === constants.navModules.topologyDetailsModule)
                        {
                            var topologyDetailsViewModel = ko.dataFor(document.getElementById('zonesListView'));
                            self.noOfZonesEntered(topologyDetailsViewModel.zones().length);
                            self.zoneSequence(topologyDetailsViewModel.sequence());
                        }

                        // Moving from topology page to custom execution page.
                        if (previousStep === constants.navModules.topologyDetailsModule && !this.topologyPageValid())
                        {
                            console.log('Errors found ..');
                            invalid = true;
                        } else if (previousStep === constants.navModules.topologyDetailsModule)
                        {
                            var customExecPlanTabElem = document.getElementById('customTasksListingTab');
                            // we already loaded the custom execution plan page. Detect if there are any changes in the 
                            // input parameters that derive the template.
                            if (customExecPlanTabElem !== null)
                            {
                                var execPlanCustomizationViewModel = ko.dataFor(customExecPlanTabElem);
                                if (typeof (execPlanCustomizationViewModel) !== 'undefined') {
                                    execPlanCustomizationViewModel.reinit();
                                }
                            }
                        }

                        if (previousStep === constants.navModules.postProvisioningStepsModule)
                        {
                            var execPlanCustomizationViewModel = ko.dataFor(document.getElementById('customTasksListingTab'));
                            if (typeof (execPlanCustomizationViewModel) !== 'undefined') {
                                var isExecPlanPageValid = execPlanCustomizationViewModel.isFormValid();
                                if (!isExecPlanPageValid)
                                {
                                    console.log('Errors found ..');
                                    invalid = true;
                                }
                            }

                            var uploadKeysViewModel = ko.dataFor(document.getElementById('uploadKeysPGForm'));
                            if (typeof (uploadKeysViewModel) !== 'undefined') {
                                uploadKeysViewModel.reInit();
                            }
                        }

                        if (previousStep === constants.navModules.uploadKeysModule) {
                            var uploadKeysViewModel = ko.dataFor(document.getElementById('uploadKeysPGForm'));
                            if (typeof (uploadKeysViewModel) !== 'undefined') {
                                var isUploadKeysPageValid = uploadKeysViewModel.isFormValid();
                                if (!isUploadKeysPageValid) {
                                    console.log('Errors found in upload keys module.');
                                    invalid = true;
                                }
                            }
                        }
                        if (nextStep === constants.navModules.reviewModule)
                        {
                            if (self.dbTypeUsed() === 'Compute')
                            {
                                self.dataBaseNameInputValue(self.dbSIDInputValue());
                            } else if (self.dbTypeUsed() === 'VMDB System')
                            {
                                self.dataBaseNameInputValue(self.vmDBName());
                            } else
                            {
                                self.dataBaseNameInputValue(self.exaDBName())
                            }
                            self.enableTDEFlagForComputeInReviewScreen(false);
                            if (self.dbTypeUsed() === 'Compute')
                            {
                                var isProvisioningFromBackup = (self.isProvisioningFromBackup() === 'true');
                                if (isProvisioningFromBackup)
                                {
                                    var isTDEEnabledBackupChosen = (self.isProvisioningFromTDEEnabledBackup() === 'true');
                                    if (isTDEEnabledBackupChosen)
                                    {

                                        self.enableTDEFlagForComputeInReviewScreen(true);
                                    } else
                                    {
                                        var isTDEFlagChosen = self.TDECheckBoxOptionValue()[0] === 'Y';
                                        if (isTDEFlagChosen)
                                        {
                                            self.enableTDEFlagForComputeInReviewScreen(true);
                                        }
                                    }
                                } else
                                {
                                    var isTDEFlagChosen = self.TDECheckBoxOptionValue()[0] === 'Y';
                                    if (isTDEFlagChosen)
                                    {
                                        self.enableTDEFlagForComputeInReviewScreen(true);
                                    }

                                }
                            }

                            var noOfAppNodesInputValue = self.numberOfNodesToCreateInputValue();
                            if (self.lbaasOptionValue() === 'NO_LOAD_BALANCER' || noOfAppNodesInputValue === 1)
                            {
                                self.fileSystemModeValue(constants.filesystemMode.nonSharedLabel);
                            }

                            var lookupLabel = null;
                            for (var i = 0; i < self.lbaasOptions().length; i++)
                            {
                                var lookupName = self.lbaasOptions()[i].label;
                                var lookupValue = self.lbaasOptions()[i].value;
                                if (lookupValue === self.lbaasOptionValue())
                                {
                                    lookupLabel = lookupName;
                                }
                            }
                            self.webEntryTypeLabel(lookupLabel);
                        }
                        if (invalid)
                        {
                            if (!$.isEmptyObject(trainSelectionEvent))
                            {
                                trainSelectionEvent.preventDefault();
                            }
                            self.stayInSameStep(previousStep);
                        } else
                        {
                            console.log('No client side errors found..proceeding to server side validations..');
                            console.log('current step in the train (next clicked) ' + self.selected());
                            self.performServerSideValidations(previousStep, nextStep, trainSelectionEvent);
                        }
                    }
                };

                self.performInstallationDetailsPGServerValidation = function (prevStep, nextStep, trainSelectionEvent)
                {
                    console.log('Performing server side validations for installation details page.');
                    self.addPageLevelMessage('Installation', 'info', 'Password validation is in progress', '');
                    var inputsToValidateFromServer =
                            [
                                {"id": "credentials.backup.backupPassword", "internalId": "backupPassword", "customMsgObject": self.backupPwdValidationMsg, "value": self.backupPassword()},
                                {"id": "credentials.backup.appsPassword", "internalId": "backupAppsPassword", "customMsgObject": self.backupAppsPwdValidationMsg, "value": self.backupAppsPassword()}
                            ];
                    var isSrcWalletPwdRendered = self.showSourceWalletPassword();
                    if (isSrcWalletPwdRendered)
                    {
                        inputsToValidateFromServer.push({"id": "credentials.backup.sourceTDEPassword", "internalId": "sourceWalletPassword", "customMsgObject": self.srcWalletPwdValidationMsg, "value": self.sourceWalletPassword()});
                    }

                    var isWlsPwdRequired = self.showBackupWlsAdminPwd();
                    if (isWlsPwdRequired)
                    {
                        inputsToValidateFromServer.push({"id": "credentials.environment.weblogicPassword", "internalId": "wlsPassword", "customMsgObject": self.wlsPwdValidationMsg, "value": self.backupWeblogicPassword()});
                    }
                    var tenancyName = rootViewModel.tenancyNameValue();
                    var backupIdentifier = self.backupBucket();
                    self.validateOnServer(inputsToValidateFromServer, tenancyName, backupIdentifier, prevStep, nextStep, trainSelectionEvent);
                };
                self.validateOnServer = function (validationsArray, tenancyName, backupIdentifier, prevStep, nextStep, trainSelectionEvent)
                {
                    var requestBody =
                            {
                                "tenancyName": tenancyName,
                                "backupIdentifier": backupIdentifier,
                                "inputsToValidate": []
                            };
                    var noOfValidations = validationsArray.length;
                    for (var i = 0; i < noOfValidations; i++)
                    {
                        var id = validationsArray[i].id;
                        var internalId = validationsArray[i].internalId;
                        var value = validationsArray[i].value;
                        var inputObj = new Object();
                        inputObj.id = id;
                        inputObj.internalId = internalId;
                        inputObj.value = value;
                        requestBody.inputsToValidate.push(inputObj);
                    }
                    var requestBodyJSON = JSON.stringify(requestBody);
                    console.log('Request Body JSON :: ' + requestBodyJSON);
                    actionsHelper.validateEnvironmentCredentialsForRestore(requestBodyJSON, function (error, validationResponse)
                    {
                        var allValidationsPassed = true;
                        var failedToValidate = false;

                        if (error !== null && error !== '' && error.status === 500) {
                            self._failedPwdValidations_Backups.push(backupIdentifier);
                            allValidationsPassed = false;
                            var errorMessages = new Array();
                            var validationMsg = oj.Translations.getTranslatedString("validationMsgs.serverSidePwdValidationNotAvailableMsg");
                            var validationCustomMsg = {summary: validationMsg,
                                detail: validationMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                            errorMessages.push(validationCustomMsg);

                            var customMsgObservable = null;
                            for (var y = 0; y < validationsArray.length; y++)
                            {
                                customMsgObservable = validationsArray[y].customMsgObject;
                                customMsgObservable(errorMessages);
                            }
                        } else {
                            for (var i = 0; i < validationResponse.length; i++) {
                                var validater = validationResponse[i];
                                var canDoValidation = validater.canValidate;
                                if (canDoValidation === null || typeof (canDoValidation) === 'undefined' || !canDoValidation)
                                {
                                    failedToValidate = true;


                                }
                            }
                            if (failedToValidate) {
                                self._failedPwdValidations_Backups.push(backupIdentifier);
                                allValidationsPassed = false;
                                for (var i = 0; i < validationResponse.length; i++)
                                {
                                    var validater = validationResponse[i];
                                    var errorMessages = new Array();
                                    var validationMsg = oj.Translations.getTranslatedString("validationMsgs.serverSidePwdValidationNotAvailableMsg");
                                    var validationCustomMsg = {summary: validationMsg,
                                        detail: validationMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                                    errorMessages.push(validationCustomMsg);
                                    var internalId = validater.internalId;
                                    var customMsgObservable = null;
                                    for (var y = 0; y < validationsArray.length; y++)
                                    {
                                        var internalIdInArray = validationsArray[y].internalId;
                                        if (internalIdInArray === internalId)
                                        {
                                            customMsgObservable = validationsArray[y].customMsgObject;
                                            customMsgObservable(errorMessages);
                                        }
                                    }
                                }
                            } else {
                                for (var i = 0; i < validationResponse.length; i++)
                                {
                                    var validater = validationResponse[i];
                                    var isValid = validater.isValid;
                                    if (!isValid)
                                    {
                                        allValidationsPassed = false;
                                        var errorMessages = new Array();
                                        for (var z = 0; z < validater.messages.length; z++)
                                        {
                                            var validationCustomMsg = {summary: validater.messages[z].message,
                                                detail: validater.messages[z].message, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                            errorMessages.push(validationCustomMsg);
                                        }
                                        var internalId = validater.internalId;
                                        var customMsgObservable = null;
                                        for (var y = 0; y < validationsArray.length; y++)
                                        {
                                            var internalIdInArray = validationsArray[y].internalId;
                                            if (internalIdInArray === internalId)
                                            {
                                                customMsgObservable = validationsArray[y].customMsgObject;
                                                customMsgObservable(errorMessages);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (!allValidationsPassed)
                        {
                            if (!$.isEmptyObject(trainSelectionEvent))
                            {
                                trainSelectionEvent.preventDefault();
                            }
                            self.stayInSameStep(prevStep);
                        } else
                        {
                            self.proceeedToNextStep(prevStep, nextStep, trainSelectionEvent);
                        }

                        self.disableNextBtn(false);
                        self.clearPageLevelMessagesOnNavigation();
                    });
                };
                self.performServerSideValidations = function (prevStep, nextStep, trainSelectionEvent)
                {
                    var proceed = false;
                    if (prevStep === constants.navModules.installationDetailsModule && self.isInstallationTypeUsed() === constants.installationTypes.backup && !self.canSkipServerSideValidationsForBackup())
                    {
                        self.disableNextBtn(true);
                        self.performInstallationDetailsPGServerValidation(prevStep, nextStep);
                    } else if (prevStep === constants.navModules.uploadKeysModule)
                    {
                        self.disableNextBtn(true);
                        createCloneUtils.performSSHKeysPGServerValidation(self, prevStep, nextStep, trainSelectionEvent);
                    } else
                    {
                        proceed = true;
                    }
                    if (proceed)
                    {
                        self.proceeedToNextStep(prevStep, nextStep, trainSelectionEvent);
                    }

                };
                self.stayInSameStep = function (prevStep)
                {
                    self.selected(prevStep);
                    self.currentStep(prevStep);
                    self.currentModule(self.currentStep());
                };
                self.proceeedToNextStep = function (prevStep, nextStep, trainSelectionEvent)
                {
                    if (self.selected() === 'DBTierDetails_oci')
                    {
                        self.startExaDataDbSystemPatchLevelValidationTimerFunction();
                        self.startvmDbSystemPatchLevelValidationTimerFunction();
                    } else
                    {
                        self.endExaDataDbSystemPatchLevelValidationTimerFunction();
                        self.endvmDbSystemPatchLevelValidationTimerFunction();
                    }

                    var prevStepRank = self.nameToRankMap.get(prevStep);
                    var nextStepRank = self.nameToRankMap.get(nextStep);
                    if (nextStepRank - prevStepRank > 1)
                    {
                        // We are not allowed to skip steps at this moment. so go to next step.
                        var prevStepIdx = self.findIndexOfATrainStep(prevStep);
                        if (prevStepIdx !== -1)
                        {
                            if (!$.isEmptyObject(trainSelectionEvent))
                            {
                                trainSelectionEvent.preventDefault();
                            }
                            var newIdxToMove = prevStepIdx + 1;
                            nextStep = self.stepArray()[newIdxToMove].id;
                        }

                    }


                    self.clearPageLevelMessagesOnNavigation();
                    self.selected(nextStep);
                    self.currentStep(nextStep);
                    self.currentModule(self.currentStep());
                };

                self.isWarningRequiredForCustomExecutionPlanChange = function (eventName, eventValue) {
                    var customTaksListingTabElem = document.getElementById('customTasksListingTab');
                    if (customTaksListingTabElem === null) {
                        return false;
                    }
                    var executionFrameworkPGViewModel = ko.dataFor(customTaksListingTabElem);
                    if (executionFrameworkPGViewModel === null || typeof (executionFrameworkPGViewModel) === 'undefined') {
                        return false;
                    }
                    if (typeof (executionFrameworkPGViewModel) !== 'undefined') {
                        var lastExecutedParams = executionFrameworkPGViewModel.prevRunParams();
                        if (lastExecutedParams === null || lastExecutedParams.length < 1) {
                            return false;
                        } else {

                        }
                    }
                };


                self.findIndexOfATrainStep = function (stepName)
                {
                    for (var i = 0; i < self.stepArray().length; i++)
                    {
                        var currentStepName = self.stepArray()[i].id;
                        if (currentStepName === stepName)
                        {
                            return i;
                        }
                    }
                    return -1;
                };
                self.addPageLevelMessage = function (pageName, messageSeverity, messageSummary, messageDetail, clearAllPrevMessages)
                {
                    var newPageMessageObject = new Object();
                    newPageMessageObject.severity = messageSeverity;
                    newPageMessageObject.summary = messageSummary;
                    newPageMessageObject.detail = messageDetail;
                    if (typeof (clearAllPrevMessages) !== 'undefined' && clearAllPrevMessages) {
                        var tempArray = new Array();
                        tempArray.push(newPageMessageObject);
                        self.pageLevelMessages(tempArray);
                    } else {
                        var tempArray = self.pageLevelMessages();
                        tempArray.push(newPageMessageObject);
                        self.pageLevelMessages(tempArray);
                    }

                };
                self.clearPageLevelMessagesOnNavigation = function ()
                {
                    self.pageLevelMessages([]);
                };
                self.cleanup = function () {
                    console.log('cleaning variables');
                    self.dataBaseNameInputValue('');
                    self.plugDataBaseInputValue('');
                    self.selectedDBReleaseValue('');
                };
                // Tag module selected observable variables
                self.selectedTagNamespace = ko.observable('');
                self.selectedTagKeyText = ko.observable('');
                self.selectedTagKeySelect = ko.observable('');
                self.selectedTagValue = ko.observable('');
                self.submitEnvironmentCreation = function ()
                {

                    console.log('Environment Name Input Value =' + self.envNameInputValue());
                    console.log("about to submit the flow");
                    var dbType = self.dbTypeUsed();
                    var networkProfileNameSelected = self.selectedNetworkProfileName();
                    var existingDBSystem = self.existingDBSystem();
                    var installType = '';
                    var serviceType = '';
                    var ebsVersion = self.selectedEbsVerValue();
                    var backupBucket = '';
                    var computeDBName = '';
                    var computeDBShape = '';
                    var computeDBVersion = '';
                    var vmdbEdition = '';
                    var vmdbShape = '';
                    var licenseType = '';
                    var existingDBSystemName = '';
                    var dbName = '';
                    var newDbSystemName = '';
                    var newDbSystemShape = '';
                    var diskRedundancy = '';
                    var dbSystemEdition = '';
                    var dbSystemCPUCount = '';
                    var dbcsAdminPwd = '';
                    var wlsAdminPwd = '';
                    var tdeEnabled = '';
                    var sourceTdePwd = '';
                    var backupPwd = '';
                    var appsPwd = '';
                    var createEBSURL = '';
                    var pdbName = '';
                    var psu = '';
                    var clusterName = '';
                    var nodeCount;
                    var enableTDEFlagForCompute = false;
                    // Variables for tag module
                    var selTagName = '';
                    var selTagKeyText = '';
                    var selTagKeySelect = '';
                    var selFreeTagValue = '';
                    var selTagValue = '';
                    var backupChannelCount = '';

                    if (self.isInstallationTypeUsed() === NEW_INSTALLATION)
                    {
                        installType = self.selectedPurposeValue();
                    } else
                    {
                        backupBucket = self.backupBucket();
                        appsPwd = self.backupAppsPassword();
                        wlsAdminPwd = self.backupWeblogicPassword();
                    }
                    if (dbType === 'Compute')
                    {
                        computeDBName = self.dataBaseNameInputValue();
                        computeDBShape = self.dbCompSelectedShapeValue();
                        computeDBVersion = self.selectedDBReleaseValue();
                        serviceType = constants.dbTypes.computeds;
                        backupChannelCount = self.computeSelectedBackupChannelCount();

                        /* If you are restoring from a back up and the back up is already TDE Enabled, then we will need the admin password. 
                         * If the back up is not TDE Enabled, then check if the TDE enabled flag is checked by the user, if so we will need the admin password.
                         */
                        var isProvisioningFromBackup = (self.isProvisioningFromBackup() === 'true');
                        if (isProvisioningFromBackup)
                        {
                            var isTDEEnabledBackupChosen = (self.isProvisioningFromTDEEnabledBackup() === 'true');
                            if (isTDEEnabledBackupChosen)
                            {
                                dbcsAdminPwd = self.backupAdminPwd();
                                // If the back up has already TDE enabled, then we restore with TDE enabled = true.
                                enableTDEFlagForCompute = true;
                            } else
                            {
                                var isTDEFlagChosen = self.TDECheckBoxOptionValue()[0] === 'Y';
                                dbcsAdminPwd = self.backupAdminPwd();
                                if (isTDEFlagChosen)
                                {
                                    enableTDEFlagForCompute = true;
                                }
                            }
                        } else
                        {
                            var isTDEFlagChosen = self.TDECheckBoxOptionValue()[0] === 'Y';
                            if (isTDEFlagChosen)
                            {
                                enableTDEFlagForCompute = true;
                            }
                            dbcsAdminPwd = self.backupAdminPwd();
                        }

                    } else if (dbType === 'VMDB System')
                    {
                        serviceType = constants.dbTypes.vmdbsystem;
                        backupChannelCount = self.vmdbSelectedBackupChannelCount();
                        dbName = self.vmDBName();
                        vmdbEdition = self.vmDBSoftwareEdition();
                        vmdbShape = self.vmdbSelectedShapeValue();
                        licenseType = self.vmdbLicenseType();
                        dbcsAdminPwd = self.vmDBSystemAdminPassword();
                        pdbName = self.vmDBPDBName();
                        clusterName = self.clusterName();
                        nodeCount = self.vmdbNodeCount();
                        psu = self.vmDBSystemPSU();
                    } else if (dbType === 'Exadata System')
                    {
                        serviceType = constants.dbTypes.exadatadbsystem;
                        backupChannelCount = self.exaSelectedBackupChannelCount();
                        existingDBSystemName = self.exaDBSystemInputValue();
                        dbName = self.exaDBName();
                        dbcsAdminPwd = self.exaDBSystemAdminPassword();
                        pdbName = self.exaDBPDBName();
                        psu = self.exaDBSystemPSU();
                    }


                    // Logic to set values for tag module
                    if (self.selectedTagNamespace() === 'none') {
                        selTagKeyText = self.selectedTagKeyText();
                        selFreeTagValue = self.selectedTagValue();
                    } else {
                        selTagName = self.selectedTagNamespace();
                        selTagKeySelect = self.selectedTagKeySelect();
                        selTagValue = self.selectedTagValue();
                    }

                    // Added changes to the requestBody for TDE
                    var requestBody =
                            {
                                "action": {

                                },
                                "credentials": {
                                    "environment": {
                                        "databaseAdminPassword": dbcsAdminPwd,
                                        "weblogicPassword": wlsAdminPwd
                                    },
                                    "ssh": {
                                        "appTier": [

                                        ],
                                        "dbTier": [

                                        ]
                                    }
                                },

                                "environment": {
                                    "name": self.envNameInputValue(),
                                    "networkProfile": networkProfileNameSelected,
                                    "installType": installType,
                                    "ebsVersion": ebsVersion,
                                    "dbTier": {
                                        "logicalDomainName": "",
                                        "serviceType": serviceType,
                                        "dbService": {

                                            "exaDbSystem": {
                                                "name": existingDBSystemName,
                                            },
                                            "vmDbSystem": {
                                                "shape": vmdbShape,
                                                "edition": vmdbEdition,
                                                "licensingType": licenseType
                                            },
                                            "database": {
                                                "name": dbName,
                                                "version": self.selectedDBReleaseValue(),
                                                "pdbName": pdbName,
                                                "noOfNodes": nodeCount,
                                                "clusterName": clusterName,
                                                "patchLevel": psu,
                                                "nodes": [

                                                ]
                                            }
                                        },
                                        "compute": {
                                            "name": computeDBName,
                                            "shape": computeDBShape,
                                            "pdbName": "",
                                            "version": computeDBVersion,
                                            "enableTDE": enableTDEFlagForCompute,
                                            "faultDomain": "",
                                            "logicalHostName": (self.dbLogicalHostNamePrefixValue() ? self.dbLogicalHostNamePrefixValue().toLowerCase() : self.dbLogicalHostNamePrefixValue())
                                        }
                                    },
                                    "appTier": {
                                        "logicalDomainName": "",
                                        "zones": [

                                        ]
                                    },
                                    "tags": {
                                        "freeFloat": [
                                            {
                                                "key": selTagKeyText,
                                                "value": selFreeTagValue
                                            }
                                        ],
                                        "defined": [
                                            {
                                                "namespace": selTagName,
                                                "key": selTagKeySelect,
                                                "value": selTagValue
                                            }
                                        ]
                                    }

                                },
                                "advanced": {
                                    "rman": {

                                    }
                                }
                            };

                    var executionFrameworkPGViewModel = ko.dataFor(document.getElementById('customTasksListingTab'));
                    if (typeof (executionFrameworkPGViewModel) !== 'undefined') {
                        var formDataForSubmit = executionFrameworkPGViewModel.getExtensibleTasksFormData();
                        requestBody.extensibleTasks = formDataForSubmit;
                        var pausedTasks = executionFrameworkPGViewModel.getPausedTasksFormData();
                        if (pausedTasks !== null) {
                            requestBody.pauseAt = pausedTasks;
                        }
                    }

                    var appTierSSHKeys = createCloneUtils.getFormDataForAppTierSSHKeys();
                    if (appTierSSHKeys !== null && appTierSSHKeys.length > 0) {
                        requestBody.credentials.ssh.appTier = appTierSSHKeys;
                    }
                    var dbTierSSHKeys = createCloneUtils.getFormDataForDBTierSSHKeys();
                    if (dbTierSSHKeys !== null && dbTierSSHKeys.length > 0) {
                        requestBody.credentials.ssh.dbTier = dbTierSSHKeys;
                    }

                    if (serviceType === constants.dbTypes.computeds)
                    {
                        if (self.faultDomainSelectionCompute() === "Manual")
                        {
                            requestBody.environment.dbTier.compute.faultDomain = self.computeSelectedFaultDomain();
                        }
                        if (self.showPDBPromptForCompute() === 'Yes')
                        {
                            requestBody.environment.dbTier.compute.pdbName = self.computePDBName();
                        }
                        requestBody.environment.dbTier.logicalDomainName = self.dbLogicalDomainName() ? self.dbLogicalDomainName().toLowerCase() : self.dbLogicalDomainName();
                    }

                    if (serviceType === constants.dbTypes.vmdbsystem)
                    {
                        //requestBody.environment.dbTier.logicalDomainName = self.vmdbLogicalDomainName();
                        var vmDBNodesArray = requestBody.environment.dbTier.dbService.database.nodes;
                        if (nodeCount > 0 && self.dbNodesObservableArray().length > 0 && nodeCount === self.dbNodesObservableArray().length)
                        {
                            for (var i = 0; i < nodeCount; i++)
                            {
                                var eachNodeEntry = new Object();
                                eachNodeEntry.faultDomain = "";
                                //eachNodeEntry.logicalHostName = nodeCount > 1? self.vmdbLogicalHostNamePrefixValue() + "0" + i+1 : self.vmdbLogicalHostNamePrefixValue();
                                if (self.faultDomainSelectionVMDB() === "Manual")
                                    eachNodeEntry.faultDomain = self.dbNodesObservableArray()[i].faultDomain();
                                vmDBNodesArray.push(eachNodeEntry);
                            }
                        }
                    }
                    if (backupChannelCount === null) {
                        backupChannelCount = '';
                    }
                    requestBody.advanced.rman.channelCount = backupChannelCount;

                    var applicationTierGroups = requestBody.environment.appTier.zones;
                    var topologyDetailsViewModel = ko.dataFor(document.getElementById('zonesListView'));
                    var appLogicalDomain = topologyDetailsViewModel.getAppsLogicalDomain();
                    requestBody.environment.appTier.logicalDomainName = appLogicalDomain ? appLogicalDomain.toLowerCase() : appLogicalDomain;
                    var zonesPostInformation = topologyDetailsViewModel.getZonePostData();
                    if (zonesPostInformation !== null && zonesPostInformation.length > 0)
                    {
                        for (var i = 0; i < zonesPostInformation.length; i++)
                        {
                            applicationTierGroups.push(zonesPostInformation[i]);
                        }
                    }

                    var infoMsg = oj.Translations.getTranslatedString("confirmPopup.advCreateInfoMsg", {'envName': self.envNameInputValue()});
                    var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.advCreateEnvTitle");
                    popupHelper.openInfoMsg(constants.divTags.createAdvEnvPopupTag, infoMsg, msgOrigin);
                    if (self.isInstallationTypeUsed() === NEW_INSTALLATION)
                    {
                        // Disable the submit button immeditaly after the user clicks on the submit to avoid multiple submits.
                        // If the submission failed, then the code below enables the submit button again for the user to re-submit.
                        self.disableSubmitBtn(true);
                        var requestBodyJSON = JSON.stringify(requestBody);
                        actionsHelper.createFreshEnv(requestBodyJSON, function (error, success)
                        {
                            if (error === '')
                            {
                                self.cleanup();
                                var context = ko.contextFor(document.getElementById(constants.divTags.advancedInstallationPage));
                                rootViewModel.displayPopupId(constants.divTags.createAdvEnvPopupTag);
                                var confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.advCreateSuccessEnvMsg", {'envName': self.envNameInputValue()});
                                popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);
                                pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                            } else
                            {
                                self.disableSubmitBtn(false);
                                var responseText = error.responseText;
                                var response = JSON.parse(responseText);
                                popupHelper.openErrorMsg(constants.divTags.createAdvEnvPopupTag, response.message, msgOrigin);
                            }
                        });
                    } else
                    {
                        // Disable the submit button immeditaly after the user clicks on the submit to avoid multiple submits.
                        // If the submission failed, then the code below enables the submit button again for the user to re-submit.
                        self.disableSubmitBtn(true);
                        requestBody.action.backup = {
                            "identifier": backupBucket,
                            "tdeEnabled": self.showSourceWalletPassword()
                        };
                        requestBody.credentials.backup = {
                            "backupPassword": self.backupPassword(),
                            "appsPassword": appsPwd,
                            "sourceTDEPassword": self.sourceWalletPassword()
                        };
                        var requestBodyJSON = JSON.stringify(requestBody);
                        actionsHelper.createEnvFromBackup(requestBodyJSON, function (error, success)
                        {
                            if (error === '')
                            {
                                self.cleanup();
                                var context = ko.contextFor(document.getElementById(constants.divTags.advancedInstallationPage));
                                rootViewModel.displayPopupId(constants.divTags.createAdvEnvPopupTag);
                                var confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.advCreateSuccessEnvMsg", {'envName': self.envNameInputValue()});
                                popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);
                                pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                            } else
                            {
                                self.disableSubmitBtn(false);
                                var responseText = error.responseText;
                                var response = JSON.parse(responseText);
                                popupHelper.openErrorMsg(constants.divTags.createAdvEnvPopupTag, response.message, msgOrigin);
                            }
                        });
                    }


                };
                //On load default option
                var loading = oj.Translations.getTranslatedString('info.loading');
                var _index = 0;
                self.selectedTagId;
                self.tagNamespaceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.tagNamespaceOptionsDataProvider = new ArrayDataProvider(self.tagNamespaceOptionsList, {idAttribute: 'value'});
                self.tagKeyOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.tagKeyList = ko.observableArray([{'label': loading, 'value': ''}]);
                self.tagValueOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);

                self.tagObsArray = ko.observableArray([]);
                self.additionalTags = ko.observableArray([
                    {type: ["None"], tagKeyText: "", tagKeySelect: "", tagValue: "", tagValueSelect: "", id: _index++}]);

                // Observable variable to show and hide tag key as textfield or combobox
                self.showTagText = ko.observable(true);
                self.showTagTextValue = ko.observable(true);

                // On change of tag namespace
                self.changeTagNamespace = function (event, current) {
                    self.tagKeyOptionsList([]);
         
                    if (self.tagKeyList().length > 0) {
                        var returnKeysValues = createCloneUtils.changeTagNamespace(event, current, self.tagKeyList());
                        if (returnKeysValues === "textfield") {
                            self.showTagText(true);
                        } else {
                            self.showTagText(false);
                            self.tagKeyOptionsList(returnKeysValues);
                            // Set default value as first option of the options
                            self.selectedTagKeySelect(self.tagKeyOptionsList()[0].value);
                        }
                    }
                };

                // On change of tag key
                self.changeTagKey = function (event, current) {
                    self.selectedTagValue('');
                    if (self.tagKeyOptionsList().length > 0) {
                        var returnKeysValues = createCloneUtils.changeTagKey(event, self.tagKeyOptionsList());
                        if (returnKeysValues === "textfield") {
                            self.showTagTextValue(true);
                        } else {
                            self.showTagTextValue(false);
                            self.tagValueOptionsList(returnKeysValues);
                            self.selectedTagValue(self.tagValueOptionsList()[0].value);
                        }
                    }
                }
                // remove white space from tag value
                self.changeTagValue = function (event, current) {
                    self.selectedTagValue(event.detail.value ? event.detail.value.trim() : event.detail.value);
                };
                var TagKeyTextValidator = function () {};
                oj.Object.createSubclass(TagKeyTextValidator, oj.Validator, "TagKeyTextValidator");
                self.tagKeyTextValidator = [new TagKeyTextValidator()];
                TagKeyTextValidator.prototype.validate = function (value) {

                    var patt = /(\s|\.)/;
                    if (patt.test(value)) {
                        throw new Error(oj.Translations.getTranslatedString('validationMsgs.tagKeyTextValidationMsg'));
                    }
                };
                // Commented Validate multiple rows
                self.rowValidators = {
                    validate: function (value) {

                    }
                };
                // DB SID validation
                self.dbSIDValidator = ko.observableArray(
                        [new RegExpValidator(
                                    {pattern: '^[A-Za-z][a-zA-Z0-9]{1,7}',
                                        messageDetail: oj.Translations.getTranslatedString("validationMsgs.databaseSIDValidationMsg")})]
                        );
                // vm DB Name validation
                self.vmDBNameValidator = ko.observableArray(
                        [new RegExpValidator(
                                    {pattern: '^[A-Za-z][a-zA-Z0-9]{0,7}',
                                        messageDetail: oj.Translations.getTranslatedString("validationMsgs.databaseNameValidationMsg")})]
                        );
                // vm DB PDB Name validation
                self.vmDBPDBNameValidator = ko.observableArray(
                        [new RegExpValidator(
                                    {pattern: '^[a-zA-Z][a-zA-Z\\d-]{1,10}$',
                                        messageDetail: oj.Translations.getTranslatedString("validationMsgs.clusterNameValidationMsg")})]
                        );
                // exa Name validation
                self.exaDBNameValidator = ko.observableArray(
                        [new RegExpValidator(
                                    {pattern: '^[A-Za-z][a-zA-Z0-9]{0,7}',
                                        messageDetail: oj.Translations.getTranslatedString("validationMsgs.databaseNameValidationMsg")})]
                        );
                // web entry port number validation
                self.webEntryPortValidator = [
                    new AsyncNumberRangeValidator({
                        min: 1, max: 65534,
                        hint: {inRange: oj.Translations.getTranslatedString("validationMsgs.portNumberMsg")}
                    })];
                // numNodes validation
                self.nodeNumValidator = [
                    new AsyncNumberRangeValidator({
                        min: 1, max: 100
                    })];
                // numNodes validation
                self.additionalStorageValidator = [
                    new AsyncNumberRangeValidator({
                        min: 0, max: 32768
                    })];
            }

            return createEnvironmentViewModel;
        });
