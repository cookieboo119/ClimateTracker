/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * GetQuotes - This class makes a getquotes request for one day period for
 * a single security. It also ensures that the data is being retrieved for a weekday.
 * This is followed by retrieve getquotes request to display data.
 */

package com.bloomberg.datalic.dlws;

import java.util.Calendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.DateRange;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.Period;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.QRQuote;
import com.bloomberg.datalic.dlws.stubs.QuotesHeaders;
import com.bloomberg.datalic.dlws.stubs.QuotesInstrumentData;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetQuotesRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetQuotesResponse;

public class GetQuotes {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            QuotesHeaders headers = new QuotesHeaders();
            headers.setProgramflag(programFlag);
            DateRange dateRange = new DateRange();
            Calendar calendar = Calendar.getInstance();

            // Get nearest weekday
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == Calendar.SATURDAY) {
                calendar.add(Calendar.DAY_OF_MONTH, -1);
            } else if (dayOfWeek == Calendar.SUNDAY) {
                calendar.add(Calendar.DAY_OF_MONTH, -2);
            }

            XMLGregorianCalendar start = DatatypeFactory.newInstance().newXMLGregorianCalendar();
            start.setDay(calendar.get(Calendar.DATE));
            // Adjust month value since 'Calendar' month value is 0-based,
            // example: 0 for January,
            // whereas 'XMLGregorianCalendar' month value is between 1 to 12.
            start.setMonth(calendar.get(Calendar.MONTH) + 1);
            start.setYear(calendar.get(Calendar.YEAR));

            // 1 day's worth of ticks
            Period period = new Period();
            period.setStart(start);
            period.setEnd(start);
            dateRange.setPeriod(period);

            headers.setDaterange(dateRange);

            // Setting instruments
            Instrument ticker = new Instrument();
            ticker.setId("IBM US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.EQUITY);
            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);

            // Construct and submit getquotes request
            System.out.println("Sending submit getquotes request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetQuotesRequest(headers, instruments, statusCode, requestId, responseId);
            System.out.println("Submit getquotes request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve getquotes
            RetrieveGetQuotesRequest rtvGetQuotesReq = new RetrieveGetQuotesRequest();
            rtvGetQuotesReq.setResponseId(responseId.value);
            RetrieveGetQuotesResponse rtvGetQuotesResp;
            System.out.println("Sending retrieve getquotes request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetQuotesResp = ps.retrieveGetQuotesResponse(rtvGetQuotesReq);
            } while (rtvGetQuotesResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetQuotesResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve getquotes request successful for responseId: "
                        + rtvGetQuotesResp.getResponseId());
                for (QuotesInstrumentData quotesInstrumentData : rtvGetQuotesResp
                        .getInstrumentDatas().getInstrumentData()) {
                    System.out.println("Data for " + quotesInstrumentData.getInstrument().getId()
                            + " " + quotesInstrumentData.getInstrument().getYellowkey() + ":");
                    for (QRQuote qrQuote : quotesInstrumentData.getQuotes().getQuote()) {
                        System.out.println("  price = " + qrQuote.getPrice() + ", volume = "
                                + qrQuote.getVolume());
                    }
                }
            } else if (rtvGetQuotesResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
