define(['ojs/ojcore', 'knockout', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper',
    'ebs/navigation/pageNavigationHelper',
    'ebs/constants', 'ebs/utils/userRole', 'ojs/ojcollapsible', 'ojs/ojformlayout',  'ojs/ojinputtext', 'ojs/ojlabelvalue'
], function (oj, ko, popupHelper, actionsHelper, pageNavigationHelper, constants, userRole) {

    function networkProfileDetailsContentViewModel() {
        var self = this;
        console.log('Inside Network Profile Details View');

        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        var name = rootViewModel.currentNetworkName();
        self.networkProfileName = name;
        rootViewModel.currentPageHeader(name);
        rootViewModel.showContextHeader(true);
        rootViewModel.showNavTab(false);
        self.isDefault = ko.observable(rootViewModel.isDefaultNetworkProfile());
        self.deleteButtonEnabled = ko.observable(false);
        

        // Check if the user is not an admin, disable all the actions
        self.isAdminUser = userRole.isAdminUser();
        console.log("isAdminUser :: " + self.isAdminUser);
        
        if(self.isAdminUser && !self.isDefault()){
            self.deleteButtonEnabled(true);
        }
        self.displayExternalZone = ko.observable(false);
        self.prevPage = ko.observable(oj.Translations.getTranslatedString('pageHeader.networkProfiles'));
        self.networkProfileMenuItemsWithDelete = [
            {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.deleteNetworkProfile'), disabled: false}
        ];

        self.confirmDeleteMsg = ko.observable();
        self.selectedListItem = ko.observable();

        self.deleteNetworkProfileAssertion = function () {
            console.log('Triggering delete action..');
            self.confirmDeleteMsg(oj.Translations.getTranslatedString("confirmPopup.deleteNetworkAssertMsg", {networkName: name}));
            var popup = document.querySelector(constants.divTags.networkListDelPopupTag);
            popup.open(event.target);
      };

        self.deleteNetworkProfile = function (event, ui) {
            var popup = document.querySelector(constants.divTags.networkListDelPopupTag);
            popup.close();
            self.selectedListItem([]);
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteNetworkInfoMsg", {'networkName': name});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.delNetworkTitle");
            popupHelper.openInfoMsg(constants.divTags.networkProfileConfPopupTag, infoMsg, msgOrigin);

            actionsHelper.deleteNetworkProfile(name, function (error, success) {
                if (error === null) {
                    var context = ko.contextFor(document.getElementById("networkDetailsPageTopDiv"));
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteNetworkConfirmMsg", {'networkName': name});
                    popupHelper.openSuccessMsg(constants.divTags.networkProfileConfPopupTag, successMsg, msgOrigin);
                    pageNavigationHelper.clearGlobalVarBeforeNavigationToNetworkListPG(rootViewModel);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileListModule, constants.navModules.networkProfileListModule);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.networkProfileConfPopupTag, response.message, msgOrigin);
                }
            });
        };

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.networkProfileConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.networkProfileConfPopupTag, data, event);
        };

        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.networkListDelPopupTag);
            popup.close();
        };

        // Network Profile detail placeholders
        self.networkName = ko.observable('');
        self.description = ko.observable('');
        self.ebsCompartment = ko.observable('');
        self.networkCompartment = ko.observable('');
        self.region = ko.observable('');
        self.vcn = ko.observable('');
        self.availabilityDomain = ko.observable('');
        self.subnetType = ko.observable('');
        self.dbTierSubnetType = ko.observable('');
        self.dbTierSubnetName = ko.observable('');
        self.dbTierBackupSubnetName = ko.observable('');
        self.appTierSubnetType = ko.observable('');
        self.appTierSubnetName = ko.observable('');
        self.lbaasSubnetType = ko.observable('');
        self.lbaasSubnetName = ko.observable('');
        self.lbaashaSubnetName = ko.observable('');
        self.appTierSubnetType_External = ko.observable('');
        self.appTierSubnetName_External = ko.observable('');
        self.lbaasSubnetType_External = ko.observable('');
        self.lbaasSubnetName_External = ko.observable('');
        self.lbaashaSubnetName_External = ko.observable('');

        self.useRegionalSubnets = ko.observable('');
        self.isRegionSingleAD = ko.observable('');

        // Get network profile details from server
        actionsHelper.getNetworkProfileDetails(name, function (error, networkProfile) {
            if (error === '') {
                self.networkName(networkProfile.name);
                self.description(networkProfile.description);
                self.ebsCompartment(networkProfile.ebsCompartment);
                self.networkCompartment(networkProfile.networkCompartment);
                self.region(networkProfile.region);
                self.vcn(networkProfile.vcn);
                self.availabilityDomain(networkProfile.availabilityDomain);
                self.dbTierSubnetType((networkProfile.dbTier.isPrivate === true) ? "Private" : "Public");
                self.dbTierSubnetName(networkProfile.dbTier.subnetName);
                self.dbTierBackupSubnetName(networkProfile.dbTier.backupSubnetName);
                self.appTierSubnetType((networkProfile.appTier.internal[0].isPrivate === true) ? "Private" : "Public");
                self.appTierSubnetName(networkProfile.appTier.internal[0].subnetName);
                self.lbaasSubnetType((networkProfile.lbaas.internal.isPrivate === true) ? "Private" : "Public");
                self.lbaasSubnetName(networkProfile.lbaas.internal.subnetName);
                self.lbaashaSubnetName(networkProfile.lbaas.internal.haSubnetName);

                var externalZoneAppTierDetail = networkProfile.appTier.external;
                var externalZoneLbaasDetail = networkProfile.lbaas.external;

                if (typeof (externalZoneAppTierDetail) === 'undefined'
                        || typeof (externalZoneAppTierDetail[0]) === 'undefined'
                        || typeof (externalZoneLbaasDetail) === 'undefined'
                        || typeof (externalZoneLbaasDetail.subnetName) === 'undefined'
                        )
                {
                    self.displayExternalZone(false);
                } else
                {
                    self.displayExternalZone(true);
                    self.appTierSubnetType_External((networkProfile.appTier.external[0].isPrivate === true) ? "Private" : "Public");
                    self.appTierSubnetName_External(networkProfile.appTier.external[0].subnetName);
                    self.lbaasSubnetType_External((networkProfile.lbaas.external.isPrivate === true) ? "Private" : "Public");
                    self.lbaasSubnetName_External(networkProfile.lbaas.external.subnetName);
                    self.lbaashaSubnetName_External(networkProfile.lbaas.external.haSubnetName);
                }

                var useRegional = networkProfile.useRegionalSubnets;
                var subnetType = '';
                if (typeof (useRegional) !== 'undefined' && useRegional !== null) {
                    if (useRegional) {
                        subnetType = constants.subnetType.Regional;
                    } else {
                        subnetType = constants.subnetType.AvailabilityDomainSpecific;
                    }
                }
                self.subnetType(subnetType);

                self.useRegionalSubnets(networkProfile.useRegionalSubnets);
                self.isRegionSingleAD(networkProfile.isRegionSingleAD);

                self.handleLoadbalancerHASubnetRegion();
                self.handleLoadbalancerHASubnetRegion_External();
            }
            
            var desc = document.getElementById("desc|input");
            if(desc) desc.style.fontSize = "18px";
        });

        self.displayLoadBalancerHASubnetRegion = ko.observable('');
        self.handleLoadbalancerHASubnetRegion = function () {
            console.log("regional=" + self.useRegionalSubnets());
            console.log("singleAd=" + self.isRegionSingleAD());
            console.log("type=" + self.lbaasSubnetType());

            if (self.useRegionalSubnets() ||
                    self.isRegionSingleAD() ||
                    self.lbaasSubnetType() === 'Private') {
                self.displayLoadBalancerHASubnetRegion(false);
            } else
                self.displayLoadBalancerHASubnetRegion(true);

            console.log('self.displayLoadBalancerHASubnetRegion : ' + self.displayLoadBalancerHASubnetRegion());
        };

        self.displayLoadBalancerHASubnetRegion_External = ko.observable('');
        self.handleLoadbalancerHASubnetRegion_External = function () {
            console.log("regional(external)=" + self.useRegionalSubnets());
            console.log("singleAd(external)=" + self.isRegionSingleAD());
            console.log("type(external)=" + self.lbaasSubnetType_External());

            if (self.useRegionalSubnets() ||
                    self.isRegionSingleAD() ||
                    self.lbaasSubnetType_External() === 'Private') {
                self.displayLoadBalancerHASubnetRegion_External(false);
            } else
                self.displayLoadBalancerHASubnetRegion_External(true);

            console.log('self.displayLoadBalancerHASubnetRegion_External : ' + self.displayLoadBalancerHASubnetRegion_External());
        };

        // Back button functionality
        self.handleBackLink = function (event, ui) {
            var context = ko.contextFor(document.getElementById("networkDetailsPageTopDiv"));
            // Clear off global variables before going back to network profile list PG.
            // These were set when we came from list page to details pg.
            pageNavigationHelper.clearGlobalVarBeforeNavigationToNetworkListPG(rootViewModel);

            pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileListModule, constants.navModules.networkProfileListModule);
        };

        $(function () {
         var descDiv = document.getElementById("descriptionContent");
         if(descDiv && descDiv.parentNode)
         {
             descDiv.parentNode.style.flex = "1 1 100%";
             descDiv.parentNode.style.maxWidth = "100%";
             descDiv.parentNode.style.width = "100%";
         }
        });
    }
    return networkProfileDetailsContentViewModel;
});