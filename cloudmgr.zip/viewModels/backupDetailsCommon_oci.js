/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * environmentBackups_oci module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/constants','ebs/popup/popupHelper', 'ebs/utils/dateTimeHelper','ebs/utils/compartmentUtils',
    'ojs/ojarraydataprovider', 'ojs/ojcollectiondataprovider', 'jquery', 'ojs/ojknockout', 'ojs/ojbutton', 'ojs/ojmenu', 'ojs/ojtoolbar', 'ojs/ojdialog',
    'ojs/ojnavigationlist', 'ojs/ojaccordion', 'ojs/ojoffcanvas', 'ojs/ojpopup', 'ojs/ojmodule', 
    'ojs/ojarraytabledatasource', 'ojs/ojcollapsible', 'ojs/ojoffcanvas', 'ojs/ojinputtext', 'ojs/ojmenu','ojs/ojinputsearch',  'ojs/ojlistitemlayout'
], function (oj, ko, actionsHelper, pageNavigationHelper, constants, popupHelper, dateTimeHelper, compartmentUtils, ArrayDataProvider, CollectionDataProvider) {
    /**
     * The view model for the main content view template
     */
    function environmentBackups_ociContentViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.backups'));
        rootViewModel.showNavTab(true);
        var backupName;
        var envName = rootViewModel.currentEnvName();
        self.envName = envName;
        
        var parentPageModule = ko.dataFor(document.getElementById('landingModuleContent')).childRouterKO();
        self.isPublicBackupBucketModule = parentPageModule == constants.navModules.envBackupsModule;
        
        self.totalBackups = ko.observable();
        self.totalStorage = ko.observable();
        self.backupsList = ko.observableArray();
        self.datasourceForBackups = new ArrayDataProvider(self.backupsList, {idAttribute: 'name'});
        self.dataSource = ko.observable();
        self.storageUnits = ko.observable();
        self.selectedListItem = ko.observableArray([]);
        self.backupsLoaded = ko.observable(false);
        
        self.confirmBkpDeleteMsg = ko.observable('');
        
        
        self.atHxPos = ko.observable('right');
        self.atVxPos = ko.observable('top');
        
        self.loadData = function(compartmentId){
            self.backupsLoaded(false);
            if(self.envName != null && self.envName != '' && !self.isPublicBackupBucketModule)
            {
                // Specific to an environment.
                actionsHelper.getBackupsForEnv(self.envName,function(error, backups){
                    if(error === ''){
                        $.each(backups, function(index,value){
                            backups[index].id = this.name;
                            backups[index].createdOn = dateTimeHelper.convertToUTC(this.createdOn);
                        });
                        self.backupsList(backups);

                    }
                    self.backupsLoaded(true);
                });
            }
            else
            {   
                if (document.getElementById('filterEnvId') != null)
                {
                  document.getElementById('filterEnvId').value = '';
                }
                self.backupsList.removeAll();
                compartmentId = compartmentUtils.getCurrentSelectedCompartmentId(compartmentId);
                actionsHelper.getBackups(compartmentId, function(error, backups){
                    if(error === ''){
                        $.each(backups, function(index,value){
                            backups[index].id = this.name;
                            backups[index].createdOn = dateTimeHelper.convertToUTC(this.createdOn);
                        });
                        self.backupsList(backups);
                    }
                    self.backupsLoaded(true);
                });
           }
           self.dataSource(self.datasourceForBackups);
        };
        
        self.loadData();
        //self.dataSource(self.datasourceForBackups);
        self.backupActionMenuItems = ko.observableArray([
                {id: 'create', label: oj.Translations.getTranslatedString('labels.provisionEnv'), disabled: false},
                {id: 'delete', label: oj.Translations.getTranslatedString('labels.deleteBackup'), disabled: false}
        ]); 
        
        self.flattenArrayDS =  function(data)  {    
            var collection = new oj.Collection();    
            for (var i=0;i<data.length;i++)    {        
                collection.add(data[i]);      
            }      
            return collection;  
        };

        self.nameFilter = function(model, attr, value)   { 
            var name = model.get('name'); 
            return (name.toLowerCase().indexOf(value.toLowerCase()) > -1); 
        };
        
        self.genericFilter = function(model, attr, value)   { 
            var name = (model.get('name') !== null) ? model.get('name') : ''; 
            var dbName = (model.get('dbName') !== null) ? model.get('dbName') : '';
            var dbVersion = (model.get('dbVersion') !== null) ? model.get('dbVersion') : '';
            var ebsVersion = (model.get('ebsVersion') !== null) ? model.get('ebsVersion') : '';
            var createdOn = (model.get('createdOn') !== null) ? model.get('createdOn') : '';
            var backupSize = (model.get('size') !== null) ? model.get('size') : '';
            var compartmentName = (model.get('compartmentName') !== null) ? model.get('compartmentName') : '';
            var tdeEnabledFlag = (model.get('tdeEnabled') !== null) ? model.get('tdeEnabled') : '';
            return ((name.toLowerCase().indexOf(value.toLowerCase()) > -1) || 
                    (dbName.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (dbVersion.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (ebsVersion.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (createdOn.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (backupSize.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (compartmentName.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (tdeEnabledFlag !== null && tdeEnabledFlag !== '' && tdeEnabledFlag.toString().toLowerCase().indexOf(value.toLowerCase()) > -1)
            ); 
        };
        
        self.searchText = ko.observable('');
        self.handleSearchTextChange = function(event, ui)
        {
           event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleSearchCriteria(event, ui);
            }
        };

        self.handleSearchCriteria = function (event) {
            var filter = self.searchText();
            if (filter.length === 0) {
                self.dataSource(self.datasourceForBackups);
            } else {
                if (self.filteredDataSource === undefined) {
                    self.collection = self.flattenArrayDS(self.backupsList());
                    self.filteredCollection = self.collection.clone(); 
                    self.filteredDataSource = new CollectionDataProvider(self.filteredCollection);
                }
                var ret = self.collection.where({name: {value: filter, comparator: self.genericFilter}});
                self.filteredCollection.reset(ret);
                if (self.dataSource() === self.datasourceForBackups){
                    self.dataSource(self.filteredDataSource);
                }
            }
        };
        
        self.selectionChanged = function(event, ui){
            var currentBackupName = self.selectedListItem()[0];
            backupName = currentBackupName ? currentBackupName : backupName;
        };
        
        self.closeConfirmDeletePopup = function(event, ui){
            var popup = document.querySelector(constants.divTags.backupsDelPopupTag);
            popup.close();
        };
        
        self.confirmationPopupCloseHandler = function(data,event){
            popupHelper.confmPopuCloseHandler(constants.divTags.bkpsConfPopupTag, data, event);
        };
        
        self.startAnimationListener = function (event,ui)
        {
            popupHelper.startAnimationListener(constants.divTags.bkpsConfPopupTag, event, ui);
        };
        
        self.currentMenuBackupName = ko.observable();
        // This is called before-menu-open so you can gather data from selected item.
        self.setupMenuOptions = function (event) {
            var target = event.detail.originalEvent.target;
            var context = document.getElementById('listview').getContextByNode(target);
            var key = null; //key: backupName
            var index = -1; //index: row index in listview
            if (context) {
                index = context.index;
                key = context.key;
                // Setting the correct backup name of the current row
                self.currentMenuBackupName(key);
            }
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        }
        
        self.backupActionsHandler = function( event, ui ) {
            var localBackupName = self.currentMenuBackupName();
            if (!localBackupName)
            localBackupName = self.selectedListItem()[0];

            backupName = localBackupName ? localBackupName: backupName;
//            var actionTriggered = event.currentTarget.id;
           //var actionTriggered = ui.item[0].id;
            var actionTriggered = event.target.id
            console.log('Env name --' + backupName + ' Action Triggered --' + actionTriggered);
            if(backupName !== null && backupName !== '' && actionTriggered === 'create'){
                console.log('Triggering create action..');
                rootViewModel.backupName(backupName);
                var context = null;
                if(self.envName != null && self.envName != '' && !self.isPublicBackupBucketModule)
                {
                    context = ko.contextFor(document.getElementById('envDetailsPage'));
                }
                else
                {
                    context = ko.contextFor(document.getElementById(constants.divTags.backupPublicBucketTag));
                }
                
                pageNavigationHelper.navigateToPage(context, constants.navModules.createEnvironmentModule, constants.navModules.createEnvironmentModule);
            }else if(actionTriggered === 'delete'){
                console.log('Triggering delete action..');
                self.confirmBkpDeleteMsg(oj.Translations.getTranslatedString("confirmPopup.deleteBkpAssertMsg", {bkpName: backupName}) + "<br>" 
                        + oj.Translations.getTranslatedString("confirmPopup.deleteBkpAssertWarningMsg", {bkpName: backupName}));
                var popup = document.querySelector(constants.divTags.backupsDelPopupTag);
                popup.open(event.target);
            }   
        };   
    
        self.deleteBkp = function(event,ui){
            var popup = document.querySelector(constants.divTags.backupsDelPopupTag);
            popup.close();
            self.selectedListItem([]);
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteBkpInfoMsg", {'bkpName': backupName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.delBkpTitle");
            popupHelper.openInfoMsg(constants.divTags.bkpsConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.deleteBkp(backupName, function(error, success){
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteBkpConfirmMsg", {'bkpName': backupName});
                    popupHelper.openSuccessMsg(constants.divTags.bkpsConfPopupTag,successMsg,msgOrigin);
                    self.loadData();
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.bkpsConfPopupTag,response.message,msgOrigin);
                }
            });
        };
        
        self.gotoBackupDetails = function(){
            
        };
    }
    
    
    return environmentBackups_ociContentViewModel;
});
