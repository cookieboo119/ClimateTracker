define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper',
    'ebs/constants', 'ojs/ojvalidator-regexp', 'ojs/ojarraydataprovider', 'ebs/utils/lovUtils',
    'ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'jet-composites/compartment-lov/loader'],
    function (oj, ko, actionsHelper, popupHelper, constants, RegExpValidator, ArrayDataProvider, lovUtils) {

        function createPolicyViewModel() {
            var self = this;
            console.log('Loading Create Policy Popup View Model');
            var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
            self.tenancyId = rootViewModel.tenancyOCID;
            self.policyName = ko.observable('');
            self.policyCreateTitle = ko.observable('Create Policy');
            self.compartmentList = ko.observableArray([{
                'label': 'loading...',
                'value': ''
            }]);
            self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, { idAttribute: 'value' });               
            self.selectedCompartment = ko.observable('');
            self.resetPopupContent = function () {
                self.policyName('');
                self.selectedCompartment('');
            };
            
            self.allPolicyList = new Array();

            var PolicyNameValidator = function () { };
            oj.Object.createSubclass(PolicyNameValidator, oj.Validator, "PolicyNameValidator");
            self.policyNameValidator = [new PolicyNameValidator()];

            PolicyNameValidator.prototype.validate = function (value) {
                console.log('Policy name Validater Called');
                var regularExp = new RegExp("^([a-zA-Z0-9_]{1,50})$");
                if (regularExp.test(value)) {
                    if (value === null || value === '') {
                        return false;
                    } else {
                        var isDuplicateName = self.isDuplicatePolicyName(value);
                        if (isDuplicateName) {
                            var policyNameDuplicateValidationMsg = oj.Translations.getTranslatedString('validationMsgs.policyNameDuplicateValidationMsg');
                            throw new Error(policyNameDuplicateValidationMsg);
                            return false;
                        } else {
                            return true;
                        }
                    }
                } else {
                    var policyNameIncorrectValidationMsg = oj.Translations.getTranslatedString('validationMsgs.policyNameValidationMsg');
                    throw new Error(policyNameIncorrectValidationMsg);
                    return false;
                }

            };

            self.isDuplicatePolicyName = function (currentName) {
                for (var i = 0; i < self.allPolicyList.length; i++) {
                    var policyName = self.allPolicyList[i].name;
                    if (policyName === currentName) {
                        return true;
                    }
                }
                return false;
            };



            self.createPolicyPopupCloseCleanUpHandler = function () {
                self.resetPopupContent();
            };

            self.isFormValidForSubmission = function () {
                var compartmentField = document.getElementById('compartment');
                var nameField = document.getElementById('Name');
                var isValid = true;
                if (compartmentField.firstElementChild.valid !== 'valid') {
                    isValid = false;
                    compartmentField.firstElementChild.showMessages();
                }

                if (nameField.valid !== 'valid') {
                    isValid = false;
                    nameField.showMessages();
                }
                return isValid;
            };

            self.getFormDataForSubmit = function () {
                var submitData = {
                    "name": self.policyName(),
                    "compartmentId": self.selectedCompartment(),
                    "schedules": [

                    ]
                };
                return submitData;
            };

            self.createPolicySubmission = function () {
                var isFormValid = self.isFormValidForSubmission();
                if (!isFormValid) {
                    return;
                } else {

                    var requestData = self.getFormDataForSubmit();
                    var requestBodyJSON = JSON.stringify(requestData);
                    var infoMsg = oj.Translations.getTranslatedString("confirmPopup.createPolicyInfoMsg", { 'policyName': self.policyName() });
                    var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.policyCreateTitle");
                    popupHelper.openInfoMsg(constants.divTags.policyListingPGConfPopupTag, infoMsg, msgOrigin);
                    actionsHelper.createPolicy(constants.policies.Backup, requestBodyJSON, function (error, success) {
                        if (error === '') {
                            var successMsg = oj.Translations.getTranslatedString("confirmPopup.policyConfirmMsg");
                            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.policyCreateTitle");
                            popupHelper.openSuccessMsg(constants.divTags.policyListingPGConfPopupTag, successMsg, msgOrigin);
                            self.closePolicyCreationPopup();
                            var tableViewModel = ko.dataFor(document.getElementById('policyListingTable'));
                            tableViewModel.loadPolicies();

                        } else {
                            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.policyCreateTitle");
                            var responseText = error.responseText;
                            var response = JSON.parse(responseText);
                            popupHelper.openErrorMsg(constants.divTags.policyListingPGConfPopupTag, response.message, msgOrigin);
                        }

                    });
                }
            };

            self.closePolicyCreationPopup = function (event, ui) {
                self.createPolicyPopupCloseCleanUpHandler();
                var popup = document.querySelector(constants.divTags.createPolicyPopupTag);
                popup.close();
            };

            self.openPolicyCreationPopup = function (event) {
                var popup = document.querySelector(constants.divTags.createPolicyPopupTag);
                popup.open();
            };

            console.log('Compartment List while loading view model -' + self.compartmentList());
            actionsHelper.getCompartmentListForTenancy(function (error, compartmentsList) {
                if (error !== null && error !== '') {
                    console.log('Error in fetching Compartment List for tenancy =>' + error);
                } else {
                    self.compartmentList.removeAll();
                    self.compartmentDataProvider = null;
                    var hierarchialList = getFlatListFromHierarchicalLov(compartmentsList, self.tenancyId());
                    self.compartmentList(hierarchialList);
                    self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, { idAttribute: 'value' });
                    lovUtils.lovOptionsUpdated(self.compartmentList(), self.selectedCompartment);
                }
                console.log('Compartment List after the fetch -' + self.compartmentList());
            });

            actionsHelper.getAllPolicies("All", function (error, policyLists) {
                if (error !== null && error !== '') {
                    if (error.status === 504) {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelMessage('error', 'Error in retrieving policies.', messageContent);
                    } else {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '') {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelMessage('error', 'Error in retrieving policies.', messageContent);
                    }
                }
                var listOfPolicies = [];
                $.each(policyLists, function () {
                    var policy = {
                        id: this.id,
                        name: this.name,

                    };

                    listOfPolicies.push(policy);
                });
                self.allPolicyList = listOfPolicies;

            });
        }

        return createPolicyViewModel;
    });
