/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * header module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/utils/helpMenu', 'ebs/constants', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton'
], function (oj, ko, actionsHelper, helpMenu, constants) {
    /**
     * The view model for the main content view template
     */
    function headerContentViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
        rootViewModel.displayLoadingGif('none');
        var username = rootViewModel.username();
        var password = rootViewModel.password();
        var appUrl = rootViewModel.url();
        var tenancyRootValue = rootViewModel.tenancyNameValue();
        var logoutURL = appUrl + 'cm/auth/logout';
        if(username){
            sessionStorage.setItem('username', username);
        }else{
            username = sessionStorage.getItem('username');
        }
        var bearerToken = rootViewModel.authToken();
        if (bearerToken) {
            sessionStorage.setItem('bearerToken', bearerToken);
        } else {
            bearerToken = sessionStorage.getItem('bearerToken');
        }
        
        var getInitials = function (string) {
            if(string != null && string.indexOf('.') >= 0)
            {
              var names = string.split('.'),
              initials = names[0].substring(0, 1).toUpperCase();
              initials += names[1].substring(0, 1).toUpperCase();
              return initials;
            }
            else if(string != null)
            {
              return string.substring(0, 2).toUpperCase();
            }
        };
        var token = bearerToken;
        self.tenancyMenu = ko.observableArray();
        self.headerUsername = ko.observable(getInitials(username));
        self.tenancy = ko.observable(rootViewModel.tenancyNameValue());
        self.region = ko.observable(rootViewModel.selectedRegionValue());
        
        self.provider = ko.observable('OCI');
        self.appName = 'E-Business Suite Cloud Manager';
        
        self.cmVersion = ko.observable('');
        self.cmNewVersion = ko.observable('');
        self.updateMsg = ko.observable('');
        self.updateAvailable = ko.observable('');
        self.showUpdateMsg = ko.observable(false);
        self.updateAvailableLabel = ko.observable('');
        
        self.internalIpAddress = ko.observable();
        self.externalIpAddress = ko.observable();
        
        $.ajaxSetup({
                    crossDomain: true,
                    headers: {
                        'Authorization': bearerToken
                    },
                    error: function (jxhr, event, data) {
                        var status = jxhr.status;
                        console.log('status ' + status);
                        if (status === 401) {
                            oj.Router.rootInstance.go('login');
                        }
                    }       
        });
        if (typeof tenancyRootValue === 'undefined'){
            $.getJSON(appUrl + constants.rest.userProfile, function (userInfo) {
                if(userInfo.isSSHKeysValid)
                {
                    //only for valid user, update rootViewModel with info directly from userInfo;
                    //otherwise accountDetails will update rootViewModel with info from global profile
                    rootViewModel.tenancyNameValue(userInfo.tenancyName);
                    rootViewModel.tenancyOCID(userInfo.tenancyOCID);
                    rootViewModel.selectedRegionValue(userInfo.region);
                }
              
                self.tenancy(rootViewModel.tenancyNameValue());
                self.region(rootViewModel.selectedRegionValue());
               
                rootViewModel.username(userInfo.username);
                self.tenancyMenu.push(
                    {
                        id: 'Tenancy',
                        label: userInfo.tenancyName,
                        disabled : true 
                    },
                    {
                        id: 'Region',
                        label: userInfo.region,
                        disabled : true 
                    }
                );
            });
        }else{
            self.tenancyMenu.push(
                {
                    id: 'Tenancy',
                    label: rootViewModel.tenancyNameValue(),
                    disabled : true 
                },
                {
                    id: 'Region',
                    label: rootViewModel.selectedRegionValue(),
                    disabled : true 
                }
                
            );
        }
        self.userActionsMenu = [
            {
                id: 'Profile',
                label: 'Profile',
                disabled : false
            },
            {
                id: 'About',
                label: 'About',
                disabled : false
            },
            {
                id: 'Sign Out',
                label: 'Sign Out',
                disabled : false
            } 
        ];
        
        // Help Menus Start
        helpMenu.initHelper();
        self.helpBtnLabel = ko.observable(oj.Translations.getTranslatedString('labels.helpLabel'));
            
        self.helpActionsHandler = function () {
            helpMenu.getHelperMenu();
            document.getElementById('helpActionsOjMenuId').refresh();
        };
        
        self.menuHelpSelectedHandler = function (event) {
            var link = event.target.value;
            window.open(link, "_blank").focus();
        };
        // Help Menus Ends
        
        self.make_base_auth = function (user, password) {
            var tok = user + ':' + password;
            var hash = btoa(tok);
            return "Basic " + hash;
        };
        
        self.userActionsHandler = function(event){
            var actionTriggered = event.target.value;
            if(actionTriggered === 'Sign Out'){
                console.log("invoking logout API");
                var basicAuthHeader = self.make_base_auth(username, password);
                rootViewModel.username('');
                sessionStorage.setItem('bearerToken', '');
                sessionStorage.setItem('loginComplete', false);
                sessionStorage.setItem('cmAdmin', '');
                window.location.replace(logoutURL);
//                var form = ([
//                    {name: 'token', value: token},
//                    {name: 'token_type_hint', value: 'access_token'}
//                ]);
                //oj.Router.rootInstance.go('login'); 
//                $.ajax
//                        ({
//                            type: "GET",
//                            url: appUrl + "auth/logout",
//                            async: true,
//                            crossDomain: true,
//                            headers: { 
//                                'Authorization': basicAuthHeader
//                                
//                            },
//                            data: form,
//                            success: function (response, status, xhr) {
//                                var httpStatus = xhr.status;
//                                console.log("http status is " + httpStatus);
//                            },
//                            error: function (jxhr, event, data) {
//                                var httpStatus = jxhr.status;
//                                console.log("http status is " + httpStatus);
//                            }
//                            
//                        });
            }else if(actionTriggered === 'Profile'){
                 oj.Router.rootInstance.go('accountDetails_oci');
            }else if(actionTriggered === 'About'){
                self.showUpdateMsg(false);
                actionsHelper.getCloudMgrUpdates(function(error, updates){
                    if(error === ''){
                        self.updateMsg(updates.message);
                        self.updateAvailable(updates.updateAvailable);
                        self.cmNewVersion("New Version : " + updates.latestVersion);
                        self.updateAvailableLabel("Version " + updates.latestVersion + " available for update");
                        self.cmVersion("Version : "+ updates.currentVersion);
                        if(updates.orchvmPrivateIP)
                         self.internalIpAddress("Private IP Address: " + updates.orchvmPrivateIP);
                        if(updates.orchvmPublicIP)
                         self.externalIpAddress("Public IP Address: " + updates.orchvmPublicIP);
                    }
                });
                document.querySelector("#aboutMsgPopup").open();
            }
            /*else if(actionTriggered === 'Help'){
                window.open("https://docs.oracle.com/cd/E72030_01/infoportal/ebsoc.html", '_blank');
            }*/
        };
        self.closeAboutMsgPopup = function(){
            document.querySelector("#aboutMsgPopup").close();
        };
        
        self.updateAvailableButtonClick = function(){
            self.showUpdateMsg(true);
        };
        
    }
    
    return headerContentViewModel;
});
