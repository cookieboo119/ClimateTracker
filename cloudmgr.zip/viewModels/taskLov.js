
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/utils/backupEnvironmentHelper', 'ebs/popup/popupHelper',
    'ebs/constants', 'ojs/ojvalidator-regexp', 'ojs/ojknockout-keyset', 'ojs/ojlistdataproviderview', 'ojs/ojarraydataprovider', 'ojs/ojtable', 'ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojselectcombobox', 'ojs/ojcheckboxset', 'ojs/ojlabel', 'ojs/ojbutton'],
        function (oj, ko, actionsHelper, backupEnvironmentHelper, popupHelper, constants, RegExpValidator, keySet, ListDataProviderView, ArrayDataProvider) {

            function TaskLovViewModel() {
                var self = this;
                console.log('Loading Task Lov View Model');
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.filter = ko.observable();
                self.parentReferenceIdentifier = null;
                self.tasks = ko.observableArray([]);
                self.dataprovider = ko.observable();
                self.position = ko.observable();
                self.position({my: {horizontal: 'left', vertical: 'top'},
                    at: {horizontal: 'left', vertical: 'top'},
                    offset: {y: 50, x: 100},
                    collision: 'fit',
                    of: 'window'}
                );

                self.openTaskLov = function (parentReferenceIdentifier) {
                    self.parentReferenceIdentifier = parentReferenceIdentifier;
                    var popup = document.querySelector(constants.divTags.taskLovPopupTag);
                    popup.open(event.target);
                };



                self.clearClick = function (event) {
                    self.filter('');
                    return true;
                };

                self.addSelectedTasks = function () {
                    var selection = new Array();

                    for (var j = 0; j < self.tasks().length; j++) {
                        var checkBoxId = 'table_checkboxset' + self.tasks()[j].TaskValue;
                        var checkBoxElem = document.getElementsByName(checkBoxId);
                        if (checkBoxElem.length === 0) {
                            continue;
                        }
                        var firstElem = checkBoxElem[0];
                        var isChecked = firstElem.checked;
                        if (isChecked) {
                            var taskObj = self.tasks()[j];
                            selection.push(taskObj);

                        }
                    }
                    if (selection.length > 0) {
                        // pass on to the base page.
                        self.clearSelectedItems(selection);
                        self.clearClick();
                        var viewModelOfExecPlanTable = ko.dataFor(document.getElementById('execPlanTable'));
                        viewModelOfExecPlanTable.addTasksToPhase(self.parentReferenceIdentifier, selection);
                    }
                    self.cancelLovPopup();
                };

                self.clearSelectedItems = function (selection) {
                    console.log('Clearing all selected items...');
                    for (var j = 0; j < selection.length; j++) {
                        var checkBoxId = 'table_checkboxset' + selection[j].TaskValue;
                        var checkBoxElem = document.getElementsByName(checkBoxId)[0];
                        checkBoxElem.click();
                    }
                };

                self.handleValueChanged = function () {
                    self.filter(document.getElementById('filter').rawValue);
                };


                self.cancelLovPopup = function () {
                    var popup = document.querySelector(constants.divTags.taskLovPopupTag);
                    popup.close();
                };

                self.initializeTaskLov = function () {
                    actionsHelper.getAllTasks(function (error, taskList) {
                        if (error !== null && error !== '') {
                            console.log('Error while getting tasks :' + error);
                        } else {
                            var taskIdx = 0;
                            for (var k = 0; k < taskList.length; k++) {
                                var task = taskList[k];
                                var taskLCM = task.isLCMActivity;
                                if (!taskLCM) {
                                    var taskForLov = new Object();
                                    taskForLov.TaskName = task.name;
                                    taskForLov.TaskValue = 'LovTask' + taskIdx;
                                    taskForLov.TaskIDForSubmit = task.id;
                                    taskIdx++;
                                    taskForLov.TaskType = task.type;
                                    self.tasks.push(taskForLov);
                                }
                            }

                        }
                    });
                };

                self.initializeDataProvider = function () {
                    self.dataprovider = ko.computed(function () {
                        var filterRegEx = new RegExp(self.filter(), 'i');
                        var filterCriterion = {
                            op: '$or',
                            criteria: [{op: '$regex', value: {TaskName: filterRegEx}}]
                        };
                        var arrayDataProvider = new ArrayDataProvider(self.tasks(), {keyAttributes: 'TaskValue'});
                        return new ListDataProviderView(arrayDataProvider, {filterCriterion: filterCriterion});
                    }, self);
                };

                self.columnArray = [
                    {"headerText": "Select",
                        "template": "checkTemplate"},
                    {"headerText": "Task Name",
                        "field": "TaskName",
                        "template": "ColTemplate"},
                    {"headerText": "Task Type",
                        "field": "TaskType",
                        "template": "ColTemplate"}];


                self.initializeDataProvider();
                self.initializeTaskLov();

            }

            return TaskLovViewModel;
        });
