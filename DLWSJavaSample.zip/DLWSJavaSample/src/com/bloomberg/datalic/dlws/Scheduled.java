/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE
 */

/*
 * Scheduled - This class submits a getdata request by specifying
 * instruments and fields and also setting the program flag (daily in this case),
 * runtime and run date in the header. This class then submits a scheduled
 * request and does retrieve scheduled request to verify that the getdata
 * request is added to the daily jobs. This sample then cancels the getdata
 * request, and submits retrieve scheduled request again to verify that the
 * getdata request has been deleted from the list of daily jobs.
 */
package com.bloomberg.datalic.dlws;

import java.util.HashMap;
import java.util.Map;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveCancelResponse;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataResponse;
import com.bloomberg.datalic.dlws.stubs.RetrieveScheduledRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveScheduledResponse;
import com.bloomberg.datalic.dlws.stubs.ScheduledHeaders;
import com.bloomberg.datalic.dlws.stubs.ScheduledResponse;

public class Scheduled {

    // NOTE: The programFlag argument is ignored for this sample
    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Schedule a getdata request
            RetrieveGetDataResponse rtvGetDataResponse = GetData.submitRecurringGetDataRequest(ps);
            if (rtvGetDataResponse != null
                    && rtvGetDataResponse.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                // Construct and submit a 'scheduled' request
                submitScheduledRequest(ps);

                // Cancel the scheduled getdata request submitted earlier
                RetrieveCancelResponse rtvCancelResp = Cancel.submitAndRetrieve(ps,
                        rtvGetDataResponse.getResponseId());
                if (rtvCancelResp != null
                        && rtvCancelResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                    Cancel.display(rtvCancelResp);
                    // Submit scheduled request again to check if the getdata
                    // request scheduled earlier was deleted successfully
                    submitScheduledRequest(ps);
                } else {
                    System.out.println("Error in the cancel request.");
                }
            } else {
                System.out.println("Error in submitRecurringGetDataRequest.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Submit a 'scheduled' request, retrieve response and display it
    void submitScheduledRequest(PerSecurityWS ps) throws InterruptedException {
        Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
        Holder<String> requestId = new Holder<String>();
        Holder<String> responseId = new Holder<String>();
        ps.submitScheduledRequest(statusCode, requestId, responseId);
        System.out.println("Submit scheduled request status: " + statusCode.value.getDescription()
                + ", responseId: " + responseId.value);

        // Submit retrieve scheduled request
        RetrieveScheduledRequest rtvScheduledReq = new RetrieveScheduledRequest();
        rtvScheduledReq.setResponseId(responseId.value);
        RetrieveScheduledResponse rtvScheduledResp;
        System.out.println("Sending retrieve scheduled request");

        // Keep polling for response till the data is available
        do {
            Thread.sleep(PerSecurity.POLL_FREQUENCY);
            rtvScheduledResp = ps.retrieveScheduledResponse(rtvScheduledReq);
        } while (rtvScheduledResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

        // Display data
        if (rtvScheduledResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
            System.out.println("Retrieve scheduled request was successful for responseId: "
                    + rtvScheduledResp.getResponseId());
            display(rtvScheduledResp);
        } else if (rtvScheduledResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
            System.out.println("Error in the retrieve scheduled request.");
        }
    }

    // Display RetrieveScheduledResponse object
    void display(RetrieveScheduledResponse rtvScheduledResp) {
        for (ScheduledResponse scheduledResponse : rtvScheduledResp.getFileDatas().getFileData()) {
            System.out.println("Response ID: " + scheduledResponse.getResponseId());
            Map<String, String> headers = getHeaders(scheduledResponse.getHeaders());
            System.out.println("  Header details: ");
            System.out.println("    ProgramName: " + headers.get("programName") + ", ProgramFlag: "
                    + headers.get("programFlag") + ", RunDate: " + headers.get("runDate")
                    + ", Time: " + scheduledResponse.getTime());
            System.out.println("  Instruments: ");
            for (Instrument instrument : scheduledResponse.getInstruments().getInstrument()) {
                String yellowKey = "";
                if (instrument.getYellowkey() != null) {
                    yellowKey = " " + instrument.getYellowkey().toString();
                }

                String idType = "";
                if (instrument.getType() != null) {
                    idType = "|" + instrument.getType().toString();
                }
                System.out.println("    " + instrument.getId() + yellowKey + idType);
            }

            if (scheduledResponse.getFields() != null) {
                System.out.println("  Fields: ");
                for (String field : scheduledResponse.getFields().getField()) {
                    System.out.println("    " + field);
                }
            }
        }
    }

    // Extract relevant headers from ScheduledHeaders
    // return map of extracted headers with their values
    Map<String, String> getHeaders(ScheduledHeaders headers) {
        String programName = "";
        String programFlag = "";
        String runDate = "";

        // Populate result map according to the header type
        if (headers.getGetdataHeaders() != null) {
            programName = "getdata";
            programFlag = headers.getGetdataHeaders().getProgramflag().toString();
            runDate = headers.getGetdataHeaders().getRundate();
        } else if (headers.getGethistoryHeaders() != null) {
            programName = "gethistory";
            programFlag = headers.getGethistoryHeaders().getProgramflag().toString();
            runDate = headers.getGethistoryHeaders().getRundate();
        } else if (headers.getGetquotesHeaders() != null) {
            programName = "getquotes";
            programFlag = headers.getGetquotesHeaders().getProgramflag().toString();
            runDate = headers.getGetquotesHeaders().getRundate();
        } else if (headers.getGetallquotesHeaders() != null) {
            programName = "getallquotes";
            programFlag = headers.getGetallquotesHeaders().getProgramflag().toString();
            runDate = headers.getGetallquotesHeaders().getRundate();
        } else if (headers.getGetactionsHeaders() != null) {
            programName = "getactions";
            programFlag = headers.getGetactionsHeaders().getProgramflag().toString();
            runDate = headers.getGetactionsHeaders().getRundate();
        } else if (headers.getGetcompanyHeaders() != null) {
            programName = "getcompany";
            programFlag = headers.getGetcompanyHeaders().getProgramflag().toString();
            runDate = headers.getGetcompanyHeaders().getRundate();
        } else if (headers.getGetfundamentalsHeaders() != null) {
            programName = "getfundamentals";
            programFlag = headers.getGetfundamentalsHeaders().getProgramflag().toString();
            runDate = headers.getGetfundamentalsHeaders().getRundate();
        }

        Map<String, String> headersMap = new HashMap<String, String>();
        programName = (programName == null) ? "" : programName;
        programFlag = (programFlag == null) ? "" : programFlag;
        runDate = (runDate == null) ? "" : runDate;
        headersMap.put("programName", programName);
        headersMap.put("programFlag", programFlag);
        headersMap.put("runDate", runDate);
        return headersMap;
    }
}
