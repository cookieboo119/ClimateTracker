/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/* GetDataMacro - This class submits a getdata request by specifying
 * the instruments as macros and fields for the request parameters. This is
 * followed by retrieve getdata response to get the values for the fields.
 * This class also illustrates handling invalid macros in the response.
 */
package com.bloomberg.datalic.dlws;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.Fields;
import com.bloomberg.datalic.dlws.stubs.GetDataHeaders;
import com.bloomberg.datalic.dlws.stubs.InstrumentData;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.Macro;
import com.bloomberg.datalic.dlws.stubs.MacroType;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.PrimaryQualifier;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataResponse;
import com.bloomberg.datalic.dlws.stubs.SecondaryQualifier;
import com.bloomberg.datalic.dlws.stubs.SecondaryQualifierOperator;
import com.bloomberg.datalic.dlws.stubs.SecondaryQualifierType;

public class GetDataMacro {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            GetDataHeaders headers = new GetDataHeaders();
            headers.setProgramflag(programFlag);
            headers.setSecmaster(Boolean.TRUE);
            headers.setPricing(Boolean.TRUE);

            // Setting macro for the instrument
            PrimaryQualifier primaryQualifier = new PrimaryQualifier();
            primaryQualifier.setPrimaryQualifierType(MacroType.SECTYP);
            primaryQualifier.setPrimaryQualifierValue("OPT_CHAIN");
            Macro macro1 = new Macro();
            macro1.setPrimaryQualifier(primaryQualifier);
            SecondaryQualifier secondaryQualifier = new SecondaryQualifier();
            secondaryQualifier = new SecondaryQualifier();
            secondaryQualifier.setSecondaryQualifierOperator(SecondaryQualifierOperator
                    .fromValue("Equals"));
            secondaryQualifier.setSecondaryQualifierType(SecondaryQualifierType.TICKER);
            secondaryQualifier.setSecondaryQualifierValue("AAPL US Equity");
            macro1.getSecondaryQualifier().add(secondaryQualifier);

            // Setting an incorrect macro
            PrimaryQualifier invalidPrimaryQualifier = new PrimaryQualifier();
            invalidPrimaryQualifier.setPrimaryQualifierType(MacroType.SECTYP);
            invalidPrimaryQualifier.setPrimaryQualifierValue("NOCHAIN");
            Macro macro2 = new Macro();
            macro2.setPrimaryQualifier(invalidPrimaryQualifier);
            SecondaryQualifier invalidSecondaryQualifier = new SecondaryQualifier();
            invalidSecondaryQualifier = new SecondaryQualifier();
            invalidSecondaryQualifier.setSecondaryQualifierOperator(SecondaryQualifierOperator
                    .fromValue("Equals"));
            invalidSecondaryQualifier
                    .setSecondaryQualifierType(SecondaryQualifierType.SECURITY_DES);
            invalidSecondaryQualifier.setSecondaryQualifierValue("SPX Index");
            macro2.getSecondaryQualifier().add(invalidSecondaryQualifier);

            Instruments instruments = new Instruments();
            instruments.getMacro().add(macro1);
            instruments.getMacro().add(macro2);

            // Setting fields
            Fields fields = new Fields();
            fields.getField().add("TICKER");
            fields.getField().add("PX_LAST");
            fields.getField().add("NAME");

            // Construct and submit getdata request
            System.out.println("Sending submit getdata request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetDataRequest(headers, null, fields, instruments, statusCode, requestId,
                    responseId);
            System.out.println("Submit getdata request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve getdata
            RetrieveGetDataRequest rtvGetDataReq = new RetrieveGetDataRequest();
            rtvGetDataReq.setResponseId(responseId.value);
            RetrieveGetDataResponse rtvGetDataResp;
            System.out.println("Sending retrieve getdata request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetDataResp = ps.retrieveGetDataResponse(rtvGetDataReq);
            } while (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve getdata request successful for responseId: "
                        + rtvGetDataResp.getResponseId());
                for (InstrumentData instrumentData : rtvGetDataResp.getInstrumentDatas()
                        .getInstrumentData()) {
                    if (instrumentData.getCode().equals("0")) {
                        System.out.println("Data for " + instrumentData.getInstrument().getId()
                                + " " + instrumentData.getInstrument().getYellowkey() + ":");
                        for (int i = 0; i < instrumentData.getData().size(); i++) {
                            System.out.println("  " + rtvGetDataResp.getFields().getField().get(i)
                                    + ": " + instrumentData.getData().get(i).getValue());
                        }
                    } else {
                        System.out.println("\n\nError Code " + instrumentData.getCode()
                                + ": incorrect macro. The Macro object is as follows: ");
                        System.out.println("Primary Qualifier: ");
                        System.out.println("Primary Qualifier type: "
                                + instrumentData.getMacro().getPrimaryQualifier()
                                        .getPrimaryQualifierType().toString());
                        System.out.println("Primary Qualifier Value: "
                                + instrumentData.getMacro().getPrimaryQualifier()
                                        .getPrimaryQualifierValue().toString());
                        System.out.println("Secondary Qualifier: ");
                        for (SecondaryQualifier secondaryQualifier2 : instrumentData.getMacro()
                                .getSecondaryQualifier()) {
                            System.out.println("Secondary Qualifier type: "
                                    + secondaryQualifier2.getSecondaryQualifierType());
                            System.out.println("Secondary Qualifier Operator: "
                                    + secondaryQualifier2.getSecondaryQualifierOperator());
                            System.out.println("Secondary Qualifier value: "
                                    + secondaryQualifier2.getSecondaryQualifierValue());
                        }
                    }
                }
            } else if (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
