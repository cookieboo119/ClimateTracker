/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * PortFolioValidation - This class makes portfolio validation request.
 * The data is displayed if available.
 */

package com.bloomberg.datalic.dlws;

import com.bloomberg.datalic.dlws.stubs.GetPortfolioValidationRequest;
import com.bloomberg.datalic.dlws.stubs.GetPortfolioValidationResponse;
import com.bloomberg.datalic.dlws.stubs.InstrumentData;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;

public class PortfolioValidation {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Submit a BVAL snapshot getdata request
            String responseId = GetData.submitBvalSnapshotGetDataRequest(ps, programFlag);
            if (responseId != null) {
                // Construct and submit getportfoliovalidation request for above
                // BVAL snapshot request
                GetPortfolioValidationRequest getPortfolioValidationReq = new GetPortfolioValidationRequest();
                getPortfolioValidationReq.setResponseId(responseId);
                GetPortfolioValidationResponse getPortfolioValidationResp;
                System.out.println("Sending submit getportfoliovalidation request");

                // Keep polling for response till the data is available
                do {
                    Thread.sleep(PerSecurity.POLL_FREQUENCY);
                    getPortfolioValidationResp = ps
                            .getPortfolioValidation(getPortfolioValidationReq);
                } while (getPortfolioValidationResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

                // Display data
                if (getPortfolioValidationResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                    System.out.println("getportfoliovalidation request successful for responseId: "
                            + getPortfolioValidationResp.getResponseId());
                    for (InstrumentData instrumentData : getPortfolioValidationResp
                            .getInstrumentDatas().getInstrumentData()) {
                        String yellowKey = "";
                        if (instrumentData.getInstrument().getYellowkey() != null) {
                            yellowKey = " "
                                    + instrumentData.getInstrument().getYellowkey().toString();
                        }
                        System.out.println("Data for " + instrumentData.getInstrument().getId()
                                + yellowKey + ":");
                        System.out.println("  validation code = " + instrumentData.getCode());
                    }
                } else if (getPortfolioValidationResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                    System.out.println("Error in the getportfoliovalidation request");
                }
            } else {
                System.out.println("Error in submitBvalSnapshotGetDataRequest.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
