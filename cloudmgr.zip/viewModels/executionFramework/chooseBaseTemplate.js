define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/utils/dateTimeHelper', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider'
            ,'ojs/ojarraydataprovider', 'ebs/utils/lovUtils', 'ojs/ojaccordion', 'ojs/ojinputtext', 'ojs/ojpopup', 'ojs/ojrowexpander', 'ojs/ojflattenedtreetabledatasource', 'ojs/ojjsontreedatasource', 'ojs/ojtable', 'ojs/ojmessages', 'ojs/ojswitch', 'ojs/ojbutton'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper, constants, dateTimeHelper, FlattenedTreeDataProviderView, ArrayTreeDataProvider, ArrayDataProvider, lovUtils) {
    /**
     * The view model for the main content view template
     */
    function BaseTemplateViewModel() {
        var self = this;
        self.executionPlanNameEntered = ko.observable('');
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.executionPlanDescriptionEntered = ko.observable('');
        self.executionPlanTemplateSelected = ko.observable();
        self.executionPlanTemplateList = ko.observableArray([{'label': 'loading', 'value': 'loading...'}]);
        self.executionPlanTemplateDataProvider = new ArrayDataProvider(self.executionPlanTemplateList, {idAttribute: 'value'});
        self.isEditMode = ko.observable(false);
        self.currentPlanEditing = ko.observable('');
        self.allPlanList = new Array();

        var TemplateNameValidator = function ()
        {};
        oj.Object.createSubclass(TemplateNameValidator, oj.Validator, "TemplateNameValidator");
        self.templateNameValidator = [new TemplateNameValidator()];

        TemplateNameValidator.prototype.validate = function (value)
        {
            console.log('Template name Validater Called');
            var regularExp = new RegExp("^([a-zA-Z0-9_ ]{1,50})$");
            if (regularExp.test(value))
            {
                if (value === null || value === '') {
                    return false;
                } else {
                    var isDuplicateName = self.isDuplicateExecutionPlanName(value);
                    if (isDuplicateName) {
                        var execPlanNameDuplicateValidationMsg = oj.Translations.getTranslatedString('validationMsgs.executionPlanNameDuplicateValidationMsg');
                        throw new Error(execPlanNameDuplicateValidationMsg);
                        return false;
                    } else {
                        return true;
                    }
                }
            } else
            {
                var execPlanNameNameIncorrectValidationMsg = oj.Translations.getTranslatedString('validationMsgs.executionPlanNameValidationMsg');
                throw new Error(execPlanNameNameIncorrectValidationMsg);
                return false;
            }

        };

        self.isDuplicateExecutionPlanName = function (currentName) {
            for (var i = 0; i < self.allPlanList.length; i++) {
                var planName = self.allPlanList[i].name;
                if (planName === currentName) {
                    return true;
                }
            }
            return false;
        };

        self.initializeListOfExecutionPlanTemplates = function () {
            actionsHelper.getListOfExecutionPlans(function (error, execPlanList) {
                self.allPlanList = execPlanList;
            });
            actionsHelper.getListOfActivitiesSupportingCustomization(function (error, listOfActivities)
            {
                self.executionPlanTemplateList(listOfActivities);
                self.executionPlanTemplateDataProvider = new ArrayDataProvider(self.executionPlanTemplateList, {idAttribute: 'value'});
                lovUtils.lovOptionsUpdated(self.executionPlanTemplateList(), self.executionPlanTemplateSelected);
                if (self.isEditMode()) {
                    var associatedFlowLabel = rootViewModel._currentExecutionPlanAssociatedFlowLabel;
                    for(var k=0;k<listOfActivities.length;k++){
                        var label = listOfActivities[k].label;
                        if(label === associatedFlowLabel){
                            var value = listOfActivities[k].value;
                            self.executionPlanTemplateSelected(value);
                        }
                    }
                    self.executionPlanNameEntered(self.currentPlanEditing());
                }
            });
        };

        self.isFormValid = function () {
            var valid = true;

            var executionPlanNameElement = document.getElementById('ExecutionPlanName');
            var isDuplicate = self.isDuplicateExecutionPlanName(executionPlanNameElement.value) && !self.isEditMode();

            if (executionPlanNameElement.valid !== 'valid' || isDuplicate)
            {
                executionPlanNameElement.validate();
                executionPlanNameElement.showMessages();
                valid = false;
            }

            var executionPlanDescElement = document.getElementById('ExecutionPlanDescription');
            if (executionPlanDescElement.valid !== 'valid')
            {
                executionPlanDescElement.showMessages();
                valid = false;
            }

            var executionPlanTemplateElement = document.getElementById('ExecutionPlanTemplate');
            if (executionPlanTemplateElement.valid !== 'valid')
            {
                executionPlanTemplateElement.showMessages();
                valid = false;
            }

            return valid;



        };

        self.handleExecutionTemplateOptionChange = function (event) {
            // Nothing to do for now.
        };



        var execPlanForEdit = rootViewModel._currentExecutionPlanForEdit;
        if (execPlanForEdit !== null && execPlanForEdit !== '') {
            self.isEditMode(true);
            self.currentPlanEditing(execPlanForEdit);
            var desc = rootViewModel._currentExecutionPlanDescForEdit;
            self.executionPlanDescriptionEntered(desc);
        }
        self.initializeListOfExecutionPlanTemplates();

    }
    return BaseTemplateViewModel;

});
