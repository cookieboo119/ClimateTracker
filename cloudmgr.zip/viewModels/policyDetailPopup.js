define(['ojs/ojcore', 'knockout', 'jquery', 'ebs/actions/actionsHelper', 'ebs/utils/backupEnvironmentHelper', 'ebs/popup/popupHelper',
    'ebs/constants', 'ojs/ojvalidator-regexp', 'ebs/navigation/pageNavigationHelper', 'ebs/utils/compartmentUtils', 'ebs/utils/scheduleUtils',
    'ojs/ojinputtext', 'ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojarraydataprovider', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojfilepicker', 'ojs/ojtable', 'ojs/ojswitch'],
        function (oj, ko, $, actionsHelper, backupEnvironmentHelper, popupHelper, constants, RegExpValidator, pageNavigationHelper, compartmentUtils, scheduleUtils) {

            function policyDetailPopupViewModel() {
                var self = this;
                console.log('Loading Policy Details Popup View Model');
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.compartmentName = ko.observable('');
                self.policyName = ko.observable('');
                self.scheduleListLoaded = ko.observable(false);
                self.compartments = ko.observableArray([]);
                self.schedules = ko.observableArray([]);
                self.scheduleDataSource = new oj.ArrayTableDataSource(
                        self.schedules,
                        {idAttribute: 'id'});
                self.scheduleDataSourceObservable = ko.observable(self.scheduleDataSource);
                self.policyPopupTitle = ko.observable('Policy Details');
                self.position = ko.observable();
                self.position({my: {horizontal: 'left', vertical: 'top'},
                    at: {horizontal: 'left', vertical: 'top'},
                    offset: {y: 50, x: 100},
                    collision: 'fit',
                    of: 'window'}
                );
                self.scheduleTableColumns = [
                    {headerText: 'Schedule Type',
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 8em; width: 8em; text-align: left;",
                        style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                        field: 'type_display',
                        sortable: 'enabled',
                        template: 'textCellTemplate',
                        sortProperty: 'type_display'},
                    {headerText: 'Start Time',
                        headerStyle: "font-weight: bold; min-width: 8em; max-width: 8em; width: 8em; text-align: left;",
                        style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                        field: 'startTime',
                        sortable: 'enabled',
                        template: 'textCellTemplate',
                        sortProperty: 'startTime'}

                ];

                self.openPopup = function (envName, policyName, policyIdentifier, jobType, event) {
                    self.policyPopupTitle(policyName + " details");
                    var popup = document.querySelector(constants.divTags.policyDetailPopupTag);
                    popup.open(event.target);
                    self.scheduleListLoaded(false);
                    if('backup' === jobType)
                    {
                        actionsHelper.getEnvironmentBackupPolicyDetail(envName, function (error, policyDetail) {
                            if (error === null || error === '') {
                                var name = policyDetail.name;
                                self.policyName(name);
                                var compartmentIdentifier = policyDetail.compartmentId;
                                var compartmentName = compartmentUtils.getCompartmentNameFromOCID(compartmentIdentifier, self.compartments());
                                self.compartmentName(compartmentName);
                                var schedules = policyDetail.schedules;
                                var listOfSchedules = [];
                                $.each(schedules, function () {
                                    var schedule = {
                                        id: this.id,
                                        type_display: scheduleUtils.getUserFriendlyNameForPeriod(this.period),
                                        type_value: this.period,
                                        startTime: scheduleUtils.getStartTimeStringFromSchedule(this.period, this.hourOfDay, this.dayOfWeek, this.dayOfMonth, this.month),
                                    };
                                    if (typeof (schedule) === 'undefined' || typeof (schedule.id) === 'undefined' || schedule.id === null || schedule.id === '') {
                                        // skip this schedule.
                                    } else {
                                        listOfSchedules.push(schedule);
                                    }
                                });
                                self.schedules(listOfSchedules);
                            }
                            self.scheduleListLoaded(true);
                        });
                    }
                };



                self.closePopup = function () {
                    self.cleanUpViewModel();
                    var popup = document.querySelector(constants.divTags.policyDetailPopupTag);
                    popup.close();
                };

                self.cleanUpViewModel = function () {

                };
                
                     
            actionsHelper.getCompartmentListForTenancy(function (error, compartmentsList) {
                 if (error != null && error != '') {
                     console.log('Error in policyDetailPopup: fetching Compartment List for tenancy =>' + error);
                 } else {
                    self.compartments(compartmentsList);
                 }
             });
         }

            return policyDetailPopupViewModel;
        });
