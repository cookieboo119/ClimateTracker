define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/utils/dateTimeHelper', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider'
    , 'ojs/ojaccordion', 'ojs/ojinputtext', 'ojs/ojpopup', 'ojs/ojrowexpander', 'ojs/ojflattenedtreetabledatasource', 'ojs/ojjsontreedatasource', 'ojs/ojtable', 'ojs/ojmessages', 'ojs/ojswitch', 'ojs/ojbutton'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper, constants, dateTimeHelper, FlattenedTreeDataProviderView, ArrayTreeDataProvider) {
    /**
     * The view model for the main content view template
     */
    function CustomizationTemplateViewModel() {
        var self = this;
        self.tableDataObject = ko.observable();
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.tableDataProvider = ko.observable();
        var ACTIONS_MENU_ID_SUFFIX = "~menu";
        var executionPlanDataForUI = null;
        self.selectedRow = ko.observable();
        self.flattenedTreeStructure = ko.observableArray();
        self.isLCMCustomizationTemplate = ko.observable(false);

        self.tableColumnsArray = [
            { "headerText": "Phase", "sortable": "disabled", "headerStyle": "font-weight:bold" },

            { "headerText": "Actions", "sortable": "disabled", "headerStyle": "font-weight:bold" }
        ];
        self._currentTaskKey = null;
        self._lastLoadedTemplate = null;
        self.menuOptions = ko.observableArray([]);
        self.templateLoaded = ko.observable(false);
        var insertAfterEnabled = { id: 'InsertAfter', label: 'Insert After', disabled: false };
        var emptyOption = { id: 'emptyOption', label: '', disabled: false };
        var deletePhaseOption = { id: 'deletePhase', label: 'Delete Phase', disabled: false };
        var addTaskOption = { id: 'addTask', label: 'Add Tasks', diabled: false };
        var deleteTaskOption = { id: 'deleteTask', label: 'DeleteTask', disabled: false };
        self.customPhaseSequence = ko.observable(0);
        self.savedScrollTop = ko.observable(0);

        self.getTaskDataFromFlattenedArray = function (childKey) {
            var elements = self.flattenedTreeStructure();
            if (elements === null) {
                return -1;
            } else {
                for (var i = 0; i < elements.length; i++) {
                    var childElem = elements[i];
                    if (childElem.attr.id === childKey) {
                        return childElem;
                    }
                }
                return -1;
            }
        };



        self.flattenData = function () {
            var phases = self.tableDataObject().length;
            for (var i = 0; i < phases; i++) {
                var phaseElemData = self.tableDataObject()[i];
                self.flattenedTreeStructure().push(phaseElemData);
                var taskChildren = phaseElemData.children;
                if (typeof (taskChildren) !== 'undefined' && taskChildren !== null && taskChildren.length > 0) {
                    for (var k = 0; k < taskChildren.length; k++) {
                        self.flattenedTreeStructure().push(taskChildren[k]);
                    }
                }
            }
        };


        self.restoreScrollTop = function () {
            console.log('Restoring scroll top to :' + self.savedScrollTop());
            document.documentElement.scrollTop = self.savedScrollTop();
        };

        self.refreshTable = function (restoreScrollTop) {
            self.flattenedTreeStructure([]);
            var options = [];
            var options =
            {
                'expanded': 'all',
                'rowHeader': 'id',
            };

            self.flattenData();
            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                new oj.FlattenedTreeDataSource(
                    new oj.JsonTreeDataSource(self.tableDataObject()), options)
            ))
                ;
            setTimeout(function () {
                self.restoreScrollTop();
            }, 200);
        };

        self.getNearestSeededPhaseIdentifier = function (allPhasesAndTasks) {
            for (var i = allPhasesAndTasks.length - 1; i >= 0; i--) {
                var phaseObject = allPhasesAndTasks[i];
                var isSeededAttr = phaseObject.attr.isSeeded;
                if (typeof (isSeededAttr) !== 'undefined' && isSeededAttr) {
                    return phaseObject.attr.id;
                }
            }
            return null;
        };


        self.prepareJsonForTableView = function (rawExecutionPlan, isEditFlow) {
            var allPhasesAndTasks = new Array();
            for (var i = 0; i < rawExecutionPlan.length; i++) {
                var phase = rawExecutionPlan[i];
                var UIPhaseObject = new Object();
                UIPhaseObject.attr = new Object();
                if (!isEditFlow) {
                    UIPhaseObject.attr.isExtensible = phase.isExtensible;
                    UIPhaseObject.attr.isSeeded = phase.isSeeded;
                    UIPhaseObject.attr.id = phase.id;
                    UIPhaseObject.attr.label = phase.label;
                } else {
                    UIPhaseObject.attr.isExtensible = phase.attr.isExtensible;
                    UIPhaseObject.attr.isSeeded = phase.attr.isSeeded;
                    UIPhaseObject.attr.id = phase.attr.id;
                    UIPhaseObject.attr.label = phase.attr.label;
                    if (typeof (UIPhaseObject.attr.isSeeded) !== 'undefined' && !UIPhaseObject.attr.isSeeded) {
                        var nearestSeededPhaseIdentifier = self.getNearestSeededPhaseIdentifier(allPhasesAndTasks);
                        if (nearestSeededPhaseIdentifier !== null) {
                            UIPhaseObject.attr._seededPhaseReferenceIdentifier = nearestSeededPhaseIdentifier;
                        }
                    }
                }
                if (UIPhaseObject.attr.isSeeded) {
                    if (UIPhaseObject.attr.isExtensible) {
                        UIPhaseObject.attr._menuEnabled = true;
                    } else {
                        UIPhaseObject.attr._menuEnabled = false;
                    }
                } else {
                    UIPhaseObject.attr._menuEnabled = true;
                }
                UIPhaseObject.attr._actionsMenuId = UIPhaseObject.attr.id + ACTIONS_MENU_ID_SUFFIX;
                UIPhaseObject.attr._reorderEnabled = false;
                UIPhaseObject.attr._isPhase = true;
                var childrenAttr = phase.children;
                if (typeof (childrenAttr) === 'undefined' || childrenAttr === null || childrenAttr.length === 0 || UIPhaseObject.attr.isSeeded) {
                    allPhasesAndTasks.push(UIPhaseObject);
                } else {
                    var UITaskElements = new Array();
                    for (var k = 0; k < childrenAttr.length; k++) {
                        var taskElement = childrenAttr[k];
                        var UITaskObject = new Object();
                        UITaskObject.attr = new Object();
                        if (!isEditFlow) {
                            UITaskObject.attr.isExtensible = typeof (taskElement.isExtensible) === 'undefined' ? false : taskElement.isExtensible;
                            UITaskObject.attr.isSeeded = taskElement.isSeeded;
                            UITaskObject.attr.id = taskElement.id;
                            UITaskObject.attr.label = taskElement.label;
                        } else {
                            UITaskObject.attr.isExtensible = typeof (taskElement.attr.isExtensible) === 'undefined' ? false : taskElement.attr.isExtensible;
                            UITaskObject.attr.isSeeded = taskElement.attr.isSeeded;
                            UITaskObject.attr.id = taskElement.attr.id;
                            UITaskObject.attr.label = taskElement.attr.label;
                            UITaskObject.attr._taskIDForSubmit = taskElement.attr.id;
                        }
                        UITaskObject.attr._menuEnabled = true;
                        UITaskObject.attr._reorderEnabled = true;
                        UITaskObject.attr._isPhase = false;
                        UITaskObject.attr._actionsMenuId = UITaskObject.attr.id + ACTIONS_MENU_ID_SUFFIX;
                        UITaskElements.push(UITaskObject);
                    }
                    UIPhaseObject.children = UITaskElements;
                    allPhasesAndTasks.push(UIPhaseObject);
                }
            }
            executionPlanDataForUI = allPhasesAndTasks;
        };



        self.setupMenuOptions = function (event, ui) {
            self.menuOptions([]);
            self._currentTaskKey = null;

            if (ui.id !== null && ui.id !== '') {
                var taskKey = ui.id;
                var taskElementData = self.getTaskDataFromFlattenedArray(taskKey);
                if (taskElementData === null || taskElementData === '') {
                    console.log('Task Element(Data Object) is null. So disabling all menu options. Task Key => ' + taskKey);
                    self.menuOptions.push(emptyOption);
                } else {
                    self._currentTaskKey = taskKey;
                    /* If isExtensible then allow addAfter */
                    var _custAllowed = taskElementData.attr.isExtensible;
                    if (_custAllowed) {
                        self.menuOptions.push(insertAfterEnabled);

                    }
                    /* If this is a phase and it is custom, then enable delete phase & add custom tasks */
                    var _isPhase = taskElementData.attr._isPhase;
                    var isSeeded = taskElementData.attr.isSeeded;
                    if (_isPhase) {
                        if (!isSeeded) {
                            self.menuOptions.push(deletePhaseOption);
                            self.menuOptions.push(addTaskOption);
                        }
                    }

                    var _isDeleteTasksEnabled = !_isPhase;
                    if (_isDeleteTasksEnabled) {
                        self.menuOptions.push(deleteTaskOption);
                    }

                }
            } else {
                console.log('Original Event Target is null or Original Event target element id is null. So disabling all menu options.');
                self.menuOptions.push(emptyOption);
            }
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        };

        self.handleEventsFromMenu = function (event) {
            var eventSourceName = event.target.value;
            if (self._currentTaskKey === null) {
                console.log('Current Task Key is null so no event handling.');
                return;
            } else {
                if (eventSourceName === 'InsertAfter') {
                    self.insertNewPhaseAfter(self._currentTaskKey, event);
                } else if (eventSourceName === 'addTask') {
                    self.openTaskLov(event, self._currentTaskKey);
                } else if (eventSourceName === 'deleteTask') {
                    self.deleteTaskFromPhase(event, self._currentTaskKey);
                } else if (eventSourceName === 'deletePhase') {
                    self.deleteCustomPhase(event, self._currentTaskKey);
                }
            }
        };

        self.deleteTaskFromPhase = function (event, childTaskKey) {
            var taskDataFromDataProvider = self.findElementDataInDataProvider(childTaskKey);
            var parentTaskId = taskDataFromDataProvider.parent;
            var parentElementDataObject = self.getPhaseDataObject(parentTaskId);
            var childIdx = self.getChildIndexFromParentDataObject(childTaskKey, parentElementDataObject);
            parentElementDataObject.children.splice(childIdx, 1);
            self.refreshTable();
        };

        self.findElementDataInDataProvider = function (keyElement) {
            var providerCache = self.tableDataProvider()._data.m_cache;
            for (var i = 0; i < providerCache.length; i++) {
                var key = providerCache[i].key;
                if (key === keyElement) {
                    return providerCache[i];
                }
            }
            return -1;
        };

        self.getChildIndexFromParentDataObject = function (childKey, parentDataObject) {
            var childElements = parentDataObject.children;
            if (childElements === null) {
                return -1;
            } else {
                for (var i = 0; i < childElements.length; i++) {
                    var childElem = childElements[i];
                    if (childElem.attr.id === childKey) {
                        return i;
                    }
                }
                return -1;
            }
        };

        self.getIndexOfPhaseElement = function (phaseKey) {
            var rootDataObject = self.tableDataObject();
            if (rootDataObject === null || rootDataObject.length === 0) {
                return -1;
            } else {
                for (var i = 0; i < rootDataObject.length; i++) {
                    var phaseElement = rootDataObject[i];
                    var idOfPhaseElement = phaseElement.attr.id;
                    if (idOfPhaseElement === phaseKey) {
                        return i;
                    }
                }
                return -1;
            }
        };

        self.getPhaseDataObject = function (phaseKey) {
            var rootDataObject = self.tableDataObject();
            if (rootDataObject === null || rootDataObject.length === 0) {
                return -1;
            } else {
                for (var i = 0; i < rootDataObject.length; i++) {
                    var phaseElement = rootDataObject[i];
                    var idOfPhaseElement = phaseElement.attr.id;
                    if (idOfPhaseElement === phaseKey) {
                        return phaseElement;
                    }

                }
                return null;
            }
        };

        self.getPhaseDataObjectAtIndex = function (index) {
            var rootDataObject = self.tableDataObject();
            if (rootDataObject === null || rootDataObject.length === 0) {
                return -1;
            } else {
                for (var i = 0; i < rootDataObject.length; i++) {
                    var phaseElement = rootDataObject[i];
                    if (index === i) {
                        return phaseElement;
                    }
                }
                return null;
            }
        };

        self.openTaskLov = function (event, phaseIdOfContainer) {
            var viewModelOfTaskLovModule = ko.dataFor(document.getElementById(constants.divTags.taskLovPopupRoot));
            viewModelOfTaskLovModule.openTaskLov(phaseIdOfContainer);
            console.log('Opening add task lov');
            event.preventDefault();
        };



        self.addTasksToPhase = function (parentReferenceIdentifier, selection) {
            if (selection === null || parentReferenceIdentifier === null) {
                console.log('Either selection or parent reference identifier is null . so tasks not added to phase.');
            }
            var customPhaseObject = self.getPhaseDataObject(parentReferenceIdentifier);
            if (customPhaseObject === null || customPhaseObject === '') {
                console.log('Could not find the phase element. so tasks not added to phase');
            }
            var customPhaseObjectChildrenObject = customPhaseObject.children;
            var parentPhaseIdentifier = customPhaseObject.attr.id;
            for (var i = 0; i < selection.length; i++) {
                var selectedTask = selection[i];
                var incomingTaskName = selectedTask.TaskName;
                var isDuplicate = self.isTaskPresentUnderThisPhase(customPhaseObject, incomingTaskName);
                if (isDuplicate) {
                    console.log('Duplicate Task Name : ' + incomingTaskName + ' ignored.');
                    continue;
                }
                var newChildTaskObject = new Object();
                newChildTaskObject.attr = new Object();
                newChildTaskObject.attr.id = parentPhaseIdentifier + "_" + selectedTask.TaskValue;
                newChildTaskObject.attr._taskIDForSubmit = selectedTask.TaskIDForSubmit;
                newChildTaskObject.attr.label = selectedTask.TaskName;
                if (selectedTask.TaskType === 'Seeded')
                    newChildTaskObject.attr.isSeeded = true;
                else
                    newChildTaskObject.attr.isSeeded = false;
                newChildTaskObject.attr.isExtensible = false;
                newChildTaskObject.attr._actionsMenuId = newChildTaskObject.attr.id + ACTIONS_MENU_ID_SUFFIX;
                newChildTaskObject.attr._reorderEnabled = true;
                newChildTaskObject.attr._isPhase = false;
                newChildTaskObject.attr._menuEnabled = true;
                customPhaseObjectChildrenObject.push(newChildTaskObject);
                self.refreshTable();
            }

        };

        self.isTaskPresentUnderThisPhase = function (customPhaseObject, incomingTaskIdentifier) {
            var customPhaseObjectChildrenObject = customPhaseObject.children;
            if (customPhaseObjectChildrenObject === null || customPhaseObjectChildrenObject.length === 0) {
                return false;
            } else {
                for (var i = 0; i < customPhaseObjectChildrenObject.length; i++) {
                    var childTaskObject = customPhaseObjectChildrenObject[i];
                    var childTaskIdentifier = childTaskObject.attr.label;
                    if (childTaskIdentifier === incomingTaskIdentifier) {
                        return true;
                    }
                }
            }
            return false;
        };


        self.insertNewPhaseAfter = function (parentIdentifier, event) {
            var indexOfPhaseElem = self.getIndexOfPhaseElement(parentIdentifier);
            if (indexOfPhaseElem === -1) {
                console.log('Error inserting new phase after the phase element. The Index of phase Element is -1');
                return;
            }
            var phaseDataObject = self.getPhaseDataObject(parentIdentifier);
            if (phaseDataObject === null) {
                console.log('Error inserting new phase after the phase element. ThePhase Data Object is not found');
                return;
            }
            if (!self.isLCMCustomizationTemplate()) {
                phaseDataObject.attr._menuEnabled = false;
                phaseDataObject.attr.isExtensible = false;
            }



            var newPhaseObject = new Object();
            newPhaseObject.attr = new Object();
            newPhaseObject.attr.id = "Custom" + self.customPhaseSequence();
            newPhaseObject.attr.label = "custom" + phaseDataObject.attr.label;
            newPhaseObject.attr.isSeeded = false;
            newPhaseObject.attr.isExtensible = false;
            newPhaseObject.attr._menuEnabled = true;
            newPhaseObject.attr._reorderEnabled = false;
            newPhaseObject.attr._recordAddedAfter = false;
            newPhaseObject.attr._actionsMenuId = newPhaseObject.attr.id + ACTIONS_MENU_ID_SUFFIX;
            newPhaseObject.attr._isPhase = true;
            if (parentIdentifier !== null) {
                newPhaseObject.attr._seededPhaseReferenceIdentifier = parentIdentifier;
            }
            newPhaseObject.children = new Array();
            var phaseLevelObject = self.tableDataObject();
            phaseLevelObject.splice(indexOfPhaseElem + 1, 0, newPhaseObject);
            self.customPhaseSequence(self.customPhaseSequence() + 1);
            self.refreshTable();
            self.openTaskLov(event, newPhaseObject.attr.id);
        };

        self.deleteCustomPhase = function (event, phaseKey) {
            var customPhaseIdx = self.getIndexOfPhaseElement(phaseKey);
            var seededPhaseIdx = customPhaseIdx - 1;
            var seededPhaseObject = self.getPhaseDataObjectAtIndex(seededPhaseIdx);
            seededPhaseObject.attr._menuEnabled = true;
            seededPhaseObject.attr.isExtensible = true;
            self.tableDataObject().splice(customPhaseIdx, 1);
            self.refreshTable();
        };

        self.handleDropRows = function (event, ui) {
            var dragData = event.dataTransfer.getData('application/ojtablerows+json');

            if (dragData) {
                var parsedDragData = JSON.parse(dragData)[0];
                self.savedScrollTop(document.documentElement.scrollTop);

                var draggedNodeTableRowIdx = parsedDragData.index;
                var draggedRowDataFromProvider = self.tableDataProvider()._data.m_cache[draggedNodeTableRowIdx];
                var draggedNodeParent = draggedRowDataFromProvider.parent;

                var droppedNodeTableRowIdx = ui.rowIndex;
                var droppedRowDataFromProvider = self.tableDataProvider()._data.m_cache[droppedNodeTableRowIdx];
                var droppedNodeParent = null;

                /* If a row is dropped at the end of the HGrid , ie., the last row of the last phase then there is no parent 
                 * meta data for that row.
                 */
                if (droppedRowDataFromProvider !== null && typeof (droppedRowDataFromProvider) !== 'undefined') {
                    droppedNodeParent = droppedRowDataFromProvider.parent;
                }

                /* In JET we drag past the actual node, suppose an element is to be dropped beyond the parent's children .
                 * i.e., as a last child of the parent element then the dropped row index will be beyond the parent limit.
                 * Hence comparing dragged parent vs dropped parent will not work for this case alone.
                 * Hence we check the dragged parent start index with in the HGrid, count the number of children and
                 * if draggedParentStartIdx + child Count + 1 is the dropped UI node index then we drop at the end.
                 */
                var draggedNodeParentNodeIdxInHierarchy = self.findElementIndexInDataProvider(draggedNodeParent);
                var parentElementDataObject = self.getPhaseDataObject(draggedNodeParent);
                var draggedNodeParentChildCount = parentElementDataObject.children.length;
                var limitIdx = draggedNodeParentNodeIdxInHierarchy + draggedNodeParentChildCount + 1;
                var isDroppedAtEnd = false;

                console.log('Dragged Node Parent --' + draggedNodeParent);
                console.log('Dropped Node Parent -- ' + droppedNodeParent);

                if (droppedNodeParent === null || draggedNodeParent !== droppedNodeParent) {
                    if (draggedNodeParentNodeIdxInHierarchy !== -1 && (ui.rowIndex > draggedNodeParentNodeIdxInHierarchy) && (ui.rowIndex <= limitIdx)) {
                        console.log('Dropped at the end of the list.');
                        isDroppedAtEnd = true;
                    } else {
                        console.log('Dragged and dropped nodes are in different sub tree. Not an allowed drop!');
                        return;
                    }
                } else {
                    console.log('Dragged and dropped node are in same parent hierarchy. An allowed drop');
                }


                var parentElementChildrenCollection = parentElementDataObject.children;
                var draggedNodeIdx = self.getChildIndexFromParentDataObject(draggedRowDataFromProvider.key, parentElementDataObject);
                var draggedNodeDataObject = self.getChildDataFromParentDataObject(draggedRowDataFromProvider.key, parentElementDataObject);
                parentElementChildrenCollection.splice(draggedNodeIdx, 1);
                if (isDroppedAtEnd) {
                    parentElementChildrenCollection.push(draggedNodeDataObject);
                } else {
                    var droppedNodeIdx = self.getChildIndexFromParentDataObject(droppedRowDataFromProvider.key, parentElementDataObject);
                    parentElementChildrenCollection.splice(droppedNodeIdx, 0, draggedNodeDataObject);
                }
                self.refreshTable(true);
            }
        };

        self.findElementIndexInDataProvider = function (keyElement) {
            var providerCache = self.tableDataProvider()._data.m_cache;
            for (var i = 0; i < providerCache.length; i++) {
                var key = providerCache[i].key;
                if (key === keyElement) {
                    return i;
                }
            }
            return -1;
        };

        self.getChildDataFromParentDataObject = function (childKey, parentDataObject) {
            var childElements = parentDataObject.children;
            if (childElements === null) {
                return -1;
            } else {
                for (var i = 0; i < childElements.length; i++) {
                    var childElem = childElements[i];
                    if (childElem.attr.id === childKey) {
                        return childElem;
                    }
                }
                return -1;
            }
        };



        self.initializeTableData = function (newValue) {
            var viewModelOfBaseTemplatePG = ko.dataFor(document.getElementById('TemplateParametersEntryForm'));
            var templateName = null;
            var execPlanForEdit = rootViewModel._currentExecutionPlanForEdit;
            if (newValue !== null && typeof (newValue) !== 'undefined') {
                templateName = newValue;
            } else {
                templateName = viewModelOfBaseTemplatePG.executionPlanTemplateSelected();
            }
            if (self._lastLoadedTemplate !== null && self._lastLoadedTemplate === templateName) {
                return;
            }
            if (self._lastLoadedTemplate !== null && execPlanForEdit !== null && execPlanForEdit !== '') {
                return; // In Edit mode, there is no reLoad scenario.
            }
            self.templateLoaded(false);
            self.tableDataProvider();
            self.tableDataObject();

            if (templateName === constants.baseTemplates.lcmTemplate) {
                self.isLCMCustomizationTemplate(true);
            } else {
                self.isLCMCustomizationTemplate(false);
            }

            if (execPlanForEdit !== null && execPlanForEdit !== '') {
                var execPlanIdentifier = rootViewModel._currentExecutionPlanIdForEdit;
                actionsHelper.fetchExecutionTemplateForEdit(execPlanIdentifier, function (error, BaseExecutionPlanJSONData) {
                    self.handleExecPlanResponseData(execPlanForEdit, BaseExecutionPlanJSONData, error, true);
                });
            } else {
                actionsHelper.getExecutionPlanTemplateForJob(templateName, function (error, BaseExecutionPlanJSONData) {
                    self.handleExecPlanResponseData(templateName, BaseExecutionPlanJSONData, error, false);
                });
            }
        };

        self.handleExecPlanResponseData = function (templateName, BaseExecutionPlanJSONData, error, isEditFlow) {
            if (error === '') {
                self._lastLoadedTemplate = templateName;
                var untransformedData = BaseExecutionPlanJSONData;
                self.prepareJsonForTableView(untransformedData, isEditFlow);
                self.tableDataObject(executionPlanDataForUI);
                self.refreshTable();
                self.templateLoaded(true);
            } else {
                // Implement.
            }
        };
        self.initializeTableData();
    }
    return CustomizationTemplateViewModel;

});