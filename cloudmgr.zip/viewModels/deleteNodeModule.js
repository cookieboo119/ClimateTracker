/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * delete node module
 */
define(['ebs/navigation/pageNavigationHelper','ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/utils/validationHelper', 'ebs/utils/progressHelper',
    'ebs/utils/backupEnvironmentHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojarraydataprovider', 'ebs/utils/compartmentsLov', 
    'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton',  'ojs/ojprogress', 'ojs/ojswitch', 'ojs/ojmessages'], 
    function (pageNavigationHelper, oj, ko, actionsHelper, validationHelper, progressHelper, backupEnvironmentHelper, popupHelper, constants, ArrayDataProvider) {
    /**
     * The view model for the main content view template
     */
    function deleteNodeModule() {
        var self = this;
        console.log('Loading Delete  Node Popup View Model');
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));


        self.enteredDeleteNodeWlsPwd = ko.observable('');
        self.enteredDeleteNodeAppsPwd = ko.observable('');
        self.deleteNodePopupTitle = ko.observable('Delete Node');       
        self.showWlsAdminPwd = ko.observable(false);
        
        self.appsPwdValidationMsg = ko.observable([]);
        self.wlsPwdValidationMsg = ko.observable([]);
        self.showProgressBar = ko.observable("none");
        self.displayRemoveLBaaS = ko.observable(false);
        self.removeLBaaS = ko.observable(false);
        self.removeLBaaSMsg = ko.observable();
        
        self.deleteNodePopupMsg = oj.Translations.getTranslatedString('helpMsgs.deleteNodeInfo');
        self.zoneName = ko.observable('');
        self.showSubmitProgressBar = ko.observable("none");
        self.disableSubmitBtn = ko.observable(false);
        self.disableCancelBtn = ko.observable(false);
        self.pwdValidateProgressConfig = progressHelper.getProgressConfig('validateProgress', -1, 'Password validation is in progress.' , self.showProgressBar);
        self.submitProgressConfig = progressHelper.getProgressConfig('submitProgress', -1, 'Submitting request.' , self.showSubmitProgressBar);
        self.inlineMessages = [
            {
              severity: 'warning',
              summary: oj.Translations.getTranslatedString("confirmPopup.deleteLastNodeWarnTitle"),
              detail: oj.Translations.getTranslatedString("confirmPopup.deleteLastNodeWarnMsg"),
              closeAffordance: 'none'
            }];
        self.categoryOption = { category: 'none' };
        
        self.displayWarnMessage = ko.observable(false);
        
        self.inlineMessagesDataprovider = new ArrayDataProvider(self.inlineMessages);
        
      
        self.removeLBaaSChanged = function(event, ui)
        {
           var value =  event['detail'].value;
           if(value)
           {
            var msg = {summary:  oj.Translations.getTranslatedString('helpMsgs.removeLBaasInfo'),
                            detail: oj.Translations.getTranslatedString('helpMsgs.removeLBaasInfo'), severity: oj.Message.SEVERITY_TYPE.INFO};
            self.removeLBaaSMsg([msg]);
           }
           else{
               self.removeLBaaSMsg([]);
           }
        }
        
        self.performServerSidePwdValidations = function()
        {
            console.log('Performing server side validations for deleteNode');
            self.showProgressBar("");
            self.disableSubmitBtn(true);
            self.disableCancelBtn(true);
            var inputsToValidateFromServer =
                    [
                        {"id": "credentials.environment.appsPassword", "internalId": "deleteNodeAppsPwd", "customMsgObject": self.appsPwdValidationMsg, "value": self.enteredDeleteNodeAppsPwd()},
                    ];


            var isWlsPwdRequired = self.showWlsAdminPwd();
            if (isWlsPwdRequired)
            {
                inputsToValidateFromServer.push({"id": "credentials.environment.weblogicPassword", "internalId": "deleteNodeWeblogicPwd", "customMsgObject": self.wlsPwdValidationMsg, "value": self.enteredDeleteNodeWlsPwd()});
            }
            
            validationHelper.validateCredentialsOnServer(rootViewModel.currentEnvName(), inputsToValidateFromServer,  self.submitDeleteNodeRESTRequest, self.pwdValidationFailed);
      
        }
        
        self.pwdValidationFailed = function()
        {
            self.showProgressBar("none");
            self.disableSubmitBtn(false);
            self.disableCancelBtn(false);
        }


        self.submitDeleteNode = function ()
        {
            var validationsFailed = self.validateDeleteNodeContents();
            if (validationsFailed)
            {
                return;
            }

            self.performServerSidePwdValidations();
        }
        
        self.submitDeleteNodeRESTRequest = function(){
           self.showProgressBar("none");  
           self.showSubmitProgressBar("");
            /* Add Node Post JSON Content Preparation */
            var postJsonData = {
                "credentials": {
                    "environment": {
                        "appsPassword": "",
                        "weblogicPassword": ""
                    }
                },
                "deleteLBaaS":  self.removeLBaaS(),
                "zoneName": self.zoneName(),
                "nodes": [

                ]
            };

            postJsonData.credentials.environment.appsPassword = self.enteredDeleteNodeAppsPwd();
            postJsonData.credentials.environment.weblogicPassword = self.enteredDeleteNodeWlsPwd();
            postJsonData.nodes.push(rootViewModel.currentAppNodeNameForDelete);
            var requestBodyJSON = JSON.stringify(postJsonData);
            console.log('Submitting delete node ..');
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteNodeInfoMsg", {'appNodeName': rootViewModel.currentAppNodeNameForDelete});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.delNodeTitle");
            popupHelper.openInfoMsg(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, infoMsg, msgOrigin);
            var envName = rootViewModel.currentEnvName();
            actionsHelper.deleteAppNodeFromAnEnvironment(envName, requestBodyJSON, function (error, success) {
                if (error === null) {
                    self.closeDeleteNodePopup();
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteNodeConfirmMsg", {'appNodeName': rootViewModel.currentAppNodeNameForDelete});
                    //self.deleteThisNodeFromListView(rootViewModel.currentAppNodeNameForDelete);
                    var context = ko.contextFor(document.getElementById(constants.divTags.envDetailsPageTopDiv));
                    // Clear off global variables before going back to environments list PG.
                    // These were set when we came from list page to details pg.
                    pageNavigationHelper.clearGlobalVariablesBeforeNavigationToEnvListPG(rootViewModel);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                    popupHelper.openSuccessMsg(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, successMsg, msgOrigin);
                } else {
                    self.showSubmitProgressBar("none");
                    self.disableCancelBtn(false);
                    self.disableSubmitBtn(false);
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, response.message, msgOrigin);
                }
            });
        };

        self.validateDeleteNodeContents = function ()
        {
            var invalidsPresent = false;
            var appsPwd = document.getElementById("deleteNodeAppsPwd");
            var wlsPwd = document.getElementById('deleteNodeWeblogicPwd');


            if (appsPwd.valid !== 'valid')
            {
                appsPwd.showMessages();
                invalidsPresent = true;
            }
            if (wlsPwd && wlsPwd.valid !== 'valid')
            {
                wlsPwd.showMessages();
                invalidsPresent = true;
            }

            return invalidsPresent;
        };
        
        self.resetPopup = function ()
        {    
            self.enteredDeleteNodeWlsPwd ('');
            self.enteredDeleteNodeAppsPwd('');      
            self.showProgressBar("none");
            self.removeLBaaS(false);
            self.showSubmitProgressBar("none");
            self.disableSubmitBtn(false);
            self.disableCancelBtn(false);
            self.appsPwdValidationMsg([]);
            self.wlsPwdValidationMsg([]);
        }

        self.openPopup = function (event, ui)
        {
            var popup = document.querySelector(constants.divTags.deleteNodePopup);
            popup.open(event.target);
        };

        self.closeDeleteNodePopup = function (event, ui)
        {
            var popup = document.querySelector(constants.divTags.deleteNodePopup);
            popup.close();
        };




    }
    return deleteNodeModule;
});
