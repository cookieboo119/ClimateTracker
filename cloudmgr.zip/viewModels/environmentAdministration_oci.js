/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * environmentAdministration module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper',
    'jquery', 'ojs/ojknockout', 'ojs/ojbutton', 'ojs/ojmenu', 'ojs/ojtoolbar','ojs/ojlistview',
    'ojs/ojnavigationlist', 'ojs/ojaccordion', 'ojs/ojoffcanvas', 'ojs/ojpopup', 'ojs/ojmodule', 
    'ojs/ojarraytabledatasource', 'ojs/ojcollapsible', 'ojs/ojoffcanvas'
], function (oj, ko, actionsHelper) {
    /**
     * The view model for the main content view template
     */
    function environmentAdministrationContentViewModel() {
    }
    
    return environmentAdministrationContentViewModel;
});      

        