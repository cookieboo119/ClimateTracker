define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/utils/dateTimeHelper', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider'
            , 'ojs/ojaccordion', 'ojs/ojinputtext', 'ojs/ojpopup', 'ojs/ojrowexpander', 'ojs/ojflattenedtreetabledatasource', 'ojs/ojjsontreedatasource', 'ojs/ojtable', 'ojs/ojmessages', 'ojs/ojswitch', 'ojs/ojbutton'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper, constants, dateTimeHelper, FlattenedTreeDataProviderView, ArrayTreeDataProvider) {
    /**
     * The view model for the main content view template
     */
    function ReviewCustomizationTemplateViewModel() {
        var self = this;
        self.tableDataObject = ko.observable();
        self.tableDataProvider = ko.observable();
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.tableColumnsArray = [{"headerText": "Phase", "sortable": "disabled", "headerStyle": "font-weight:bold"},
            {"headerText": "Type", "sortable": "disabled", "headerStyle": "font-weight:bold"}

        ];

        self.initializeTableData = function () {
            self.tableDataProvider();
            self.tableDataObject();
            var viewModelOfCustTemplate = ko.dataFor(document.getElementById('execPlanTable'));
            var tableObject = viewModelOfCustTemplate.tableDataObject();
            self.tableDataObject(tableObject);
            var options = [];
            var options =
                    {
                        'expanded': 'all',
                        'rowHeader': 'id',
                    };

            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                    new oj.FlattenedTreeDataSource(
                            new oj.JsonTreeDataSource(self.tableDataObject()), options)
                    ))
                    ;
        };

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.taskListPGConfirmPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.taskListPGConfirmPopupTag, data, event);
        };

        self.confirmationCallBackFunctionSuccess = null;
        self.confirmationCallBackFunctionFailure = null;
        self.isNoButtonRendered = ko.observable(true);
        self.confirmationDialogTitle = ko.observable('Confirm');
        self.yesButtonText = ko.observable('Yes');
        self.noButtonText = ko.observable('No');
        self.confirmationDialogText = ko.observable('');
        self.executionPlanName = ko.observable('');
        self.executionTemplateDesc = ko.observable('');
        self.executionTemplateNameSelected = ko.observable('');
        var firstStepInTrain = document.getElementById("TemplateParametersEntryForm");
        var planDetViewModel = ko.dataFor(firstStepInTrain);
        if (planDetViewModel !== null){
            console.log('inside 1');
            self.executionPlanName(planDetViewModel.executionPlanNameEntered());
            self.executionTemplateNameSelected(planDetViewModel.executionPlanTemplateSelected());
            self.executionTemplateDesc(planDetViewModel.executionPlanDescriptionEntered());
        } 


        self.openInformationDialog = function (content, callBackFunc) {
            self.confirmationCallBackFunctionSuccess = callBackFunc;
            self.confirmationDialogText(content);
            self.isNoButtonRendered(false);
            self.yesButtonText('OK');
            self.confirmationDialogTitle('Warning');
            document.getElementById('confirmDialog_reviewTemplate').open();
        };

        self.isCustomized = function () {
            var viewModelOfCustTemplate = ko.dataFor(document.getElementById('execPlanTable'));
            var tableObject = viewModelOfCustTemplate.tableDataObject();
            for (var k = 0; k < tableObject.length; k++) {
                var phaseObject = tableObject[k];
                var phaseTypeSeeded = phaseObject.attr.isSeeded;
                if (!phaseTypeSeeded) {
                    var taskChildren = phaseObject.children;
                    if (taskChildren !== null && typeof (taskChildren) !== 'undefined' && taskChildren.length > 0) {
                        return true;
                    }
                }
            }
            return false;
        };


        self.okConfirmationDialog = function () {
            document.getElementById('confirmDialog_reviewTemplate').close();
            self.confirmationCallBackFunctionSuccess();
        };

        self.NotokConfirmationDialog = function () {
            document.getElementById('confirmDialog_reviewTemplate').close();
            self.confirmationCallBackFunctionFailure();
        };

        self.submitExecutionPlan = function (execPlanDataJSON, execPlanName) {
            if (!self.isCustomized()) {
                self.openInformationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.executionTemplateNotCustomized'), function () {
                    var submitButtonViewModel = ko.dataFor(document.getElementById('ExecutionFrameworkCreateTrain'));
                    submitButtonViewModel.submitButtonDisabled(true);
                });
                return;
            } else {
                var isEditFlow = false;
                var firstStepInTrain = document.getElementById("TemplateParametersEntryForm");
                var firstStepViewModel = ko.dataFor(firstStepInTrain);
                if (firstStepViewModel !== null && firstStepViewModel.isEditMode()) {
                    isEditFlow = true;
                }
                var infoMsg = '';
                if (isEditFlow) {
                    infoMsg = oj.Translations.getTranslatedString("confirmPopup.customExecutionPlanEditInfoMsg", {'execPlanName': execPlanName});
                } else {
                    infoMsg = oj.Translations.getTranslatedString("confirmPopup.customExecutionPlanCreateInfoMsg", {'execPlanName': execPlanName});
                }
                var msgOrigin = '';
                if (isEditFlow) {
                    msgOrigin = oj.Translations.getTranslatedString("confirmPopup.customExecutionPlanEditTitle");
                } else {
                    msgOrigin = oj.Translations.getTranslatedString("confirmPopup.customExecutionPlanCreateTitle");
                }
                popupHelper.openInfoMsg(constants.divTags.customTemplateCreateConfirmPopup, infoMsg, msgOrigin);
                var execPlanTemplateIdentifierForEdit = '';
                if(isEditFlow){
                    execPlanTemplateIdentifierForEdit = rootViewModel._currentExecutionPlanIdForEdit;
                }
                actionsHelper.createOrUpdateExecutionTemplate(isEditFlow, execPlanTemplateIdentifierForEdit,firstStepViewModel.executionPlanNameEntered(), execPlanDataJSON, function (error)
                {
                    if (error === '')
                    {
                        var confirmationSuccessMsg = '';
                        if (isEditFlow) {
                            confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.customExecutionPlanEditSuccessMsg", {'execPlanName': execPlanName});
                        } else {
                            confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.customExecutionPlanCreateSuccessMsg", {'execPlanName': execPlanName});
                        }
                        popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);
                        setTimeout(function () {
                            var context = ko.contextFor(document.getElementById('ExecutionFrameworkCreateTrain'));
                            pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkModule, constants.navModules.executionFrameworkModule);
                            rootViewModel.initialAdministrationSubTab = constants.navModules.executionFrameworkModule;
                            rootViewModel.initialExecutionFwkSubTab = constants.navModules.executionTemplatesListingModule;
                        }, 2000);
                    } else
                    {
                        var responseText = error.responseText;
                        var response = JSON.parse(responseText);
                        popupHelper.openErrorMsg(constants.divTags.customTemplateCreateConfirmPopup, response.message, msgOrigin);
                    }

                });
            }
        };

        self.initializeTableData();


    }
    return ReviewCustomizationTemplateViewModel;

});
