/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 *  GetCompany - This class submits a getcompany request by specifying instruments
 *  and bulk fields. This is followed by retrieve getcompany response to get the
 *  data for the fields.
 */
package com.bloomberg.datalic.dlws;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.Fields;
import com.bloomberg.datalic.dlws.stubs.GetCompanyHeaders;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentData;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetCompanyRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetCompanyResponse;

public class GetCompany {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            GetCompanyHeaders headers = new GetCompanyHeaders();
            headers.setProgramflag(programFlag);
            headers.setCreditrisk(true);

            // Setting instruments
            Instrument ticker = new Instrument();
            ticker = new Instrument();
            ticker.setId("AAPL US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.fromValue("Equity"));
            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);

            // Setting fields
            Fields fields = new Fields();
            fields.getField().add("ID_BB_COMPANY");
            fields.getField().add("ID_BB_ULTIMATE_PARENT_CO_NAME");

            // Construct and submit getcompany request
            System.out.println("Sending submit getcompany request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetCompanyRequest(headers, null, fields, instruments, statusCode, requestId,
                    responseId);
            System.out.println("Submit getcompany request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve getcompany
            RetrieveGetCompanyRequest rtvGetCompanyReq = new RetrieveGetCompanyRequest();
            rtvGetCompanyReq.setResponseId(responseId.value);
            RetrieveGetCompanyResponse rtvGetCompanyResp;
            System.out.println("Sending retrieve getcompany request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetCompanyResp = ps.retrieveGetCompanyResponse(rtvGetCompanyReq);
            } while (rtvGetCompanyResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            if (rtvGetCompanyResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve getcompany request successful for responseId: "
                        + rtvGetCompanyResp.getResponseId());
                for (InstrumentData instrumentData : rtvGetCompanyResp.getInstrumentDatas()
                        .getInstrumentData()) {
                    System.out.println("Data for " + instrumentData.getInstrument().getId() + " "
                            + instrumentData.getInstrument().getYellowkey() + ":");
                    for (int i = 0; i < instrumentData.getData().size(); i++) {
                        System.out.println("  " + fields.getField().get(i)
                                + ": " + instrumentData.getData().get(i).getValue());
                    }
                }
            } else if (rtvGetCompanyResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
