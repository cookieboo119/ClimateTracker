
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/navigation/pageNavigationHelper', 'ebs/actions/actionsHelper',
    'ebs/popup/popupHelper', 'ojs/ojlistdataproviderview',
    'ojs/ojarraydataprovider', 'ebs/utils/dateTimeHelper', 'ojs/ojprogress',
    'ojs/ojarraytabledatasource', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojtable',
    'ojs/ojlistview', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojinputsearch'
], function (oj, ko, constants, pageNavigationHelper, actionsHelper, popupHelper, ListDataProviderView, ArrayDataProvider, dateTimeHelper) {
    /**
     * The view model for the main content view template
     */
    function ExecutionFrameworkTaskListViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.taskListLoaded = ko.observable(false);

        self.filter = ko.observable();
        self.tasks = ko.observableArray([]);
        self.taskListDataProvider = ko.computed(function () {
            var filterRegEx = new RegExp(self.filter(), 'i');
            var filterCriterion = {
                op: '$or',
                criteria: [{op: '$regex', value: {name: filterRegEx}},
                    {op: '$regex', value: {type: filterRegEx}},
                    {op: '$regex', value: {createdBy: filterRegEx}},
                    {op: '$regex', value: {executeOn: filterRegEx}},
                    {op: '$regex', value: {dateCreated: filterRegEx}}]
            };
            var arrayDataProvider = new ArrayDataProvider(self.tasks(), {keyAttributes: 'id',     
            sortComparators: { comparators: new Map().set("dateCreated", dateTimeHelper.dateComparator)}});
            return new ListDataProviderView(arrayDataProvider, {filterCriterion: filterCriterion});
        }, self);

        self.runningDeleteFlowValidations = ko.observable(false);
        self.validationChecks = oj.Translations.getTranslatedString("validationMsgs.ValidatingUsages");
        self.deleteTaskCurrentStatus = ko.observable();
        self.runningEditFlowValidations = ko.observable(false);
        self.editTaskCurrentStatus = ko.observable();
        self.currentItemIndex = ko.observable();
        self.menuOptions = ko.observableArray([]);
        self.taskNameForAction = ko.observable();
        self.taskIdForAction = ko.observable();
        self.confirmDeleteMsg = ko.observable();
        self.confirmEditMsg = ko.observable();
        self.deleteAdditionalInformation = ko.observable();
        self.editAdditionalInformation = ko.observable();
        self.taskListColumns = [
            {headerText: '',
                field: 'image',
                style:"width: 50px; max-width: 50px;",
                template: 'iconTemplate'}, 
            {headerText: 'Name',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'name',
                sortable: 'enabled',
                template: 'nameCellTemplate',
                sortProperty: 'name'},
            {headerText: 'Type',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'type',
                sortable: 'enabled',
                template: 'textCellTemplate',
                sortProperty: 'type'},
            {headerText: 'Run From',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'executeOn',
                template: 'textCellTemplate',
                sortable: 'enabled',
                sortProperty: 'executeOn'},
            {headerText: 'Created By',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'createdBy',
                template: 'textCellTemplate',
                sortable: 'enabled',
                sortProperty: 'createdBy'},
            {headerText: 'Date Created',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'dateCreated',
                template: 'textCellTemplate',
                sortable: 'enabled'}
            , {headerText: 'Actions',
                template: 'menuCellTemplate',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left; vertical-align: center;",
                field: 'menu',
                sortable: 'disabled'}
        ];


        var editTaskEnabled = {id: 'EditTask', label: 'Edit', disabled: false};
        var deleteTaskEnabled = {id: 'DeleteTask', label: 'Delete', disabled: false};
        self.disableServerSideValidation = false;

        self.handleCreateTaskButtonClick = function () {
            var context = ko.contextFor(document.getElementById(constants.divTags.execFwkMainPG));
            pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkTaskCreationModule, constants.navModules.executionFrameworkModule, false);
        };

        self.searchText = ko.observable('');
        self.handleSearchTextChange = function (event, ui)
        {
            event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleValueChanged(event, ui);
            }
        }
        self.handleValueChanged = function () {
            self.filter(self.searchText());
        };

        self.displayTaskDetails = function (viewModel, event) {
            var buttonIdentifier = event.target.id;
            var taskIdentifier = buttonIdentifier.split("~")[1];
            var taskName = self.getTaskNameFromIdentifier(taskIdentifier);
            var viewModelOfTaskDetailPopup = ko.dataFor(document.getElementById('TaskDetailPopupRoot'));
            viewModelOfTaskDetailPopup.openPopup(taskName, taskIdentifier, event);
        };
        
        self.getTaskIndexFromTaskId = function(taskId){
            for (var k = 0; k < self.tasks().length; k++) {
                var taskIdentifier = self.tasks()[k].id;
                if (taskIdentifier === taskId) {
                    return k;
                }
            }
        };

        self.handleEventsFromMenu = function (event, ui) {
            rootViewModel._drillDownTaskName = '';
            rootViewModel._drillDownTaskId = '';
            var taskIdx = self.getTaskIndexFromTaskId(ui.key);
            var taskName = self.tasks()[taskIdx].name;
            var taskIdentifier = self.tasks()[taskIdx].id;
            self.taskNameForAction(taskName);
            self.taskIdForAction(taskIdentifier);
            var eventSourceName = event.target.value;
            if ('EditTask' === eventSourceName) {
                self.confirmEditMsg(oj.Translations.getTranslatedString("confirmPopup.editTaskAssertMsg", {taskName: taskName}));
                var popup = document.querySelector(constants.divTags.taskListEditPopupTag);
                popup.open(event.target);
                self.runningEditFlowValidations(true);
                if (!self.disableServerSideValidation) {
                    actionsHelper.getTaskLCMActivites(taskIdentifier, function (error, lcmActivities) {
                        self.runningEditFlowValidations(false);
                        var detailsFound = false;
                        for (var k = 0; k < lcmActivities.length; k++) {
                            var lcmName = lcmActivities[k].name;
                            if (lcmName === 'update') {
                                detailsFound = true;
                                var editAllowed = lcmActivities[k].allowed;
                                if (editAllowed) {
                                    rootViewModel._drillDownTaskName = taskName;
                                    rootViewModel._drillDownTaskId = taskIdentifier;
                                    var isWarningPresent = lcmActivities[k].hasWarning;
                                    if (isWarningPresent) {
                                        self.editTaskCurrentStatus("allowed_with_warning");
                                        var message = lcmActivities[k].message;
                                        if (typeof (message) === 'undefined') {
                                            message = "No Additional Information.";
                                        }
                                        self.editAdditionalInformation(message);
                                    } else {
                                        var context = ko.contextFor(document.getElementById(constants.divTags.execFwkMainPG));
                                        pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkTaskCreationModule, '', false);
                                    }
                                } else {
                                    self.editTaskCurrentStatus("not_allowed");
                                    var message = lcmActivities[k].message;
                                    if (typeof (message) === 'undefined') {
                                        message = "No Additional Information.";
                                    }
                                    self.editAdditionalInformation(message);
                                }
                            }
                        }
                        if (!detailsFound) {
                            self.editTaskCurrentStatus("not_allowed");
                            message = "No Additional Information.";
                            self.editAdditionalInformation(message);
                        }
                    });
                } else {
                     rootViewModel._drillDownTaskName = taskName;
                      rootViewModel._drillDownTaskId = taskIdentifier;
                    self.runningEditFlowValidations(false);
                    var context = ko.contextFor(document.getElementById(constants.divTags.execFwkMainPG));
                    pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkTaskCreationModule, '', false);
                }

            } else if ('DeleteTask' === eventSourceName) {
                self.confirmDeleteMsg(oj.Translations.getTranslatedString("confirmPopup.deleteTaskAssertMsg", {taskName: taskName}));
                var popup = document.querySelector(constants.divTags.taskListDelPopupTag);
                popup.open(event.target);
                self.runningDeleteFlowValidations(true);
                if (!self.disableServerSideValidation) {
                    actionsHelper.getTaskLCMActivites(taskIdentifier, function (error, lcmActivities) {
                        self.runningDeleteFlowValidations(false);
                        var detailsFound = false;
                        for (var k = 0; k < lcmActivities.length; k++) {
                            var lcmName = lcmActivities[k].name;
                            if (lcmName === 'delete') {
                                detailsFound = true;
                                var deleteAllowed = lcmActivities[k].allowed;
                                if (deleteAllowed) {
                                    var isWarningPresent = lcmActivities[k].hasWarning;
                                    if (isWarningPresent) {
                                        self.deleteTaskCurrentStatus("allowed_with_warning");
                                        var message = lcmActivities[k].message;
                                        if (typeof (message) === 'undefined') {
                                            message = "No Additional Information.";
                                        }
                                        self.deleteAdditionalInformation(message);
                                    } else {
                                        self.deleteTaskCurrentStatus("allowed");
                                    }
                                } else {
                                    self.deleteTaskCurrentStatus("not_allowed");
                                    var message = lcmActivities[k].message;
                                    if (typeof (message) === 'undefined') {
                                        message = "No Additional Information.";
                                    }
                                    self.deleteAdditionalInformation(message);
                                }
                            }
                        }
                        if (!detailsFound) {
                            self.deleteTaskCurrentStatus("not_allowed");
                            message = "No Additional Information.";
                            self.deleteAdditionalInformation(message);
                        }
                    });
                } else {
                    self.runningDeleteFlowValidations(false);
                    self.deleteTaskCurrentStatus("allowed");
                }
            }
        };

        self.editTaskConfirmed = function () {
            var context = ko.contextFor(document.getElementById(constants.divTags.execFwkMainPG));
            pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkTaskCreationModule, '', false);
        };

        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.taskListDelPopupTag);
            popup.close();
        };

        self.closeConfirmEditPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.taskListEditPopupTag);
            popup.close();
        };

        self.getTaskNameFromIdentifier = function (taskId) {
            for (var k = 0; k < self.tasks().length; k++) {
                var taskIdentifier = self.tasks()[k].id;
                if (taskIdentifier === taskId) {
                    return self.tasks()[k].name;
                }
            }
        };

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.taskListPGConfirmPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.taskListPGConfirmPopupTag, data, event);
        };

        self.clearFilterInput = function () {
            if (document.getElementById('filterTaskSet'))
                document.getElementById('filterTaskSet').value = '';
            self.filter('');
        };

        self.deleteTask = function (event, ui) {
            var popup = document.querySelector(constants.divTags.taskListDelPopupTag);
            popup.close();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteTaskInfoMsg", {'taskName': self.taskNameForAction()});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.deleteTaskTitle");
            popupHelper.openInfoMsg(constants.divTags.taskListPGConfirmPopupTag, infoMsg, msgOrigin);
            actionsHelper.deleteTask(self.taskIdForAction(), function (error, success) {
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteTaskConfirmMsg", {'taskName': self.taskNameForAction()});
                    popupHelper.openSuccessMsg(constants.divTags.taskListPGConfirmPopupTag, successMsg, msgOrigin);
                    self.loadTasks();
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.taskListPGConfirmPopupTag, response.message, msgOrigin);
                }
            });
        };

        self.setupMenuOptions = function (event, ui) {
            var index = ui.index;
            self.currentItemIndex(index);
            self.menuOptions([]);
            self.menuOptions.push(editTaskEnabled);
            self.menuOptions.push(deleteTaskEnabled);
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        };

        self.loadTasks = function () {
            self.taskListLoaded(false);
            self.clearFilterInput();
            actionsHelper.getAllTasks(function (error, taskLists) {
                if (error !== null && error !== '')
                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelMessage('error', 'Error in retrieving tasks.', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelMessage('error', 'Error in retrieving tasks.', messageContent);
                    }
                }
                var listOfTasks = [];
                $.each(taskLists, function () {
                    var task = {
                        id: this.id,
                        name: this.name,
                        image: '',
                        type: this.type,
                        executeOn: this.executeOn,
                        dateCreated: dateTimeHelper.convertToUTC(this.createdOn),
                        createdBy: this.createdBy,
                        menu: self.menuOptions,
                        handleEventsFromMenu: self.handleEventsFromMenu,
                        setupMenuOptions: self.setupMenuOptions,
                        showDetailsPopup: self.displayTaskDetails
                    };

                    listOfTasks.push(task);
                });
                self.tasks(listOfTasks);
                self.taskListLoaded(true);
            });
        };

        self.loadTasks();
    }
    return ExecutionFrameworkTaskListViewModel;

});
