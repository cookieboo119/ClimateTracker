/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A  PARTICULAR
 * PURPOSE.
 */

/* 
 * GetFields - This class makes getfields request using the
 * market sector as criteria.
 */
package com.bloomberg.datalic.dlws;

import com.bloomberg.datalic.dlws.stubs.FieldInfo;
import com.bloomberg.datalic.dlws.stubs.FieldSearchCriteria;
import com.bloomberg.datalic.dlws.stubs.GetFieldsRequest;
import com.bloomberg.datalic.dlws.stubs.GetFieldsResponse;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;

public class GetFields {

    // NOTE: The programFlag argument is ignored for this sample
    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting the request parameters
            GetFieldsRequest getFieldsReq = new GetFieldsRequest();
            FieldSearchCriteria criteria = new FieldSearchCriteria();
            criteria.setKeyword("Price");
            criteria.getMarketsectors().add(MarketSector.fromValue("Equity"));
            getFieldsReq.setCriteria(criteria);

            // Send the request
            GetFieldsResponse getFieldsResp = ps.getFields(getFieldsReq);

            // Display response
            if (getFieldsResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("getfields request successful. Response is: ");
                for (FieldInfo fieldInfo : getFieldsResp.getFields().getField()) {
                    System.out.println("Mnemonic: " + fieldInfo.getMnemonic() + "\n  ID: "
                            + fieldInfo.getId() + "\n  Description: " + fieldInfo.getDescription()
                            + "\n  Definition: " + fieldInfo.getDefinition());
                }
            } else if (getFieldsResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}