/**
 * network profile module
 */

define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/navigation/pageNavigationHelper', 'ojs/ojarraydataprovider', 'ebs/utils/lovUtils', 'ojs/ojselectcombobox', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ebs/utils/compartmentsLov', 'ojs/ojinputtext', 'ojs/ojknockout-validation', 'ojs/ojmessages', 'ojs/ojarraydataprovider', 'ojs/ojswitch', 'ojs/ojselectsingle', "jet-composites/compartment-lov/loader"], 
function (oj, ko, actionsHelper, popupHelper, constants, pageNavigationHelper, ArrayDataProvider, lovUtils)
{
    /**
     * The view model for the network profile page.
     */
    function networkProfileViewModel()
    {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        console.log('Loading Network Profile Content View Model');
        self.messages = ko.observableArray([]);
        self.tenancyId = rootViewModel.tenancyOCID();
        self.errorsFound = false;
        // Read the resubmit flow from previous page.
        self.isEditFlow = ko.observable(false);
        self.isEditFlow(rootViewModel.updateNetworkProfileFlow());
        self.overrideWithUserValues = false;
        self.currentlyEditingNetworkProfile = rootViewModel.currentNetworkName();
        var NetworkProfileNameValidator = function ()
        {};
        oj.Object.createSubclass(NetworkProfileNameValidator, oj.Validator, "NetworkProfileNameValidator");
        self.networkProfileNameValidator = [new NetworkProfileNameValidator()];
        var NetworkProfileDescValidator = function () {};
        oj.Object.createSubclass(NetworkProfileDescValidator, oj.Validator, "NetworkProfileDescValidator");
        self.networkProfileDescValidator = [new NetworkProfileDescValidator()];
        /* Variables used in the functions */

        rootViewModel.currentPageHeader('Create Network Profile');
        self.listOfCompartments = ko.observable('');
        self.listOfVCNsAndSubnets = ko.observable('');
        var loadingOption = new Object();
        loadingOption.label = 'loading...';
        loadingOption.value = 'loading...';
        var loadingOptionList = new Array();
        loadingOptionList[0] = loadingOption;
        var emptyOption = new Object();
        emptyOption.label = '';
        emptyOption.value = '';
        var emptyOptionList = new Array();
        emptyOptionList[0] = emptyOption;
        self.availabilityDomainAndSubnetList = ko.observable('');
        var LOADING_OPTION = 'loading...';
        self.subnetValidationMsgForDBTierSubnet = ko.observable();
        self.subnetValidationMsgForAppTierSubnet = ko.observable();
        self.subnetValidationMsgForLoadBalancerSubnet = ko.observable();
        self.subnetValidationMsgForHALoadBalancerSubnet = ko.observable();
        self.subnetValidationMsgForAppTierSubnet_External = ko.observable();
        self.subnetValidationMsgForLoadBalancerSubnet_External = ko.observable();
        self.subnetValidationMsgForHALoadBalancerSubnet_External = ko.observable();
        self.vcnValidationMsg = ko.observable();
        self.adValidationMsg = ko.observable();
        self.subnetTypeValidationMsg = ko.observable();
        self.disableSubmitBtn = ko.observable(true);
        self.networkProfileDescEntered = ko.observable('');
        self.enteredSubnetType = '';
        self.enteredNetworkProfileName = '';
        self.enteredEBSCompartmentOCID = '';
        self.enteredNetworkCompartmentOCID = '';
        self.enteredVCNOCID = '';
        self.enteredAvailabilityDomainOCID = '';
        self.enteredDbTierSubnetOCID = '';
        self.enteredDBTierSubnetType = '';
        self.enteredAppTierSubnetType = '';
        self.enteredappTierSubnetOCID = '';
        self.enteredLbaasSubnetType = '';
        self.enteredLbaasSubnetOCID = '';
        self.enteredLbaasHASubnetOCID = '';
        self.existingNetworkProfileNames = new Array();
        self.externalZonesSupported = ko.observable(true);

        self.editFlowExternalZonePresent = false;
        self.enteredExternalAppTierSubnetType = '';
        self.enteredExternalAppTierSubnetOCID = '';
        self.enteredExternalLbaasSubnetType = '';
        self.enteredExternalLbaasSubnetOCID = '';
        self.enteredExternalLbaasHASubnetOCID = '';
        /* Input Details */
        self.networkProfileNameEntered = ko.observable('');
        if (self.isEditFlow())
        {
            self.networkProfileNameEntered('loading...');
            actionsHelper.getNetworkProfileDetails(self.currentlyEditingNetworkProfile, function (error, networkProfileDetail)
            {
                var nameOfNetworkProfile = networkProfileDetail.name;
                var desc = networkProfileDetail.description;
                var ebsCompartmentOCID = networkProfileDetail.ebsCompartmentOCID;
                var networkCompartmentOCID = networkProfileDetail.networkCompartmentOCID;
                var vcnOCID = networkProfileDetail.vcnOCID;
                var availabilityDomainOCID = networkProfileDetail.availabilityDomainOCID;
                var dbTierSubnetOCID = networkProfileDetail.dbTier.subnetOCID;
                var dbTierSubnetType = '';
                var isDbTierSubnetPvt = networkProfileDetail.dbTier.isPrivate;
                if (isDbTierSubnetPvt || isDbTierSubnetPvt === 'true')
                {
                    dbTierSubnetType = 'Private';
                } else
                {
                    dbTierSubnetType = 'Public';
                }

                var appTierSubnetOCID = networkProfileDetail.appTier.internal[0].subnetOCID;
                var appTierSubnetType = '';
                var isAppTierSubnetPvt = networkProfileDetail.appTier.internal[0].isPrivate;
                if (isAppTierSubnetPvt || isAppTierSubnetPvt === 'true')
                {
                    appTierSubnetType = 'Private';
                } else
                {
                    appTierSubnetType = 'Public';
                }

                var lbaasSubnetType = '';
                var isLbaasSubnetPvt = networkProfileDetail.lbaas.internal.isPrivate;
                if (isLbaasSubnetPvt || isLbaasSubnetPvt === 'true')
                {
                    lbaasSubnetType = 'Private';
                } else
                {
                    lbaasSubnetType = 'Public';
                }

                var lbaasSubnetOCID = networkProfileDetail.lbaas.internal.subnetOCID;
                var lbaasHASubnetOCID = networkProfileDetail.lbaas.internal.haSubnetOCID;
                var useRegionalSubTypeAttr = networkProfileDetail.useRegionalSubnets;
                if (typeof (useRegionalSubTypeAttr) === 'undefined' || useRegionalSubTypeAttr === null || !useRegionalSubTypeAttr)
                {
                    self.enteredSubnetType = constants.subnetType.AvailabilityDomainSpecific;
                } else
                {
                    self.enteredSubnetType = constants.subnetType.Regional;
                }



                self.enteredNetworkProfileName = nameOfNetworkProfile;
                self.enteredEBSCompartmentOCID = ebsCompartmentOCID;
                self.enteredNetworkCompartmentOCID = networkCompartmentOCID;
                self.enteredVCNOCID = vcnOCID;
                self.enteredAvailabilityDomainOCID = availabilityDomainOCID;
                self.enteredDbTierSubnetOCID = dbTierSubnetOCID;
                self.enteredDBTierSubnetType = dbTierSubnetType;
                self.enteredappTierSubnetOCID = appTierSubnetOCID;
                self.enteredAppTierSubnetType = appTierSubnetType;
                self.enteredLbaasSubnetType = lbaasSubnetType;
                self.enteredLbaasSubnetOCID = lbaasSubnetOCID;
                self.enteredLbaasHASubnetOCID = lbaasHASubnetOCID;
                self.networkProfileNameEntered(self.enteredNetworkProfileName);
                self.networkProfileDescEntered(desc);

                var externalAttr = networkProfileDetail.appTier.external;
                if (typeof (externalAttr) === 'undefined') {
                    self.editFlowExternalZonePresent = false;
                    self.externalZonesSupported(false);
                } else {
                    var externalNodePresent = externalAttr;
                    if (typeof (externalNodePresent) === 'undefined') {
                        self.editFlowExternalZonePresent = false;
                        self.externalZonesSupported(false);
                    } else {
                        self.editFlowExternalZonePresent = true;
                        self.externalZonesSupported(true);
                        var isExternalAppTierSubnetPvt = networkProfileDetail.appTier.external.isPrivate;
                        var externalAppTierSubnetType = '';
                        if (isExternalAppTierSubnetPvt || isExternalAppTierSubnetPvt === 'true')
                        {
                            externalAppTierSubnetType = 'Private';
                        } else
                        {
                            externalAppTierSubnetType = 'Public';
                        }

                        self.enteredExternalAppTierSubnetType = externalAppTierSubnetType;
                        self.enteredExternalAppTierSubnetOCID = networkProfileDetail.appTier.external.subnetOCID;
                        var externallbaasSubnetType = '';
                        var isLbaasSubnetPvt = networkProfileDetail.lbaas.external.isPrivate;
                        if (isLbaasSubnetPvt || isLbaasSubnetPvt === 'true')
                        {
                            externallbaasSubnetType = 'Private';
                        } else
                        {
                            externallbaasSubnetType = 'Public';
                        }
                        self.enteredExternalLbaasSubnetType = externallbaasSubnetType;
                        self.enteredExternalLbaasSubnetOCID = networkProfileDetail.lbaas.external.subnetOCID;
                        if(typeof (networkProfileDetail.lbaas.external.haSubnetOCID) !== 'undefined')
                          self.enteredExternalLbaasHASubnetOCID = networkProfileDetail.lbaas.external.haSubnetOCID;
                    }
                }

            });
        } else
        {

            actionsHelper.getNetworkProfiles("All", function (error, networkProfilesList)
            {
                for (var i = 0; i < networkProfilesList.length; i++)
                {
                    self.existingNetworkProfileNames.push(networkProfilesList[i].name);
                }
            });
        }
        self.selectedEBSCompartment = ko.observable('');
        self.EBSCompartmentList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.ebsCompartmentDataProvider = new ArrayDataProvider(self.EBSCompartmentList, {idAttribute: 'value'});
        lovUtils.lovOptionsUpdated(self.EBSCompartmentList(), self.selectedEBSCompartment);
        self.selectedNetworkCompartment = ko.observable('');
        self.NetworkCompartmentList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.networkCompartmentDataProvider = new ArrayDataProvider(self.NetworkCompartmentList, {idAttribute: 'value'});
        lovUtils.lovOptionsUpdated(self.NetworkCompartmentList(), self.selectedNetworkCompartment);
        self.VCNList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.vcnDataProvider = new ArrayDataProvider(self.VCNList, {idAttribute: 'value'});
        self.selectedVCN = ko.observable('');
        lovUtils.lovOptionsUpdated(self.VCNList(), self.selectedVCN);
        self.subnetTypeList = ko.observableArray([
            {
                'label': constants.subnetType.Regional,
                'value': constants.subnetType.Regional
            },
            {
                'label': constants.subnetType.AvailabilityDomainSpecific,
                'value': constants.subnetType.AvailabilityDomainSpecific
            }
        ]);
        self.subnetTypeDataProvider = new ArrayDataProvider(self.subnetTypeList, {idAttribute: 'value'});
        self.subnetTypeSelected = ko.observable('Regional');
        lovUtils.lovOptionsUpdated(self.subnetTypeList(), self.subnetTypeSelected);
        self.skipReadingEventInformation = false;
        self.availabilityDomainList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.availabilityDomainDataProvider = new ArrayDataProvider(self.availabilityDomainList, {idAttribute: 'value'});      
        self.selectedAvailabilityDomain = ko.observable('');
        lovUtils.lovOptionsUpdated(self.availabilityDomainList(), self.selectedAvailabilityDomain);
        /* Database Tier Details */
        self.dataBaseTierSubnetTypeList = ko.observableArray([
            {
                'label': 'Private',
                'value': 'Private'
            },
            {
                'label': 'Public',
                'value': 'Public'
            }]);
        self.dataBaseTierSubnetTypeDataProvider = new ArrayDataProvider(self.dataBaseTierSubnetTypeList, {idAttribute: 'value'});      
        self.selectedDataBaseTierSubnetType = ko.observable('');
        lovUtils.lovOptionsUpdated(self.dataBaseTierSubnetTypeList(), self.selectedDataBaseTierSubnetType);
        self.dataBaseTierSubnetList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.dataBaseTierSubnetDataProvider = new ArrayDataProvider(self.dataBaseTierSubnetList, {idAttribute: 'value'});      
        self.selectedDataBaseTierSubnet = ko.observable('');
        lovUtils.lovOptionsUpdated(self.dataBaseTierSubnetList(), self.selectedDataBaseTierSubnet);
        /* Application Tier Details */
        self.appTierSubnetTypeList = ko.observableArray([
            {
                'label': 'Private',
                'value': 'Private'
            },
            {
                'label': 'Public',
                'value': 'Public'
            }]);
        self.appTierSubnetTypeDataProvider = new ArrayDataProvider(self.appTierSubnetTypeList, {idAttribute: 'value'});      
        self.selectedAppTierSubnetType = ko.observable('');
        lovUtils.lovOptionsUpdated(self.appTierSubnetTypeList(), self.selectedAppTierSubnetType);
        self.appTierSubnetList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.appTierSubnetDataProvider = new ArrayDataProvider(self.appTierSubnetList, {idAttribute: 'value'});      
        self.selectedAppTierSubnet = ko.observable('');
        lovUtils.lovOptionsUpdated(self.appTierSubnetList(), self.selectedAppTierSubnet);
        self.loadBalancerSubnetTypeList = ko.observableArray([
            {
                'label': 'Public',
                'value': 'Public'
            },
            {
                'label': 'Private',
                'value': 'Private'
            }]);
        self.loadBalancerSubnetTypeDataProvider = new ArrayDataProvider(self.loadBalancerSubnetTypeList, {idAttribute: 'value'});      
        self.selectedloadBalancerSubnetType = ko.observable('');
        lovUtils.lovOptionsUpdated(self.loadBalancerSubnetTypeList(), self.selectedloadBalancerSubnetType);
        self.loadBalancerSubnetList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.loadBalancerSubnetDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList, {idAttribute: 'value'});      
        self.selectedloadBalancerSubnet = ko.observable('');
        lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList(), self.selectedloadBalancerSubnet);
        self.loadBalancerHASubnetList = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.loadBalancerHASubnetDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList, {idAttribute: 'value'});  
        self.selectedLoadBalancerHASubnet = ko.observable('');
        lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList(), self.selectedLoadBalancerHASubnet);
        self.appTierSubnetTypeList_External = ko.observableArray([
            {
                'label': 'Private',
                'value': 'Private'
            },
            {
                'label': 'Public',
                'value': 'Public'
            }]);
        self.appTierSubnetTypeExternalDataProvider = new ArrayDataProvider(self.appTierSubnetTypeList_External, {idAttribute: 'value'});              
        self.selectedAppTierSubnetType_External = ko.observable('');
        lovUtils.lovOptionsUpdated(self.appTierSubnetTypeList_External(), self.selectedAppTierSubnetType_External);
        
        self.appTierSubnetList_External = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});              
        self.selectedAppTierSubnet_External = ko.observable('');
        lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
        
        self.loadBalancerSubnetTypeList_External = ko.observableArray([
            {
                'label': 'Public',
                'value': 'Public'
            },
            {
                'label': 'Private',
                'value': 'Private'
            }]);
        self.loadBalancerSubnetTypeExternalDataProvider = new ArrayDataProvider(self.loadBalancerSubnetTypeList_External, {idAttribute: 'value'});              
        self.selectedloadBalancerSubnetType_External = ko.observable('');
        lovUtils.lovOptionsUpdated(self.loadBalancerSubnetTypeList_External(), self.selectedloadBalancerSubnetType_External);
        
        self.loadBalancerSubnetList_External = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.loadBalancerSubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList_External, {idAttribute: 'value'});            
        self.selectedloadBalancerSubnet_External = ko.observable('');
        lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList_External(), self.selectedloadBalancerSubnet_External);
        
        self.loadBalancerHASubnetList_External = ko.observableArray([
            {
                'label': 'loading...',
                'value': 'loading...'
            }]);
        self.loadBalancerHASubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList_External, {idAttribute: 'value'});              
        self.selectedLoadBalancerHASubnet_External = ko.observable('');
        lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList_External(), self.selectedLoadBalancerHASubnet_External);
        
        self.clearPageLevelMessages = function ()
        {
            self.messages([]);
        };
        self.waitForVCNList = function ()
        {

            self.vcnValidationMsg([]);
            self.selectedVCN('');
            self.adValidationMsg([]);
            self.disableSubmitBtn(true);
            self.clearPageLevelMessages();
            self.dataBaseTierSubnetList(loadingOptionList);
            self.dataBaseTierSubnetDataProvider = new ArrayDataProvider(self.dataBaseTierSubnetList, {idAttribute: 'value'});   
            lovUtils.lovOptionsUpdated(self.dataBaseTierSubnetList(), self.selectedDataBaseTierSubnet);
            self.appTierSubnetList(loadingOptionList);
            self.appTierSubnetDataProvider = new ArrayDataProvider(self.appTierSubnetList, {idAttribute: 'value'});   
            lovUtils.lovOptionsUpdated(self.appTierSubnetList(), self.selectedAppTierSubnet);
            self.loadBalancerSubnetList(loadingOptionList);
            self.loadBalancerSubnetDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList, {idAttribute: 'value'});  
            lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList(), self.selectedloadBalancerSubnet);
            self.loadBalancerHASubnetList(loadingOptionList);
            self.loadBalancerHASubnetDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList, {idAttribute: 'value'});  
            lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList(), self.selectedLoadBalancerHASubnet);
            self.availabilityDomainList(loadingOptionList);
            self.availabilityDomainDataProvider = new ArrayDataProvider(self.availabilityDomainList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.availabilityDomainList(), self.selectedAvailabilityDomain);
            self.VCNList(loadingOptionList);
            self.vcnDataProvider = new ArrayDataProvider(self.VCNList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.VCNList(), self.selectedVCN);
        };
        self.waitForAvailabilityDomainList = function ()
        {
            self.adValidationMsg([]);
            self.disableSubmitBtn(true);
            self.clearPageLevelMessages();
            self.dataBaseTierSubnetList(loadingOptionList);
            self.dataBaseTierSubnetDataProvider = new ArrayDataProvider(self.dataBaseTierSubnetList, {idAttribute: 'value'});  
            lovUtils.lovOptionsUpdated(self.dataBaseTierSubnetList(), self.selectedDataBaseTierSubnet);
            self.appTierSubnetList(loadingOptionList);
            self.appTierSubnetDataProvider = new ArrayDataProvider(self.appTierSubnetList, {idAttribute: 'value'});   
            lovUtils.lovOptionsUpdated(self.appTierSubnetList(), self.selectedAppTierSubnet);
            self.loadBalancerSubnetList(loadingOptionList);
            self.loadBalancerSubnetDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList, {idAttribute: 'value'});    
            lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList(), self.selectedloadBalancerSubnet);
            self.loadBalancerHASubnetList(loadingOptionList);
            self.loadBalancerHASubnetDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList, {idAttribute: 'value'});  
            lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList(), self.selectedLoadBalancerHASubnet);
            self.availabilityDomainList(loadingOptionList);
            self.availabilityDomainDataProvider = new ArrayDataProvider(self.availabilityDomainList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.availabilityDomainList(), self.selectedAvailabilityDomain);
        };
        self.addPageLevelMessage = function (messageSeverity, messageSummary, messageDetail)
        {
            var newPageMessageObject = new Object();
            newPageMessageObject.severity = messageSeverity;
            newPageMessageObject.summary = messageSummary;
            newPageMessageObject.detail = messageDetail;
            var tempArray = self.messages();
            tempArray.push(newPageMessageObject);
            self.messages(tempArray);
        };
        self.populateEBSCompartmentList = function ()
        {
            if (self.overrideWithUserValues && !self.errorsFound)
            {
                var newList = self.sortListWithUserValueOnTop(self.listOfCompartments(), self.enteredEBSCompartmentOCID, 'EBS Compartment');
                self.EBSCompartmentList(newList);
            } else
            {
                self.EBSCompartmentList(self.listOfCompartments());
            }
            self.ebsCompartmentDataProvider = new ArrayDataProvider(self.EBSCompartmentList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.EBSCompartmentList(), self.selectedEBSCompartment);
        };
        self.sortListWithUserValueOnTop = function (listElement, userValue, componentName)
        {
            var length = listElement.length;
            if (length < 2)
            {
                return listElement;
            } else
            {
                for (var i = 0; i < listElement.length; i++)
                {
                    var currentValue = listElement[i].value;
                    var currentElement = listElement[i];
                    if (currentValue === userValue)
                    {
                        listElement.splice(i, 1);
                        listElement.splice(0, 0, currentElement);
                        return listElement;
                    }
                }

                var messageContent = oj.Translations.getTranslatedString("warningOrConfirmationMsgs.ociResourceWarning", {'userValue': userValue, 'componentName': componentName});
                self.addPageLevelMessage('warning', 'Resource not available', messageContent);
                self.errorsFound = true;
            }
            return listElement;
        };
        self.populateNetworkCompartmentList = function ()
        {

            if (self.overrideWithUserValues && !self.errorsFound)
            {
                var newNetworkCompartmentList = self.sortListWithUserValueOnTop(self.listOfCompartments(), self.enteredNetworkCompartmentOCID, 'Network Compartment');
                self.NetworkCompartmentList(newNetworkCompartmentList);
            } else
            {
                self.NetworkCompartmentList(self.listOfCompartments());
            }
            self.networkCompartmentDataProvider = new ArrayDataProvider(self.NetworkCompartmentList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.NetworkCompartmentList(), self.selectedNetworkCompartment);
        };
        self.handleSubnetTypeChangeListener = function (event)
        {
            if (self.overrideWithUserValues)
            {
                return;
            }
            self.skipReadingEventInformation = true;
            self.handleLoadbalancerHASubnetRegion();
            self.handleLoadbalancerHASubnetRegion(true);
            self.handleVCNOptionChange(event);
            self.skipReadingEventInformation = false;
        };
        self.handleNetworkCompartmentOptionChange = function (event)
        {


            var compartmentNameSelected = null;
            if (typeof (event) !== 'undefined')
            {
                compartmentNameSelected = event['detail'].value;
            } else
            {
                compartmentNameSelected = self.selectedNetworkCompartment();
            }
            if (compartmentNameSelected === null || compartmentNameSelected === LOADING_OPTION)
            {
                return;
            }
            // Trigger a REST call to fetch the VCN's under the compartment and then set the variable listOfVCNsAndSubnets.
            self.waitForVCNList();
            actionsHelper.getVCNListUnderCompartment(compartmentNameSelected, function (error, vcnList)
            {
                var isEmpty = self.handleEmptyVCNList(vcnList, compartmentNameSelected);
                if (isEmpty)
                {
                    return;
                }
                if (error !== null && error !== '')

                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelMessage('error', 'Error in fetching virtual cloud networks', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelMessage('error', 'Error in fetching virtual cloud networks', messageContent);
                    }
                    self.disableSubmitBtn(true);
                } else
                {
                    // call the populate VCN List.
                    self.populateVCNList(vcnList);
                    self.disableSubmitBtn(true);
                }

            });
        };
        self.populateVCNList = function (vcnListFromServer)
        {
            // After compartment change triggered the REST call and we get all VCN under the compartment populate VCN List.
            if (self.overrideWithUserValues && !self.errorsFound)
            {
                var newList = self.sortListWithUserValueOnTop(vcnListFromServer, self.enteredVCNOCID, VCN);
                self.VCNList(newList);
                // Populate the DB , App and Lbaas subnet type here.
                self.selectedDataBaseTierSubnetType(self.enteredDBTierSubnetType);
                self.selectedAppTierSubnetType(self.enteredAppTierSubnetType);
                self.selectedloadBalancerSubnetType(self.enteredLbaasSubnetType);
                if (self.editFlowExternalZonePresent) {
                    self.selectedAppTierSubnet_External(self.enteredExternalAppTierSubnetType);
                    self.selectedloadBalancerSubnetType_External(self.enteredExternalLbaasSubnetType);
                }
            } else
            {
                self.VCNList(vcnListFromServer);
            }
            self.vcnDataProvider = new ArrayDataProvider(self.VCNList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.VCNList(), self.selectedVCN);
        };
        self.handleVCNOptionChange = function (event)
        {


            var compartmentNameSelected = self.selectedNetworkCompartment();
            var vcnNameSelected = null;
            if (typeof (event) !== 'undefined' && !self.skipReadingEventInformation)
            {
                vcnNameSelected = event['detail'].value;
            } else
            {
                vcnNameSelected = self.selectedVCN();
            }

            /* Specifically handle the case when intermediately form waitForVCN() we get into this call.
             * This is identified by event and the target = VCN and then selected VCN Value is set to ''.
             */
            if ((typeof (event) !== 'undefined' && event.target !== null && event.target.id === 'VCN' && self.selectedVCN() === "") || vcnNameSelected === null || compartmentNameSelected === null || compartmentNameSelected === LOADING_OPTION || vcnNameSelected === LOADING_OPTION)
            {

                return;
            }

            // Trigger a REST call to fetch the AD's under the compartment / VCN and then set the variable listOfAD's.
            self.waitForAvailabilityDomainList();
            var selectedSubnetType = self.subnetTypeSelected();
            actionsHelper.getAvailabilityDomainListUnderCompartmentAndVCN(compartmentNameSelected, vcnNameSelected, selectedSubnetType, function (error, adList)
            {

                var isEmpty = self.handleEmptyADList(adList, compartmentNameSelected, vcnNameSelected);
                if (isEmpty)
                {
                    return;
                }
                if (error !== null && error !== '')
                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelMessage('error', 'Error in fetching availability domains', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelMessage('error', 'Error in fetching availability domains', messageContent);
                    }
                    self.disableSubmitBtn(true);
                } else
                {
                    // call the populate AD List.
                    self.populateAvailabilityDomainList(adList);
                    self.availabilityDomainAndSubnetList(adList);
                    self.disableSubmitBtn(false);
                    self.handleLoadbalancerHASubnetRegion();
                    self.handleLoadbalancerHASubnetRegion(true);
                }
            });
        };
        // Return true if AD is single
        isSingleAD = function () {
            var len = (null === self.availabilityDomainAndSubnetList()) ? 0 : self.availabilityDomainAndSubnetList().length;
            if (len === 1) {
                return true;
            } else {
                return false;
            }
        };
        self.displayLoadBalancerHASubnetRegion = ko.observable(false);
        self.displayLoadBalancerHASubnetRegion_External = ko.observable(false);
        // Return lb HA subnet type
        getLbHASubnetType = function (isExternalAppTier)
        {
            var isExternalTier = typeof (isExternalAppTier) !== 'undefined' && isExternalAppTier;
            if (isExternalTier)
            {
                if (document.getElementById('LoadBalancerSubnetType_External') === null)
                {
                    return "Public";
                } else
                {
                    return document.getElementById('LoadBalancerSubnetType_External').value;
                }
            } else
            {
                return document.getElementById('LoadBalancerSubnetType').value;
            }
        };
        /*
         * 1. If single availability domain then return true else return false
         * 2. If LoadBalancerSubnetType is private then return false
         * 3. If LoadBalancerSubnetType is public and multi AD then return true
         */
        self.handleLoadbalancerHASubnetRegion = function (isExternalAppTier)
        {
            var isExternal = typeof (isExternalAppTier) !== 'undefined' && isExternalAppTier;
            var displayLoadBalancerHASubnet = true;
            var subnetTypeSelected = self.subnetTypeSelected();
            // For single AD and lb HA type
            if (isExternal)
            {
                if (isSingleAD() === true || getLbHASubnetType(isExternalAppTier) === 'Private' || subnetTypeSelected === constants.subnetType.Regional)
                {
                    displayLoadBalancerHASubnet = false;
                }
            } else
            {
                if (isSingleAD() === true || getLbHASubnetType(isExternalAppTier) === 'Private' || subnetTypeSelected === constants.subnetType.Regional)
                {
                    displayLoadBalancerHASubnet = false;
                }
            }
            console.log('load balancer ha display : ' + displayLoadBalancerHASubnet);
            if (isExternal)
            {
                self.displayLoadBalancerHASubnetRegion_External(displayLoadBalancerHASubnet);
            } else
            {
                self.displayLoadBalancerHASubnetRegion(displayLoadBalancerHASubnet);
            }
        };
        self.handleEmptyVCNList = function (vcnList, compartmentName)
        {
            if (vcnList === null || vcnList.length < 1)
            {
                var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.vcnUnavailable", {compartmentName: compartmentName});
                var validationCustomMsg = {summary: translatedMsg,
                    detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                self.VCNList(emptyOptionList);
                self.vcnDataProvider = new ArrayDataProvider(self.VCNList, {idAttribute: 'value'});
                self.selectedVCN('');
                self.vcnValidationMsg([validationCustomMsg]);
                self.availabilityDomainList(emptyOptionList);
                self.availabilityDomainDataProvider = new ArrayDataProvider(self.availabilityDomainList, {idAttribute: 'value'});
                self.selectedAvailabilityDomain('');
                return true;
            }
            return false;
        };
        self.handleEmptyADList = function (adList, vcnName, compartmentName)
        {

            if (adList === null || adList.length < 1)
            {
                var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.adsubnetUnavailable", {vcnName: vcnName, compartmentName: compartmentName});
                var validationCustomMsg = {summary: translatedMsg,
                    detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                self.availabilityDomainList(emptyOptionList);
                self.availabilityDomainDataProvider = new ArrayDataProvider(self.availabilityDomainList, {idAttribute: 'value'});
                self.selectedAvailabilityDomain('');
                self.adValidationMsg([validationCustomMsg]);
                return true;
            }
            return false;
        };
        self.populateAvailabilityDomainList = function (availabilityDomainListFromServer)
        {
            // After VCN change triggered the REST call and we get all AD/Subnets under the compartment / VCN.
            if (self.overrideWithUserValues && !self.errorsFound)
            {
                var newList = self.sortListWithUserValueOnTop(availabilityDomainListFromServer, self.enteredAvailabilityDomainOCID, 'Availability Domain');
                self.availabilityDomainList(newList);
            } else
            {
                self.availabilityDomainList(availabilityDomainListFromServer);
            }
            self.availabilityDomainDataProvider = new ArrayDataProvider(self.availabilityDomainList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.availabilityDomainList(), self.selectedAvailabilityDomain);
            self.disableSubmitBtn(false);
        };
        self.handleAvailabilityDomainOptionChange = function (event)
        {

            // Trigger DB, App and LB subnets list population.
            self.populateDBTierSubnets(event);
            self.populateAppTierSubnets(event);
            self.populateAppTierSubnets(event, true);
            self.populateLoadBalancerTierSubnets(event);
            self.populateLoadBalancerTierSubnets(event, true);
            var adValueSelected = (event !== null && event["detail"] !== null) ? event["detail"].value : null;
            var isValidADValue = adValueSelected !== null && adValueSelected !== LOADING_OPTION;
            if (isValidADValue)
            {
                self.overrideWithUserValues = false;
            }
        };
        NetworkProfileNameValidator.prototype.validate = function (value)
        {
            var list = self.existingNetworkProfileNames;
            var uniqueNtwkProfileNameErrorMsg = oj.Translations.getTranslatedString('validationMsgs.uniqueNetworkProfileNameMdg');
            var ntwkProfileNameErrorMsg = oj.Translations.getTranslatedString('validationMsgs.networkProfileNameValidationMsg');
            if (list === null || list.length < 1)
            {
                var regularExp = new RegExp("^([a-zA-Z0-9_]{1,100})$");
                if (regularExp.test(value))
                {
                    return true;
                } else
                {
                    throw new Error(ntwkProfileNameErrorMsg);
                }
            } else
            {
                // Checking entered network profile name exist in the already network list
                // If -1, value doesnot exist. Else index will return the position.
                if (list.indexOf(value) > -1) {
                    throw new Error(uniqueNtwkProfileNameErrorMsg);
                } else
                {
                    var regularExp = new RegExp("^([a-zA-Z0-9_]{1,100})$");
                    if (regularExp.test(value))
                    {
                        return true;
                    } else
                    {
                        throw new Error(ntwkProfileNameErrorMsg);
                    }
                }
            }
            return true;
        };
        NetworkProfileDescValidator.prototype.validate = function (value) {
            if (null !== value && value.length > 255) {
                throw new Error(oj.Translations.getTranslatedString('validationMsgs.networkProfileDescValidationMsg'));
            }
        };
        self.populateDBTierSubnets = function (event)
        {
            // Populate subnet and back up subnet based on selected VCN, selected AD and based on private/public subnet selection.
            var dbTierSubnetType = null;
            var adNameSelected = null;
            var eventTargetElement = event.target.id;
            if (eventTargetElement === null || eventTargetElement === '')
            {
                return;
            }

            if (typeof (event) !== 'undefined' && eventTargetElement === 'AD')
            {
                adNameSelected = event['detail'].value;
            } else
            {
                adNameSelected = self.selectedAvailabilityDomain();
            }

            if (typeof (event) !== 'undefined' && eventTargetElement === 'DBTierSubnetType')
            {
                dbTierSubnetType = event['detail'].value;
            } else
            {
                dbTierSubnetType = self.selectedDataBaseTierSubnetType();
            }


            if (adNameSelected === null || adNameSelected === null || adNameSelected === LOADING_OPTION)
            {

                self.dataBaseTierSubnetList(loadingOptionList);
                self.dataBaseTierSubnetDataProvider = new ArrayDataProvider(self.dataBaseTierSubnetList, {idAttribute: 'value'});      
                lovUtils.lovOptionsUpdated(self.dataBaseTierSubnetList(), self.selectedDataBaseTierSubnet);
                return;
            }



            var listOfSubnetsUnderSelectedAD = null;
            for (var i = 0; i < self.availabilityDomainAndSubnetList().length; i++)
            {
                var currentAdName = self.availabilityDomainAndSubnetList()[i].value;
                if (currentAdName === adNameSelected)
                {
                    listOfSubnetsUnderSelectedAD = self.availabilityDomainAndSubnetList()[i].subnets;
                    break;
                }
            }

            var listOfDBTierSubnets = new Array();
            var isDBTierSubnetTypePrivate = dbTierSubnetType === 'Private' ? true : false;
            if (listOfSubnetsUnderSelectedAD !== null)
            {
                for (var j = 0; j < listOfSubnetsUnderSelectedAD.length; j++)
                {
                    var currentSubnet = listOfSubnetsUnderSelectedAD[j];
                    var currentSubnetType = currentSubnet.isPrivate;
                    if (currentSubnetType === isDBTierSubnetTypePrivate)
                    {
                        listOfDBTierSubnets.push(currentSubnet);
                    }
                }
            }
            if (listOfDBTierSubnets === null || listOfDBTierSubnets.length === 0)
            {
                self.dataBaseTierSubnetList(emptyOptionList);
                self.dataBaseTierSubnetDataProvider = new ArrayDataProvider(self.dataBaseTierSubnetList, {idAttribute: 'value'});    
                lovUtils.lovOptionsUpdated(self.dataBaseTierSubnetList(), self.selectedDataBaseTierSubnet);
                var adLabel = self.getDisplayNameForLOV('availabilityDomain', 'name');
                if (dbTierSubnetType === 'Private')
                {
                    var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.privateSubnetsUnavailable", {name: adLabel});
                    var validationCustomMsg = {summary: translatedMsg,
                        detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                } else
                {
                    var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.publicSubnetsUnavailable", {name: adLabel});
                    var validationCustomMsg = {summary: translatedMsg,
                        detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                }
                self.subnetValidationMsgForDBTierSubnet([validationCustomMsg]);
            } else
            {
                if (self.overrideWithUserValues && !self.errorsFound)
                {
                    var newList = self.sortListWithUserValueOnTop(listOfDBTierSubnets, self.enteredDbTierSubnetOCID, 'DB Tier Subnet');
                    self.dataBaseTierSubnetList(newList);
                } else
                {
                    self.dataBaseTierSubnetList(listOfDBTierSubnets);
                }
                self.dataBaseTierSubnetDataProvider = new ArrayDataProvider(self.dataBaseTierSubnetList, {idAttribute: 'value'});      
                lovUtils.lovOptionsUpdated(self.dataBaseTierSubnetList(), self.selectedDataBaseTierSubnet);
            }


        };
        self.handleDBTierSubnetTypeChangeEvent = function (event)
        {
            // Trigger populate DB Tier Subnets.
            if (self.overrideWithUserValues)
            {
                return;
            }
            self.populateDBTierSubnets(event);
        };
        self.populateAppTierSubnets = function (event, isForExternalZone)
        {
            // Populate subnet based on selected VCN, selected AD and based on private/public subnet selection.

            console.log('Populating App Tier Subnet List : Is External ' + isForExternalZone);

            var appTierSubnetType = null;
            var adNameSelected = null;
            var isExternalZone = typeof (isForExternalZone) !== 'undefined' && isForExternalZone;
            var eventTargetElement = event.target.id;
            if (eventTargetElement === null || eventTargetElement === '')
            {
                return;
            }

            if (typeof (event) !== 'undefined' && eventTargetElement === 'AD')
            {
                adNameSelected = event['detail'].value;
            } else
            {
                adNameSelected = self.selectedAvailabilityDomain();
            }

            console.log('AD Name Selected :' + adNameSelected);

            if (isExternalZone)
            {
                if (typeof (event) !== 'undefined' && eventTargetElement === 'AppTierSubnetType_External')
                {
                    appTierSubnetType = event['detail'].value;
                } else
                {
                    appTierSubnetType = self.selectedAppTierSubnetType_External();
                }
            } else
            {

                if (typeof (event) !== 'undefined' && eventTargetElement === 'AppTierSubnetType')
                {
                    appTierSubnetType = event['detail'].value;
                } else
                {
                    appTierSubnetType = self.selectedAppTierSubnetType();
                }
            }


            if (adNameSelected === null || adNameSelected === null || adNameSelected === LOADING_OPTION)
            {
                if (isExternalZone)
                {
                    console.log('List :' + loadingOptionList);
                    self.appTierSubnetList_External(loadingOptionList);
                    self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});   
                    lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
                } else
                {
                    console.log('List :' + loadingOptionList);
                    self.appTierSubnetList(loadingOptionList);
                    self.appTierSubnetDataProvider = new ArrayDataProvider(self.appTierSubnetList, {idAttribute: 'value'});  
                    lovUtils.lovOptionsUpdated(self.appTierSubnetList(), self.selectedAppTierSubnet);
                }
                return;
            }



            var listOfSubnetsUnderSelectedAD = null;
            for (var i = 0; i < self.availabilityDomainAndSubnetList().length; i++)
            {
                var currentAdName = self.availabilityDomainAndSubnetList()[i].value;
                if (currentAdName === adNameSelected)
                {
                    listOfSubnetsUnderSelectedAD = self.availabilityDomainAndSubnetList()[i].subnets;
                    console.log('List of Subnets under selected AD : ' + listOfSubnetsUnderSelectedAD);
                    break;
                }
            }

            var listOfAppTierSubnets = new Array();
            var isAppTierSubnetTypePrivate = appTierSubnetType === 'Private' ? true : false;
            console.log('Is App Tier Subnet Type Private :' + isAppTierSubnetTypePrivate);
            if (listOfSubnetsUnderSelectedAD !== null)
            {
                for (var j = 0; j < listOfSubnetsUnderSelectedAD.length; j++)
                {
                    var currentSubnet = listOfSubnetsUnderSelectedAD[j];
                    var currentSubnetType = currentSubnet.isPrivate;
                    if (currentSubnetType === isAppTierSubnetTypePrivate)
                    {
                        listOfAppTierSubnets.push(currentSubnet);
                    }
                }
            }
            if (listOfAppTierSubnets === null || listOfAppTierSubnets.length === 0)
            {
                if (isExternalZone)
                {
                    console.log('List :' + emptyOptionList);
                    self.appTierSubnetList_External(emptyOptionList);
                    self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});  
                    lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
                } else
                {
                    console.log('List :' + emptyOptionList);
                    self.appTierSubnetList(emptyOptionList);
                    self.appTierSubnetDataProvider = new ArrayDataProvider(self.appTierSubnetList, {idAttribute: 'value'});   
                    lovUtils.lovOptionsUpdated(self.appTierSubnetList(), self.selectedAppTierSubnet);
                }

                var adLabel = self.getDisplayNameForLOV('availabilityDomain', 'name');
                if (appTierSubnetType === 'Private')
                {
                    var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.privateSubnetsUnavailable", {name: adLabel});
                    var validationCustomMsg = {summary: translatedMsg,
                        detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                } else
                {
                    var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.publicSubnetsUnavailable", {name: adLabel});
                    var validationCustomMsg = {summary: translatedMsg,
                        detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                }
                if (isExternalZone)
                {
                    self.subnetValidationMsgForAppTierSubnet_External([validationCustomMsg]);
                } else
                {
                    self.subnetValidationMsgForAppTierSubnet([validationCustomMsg]);
                }
            } else
            {

                if (self.overrideWithUserValues && !self.errorsFound)
                {
                    var newList = self.sortListWithUserValueOnTop(listOfAppTierSubnets, self.enteredappTierSubnetOCID, 'App Tier Subnet');
                    console.log('List :' + newList);
                    self.appTierSubnetList(newList);
                    self.appTierSubnetDataProvider = new ArrayDataProvider(self.appTierSubnetList, {idAttribute: 'value'});  
                    lovUtils.lovOptionsUpdated(self.appTierSubnetList(), self.selectedAppTierSubnet);
                    /* If External zone is present, then load that data, else load default data because external Zone is optional */
                    if (self.editFlowExternalZonePresent) {
                        var newExternalList = self.sortListWithUserValueOnTop(listOfAppTierSubnets, self.enteredExternalAppTierSubnetOCID, 'External App Tier Subnet');
                        self.appTierSubnetList_External(newExternalList);
                        self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});     
                        lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
                        console.log('List :' + newExternalList);
                    } else {
                        console.log('List :' + listOfAppTierSubnets);
                        self.appTierSubnetList_External(listOfAppTierSubnets);
                        self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});   
                        lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
                    }

                } else
                {
                    if (isExternalZone)
                    {
                        self.subnetValidationMsgForAppTierSubnet_External([]);
                        console.log('List :' + listOfAppTierSubnets);
                        self.appTierSubnetList_External(listOfAppTierSubnets);
                        self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});  
                        lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
                    } else
                    {
                        self.appTierSubnetList(listOfAppTierSubnets);
                        self.appTierSubnetDataProvider = new ArrayDataProvider(self.appTierSubnetList, {idAttribute: 'value'});     
                        lovUtils.lovOptionsUpdated(self.appTierSubnetList(), self.selectedAppTierSubnet);
                        console.log('List :' + listOfAppTierSubnets);
                    }
                }
            }
            console.log('/Done populating app tier subnets');
        };
        
        /*
         * Due to Bug 32085134 - R.TST20.2.1: NOT ABLE TO CREATE NETWORK PROFILE 
         * Below method is not called now.
         * 
         * This is called on change of internal zone App Nodes Subnet
         * This will remove the selected app node subnet of internal zone and prepare list for external
         * 
         * Requirement : constraint user from selecting the same subnet for both internal & external network.
         * 
         */
        self.handleSubnetTypeChangeEvent = function (event) {
            var internalAppNodeSubnetSelected = event['detail'].value;
            self.listOfAppTierSubnetsExcludingInternal = new Array();
            for (var i = 0; i < self.appTierSubnetList().length; i++) {
                var currentSubnetName = self.appTierSubnetList()[i].value;
                if (currentSubnetName === internalAppNodeSubnetSelected) {
                    if(internalAppNodeSubnetSelected === LOADING_OPTION){
                        self.subnetValidationMsgForAppTierSubnet_External([]);
                        return;
                    }
                    continue;
                } else {
                    self.listOfAppTierSubnetsExcludingInternal.push(self.appTierSubnetList()[i]);
                }
            }
            self.appTierSubnetList_External(self.listOfAppTierSubnetsExcludingInternal);
            self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});  
            lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
            if (self.listOfAppTierSubnetsExcludingInternal.length === 0) {
                var adLabel = self.getDisplayNameForLOV('availabilityDomain', 'name');
                var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.privateSubnetsUnavailable", {name: adLabel});
                var validationCustomMsg = {summary: translatedMsg,
                    detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                self.appTierSubnetList_External(emptyOptionList);
                self.appTierSubnetExternalDataProvider = new ArrayDataProvider(self.appTierSubnetList_External, {idAttribute: 'value'});      
                lovUtils.lovOptionsUpdated(self.appTierSubnetList_External(), self.selectedAppTierSubnet_External);
                self.subnetValidationMsgForAppTierSubnet_External([validationCustomMsg]);
            }
        };
        
        self.handleAppTierSubnetTypeChangeEvent = function (event)
        {
            // Trigger populate App Tier subnets.
            if (self.overrideWithUserValues)
            {
                return;
            }
            self.populateAppTierSubnets(event);
        };
        self.handleAppTierSubnetTypeChangeEvent_External = function (event)
        {
            // Trigger populate App Tier subnets.
            if (self.overrideWithUserValues)
            {
                return;
            }
            self.populateAppTierSubnets(event, true);
        };
        self.populateLoadBalancerTierSubnets = function (event, isExternalAppTier)
        {
            console.log('Populating Load Balancer Tier Subnets. Is External App Tier : ' + isExternalAppTier);
            // Populate subnet and HA subnet based on selected VCN, selected AD and based on private/public subnet selection.
            // For HA load balancer list, filter all subnets that are private/public(based on selection) under an AD that is different from the selected AD on the top.
            // Populate subnet based on selected VCN, selected AD and based on private/public subnet selection.
            var isExternal = typeof (isExternalAppTier) !== 'undefined' && isExternalAppTier;
            var loadBalancerSubnetType = null;
            var adNameSelected = null;
            var eventTargetElement = event.target.id;
            if (eventTargetElement === null || eventTargetElement === '')
            {
                return;
            }

            if (isExternal)
            {
                self.subnetValidationMsgForHALoadBalancerSubnet_External([]);
            } else
            {
                self.subnetValidationMsgForHALoadBalancerSubnet([]);
            }

            if (typeof (event) !== 'undefined' && eventTargetElement === 'AD')
            {
                adNameSelected = event['detail'].value;
            } else
            {
                adNameSelected = self.selectedAvailabilityDomain();
            }

            console.log('AD Name Selected :' + adNameSelected);

            if (isExternal)
            {

                if (typeof (event) !== 'undefined' && eventTargetElement === 'LoadBalancerSubnetType_External')
                {
                    loadBalancerSubnetType = event['detail'].value;
                    // Tried to set selectedloadBalancerSubnetType here as its always giving old value
                    // Need to review with Guru
                    // self.selectedloadBalancerSubnetType(loadBalancerSubnetType);
                } else
                {
                    loadBalancerSubnetType = self.selectedloadBalancerSubnetType_External();
                }
            } else
            {
                if (typeof (event) !== 'undefined' && eventTargetElement === 'LoadBalancerSubnetType')
                {
                    loadBalancerSubnetType = event['detail'].value;
                    // Tried to set selectedloadBalancerSubnetType here as its always giving old value
                    // Need to review with Guru
                    // self.selectedloadBalancerSubnetType(loadBalancerSubnetType);
                } else
                {
                    loadBalancerSubnetType = self.selectedloadBalancerSubnetType();
                }
            }

            if (adNameSelected === null || adNameSelected === null || adNameSelected === LOADING_OPTION)
            {
                if (isExternal)
                {
                    console.log('Load Balancer1 Subnet List : ' + loadingOptionList);
                    self.subnetValidationMsgForLoadBalancerSubnet_External([]);
                    self.loadBalancerSubnetList_External(loadingOptionList);
                    self.loadBalancerSubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList_External, {idAttribute: 'value'});    
                    lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList_External(), self.selectedloadBalancerSubnet_External);
        
                    self.loadBalancerHASubnetList_External(loadingOptionList);
                    self.loadBalancerHASubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList_External, {idAttribute: 'value'});  
                    lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList_External(), self.selectedLoadBalancerHASubnet_External);
                } else
                {
                    console.log('Load Balancer1 Subnet List : ' + loadingOptionList);
                    self.loadBalancerSubnetList(loadingOptionList);
                    self.loadBalancerSubnetDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList, {idAttribute: 'value'});   
                    lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList(), self.selectedloadBalancerSubnet);
                    self.loadBalancerHASubnetList(loadingOptionList);
                    self.loadBalancerHASubnetDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList, {idAttribute: 'value'});    
                    lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList(), self.selectedLoadBalancerHASubnet);
                }
                return;
            }


            /* This is for Load Balancer 1 */
            var listOfSubnetsUnderSelectedAD = null;
            for (var i = 0; i < self.availabilityDomainAndSubnetList().length; i++)
            {
                var currentAdName = self.availabilityDomainAndSubnetList()[i].value;
                if (currentAdName === adNameSelected)
                {
                    listOfSubnetsUnderSelectedAD = self.availabilityDomainAndSubnetList()[i].subnets;
                    break;
                }
            }
            var listOfLoadBalancerSubnets = new Array();
            var isLoadBalancerSubnetTypePrivate = loadBalancerSubnetType === 'Private' ? true : false;
            if (listOfSubnetsUnderSelectedAD !== null)
            {
                for (var j = 0; j < listOfSubnetsUnderSelectedAD.length; j++)
                {
                    var currentSubnet = listOfSubnetsUnderSelectedAD[j];
                    var currentSubnetType = currentSubnet.isPrivate;
                    if (currentSubnetType === isLoadBalancerSubnetTypePrivate)
                    {
                        listOfLoadBalancerSubnets.push(currentSubnet);
                    }
                }
            }

            console.log('List of Load Balancer Subnets : ' + listOfLoadBalancerSubnets);
            if (listOfLoadBalancerSubnets === null || listOfLoadBalancerSubnets.length === 0)
            {
                if (isExternal) {
                    console.log('Load Balancer1 Subnet List : ' + emptyOptionList);
                    self.loadBalancerSubnetList_External(emptyOptionList);
                    self.loadBalancerSubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList_External, {idAttribute: 'value'});    
                    lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList_External(), self.selectedloadBalancerSubnet_External);
        
                } else {
                    console.log('Load Balancer1 Subnet List : ' + emptyOptionList);
                    self.loadBalancerSubnetList(emptyOptionList);
                    self.loadBalancerSubnetDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList, {idAttribute: 'value'});  
                    lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList(), self.selectedloadBalancerSubnet);
                }
                var adLabel = self.getDisplayNameForLOV('availabilityDomain', 'name');
                if (loadBalancerSubnetType === 'Private')
                {
                    var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.privateSubnetsUnavailable", {name: adLabel});
                    var validationCustomMsg = {summary: translatedMsg,
                        detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                } else
                {
                    var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.publicSubnetsUnavailable", {name: adLabel});
                    var validationCustomMsg = {summary: translatedMsg,
                        detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                }
                if (isExternal)
                    self.subnetValidationMsgForLoadBalancerSubnet_External([validationCustomMsg]);
                else
                    self.subnetValidationMsgForLoadBalancerSubnet([validationCustomMsg]);
            } else
            {

                if (self.overrideWithUserValues && !self.errorsFound)
                {
                    var newList = self.sortListWithUserValueOnTop(listOfLoadBalancerSubnets, self.enteredLbaasSubnetOCID, 'Load balancer subnet');
                    self.loadBalancerSubnetList(newList);
                    self.loadBalancerSubnetDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList, {idAttribute: 'value'}); 
                    lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList(), self.selectedloadBalancerSubnet);
                    console.log('Load Balancer1 Subnet List : ' + newList);
                    /* If External zone is present, then load that data, else load default data because external Zone is optional */
                    if (self.editFlowExternalZonePresent) {
                        var newExternalList = self.sortListWithUserValueOnTop(listOfLoadBalancerSubnets, self.enteredExternalLbaasSubnetOCID, 'External Load Balancer Subnet');
                        self.loadBalancerSubnetList_External(newExternalList);
                        self.loadBalancerSubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList_External, {idAttribute: 'value'});      
                        console.log('List :' + newExternalList);
                    } else {
                        console.log('List :' + listOfLoadBalancerSubnets);
                        self.loadBalancerSubnetList_External(listOfLoadBalancerSubnets);
                        self.loadBalancerSubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList_External, {idAttribute: 'value'}); 
                        lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList_External(), self.selectedloadBalancerSubnet_External);
                    }
                    
                } else
                {
                    if (isExternal)
                    {
                        console.log('Load Balancer1 Subnet List : ' + listOfLoadBalancerSubnets);
                        self.loadBalancerSubnetList_External(listOfLoadBalancerSubnets);
                        self.loadBalancerSubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList_External, {idAttribute: 'value'});      
                        lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList_External(), self.selectedloadBalancerSubnet_External);
                    } else
                    {
                        console.log('Load Balancer1 Subnet List : ' + listOfLoadBalancerSubnets);
                        self.loadBalancerSubnetList(listOfLoadBalancerSubnets);
                        self.loadBalancerSubnetDataProvider = new ArrayDataProvider(self.loadBalancerSubnetList, {idAttribute: 'value'});   
                        lovUtils.lovOptionsUpdated(self.loadBalancerSubnetList(), self.selectedloadBalancerSubnet);
                    }
                }
            }

            console.log('Populating Load Balancer Subnets for HA');

            /* This is for Load Balancer 2 */
            var listOfsubnetsForHA = new Array();
            var isLoadBalancerSubnetTypePrivate = loadBalancerSubnetType === 'Private' ? true : false;
            console.log('Is Load Balancer Subnet Type Private :' + isLoadBalancerSubnetTypePrivate);
            for (var i = 0; i < self.availabilityDomainAndSubnetList().length; i++)
            {
                var currentAdName = self.availabilityDomainAndSubnetList()[i].value;
                if (currentAdName === adNameSelected)
                {
                    continue;
                } else
                {
                    var listOfSubnetsUnderCurrentAD = self.availabilityDomainAndSubnetList()[i].subnets;
                    if (listOfSubnetsUnderCurrentAD === null || listOfSubnetsUnderCurrentAD.length <= 0)
                    {
                        continue;
                    } else
                    {
                        var filteredSubnetsList = new Array();
                        for (var j = 0; j < listOfSubnetsUnderCurrentAD.length; j++)
                        {
                            var currentSubnet = listOfSubnetsUnderCurrentAD[j];
                            var currentSubnetType = currentSubnet.isPrivate;
                            if (currentSubnetType === isLoadBalancerSubnetTypePrivate)
                            {
                                filteredSubnetsList.push(currentSubnet);
                            }
                        }
                        if (filteredSubnetsList.length <= 0)
                        {
                            continue;
                        } else
                        {
                            var adListObject = new Object();
                            adListObject.label = self.availabilityDomainAndSubnetList()[i].label;
                            adListObject.children = filteredSubnetsList;
                            listOfsubnetsForHA.push(adListObject);
                        }
                    }
                }
            }

            console.log('List of subnets for HA :' + listOfsubnetsForHA);

            if (listOfsubnetsForHA.length <= 0)
            {
                var translatedMsg = oj.Translations.getTranslatedString("validationMsgs.publicSubnetsUnavailableUnderADs");
                var validationCustomMsg = {summary: translatedMsg,
                    detail: translatedMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                if (isExternal)
                {
                    self.subnetValidationMsgForHALoadBalancerSubnet_External([validationCustomMsg]);
                } else
                {
                    self.subnetValidationMsgForHALoadBalancerSubnet([validationCustomMsg]);
                }
            } else
            {
                if (isExternal)
                {
                    console.log('List of Subnets for HA ' + listOfsubnetsForHA);
                    self.loadBalancerHASubnetList_External(listOfsubnetsForHA);
                    self.loadBalancerHASubnetExternalDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList_External, {idAttribute: 'value'});    
                    lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList_External(), self.selectedLoadBalancerHASubnet_External);
                } else
                {
                    console.log('List of Subnets for HA ' + listOfsubnetsForHA);
                    self.loadBalancerHASubnetList(listOfsubnetsForHA);
                    self.loadBalancerHASubnetDataProvider = new ArrayDataProvider(self.loadBalancerHASubnetList, {idAttribute: 'value'});   
                    lovUtils.lovOptionsUpdated(self.loadBalancerHASubnetList(), self.selectedLoadBalancerHASubnet);
                }
                if (self.overrideWithUserValues && !self.errorsFound)
                {
                    self.selectedLoadBalancerHASubnet(self.enteredLbaasHASubnetOCID);
                     if (self.editFlowExternalZonePresent && self.enteredExternalLbaasHASubnetOCID !== '') {
                         self.selectedLoadBalancerHASubnet_External(self.enteredExternalLbaasHASubnetOCID);
                     }
                }

            }
            console.log('/Done with populating list of load balancer subnets');
        };
        self.handleLoadBalancerSubnetTypeChangeEvent = function (event)
        {
            // Trigger populate Load Balancer Tier subnets.
            if (self.overrideWithUserValues)
            {
                return;
            }
            if (event.detail.previousValue === event.detail.value)
            {
                return;
            }
            self.populateLoadBalancerTierSubnets(event);
            self.handleLoadbalancerHASubnetRegion();
        };
        self.handleLoadBalancerSubnetTypeChangeEvent_External = function (event)
        {
            // Trigger populate Load Balancer Tier subnets.
            if (self.overrideWithUserValues)
            {
                return;
            }

            if (event.detail.previousValue === event.detail.value)
            {
                return;
            }
            self.populateLoadBalancerTierSubnets(event, true);
            self.handleLoadbalancerHASubnetRegion(true);
        };
        self.handleCancelButton = function (event)
        {
            event.detail.originalEvent.preventDefault();
            var context = ko.contextFor(document.getElementById(constants.divTags.networkProfileCreationPGContainer));
            rootViewModel.currentNetworkName('');
            rootViewModel.updateNetworkProfileFlow(false);
            pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileListModule, constants.navModules.networkProfileListModule);

        };
        self.getRequestSubmissionData = function ()
        {
            var isDbTierSubnetPrivate = false;
            if (self.selectedDataBaseTierSubnetType() === 'Private')
            {
                isDbTierSubnetPrivate = true;
            }

            var isAppTierSubnetPrivate = false;
            if (self.selectedAppTierSubnetType() === 'Private')
            {
                isAppTierSubnetPrivate = true;
            }

            var isLoadBalancerSubnetPrivate = false;
            if (self.selectedloadBalancerSubnetType === 'Private')
            {
                isLoadBalancerSubnetPrivate = true;
            }

            var useRegionalSubnets = true;
            if (self.subnetTypeSelected() === constants.subnetType.AvailabilityDomainSpecific)
            {
                useRegionalSubnets = false;
            }
            
            var requestBody =
                    {
                        "name": self.networkProfileNameEntered(),
                        "description": self.networkProfileDescEntered(),
                        "ebsCompartmentOCID": self.selectedEBSCompartment(),
                        "networkCompartmentOCID": self.selectedNetworkCompartment(),
                        "region": rootViewModel.selectedRegionValue(),
                        "vcnOCID": self.selectedVCN(),
                        "availabilityDomainOCID": self.selectedAvailabilityDomain(),
                        "useRegionalSubnets": useRegionalSubnets,
                        "dbTier":
                                {
                                    "isPrivate": isDbTierSubnetPrivate,
                                    "subnetOCID": self.selectedDataBaseTierSubnet(),
                                },
                        "appTier":
                                {
                                    "internal": [
                                        {
                                            "isPrivate": isAppTierSubnetPrivate,
                                            "subnetOCID": self.selectedAppTierSubnet()
                                        }
                                    ],
                                    "external": [
                                        {
                                            "isPrivate": "",
                                            "subnetOCID": ""
                                        }
                                    ]

                                },
                        "lbaas":
                                {
                                    "internal": 
                                        {
                                            "isPrivate": isLoadBalancerSubnetPrivate,
                                            "subnetOCID": self.selectedloadBalancerSubnet(),
                                            "haSubnetOCID": self.selectedLoadBalancerHASubnet()
                                        },
                                    "external": 
                                        {
                                            "isPrivate": "",
                                            "subnetOCID": "",
                                            "haSubnetOCID": ""
                                        }
                                    
                                }

                    };
            // If displayLoadBalancerHASubnetRegion is false, then send empty ha value to REST
            if (!self.displayLoadBalancerHASubnetRegion())
            {
                requestBody.lbaas.internal.haSubnetOCID = '';
            }

            // Populate only if the external zone is selected.
            if (self.externalZonesSupported()) {
                var externalAppTierEntry = requestBody.appTier.external[0];
                externalAppTierEntry.isPrivate = self.selectedAppTierSubnetType_External() === 'Private';
                externalAppTierEntry.subnetOCID = self.selectedAppTierSubnet_External();

                var externalLbaasEntry = requestBody.lbaas.external;
                externalLbaasEntry.isPrivate = self.selectedloadBalancerSubnetType_External() === 'Private';
                externalLbaasEntry.subnetOCID = self.selectedloadBalancerSubnet_External();
                if (self.displayLoadBalancerHASubnetRegion_External()) {
                    externalLbaasEntry.haSubnetOCID = self.selectedLoadBalancerHASubnet_External();
                }

            }

            return requestBody;
        };
        self.handleSubmitButton = function (event)
        {
            var invalid = self.validateAllContents();
            if (invalid)
            {
                return;
            }
            var jsonContent = JSON.stringify(self.getRequestSubmissionData());
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.networkProfileCreateInfoMsg", {'networkProfileName': self.networkProfileNameEntered()});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.networkProfileCreateTitle");
            popupHelper.openInfoMsg(constants.divTags.confirmationMessagePopupModuleTag, infoMsg, msgOrigin);
            if (self.isEditFlow())
            {
                actionsHelper.putNetworkProfile(jsonContent, function (error)
                {
                    if (error === '')
                    {
                        var context = ko.contextFor(document.getElementById(constants.divTags.networkProfileCreationPGContainer));
                        rootViewModel.displayPopupId(constants.divTags.confirmationMessagePopupModuleTag);
                        var confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.networkProfileCreateSuccessMsg", {'networkProfileName': self.networkProfileNameEntered()});
                        popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);
                        setTimeout(function () {
                            rootViewModel.currentNetworkName('');
                            rootViewModel.updateNetworkProfileFlow(false);
                            pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileListModule, constants.navModules.networkProfilesListPage);
                        }, 2000);
                    } else
                    {
                        var responseText = error.responseText;
                        var response = JSON.parse(responseText);
                        popupHelper.openErrorMsg(constants.divTags.confirmationMessagePopupModuleTag, response.message, msgOrigin);
                    }

                });
            } else
            {
                actionsHelper.createNetworkProfile(jsonContent, function (error)
                {
                    if (error === '')
                    {
                        var context = ko.contextFor(document.getElementById(constants.divTags.networkProfileCreationPGContainer));
                        rootViewModel.displayPopupId(constants.divTags.confirmationMessagePopupModuleTag);
                        var confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.networkProfileCreateSuccessMsg", {'networkProfileName': self.networkProfileNameEntered()});
                        popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);
                        //Clear session values when new network is created
                        sessionStorage.removeItem("sessionNetworkList");
                        sessionStorage.removeItem("sessionDbSubnetMap");
                        setTimeout(function () {
                            rootViewModel.currentNetworkName('');
                            rootViewModel.updateNetworkProfileFlow(false);
                            pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileListModule, constants.navModules.networkProfilesListPage);
                        }, 2000);
                    } else
                    {
                        var responseText = error.responseText;
                        var response = JSON.parse(responseText);
                        popupHelper.openErrorMsg(constants.divTags.confirmationMessagePopupModuleTag, response.message, msgOrigin);
                    }

                });
            }
        };
        self.getDisplayNameForLOV = function (lovId, paramType)
        {
            var lovIdentifier = lovId;
            var displayName = '';
            if (lovIdentifier === 'ebsCompartment')
            {
                var lov = self.EBSCompartmentList();
                var value = self.selectedEBSCompartment();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'networkCompartment')
            {
                var lov = self.NetworkCompartmentList();
                var value = self.selectedNetworkCompartment();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'vcn')
            {
                var lov = self.VCNList();
                var value = self.selectedVCN();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'availabilityDomain')
            {
                var lov = self.availabilityDomainList();
                var value = self.selectedAvailabilityDomain();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'dbTierSubnetName')
            {
                var lov = self.dataBaseTierSubnetList();
                var value = self.selectedDataBaseTierSubnet();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'dbTierBackupSubnetName')
            {
                var lov = self.dataBaseTierBackupSubnetList();
                var value = self.selectedDatabaseTierBackupSubnet();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'appTierSubnetName')
            {
                var lov = self.appTierSubnetList();
                var value = self.selectedAppTierSubnet();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'lbaasSubnetName')
            {
                var lov = self.loadBalancerSubnetList();
                var value = self.selectedloadBalancerSubnet();
                displayName = self.getNameForValue(lov, value, paramType);
            } else if (lovIdentifier === 'lbaasHASubnetName')
            {
                var lov = self.loadBalancerHASubnetList();
                var value = self.selectedLoadBalancerHASubnet();
                displayName = self.getNameForValueRecursive(lov, value, paramType);
            }

            return displayName;
        };
        self.getNameForValueRecursive = function (list, value, paramType)
        {
            var lengthOfList = list.length;
            if (lengthOfList < 1)
            {
                return '';
            } else
            {
                var adList = list;
                for (var i = 0; i < adList.length; i++)
                {
                    var currentAD = adList[i];
                    var children = currentAD.children;
                    if (children === null || children.length < 1)
                    {
                        continue;
                    } else
                    {
                        for (var j = 0; j < children.length; j++)
                        {
                            var currentSubnet = children[j];
                            var currentSubnetValue = currentSubnet.value;
                            if (currentSubnetValue === value && paramType === 'name')
                            {
                                return currentSubnet.label;
                            } else if (currentSubnetValue === value && paramType === 'cidr')
                            {
                                return currentSubnet.CIDR;
                            }

                        }
                    }
                }
            }

        };
        self.getNameForValue = function (list, value, paramType)
        {
            var lengthOfList = list.length;
            if (lengthOfList < 1)
            {
                return '';
            } else
            {
                for (var i = 0; i < lengthOfList; i++)
                {
                    var currentListElement = list[i];
                    var valueOfCurrentListElement = currentListElement.value;
                    if (valueOfCurrentListElement === value && paramType === 'name')
                    {
                        return currentListElement.label;
                    } else if (valueOfCurrentListElement === value && paramType === 'cidr')
                    {
                        return currentListElement.CIDR;
                    }
                }
                return '';
            }
        };
        self.validateAllContents = function ()
        {
            var invalidPresent = false;
            var networkProfileNameField = document.getElementById('NetworkProfileName');
            if (networkProfileNameField.valid !== 'valid')
            {
                networkProfileNameField.showMessages();
                invalidPresent = true;
            }

            var networkProfileDescField = document.getElementById('NetworkProfileDesc');
            if (networkProfileDescField.valid !== 'valid')
            {
                networkProfileDescField.showMessages();
                invalidPresent = true;
            }

            var ebsCompartmentField = document.getElementById('EBSCompartment');
            if (ebsCompartmentField.firstElementChild.valid !== 'valid')
            {
                ebsCompartmentField.firstElementChild.showMessages();
                invalidPresent = true;
            }

            var networkCompartmentField = document.getElementById('NetworkCompartment');              
            if (networkCompartmentField.firstElementChild.valid !== 'valid')
            {
                networkCompartmentField.firstElementChild.showMessages();
                invalidPresent = true;
            }

            var vcnField = document.getElementById('VCN');
            if (vcnField.valid !== 'valid')
            {
                vcnField.showMessages();
                invalidPresent = true;
            }

            var adField = document.getElementById('AD');
            if (adField.valid !== 'valid')
            {
                adField.showMessages();
                invalidPresent = true;
            }

            var dbTierSubnetField = document.getElementById('DBTierSubnet');
            if (dbTierSubnetField.valid !== 'valid')
            {
                dbTierSubnetField.showMessages();
                invalidPresent = true;
            }



            var appNodeSubnetField = document.getElementById('AppNodesSubnet');
            if (appNodeSubnetField.valid !== 'valid')
            {
                appNodeSubnetField.showMessages();
                invalidPresent = true;
            }

            var loadBalancerSubnet = document.getElementById('LoadBalancerSubnet');
            if (loadBalancerSubnet.valid !== 'valid')
            {
                loadBalancerSubnet.showMessages();
                invalidPresent = true;
            }

            // Validate loadBalancerHASubnet if true
            if (self.displayLoadBalancerHASubnetRegion())
            {
                var loadBalancerHASubnet = document.getElementById('LoadBalancerSubnetHAEnabled');
                if (loadBalancerHASubnet.valid !== 'valid')
                {
                    loadBalancerHASubnet.showMessages();
                    invalidPresent = true;
                }
            }

            var isExternalZoneEnabled = self.externalZonesSupported();
            if (isExternalZoneEnabled)
            {
                var appNodeExternalSubnetField = document.getElementById('AppNodesSubnet_External');
                if (appNodeExternalSubnetField.valid !== 'valid')
                {
                    appNodeExternalSubnetField.showMessages();
                    invalidPresent = true;
                }

                // Internal app nodes subnet cannot be the same as external app nodes subnet.
                if (appNodeSubnetField.value === appNodeExternalSubnetField.value) {
                    var validationCustomMsg = {summary: oj.Translations.getTranslatedString("validationMsgs.internalExternalSubnetsAreSame"),
                        detail: oj.Translations.getTranslatedString("validationMsgs.internalExternalSubnetsAreSame"), severity: oj.Message.SEVERITY_TYPE.ERROR};
                    self.subnetValidationMsgForAppTierSubnet_External([validationCustomMsg]);
                    appNodeExternalSubnetField.showMessages();
                    invalidPresent = true;
                } else {
                    self.subnetValidationMsgForAppTierSubnet_External([]);
                }
                
                
                

                var loadBalancerExternalSubnet = document.getElementById('LoadBalancerSubnet_External');
                if (loadBalancerExternalSubnet.valid !== 'valid')
                {
                    loadBalancerExternalSubnet.showMessages();
                    invalidPresent = true;
                }

                if (self.displayLoadBalancerHASubnetRegion_External())
                {
                    var loadBalancerHASubnet_External = document.getElementById('LoadBalancerSubnetHAEnabled_External');
                    if (loadBalancerHASubnet_External.valid !== 'valid')
                    {
                        loadBalancerHASubnet_External.showMessages();
                        invalidPresent = true;
                    }
                }
            }
            return invalidPresent;
        };
        actionsHelper.getCompartmentListForTenancy(function (error, compartmentsList)
        {
            if (self.isEditFlow())
            {
                self.overrideWithUserValues = true;
                self.subnetTypeSelected(self.enteredSubnetType);
            }
            if (error !== null && error !== '')
            {
                if (error.status === 504)
                {
                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                    self.addPageLevelMessage('error', 'Error in fetching compartment list', messageContent);
                } else
                {
                    var errorCode = error.responseJSON.code;
                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                    {
                        errorCode = error.status;
                    }
                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                    self.addPageLevelMessage('error', 'Error in fetching compartment list', messageContent);
                }
                self.disableSubmitBtn(true);
            } else
            {
                var hierarchialList = getFlatListFromHierarchicalLov(compartmentsList, self.tenancyId);
                self.listOfCompartments(hierarchialList);
                self.populateEBSCompartmentList();
                self.populateNetworkCompartmentList();
            }

        });
    }

    return networkProfileViewModel;
});
