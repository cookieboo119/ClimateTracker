
package com.bloomberg.datalic.dlws.stubs;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DLCategory2.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DLCategory2">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Security Master"/>
 *     &lt;enumeration value="Derived - Intraday"/>
 *     &lt;enumeration value="Derived - End of Day"/>
 *     &lt;enumeration value="Pricing - Intraday"/>
 *     &lt;enumeration value="Pricing - End of Day"/>
 *     &lt;enumeration value="User Entered Info."/>
 *     &lt;enumeration value="Corporate Actions"/>
 *     &lt;enumeration value="Historical Time Series"/>
 *     &lt;enumeration value="Estimates"/>
 *     &lt;enumeration value="Fundamentals"/>
 *     &lt;enumeration value="Quote Composite"/>
 *     &lt;enumeration value="Quote Composite History"/>
 *     &lt;enumeration value="Credit Risk"/>
 *     &lt;enumeration value="Packaged"/>
 *     &lt;enumeration value="Open Source"/>
 *     &lt;enumeration value="Reg SSFA"/>
 *     &lt;enumeration value="Volatility Surface"/>
 *     &lt;enumeration value="Volatility Cube"/>
 *     &lt;enumeration value="Bram Fair Value Hierarchy Leveling Tool"/>
 *     &lt;enumeration value="Credit Risk Corporate Structure"/>
 *     &lt;enumeration value="Credit Risk Capital Structure"/>
 *     &lt;enumeration value="Credit Risk Regulatory Compliance"/>
 *     &lt;enumeration value="Premium BRAM Transparency"/>
 *     &lt;enumeration value="Price Uncertainty"/>
 *     &lt;enumeration value="Not Downloadable"/>
 *     &lt;enumeration value="Central Bank Eligibility"/>
 *     &lt;enumeration value="Covered Funds"/>
 *     &lt;enumeration value="High Quality Liquid Assets"/>
 *     &lt;enumeration value="Liquidity Assessment"/>
 *     &lt;enumeration value="MiFIR"/>
 *     &lt;enumeration value="Default Risk"/>
 *     &lt;enumeration value="IFRS 9 SPPI"/>
 *     &lt;enumeration value="Collateral Tagging"/>
 *     &lt;enumeration value="US Withholding Tax"/>
 *     &lt;enumeration value="Expected Credit Loss"/>
 *     &lt;enumeration value="Basic Tax"/>
 *     &lt;enumeration value="Investor Protection"/>
 *     &lt;enumeration value="EnvironmentalSocialAndGovernance"/>
 *     &lt;enumeration value="FundamentalsIndustrySpecific"/>
 *     &lt;enumeration value="FundamentalsSegmentation"/>
 *     &lt;enumeration value="Securities Financing Transactions Regulation"/>
 *     &lt;enumeration value="SecurityOwnership"/>
 *     &lt;enumeration value="SupplyChain"/>
 *     &lt;enumeration value="UK MIFI"/>
 *     &lt;enumeration value="FRTB SA Bucketing"/>
 *     &lt;enumeration value="ESGScores"/>
 *     &lt;enumeration value="Regulatory &amp; Risk Group 2 Misc"/>
 *     &lt;enumeration value="ESG Climate"/>
 *     &lt;enumeration value="Market Implied Probability of Default"/>
 *     &lt;enumeration value="Regulatory &amp; Risk Group 3 Misc"/>
 *     &lt;enumeration value="Regulatory &amp; Risk Group 4 Misc"/>
 *     &lt;enumeration value="Primary Market"/>
 *     &lt;enumeration value="Fund Analytics"/>
 *     &lt;enumeration value="ESG Regulation"/>
 *     &lt;enumeration value="Holiday Pricing"/>
 *     &lt;enumeration value="CAPFloor Volatility"/>
 *     &lt;enumeration value="ATM Volatility"/>
 *     &lt;enumeration value="ATMOTM Swaption"/>
 *     &lt;enumeration value="FRTBRFETData"/>
 *     &lt;enumeration value="BenchmarkRegulation"/>
 *     &lt;enumeration value="Fund ESG Analytics"/>
 *     &lt;enumeration value="BCurve"/>
 *     &lt;enumeration value="Implied Dividend"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DLCategory2")
@XmlEnum
public enum DLCategory2 {

    @XmlEnumValue("Security Master")
    SECURITY_MASTER("Security Master"),
    @XmlEnumValue("Derived - Intraday")
    DERIVED_INTRADAY("Derived - Intraday"),
    @XmlEnumValue("Derived - End of Day")
    DERIVED_END_OF_DAY("Derived - End of Day"),
    @XmlEnumValue("Pricing - Intraday")
    PRICING_INTRADAY("Pricing - Intraday"),
    @XmlEnumValue("Pricing - End of Day")
    PRICING_END_OF_DAY("Pricing - End of Day"),
    @XmlEnumValue("User Entered Info.")
    USER_ENTERED_INFO("User Entered Info."),
    @XmlEnumValue("Corporate Actions")
    CORPORATE_ACTIONS("Corporate Actions"),
    @XmlEnumValue("Historical Time Series")
    HISTORICAL_TIME_SERIES("Historical Time Series"),
    @XmlEnumValue("Estimates")
    ESTIMATES("Estimates"),
    @XmlEnumValue("Fundamentals")
    FUNDAMENTALS("Fundamentals"),
    @XmlEnumValue("Quote Composite")
    QUOTE_COMPOSITE("Quote Composite"),
    @XmlEnumValue("Quote Composite History")
    QUOTE_COMPOSITE_HISTORY("Quote Composite History"),
    @XmlEnumValue("Credit Risk")
    CREDIT_RISK("Credit Risk"),
    @XmlEnumValue("Packaged")
    PACKAGED("Packaged"),
    @XmlEnumValue("Open Source")
    OPEN_SOURCE("Open Source"),
    @XmlEnumValue("Reg SSFA")
    REG_SSFA("Reg SSFA"),
    @XmlEnumValue("Volatility Surface")
    VOLATILITY_SURFACE("Volatility Surface"),
    @XmlEnumValue("Volatility Cube")
    VOLATILITY_CUBE("Volatility Cube"),
    @XmlEnumValue("Bram Fair Value Hierarchy Leveling Tool")
    BRAM_FAIR_VALUE_HIERARCHY_LEVELING_TOOL("Bram Fair Value Hierarchy Leveling Tool"),
    @XmlEnumValue("Credit Risk Corporate Structure")
    CREDIT_RISK_CORPORATE_STRUCTURE("Credit Risk Corporate Structure"),
    @XmlEnumValue("Credit Risk Capital Structure")
    CREDIT_RISK_CAPITAL_STRUCTURE("Credit Risk Capital Structure"),
    @XmlEnumValue("Credit Risk Regulatory Compliance")
    CREDIT_RISK_REGULATORY_COMPLIANCE("Credit Risk Regulatory Compliance"),
    @XmlEnumValue("Premium BRAM Transparency")
    PREMIUM_BRAM_TRANSPARENCY("Premium BRAM Transparency"),
    @XmlEnumValue("Price Uncertainty")
    PRICE_UNCERTAINTY("Price Uncertainty"),
    @XmlEnumValue("Not Downloadable")
    NOT_DOWNLOADABLE("Not Downloadable"),
    @XmlEnumValue("Central Bank Eligibility")
    CENTRAL_BANK_ELIGIBILITY("Central Bank Eligibility"),
    @XmlEnumValue("Covered Funds")
    COVERED_FUNDS("Covered Funds"),
    @XmlEnumValue("High Quality Liquid Assets")
    HIGH_QUALITY_LIQUID_ASSETS("High Quality Liquid Assets"),
    @XmlEnumValue("Liquidity Assessment")
    LIQUIDITY_ASSESSMENT("Liquidity Assessment"),
    @XmlEnumValue("MiFIR")
    MI_FIR("MiFIR"),
    @XmlEnumValue("Default Risk")
    DEFAULT_RISK("Default Risk"),
    @XmlEnumValue("IFRS 9 SPPI")
    IFRS_9_SPPI("IFRS 9 SPPI"),
    @XmlEnumValue("Collateral Tagging")
    COLLATERAL_TAGGING("Collateral Tagging"),
    @XmlEnumValue("US Withholding Tax")
    US_WITHHOLDING_TAX("US Withholding Tax"),
    @XmlEnumValue("Expected Credit Loss")
    EXPECTED_CREDIT_LOSS("Expected Credit Loss"),
    @XmlEnumValue("Basic Tax")
    BASIC_TAX("Basic Tax"),
    @XmlEnumValue("Investor Protection")
    INVESTOR_PROTECTION("Investor Protection"),
    @XmlEnumValue("EnvironmentalSocialAndGovernance")
    ENVIRONMENTAL_SOCIAL_AND_GOVERNANCE("EnvironmentalSocialAndGovernance"),
    @XmlEnumValue("FundamentalsIndustrySpecific")
    FUNDAMENTALS_INDUSTRY_SPECIFIC("FundamentalsIndustrySpecific"),
    @XmlEnumValue("FundamentalsSegmentation")
    FUNDAMENTALS_SEGMENTATION("FundamentalsSegmentation"),
    @XmlEnumValue("Securities Financing Transactions Regulation")
    SECURITIES_FINANCING_TRANSACTIONS_REGULATION("Securities Financing Transactions Regulation"),
    @XmlEnumValue("SecurityOwnership")
    SECURITY_OWNERSHIP("SecurityOwnership"),
    @XmlEnumValue("SupplyChain")
    SUPPLY_CHAIN("SupplyChain"),
    @XmlEnumValue("UK MIFI")
    UK_MIFI("UK MIFI"),
    @XmlEnumValue("FRTB SA Bucketing")
    FRTB_SA_BUCKETING("FRTB SA Bucketing"),
    @XmlEnumValue("ESGScores")
    ESG_SCORES("ESGScores"),
    @XmlEnumValue("Regulatory & Risk Group 2 Misc")
    REGULATORY_RISK_GROUP_2_MISC("Regulatory & Risk Group 2 Misc"),
    @XmlEnumValue("ESG Climate")
    ESG_CLIMATE("ESG Climate"),
    @XmlEnumValue("Market Implied Probability of Default")
    MARKET_IMPLIED_PROBABILITY_OF_DEFAULT("Market Implied Probability of Default"),
    @XmlEnumValue("Regulatory & Risk Group 3 Misc")
    REGULATORY_RISK_GROUP_3_MISC("Regulatory & Risk Group 3 Misc"),
    @XmlEnumValue("Regulatory & Risk Group 4 Misc")
    REGULATORY_RISK_GROUP_4_MISC("Regulatory & Risk Group 4 Misc"),
    @XmlEnumValue("Primary Market")
    PRIMARY_MARKET("Primary Market"),
    @XmlEnumValue("Fund Analytics")
    FUND_ANALYTICS("Fund Analytics"),
    @XmlEnumValue("ESG Regulation")
    ESG_REGULATION("ESG Regulation"),
    @XmlEnumValue("Holiday Pricing")
    HOLIDAY_PRICING("Holiday Pricing"),
    @XmlEnumValue("CAPFloor Volatility")
    CAP_FLOOR_VOLATILITY("CAPFloor Volatility"),
    @XmlEnumValue("ATM Volatility")
    ATM_VOLATILITY("ATM Volatility"),
    @XmlEnumValue("ATMOTM Swaption")
    ATMOTM_SWAPTION("ATMOTM Swaption"),
    @XmlEnumValue("FRTBRFETData")
    FRTBRFET_DATA("FRTBRFETData"),
    @XmlEnumValue("BenchmarkRegulation")
    BENCHMARK_REGULATION("BenchmarkRegulation"),
    @XmlEnumValue("Fund ESG Analytics")
    FUND_ESG_ANALYTICS("Fund ESG Analytics"),
    @XmlEnumValue("BCurve")
    B_CURVE("BCurve"),
    @XmlEnumValue("Implied Dividend")
    IMPLIED_DIVIDEND("Implied Dividend");
    private final String value;

    DLCategory2(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DLCategory2 fromValue(String v) {
        for (DLCategory2 c: DLCategory2 .values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
