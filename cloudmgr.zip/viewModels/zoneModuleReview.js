/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * backup module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/utils/backupEnvironmentHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojarraydataprovider', 'ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojselectcombobox', 'ojs/ojcheckboxset', 'ojs/ojtable', 'ojs/ojdatacollection-utils'], function (oj, ko, actionsHelper, backupEnvironmentHelper, popupHelper, constants, ArrayDataProvider) {
    /**
     * The view model for the main content view template
     */
    function zoneModuleReviewViewModel(params) {
        var self = this;
        console.log('Loading Zone Module Review View Model');
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.webEntryTypeLabel_rvw = ko.observable('');
        self.lbaasShape_rvw = ko.observable('');
        self.uiSequenceNum = ko.observable('');
        self.lbaasOptionValue_rvw = ko.observable('');
        self.webEntryProtocolInputValue_rvw = ko.observable('');
        self.webEntryHostname_rvw = ko.observable('');
        self.webEntryPort_rvw = ko.observable('');
        self.webEntryDomain_rvw = ko.observable('');
        self.zoneName = ko.observable('');
        self.zoneType_rvw = ko.observable('');
        self.appNodesDataProvider = null;
        self.storageType = ko.observable('');

        self.columnArray = [{"headerText": "Logical FQDN",
                        "field": "logicalFQDN"},
            {"headerText": "Shape",
                "field": "Shape"},
            {"headerText": "Storage (GB)",
                "field": "Storage"},
            {"headerText": "Fault Domain",
                "field": "FaultDomain"}
        ];

        self.renderReviewRegion = function (viewModelOfDetailChild, webEntryTypeLabel, lbaasShape, uiSequence, lbaasOptionValue, webEntryProtocolInputValue, webEntryHostName, webEntryPort, webEntryDomain, zoneName, zoneType)
        {
            self.webEntryTypeLabel_rvw(webEntryTypeLabel);
            self.lbaasShape_rvw(lbaasShape);
            self.uiSequenceNum(uiSequence);
            self.lbaasOptionValue_rvw(lbaasOptionValue);
            self.webEntryProtocolInputValue_rvw(webEntryProtocolInputValue);
            self.webEntryHostname_rvw(webEntryHostName);
            self.webEntryPort_rvw(webEntryPort);
            self.webEntryDomain_rvw(webEntryDomain);
            self.zoneName(zoneName);
            self.zoneType_rvw(zoneType);


            var fileSystemModeValue = viewModelOfDetailChild.fileSystemModeSelected();
            var fileSystemModeLabel = '';
            for (var j = 0; j < viewModelOfDetailChild.fileSystemModes().length; j++)
            {
                if (viewModelOfDetailChild.fileSystemModes()[j].value === fileSystemModeValue)
                {
                    fileSystemModeLabel = viewModelOfDetailChild.fileSystemModes()[j].label;
                    break;
                }
            }
            self.storageType(fileSystemModeLabel);


            var nodes = new Array();
            for (var i = 0; i < viewModelOfDetailChild.nodesObservableArray().length; i++)
            {
                var nodeInfo = new Object();
                nodeInfo.NodeId = viewModelOfDetailChild.nodesObservableArray()[i].NodeId;
                nodeInfo.logicalFQDN = viewModelOfDetailChild.nodesObservableArray()[i].logicalFQDN;
                nodeInfo.Shape = viewModelOfDetailChild.nodesObservableArray()[i].Shape();
                var storage = viewModelOfDetailChild.nodesObservableArray()[i].Storage;
                if (storage() === 0) {
                    nodeInfo.Storage = ko.observable('');
                } else {
                    nodeInfo.Storage = viewModelOfDetailChild.nodesObservableArray()[i].Storage;
                }
                nodeInfo.FaultDomain = viewModelOfDetailChild.nodesObservableArray()[i].FaultDomain();
                nodes.push(nodeInfo);
            }
            self.nodesObservableArray = ko.observableArray(nodes);
            self.appNodesDataProvider = new ArrayDataProvider(self.nodesObservableArray, {idAttribute: 'NodeId'});
        };

        var initSeq = params.initSeq;
        var currentRowIdx = params.index - initSeq;

        var detailChildContainer = document.getElementById('detailPageContainer');
        var moduleHolder = detailChildContainer.children[currentRowIdx].children[0].children[0];
        var viewModelOfCurrentDetailChild = ko.dataFor(moduleHolder);
        var selectedLbaasType = viewModelOfCurrentDetailChild.lbaasOptionValue();
        var lbaasOptions = viewModelOfCurrentDetailChild.lbaasOptions();
        var webEntryTypeLabel = '';
        for (var i = 0; i < lbaasOptions.length; i++)
        {
            if (lbaasOptions[i].value === selectedLbaasType)
            {
                webEntryTypeLabel = lbaasOptions[i].label;
                break;
            }
        }


        console.log('Working on Detail Child : ' + currentRowIdx + ' in review screen');
        console.log('Lbaas Option Value : ' + viewModelOfCurrentDetailChild.lbaasOptionValue());
        console.log('web entry host name : ' + viewModelOfCurrentDetailChild.webEntryHostname());
        console.log('Zone Name :' + viewModelOfCurrentDetailChild.zoneName());
        console.log('Web Entry Type Label :' + webEntryTypeLabel);
        console.log('LbaaS Shape:' + viewModelOfCurrentDetailChild.lbaasShape());
        console.log('Zone Type :' + viewModelOfCurrentDetailChild.selectedZoneType());
        console.log('Web Entry Protocol:' + viewModelOfCurrentDetailChild.webEntryProtocolInputValue());
        console.log('Web Entry Host Name:' + viewModelOfCurrentDetailChild.webEntryHostname());
        console.log('Web EntryPort :' + viewModelOfCurrentDetailChild.webEntryPort());
        console.log('Web Entry Domain:' + viewModelOfCurrentDetailChild.webEntryDomain());

        self.renderReviewRegion(viewModelOfCurrentDetailChild, webEntryTypeLabel, viewModelOfCurrentDetailChild.lbaasShape(), currentRowIdx, selectedLbaasType, viewModelOfCurrentDetailChild.webEntryProtocolInputValue(), viewModelOfCurrentDetailChild.webEntryHostname(), viewModelOfCurrentDetailChild.webEntryPort(), viewModelOfCurrentDetailChild.webEntryDomain(), viewModelOfCurrentDetailChild.zoneName(), viewModelOfCurrentDetailChild.selectedZoneType());

    }

    return zoneModuleReviewViewModel;
});
