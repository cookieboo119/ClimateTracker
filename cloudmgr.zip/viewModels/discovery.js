/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
define(['ebs/navigation/pageNavigationHelper','ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/constants',  'ojs/ojmodule-element-utils', 'ebs/popup/popupHelper', 'ebs/utils/lcmUtils', 'ebs/utils/validationHelper', 'ebs/utils/progressHelper',  'ebs/utils/compartmentUtils',
    'ebs/utils/dateTimeHelper',  'ojs/ojarraydataprovider', 'ojs/ojmodule-element', 'ojs/ojarraytabledatasource', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojtable','ojs/ojformlayout', 'ojs/ojlabelvalue', 'ojs/ojinputtext', 
    'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojselectcombobox', 'ojs/ojmessages', 'ojs/ojinputsearch'], 
function (pageNavigationHelper, oj, ko, actionsHelper, constants, ModuleElementUtils, popupHelper, lcmUtils, validationHelper, progressHelper, compartmentUtils, dateTimeHelper, ArrayDataProvider) {
    /**
     * The view model for the main content view template
     */
    function discoveryModule() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.discoveryListLoaded = ko.observable(false);
        self.disableSubmitNewBtn = ko.observable(true);
        self.searchDiscoveryPlaceHolder = ko.observable("Search Discovery Request");
        self.networkProfileList = ko.observableArray([]);
        self.discoveryJobs = ko.observableArray([]);
        self.baseDiscoveryJobs = ko.observableArray([]);
        self.discoveryDataSource = new oj.ArrayTableDataSource(
                                        self.discoveryJobs,
                                        {idAttribute: 'id'});
        self.discoveryJobsData = ko.observable();
        
        self.currentFilterArray = ko.observableArray(['name', 'envName']);
        
        self.appsPwd = ko.observable();
        self.appsPwdValidationMsg = ko.observable([]);
        self.disableRegistrationSubmitBtn = ko.observable(false);
        self.disableRegistrationCancelBtn = ko.observable(false);
        self.showRegistrationValidationProgressBar = ko.observable("none");
        self.showRegistrationSubmitProgressBar = ko.observable("none");
        self.searchText = ko.observable('');
        
        self.discoveryColumnArray = [
          { headerText: '',
            field: 'image', 
            style:"width: 70px; max-width: 70px;",
            template: 'imageCellTemplate'},
          { headerText: 'Request Name',
            headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
            style: "white-space:normal;word-wrap:break-word; text-align: left ;vertical-align: middle;",
            field: 'name',
            sortable: 'enabled',
            template: 'nameCellTemplate',
            sortProperty: 'name' },
          { headerText: 'Environment Name',
            headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
            style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: middle;",
            field: 'envName' ,
            template: 'envNameCellTemplate',
            sortable: 'enabled',
            sortProperty: 'envName'},
          { headerText: 'Report Readiness',
            headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
            style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: middle;",
            field: 'preDiscoveryStatus',
            template: 'preDiscoveryCellTemplate',
            sortable: 'enabled',
            sortProperty: 'preDiscoveryStatus'},
          { headerText: 'Report',
            headerStyle: "text-align: left; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: center;",
            style: "white-space:normal;word-wrap:break-word; text-align: center;vertical-align: middle;",
            field: 'reportAvailable',
            template: 'reportCellTemplate'},
          { headerText: 'Compliant',
            headerStyle: "text-align: left; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: center;",
            style: "white-space:normal;word-wrap:break-word; text-align: center;vertical-align: middle;",         
            field: 'isCompliant',
            template: 'compCellTemplate'},
          { headerText: 'Discovery Status',
            headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
            style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: middle;",
            field: 'discoveryStatus',
            template: 'discoveryCellTemplate',
            sortable: 'enabled',
            sortProperty: 'discoveryStatus'},
          { headerText: 'Submitted',
            headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
            style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: middle;",
            field: 'creationDate' ,
            sortable: 'enabled',
            sortProperty: 'creationDateObject'},
          { headerText: 'Actions',
            headerStyle: "text-align: left; font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: center;",
            template: 'deleteCellTemplate',
            field: 'allowDelete',
            sortable: 'disabled'}
          /*{ headerText: '',
            template: 'menuCellTemplate',
            field: 'menu',
            sortable: 'disabled'} */
          ];
        self.moduleName = ko.observable('createDiscoveryModule');
        //self.createDiscoveryModuleConfig = ko.computed(() => {return ModuleElementUtils.createConfig({name: self.moduleName()});});
        self.createDiscoveryModuleConfig = ModuleElementUtils.createConfig({name: 'createDiscoveryModule'});
        
        self.viewReportModuleConfig = ModuleElementUtils.createConfig({name: 'discoveryViewReportPopup'});
        
         self.transitionStartListener = function(event) {
          console.log("transitinStart");
        }.bind(this);
        
        this.viewDisconnectedListener = function(event) {
          console.log("viewDisconnected");
        }.bind(this);
        
       self.addInlineMessage = function (messageSeverity, messageSummary, messageDetail)
        {
            self.clearInlineMessage();
            var newPageMessageObject = new Object();
            newPageMessageObject.severity = messageSeverity;
            newPageMessageObject.summary = messageSummary;
            newPageMessageObject.detail = messageDetail;
            newPageMessageObject.closeAffordance = "none";

            var tempArray = self.confirmPopupInlineMessages();
            tempArray.push(newPageMessageObject);
            self.confirmPopupInlineMessages(tempArray);

        };
        
        self.clearInlineMessage = function()
        {
             self.confirmPopupInlineMessages([]);
        };
        
        self.confirmPopupInlineMessages = ko.observableArray([]);
        self.confirmPopupCategoryOption = { category: 'none' };
        
        self.displayConfirmPopupInlineMessage = ko.computed(function(){
            if(self.confirmPopupInlineMessages().length > 0) return true;
            else return false;
        });
        
        self.comfirmPopupInlineMessagesDataprovider = new ArrayDataProvider(self.confirmPopupInlineMessages);
        
        
        self.handleSearchTextChange = function(event, ui)
        {
           event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleSearchDiscovery(event, ui);
            }
        }
        
        self.handleSearchDiscovery = function(event, ui)
        {
            event.preventDefault();
           //var filterValue = event.detail.value;
            var filterValue = self.searchText();
            var currentFilters = self.currentFilterArray();
            if(filterValue && filterValue !== "")
            {
                var newDataArray = [];      
                currentFilters.forEach(function(filter)
                {
                    var i;
                    var filterKey = filter;
                    var cloneBaseArray = self.baseDiscoveryJobs().slice(0);
                    for (i = cloneBaseArray.length - 1; i >= 0; i--)
                    {
                        var value = cloneBaseArray[i][filterKey];
                        if (value && value.toString().toLowerCase().indexOf(filterValue.toLowerCase()) >= 0)
                            {
                                if (newDataArray.indexOf(cloneBaseArray[i]) < 0)
                                {
                                    newDataArray.push(cloneBaseArray[i]);
                                }
                            }
                    }
                });
                self.discoveryJobs.removeAll();
                self.discoveryJobs(newDataArray.slice(0));
            }
            else
            {  //reset back to original
                self.discoveryJobs.removeAll();
                self.discoveryJobs(self.baseDiscoveryJobs().slice(0));
            }
            
           /* self.discoveryDataSource = new oj.ArrayTableDataSource(
                                        self.discoveryJobs,
                                        {idAttribute: 'id'}); 
            self.discoveryJobsData(self.discoveryDataSource);    */                   

        };
        
        self.handleSubmitNewRequest = function(event, ui)
        {
          //  ModuleElementUtils.createConfig({name: 'createDiscoveryModule'}).then(function(){
            
            var discoveryNode = document.getElementById('createDiscovery');
            //ko.cleanNode(discoveryNode);
            var newRequestPopupModule = ko.dataFor(document.getElementById('createDiscovery'));
            if(newRequestPopupModule)
            {
                //newRequestPopupModule.networkProfileList(self.networkProfileList());
                newRequestPopupModule.openPopup(event, ui);
            }
        };
        
        self.getDiscoveryDataFromId = function(id)
        {
            var key = id.substring(id.indexOf('_') +1, id.length);
            var data = null;
            self.currentItemData('');
            $.each(self.discoveryJobs(), function (i, value) {
                  if (value.id === key) {
                     data = value;
                     return false; //break the loop
                  }
            });
            return data;
        }
        
        self.handleViewReportRequest = function(ui, event)
        {
            console.log("view report for: " + event.target.id);
            var id = event.target.id;
            var data = self.getDiscoveryDataFromId(id);
            if(!data)
            {
              console.log("could not find discovery data for id: " + id);
              return;
            }
            var reportPopupModule = ko.dataFor(document.getElementById('discoveryReportPopupRoot'));
            if(reportPopupModule)
            {
                reportPopupModule.discoveryData(data);
                reportPopupModule.openPopup(event, ui);
            }
        }
        
        
        self.startDiscoveryJob = function(event, ui)
        {
            console.log("start discovery job id: " + event.target.id);
            var id = event.target.id;
            var data = self.getDiscoveryDataFromId(id);
            if(!data)
            {
              console.log("could not find discovery data for id: " + id);
              return;
            } 
            if(data)
            {
                self.currentItemData(data);
                self.openConfirmPopup(event, "registration");
            }
        };
        
               
       self.registrationServerValidateProgressConfig = progressHelper.getProgressConfig('validateProgress', -1, 'Input validation is in progress.' , self.showProgressBar);
       self.registrationSubmitProgressConfig = progressHelper.getProgressConfig('submitProgress', -1, 'Submitting request.' , self.showSubmitProgressBar);
       
        self.performRegistrationServerSideValidations = function()
        {
            console.log('Performing server side validations for new discovery request.');
            self.clearInlineMessage();
            self.disableRegistrationSubmitBtn(true);
            self.disableRegistrationCancelBtn(true);
            self.showRegistrationValidationProgressBar("");
             var data = self.currentItemData();
            if(data)
            {
                
                var discoveryId = data.id;
                var inputsToValidateFromServer =
                    [
                       {"id": "credentials.environment.appsPassword", "internalId": "regAppsPwd", "customMsgObject": self.appsPwdValidationMsg, "value": self.appsPwd()},
                    ];
            
               validationHelper.validateDiscoveryRequestOnServer(discoveryId, inputsToValidateFromServer,  self.submitRegistrationRESTRequest, self.registrationServerValidationFailed);
           }
        };
        
        self.registrationServerValidationFailed = function(error)
        {
            self.disableRegistrationSubmitBtn(false);
            self.disableRegistrationCancelBtn(false);
            self.showRegistrationValidationProgressBar("none"); 
 
            if (error != null && error != '')
            {
                if (error.status === 504)
                {
                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                    //self.addPageLevelMessage('error', 'Error in validating discovery request inputs.', messageContent);
                    self.addInlineMessage('error', 'Error in validating discovery request inputs.', messageContent);
                } else
                {
                    var errorCode = error.responseJSON.code;
                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                    {
                        errorCode = error.status;
                    }
                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                    //self.addPageLevelMessage('error', 'Error in validating discovery request inputs.', messageContent);
                    self.addInlineMessage('error', 'Error in validating discovery request inputs.', messageContent);
                }
            }
 
        }; 
        
        self.submitRegistrationRESTRequest = function()
        {
           self.showRegistrationValidationProgressBar("none");  
           self.showRegistrationSubmitProgressBar("");
            var data = self.currentItemData();
            if(data)
            {
                
                var discoveryId = data.id;
                var discoveryName = data.name;
                var postJsonData = {
                "credentials": {
                    "environment": {
                        "appsPassword": "",
                      }
                   },
                };

                postJsonData.credentials.environment.appsPassword = self.appsPwd();
                var requestBodyJSON = JSON.stringify(postJsonData);
                var discoveryId = data.id;
                var envName = data.envName;
                var discoveryName = data.name;
                var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.startRegistrationMsgTitle");
                var infoMsg = oj.Translations.getTranslatedString("confirmPopup.startRegistrationInfoMsg", {'envName': envName});
                //popupHelper.openInfoMsg(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, infoMsg, msgOrigin);
                actionsHelper.registerEnvironment(discoveryId, requestBodyJSON, function (error, success) {
                 self.showRegistrationSubmitProgressBar("none");
                 self.disableRegistrationSubmitBtn(false);
                 self.disableRegistrationCancelBtn(false);
                  if (error === null || error === '') {
                    self.closeConfirmPopup();
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.startRegistrationConfirmationMsg", {'envName': envName});
                    var context = ko.contextFor(document.getElementById(constants.divTags.discoveryPage));
                    self.loadDiscoveryJobs();
                    popupHelper.openSuccessMsg(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, successMsg, msgOrigin);

                } else {
                    //self.closeConfirmPopup();
                    var errorTitle = oj.Translations.getTranslatedString("confirmPopup.startRegistrationErrMsg", {'envName': envName});
                     if (error.status === 504)
                        {
                            var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                            //self.addPageLevelMessage('error', 'Error in validating discovery request inputs.', messageContent);
                            self.addInlineMessage('error', errorTitle, messageContent);
                        } else
                        {
                            var errorCode = error.responseJSON.code;
                            if (error.responseJSON.code === null || error.responseJSON.code === '')
                            {
                                errorCode = error.status;
                            }
                            var messageContent = 'Error Message : ' + error.responseJSON.message;
                            //self.addPageLevelMessage('error', 'Error in validating discovery request inputs.', messageContent);
                            self.addInlineMessage('error', errorTitle, messageContent);
                        }
                    
                  }  
                 });
            }
            
        };
        
        self.handleRegistrationRequest = function(event, ui)
        {            
            var appsPwd = document.getElementById('regAppsPwd');
 
            if (appsPwd && appsPwd.valid !== 'valid')
            {
                appsPwd.showMessages();
                return;
            }
            
            self.performRegistrationServerSideValidations(event);
            
        };
        
        self.handleDiscoveryTaskDetail = function(ui, event)
        {
            console.log("handle discovery job id: " + event.target.id);
            var id = event.target.id;
            var data = self.getDiscoveryDataFromId(id);
            if(!data)
            {
              console.log("could not find discovery data for id: " + id);
              return;
            }
            if(data)
             {
                var discoveryJobId = data.discoveryJobId;
                oj.Router.rootInstance.store(discoveryJobId);
                rootViewModel.activityDetailsParentPage(constants.navModules.discoveryModule);
                //var context = ko.contextFor(document.getElementById(constants.divTags.cloudMgrAdministrationSubTabIdentifier)); //Menu change
                var context = ko.contextFor(document.getElementById(constants.divTags.discoveryPage));
                pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, '', false);
             }
            
        };
        
        self.handlePreDiscoveryTaskDetail = function(ui, event)
        {
            console.log("handle pre-discovery job id: " + event.target.id);
            var id = event.target.id;
            var data = self.getDiscoveryDataFromId(id);
            if(!data)
            {
              console.log("could not find discovery data for id: " + id);
              return;
            }
            if(data)
             {
                var preDiscoveryJobId = data.preDiscoveryJobId;
                oj.Router.rootInstance.store(preDiscoveryJobId);
                rootViewModel.activityDetailsParentPage(constants.navModules.discoveryModule);
                //var context = ko.contextFor(document.getElementById(constants.divTags.cloudMgrAdministrationSubTabIdentifier));
                var context = ko.contextFor(document.getElementById(constants.divTags.discoveryPage));
                pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, '', false);
             }
        };
        
        self.handleEnvNameDetailClick = function(ui, event)
        {
            console.log("handle env detail click id: " + event.target.id);
            var id = event.target.id;
            var data = self.getDiscoveryDataFromId(id);
            if(!data)
            {
              console.log("could not find discovery data for id: " + id);
              return;
            }
            if(data)
             {
                var envName = data.envName;
                if(envName)
                {      
                    rootViewModel.currentEnvName(envName);
                    rootViewModel.isDetailPG(true);
                    
                    //getEnv Detail LCM activities
                    var enableClone = false;
                    var enableBackup = false;
                    var enableDelete = false;
                    var isProvisionedUsingSingleVM = true;
                    actionsHelper.getEnvDetails(envName, function (error, envDetails) 
                    {
                        if (error === '') 
                        {
                            isProvisionedUsingSingleVM = envDetails.deploymentType === constants.deploymentType.singleVM ? true : false;
                        }
                        rootViewModel.disableAdministrationTabForEnvionment(isProvisionedUsingSingleVM);
                        
                        if("standby" === envDetails.environmentType)
                            rootViewModel.isStandbyEnv(true);
                        else
                            rootViewModel.isStandbyEnv(false);

                        //var context = ko.contextFor(document.getElementById(constants.divTags.cloudMgrAdministrationSubTabIdentifier));//Menu change
                        var context = ko.contextFor(document.getElementById(constants.divTags.discoveryPage));
                        rootViewModel.envDetailsParentPage(constants.navModules.discoveryModule);
                        pageNavigationHelper.navigateToPage(context, constants.navModules.envDetailsModule, '', false);
                    });
                }
             } 
        };
             
       // dynamic menu                       
        self.menuOptions = ko.observableArray([]);
        self.currentItemIndex = ko.observable();
        self.currentItemData = ko.observable();
        // This is called before-menu-open so you can gather data from selected item.
        self.setupMenuOptions = function(event, ui){
          var index = ui.index; 
          self.currentItemIndex(index);
          self.getMenuItems(index);
          document.getElementById(event.target.id).refresh();
          event.detail.originalEvent.stopPropagation();
        };

        // This is called from inside of the setupMenuOptions method to actually build the menu options from the data
        self.getMenuItems = function(index) {
        var data = self.discoveryJobs()[index];
        var actionsMenu = self.getActionMenu(data);
        if(actionsMenu)
           self.menuOptions(actionsMenu); 

          return;     
        };
        
        self.confirmPopupTitle = ko.observable('');
        self.confirmPopupOperation = ko.observable('');
        self.confirmPopupMsg = ko.observable('');
        
        self.actionMenuHandler = function(event, ui)
        {
            var action = event.target.id;
            if(action)
                self.openConfirmPopup(event, action);
        };
        
        self.closeConfirmPopup = function(event, ui)
        {
            var popup = document.getElementById("confirmPopup");
            popup.close() 
            self.confirmPopupTitle('');
            self.confirmPopupOperation('');
            self.confirmPopupMsg('');          
        };
        
        self.deleteDiscoveryBtnClick = function(event, ui)
        {
            var title = '';
            var msg = '';
            self.appsPwd('');
            self.clearInlineMessage();
            var id = event.target.id;
            var data = self.getDiscoveryDataFromId(id);
            if(data)
            {
              self.currentItemData(data);
              title = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryConfirmationMsgTitle"); 
              msg = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryAssertMsg", {'discoveryName': data.name}); 
              self.confirmPopupOperation(constants.discoveryOperations.delete);
              self.confirmPopupTitle(title);
              self.confirmPopupMsg(msg);   
              var popup = document.getElementById("confirmPopup");
              popup.open(event.target); 
            }
        };
                 
        self.openConfirmPopup = function(event, operation)
        {
           var title = '';
           var msg = '';
           self.appsPwd('');
           self.clearInlineMessage();
           self.showRegistrationSubmitProgressBar("none");
           self.disableRegistrationSubmitBtn(false);
           self.disableRegistrationCancelBtn(false);
           if(constants.discoveryOperations.delete === operation)
           {
              //var data = self.discoveryJobs()[self.currentItemIndex()];
              var data = self.currentItemData();
              title = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryConfirmationMsgTitle"); 
              msg = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryAssertMsg", {'discoveryName': data.name}); 
           }
           else if(constants.discoveryOperations.registration === operation)
           {   
              var data = self.currentItemData();
              title = oj.Translations.getTranslatedString("confirmPopup.startRegistrationMsgTitle"); 
              msg = oj.Translations.getTranslatedString("confirmPopup.startRegistrationAssertMsg", {'envName': data.envName}); 
           } 
           self.confirmPopupOperation(operation);
           self.confirmPopupTitle(title);
           self.confirmPopupMsg(msg);   
           var popup = document.getElementById("confirmPopup");
           popup.open(event.target); 
        };
        
        self.handleDeleteDiscovery = function(event, ui)
        {
             self.showRegistrationSubmitProgressBar("");
             self.disableRegistrationSubmitBtn(true);
             self.disableRegistrationCancelBtn(true);
             var appsPwd = document.getElementById('regAppsPwd');
            
            if (appsPwd && appsPwd.valid !== 'valid')
            {
                appsPwd.showMessages();
                return;
            }
            
            var data = self.currentItemData();
            if(data)
            {   //Delete action
                var discoveryId = data.id;
                var discoveryName = data.name;
            
                var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryConfirmationMsgTitle");
                var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryInfoMsg", {'discoveryName': discoveryName});
                popupHelper.openInfoMsg(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, infoMsg, msgOrigin);
                 actionsHelper.deleteEnvRegistration(discoveryId, function (error, success) {
                  self.showRegistrationSubmitProgressBar("none");
                  self.showRegistrationValidationProgressBar("none");
                  self.disableRegistrationSubmitBtn(false);
                  self.disableRegistrationCancelBtn(false);
                  if (error === null || error === '') {
                    self.closeConfirmPopup();
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryConfirmationMsg", {'discoveryName': discoveryName});
                    var context = ko.contextFor(document.getElementById(constants.divTags.discoveryPage));
                    self.loadDiscoveryJobs();
                    popupHelper.openSuccessMsg(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, successMsg, msgOrigin);

                } else {
                    var errorTitle = oj.Translations.getTranslatedString("confirmPopup.deleteDiscoveryErrMsg", {'discoveryName': discoveryName});
                   if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        //self.addPageLevelMessage('error', 'Error in validating discovery request inputs.', messageContent);
                        self.addInlineMessage('error', errorTitle, messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        //self.addPageLevelMessage('error', 'Error in validating discovery request inputs.', messageContent);
                        self.addInlineMessage('error', errorTitle, messageContent);
                    }
                  }  
                 });
            }
        };
          
        self.getActionMenu = function(discoveryData)
        {       
           var menu = [];
           if(discoveryData.allowDelete)
           {
             menu.push( {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: false});
           }
           else
           {
             menu.push( {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: true});
           }
           /* if("Failed" === discoveryData.discoveryStatus)
           {
                menu.push({id: constants.contextMenu.restart, label: oj.Translations.getTranslatedString('contextMenu.restart'), disabled: false});
           }
           else
           {
               menu.push({id: constants.contextMenu.restart, label: oj.Translations.getTranslatedString('contextMenu.restart'), disabled: true}); 
           }*/
           
           return menu;
        };
        
        
        self.loadDiscoveryJobs = function(compartmentId)
        {
            self.discoveryListLoaded(false);
            var searchFilter = document.getElementById('filterDiscoveryId');
            if(searchFilter && searchFilter.value)
                searchFilter.value = '';
            
            compartmentId = compartmentUtils.getCurrentSelectedCompartmentId(compartmentId);
            actionsHelper.getDiscoveryJobs(compartmentId, function (error, discoveryJobs) {
                if (error != null && error != '')
                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addInlineMessage('error', 'Error in retrieving discovery requests.', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addInlineMessage('error', 'Error in retrieving discovery requests.', messageContent);
                    }
                }
                else
                {
                    var discoveryArray = [];
                    $.each(discoveryJobs, function () {
                        var discovery = {
                            id: this.discoveryId,
                            name: this.discoveryName,
                            envName: this.environmentName,
                            DBIp: this.databaseIp,
                            dbContextFile: this.dbContextFile,
                            preDiscoveryJobId: this.preDiscoveryJobId,
                            discoveryJobId: this.registrationJobId == null? "": this.registrationJobId,
                            preDiscoveryStatus: this.preDiscoveryStatus,
                            discoveryStatus: this.registrationStatus,
                            creationDate: dateTimeHelper.convertToUTC(this.submittedOn),
                            creationDateObject: dateTimeHelper.getDateObject(this.submittedOn),
                            isCompliant: self.getIsCompliant(this.canBeRegistered, this.preDiscoveryStatus),
                            displayReport: this.preDiscoveryStatus === constants.discoveryStatus.completed? "" : "none",
                            allowDiscovery: self.getAllowDiscovery(this.canBeRegistered, this.preDiscoveryStatus, this.registrationStatus),
                            allowDelete: self.getAllowDelete(this.preDiscoveryStatus, this.registrationStatus),
                            preDiscoveryStarted: self.hasJobStarted(this.preDiscoveryJobId),
                            discoveryStarted: self.hasJobStarted(this.registrationJobId),
                            reportAvailable: (this.preDiscoveryStatus === constants.discoveryStatus.completed) ? true : false,
                            image: self.getDiscoveryStatusBasedImage(this.preDiscoveryStatus, this.registrationStatus),
                            menu: self.menuOptions,
                            preDiscoveryTaskHandler: self.handlePreDiscoveryTaskDetail,
                            discoveryTaskHandler: self.handleDiscoveryTaskDetail,
                            setupMenuHandler: self.setupMenuOptions,
                            menuActionHandler: self.actionMenuHandler,
                            startDiscoveryHandler: self.startDiscoveryJob,
                            envDetailHandler: self.handleEnvNameDetailClick,
                            handleViewReportClick: self.handleViewReportRequest,
                            deleteDiscoveryHandler: self.deleteDiscoveryBtnClick,
                        };
                        discoveryArray.push(discovery);
                    });
                   self.discoveryJobs.removeAll();
                   self.baseDiscoveryJobs.removeAll();
                   self.discoveryJobs(discoveryArray);
                   var cloneBaseArray = discoveryArray.slice(0);
                   self.baseDiscoveryJobs(cloneBaseArray);
                   self.discoveryJobsData(self.discoveryDataSource);
                   self.discoveryListLoaded(true);
                   self.disableSubmitNewBtn(false);
              }
            });
            
        };
        
          self.getIsCompliant = function(canBeRegistered, preDiscoveryStatus)
          {
              if(canBeRegistered)
                  return 'Y';
              else if((constants.discoveryStatus.completed === preDiscoveryStatus))
                  return 'N';
               return '';
          };
          
           self.getAllowDiscovery = function(compliant, preDiscoveryStatus, discoveryStatus) {
               if((compliant) && (constants.discoveryStatus.completed === preDiscoveryStatus) && 
                  (!discoveryStatus || (discoveryStatus === "") || 
                    (constants.discoveryStatus.pending === discoveryStatus)))
                   return true;
               return false;
           };
           
           self.getAllowDelete = function(preDiscoveryStatus, discoveryStatus) {
               var allowDelete = true;
               if((constants.discoveryStatus.completed === preDiscoveryStatus) && (constants.discoveryStatus.completed === discoveryStatus))
                   allowDelete = false;
               else if((constants.discoveryStatus.inProgress === preDiscoveryStatus) || 
                       (constants.discoveryStatus.inProgress === discoveryStatus) ||
                       (constants.discoveryStatus.inputValidationInProgress === preDiscoveryStatus) || 
                       (constants.discoveryStatus.inputValidationInProgress === discoveryStatus) ||
                       (constants.discoveryStatus.scheduled === preDiscoveryStatus) ||
                       (constants.discoveryStatus.scheduled === discoveryStatus))
                   allowDelete = false;
               
               return allowDelete;
           };
           
           self.hasJobStarted = function(jobId) {
               if(jobId && jobId !== "")
                   return true;
               return false;
           };
           
         
            self.startAnimationListener = function (event, ui)
            {
                popupHelper.startAnimationListener(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, event, ui);
            };

            self.confirmationPopupCloseHandler = function (data, event) {
                popupHelper.confmPopuCloseHandler(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, data, event);
            };
                  
            // Fetch image, title and alt based on discovery status
            self.getDiscoveryStatusBasedImage = function (preDiscoveryStatus, discoveryStatus) {
                var newPreDiscoveryStatus = !preDiscoveryStatus || preDiscoveryStatus === ""? constants.discoveryStatus.pending : preDiscoveryStatus; 
                newPreDiscoveryStatus = (constants.discoveryStatus.inputValidationInProgress === preDiscoveryStatus) ? constants.discoveryStatus.inProgress : preDiscoveryStatus;
                var newDiscoveryStatus = !discoveryStatus || discoveryStatus === ""? constants.discoveryStatus.pending : discoveryStatus; //not started
                newDiscoveryStatus = (constants.discoveryStatus.inputValidationInProgress === newDiscoveryStatus) ? constants.discoveryStatus.inProgress : newDiscoveryStatus;
                var overallStatus = newPreDiscoveryStatus + "_" + newDiscoveryStatus;
                var img = [];
                switch (overallStatus) {
                    case constants.discoveryStatus.completed + '_' + constants.discoveryStatus.completed:
                        img.alt = 'Successful';
                        img.title = 'Discovery Successful';
                        //img.image = "images/disc-register-complete-44x39.png";
                        img.image = "images/discovery-registration-complete.svg";
                        break;
                    case constants.discoveryStatus.completed + '_' + constants.discoveryStatus.failed:
                        img.alt = 'Failed';
                        img.title = 'Discovery Failed';
                        //img.image = "images/disc-register-failed-44x39.png";
                        img.image = "images/discovery-registration-failed.svg";
                        break;
                    case constants.discoveryStatus.completed + '_' + constants.discoveryStatus.aborted:
                        img.alt = 'Aborted';
                        img.title = 'Discovery Aborted';
                        //img.image = "images/disc-register-failed-44x39.png";
                        img.image = "images/discovery-registration-failed.svg";
                        break;
                    case constants.discoveryStatus.completed + '_' + constants.discoveryStatus.scheduled:
                        img.alt = 'Scheduled';
                        img.title = 'Discovery Scheduled';
                        //img.image = "images/disc-register-in-progress-44x39.png";
                        img.image = "images/discovery-registration-in-progress.svg";
                        break;
                    case constants.discoveryStatus.completed + '_' + constants.discoveryStatus.inProgress:
                        img.alt = 'In Progress';
                        img.title = 'Discovery In Progress';
                        //img.image = "images/disc-register-in-progress-44x39.png";
                        img.image = "images/discovery-registration-in-progress.svg";
                        break;
                    case constants.discoveryStatus.completed + '_' + constants.discoveryStatus.pending:
                        img.alt = 'Pending';
                        img.title = 'Discovery Pending';
                        //img.image = "images/disc-readiness-complete-44x39.png";
                        img.image = "images/discovery-readiness-complete.svg";
                        break;
                    case constants.discoveryStatus.failed + '_' + constants.discoveryStatus.pending:
                        img.alt = 'Failed';
                        img.title = 'PreDiscovery Failed';
                        //img.image = "images/disc-readiness-failed-44x39.png";
                        img.image = "images/discovery-readiness-failed.svg";
                        break;
                    case constants.discoveryStatus.aborted + '_' + constants.discoveryStatus.pending:
                        img.alt = 'Aborted';
                        img.title = 'PreDiscovery Aborted';
                        //img.image = "images/disc-readiness-failed-44x39.png";
                        img.image = "images/discovery-readiness-failed.svg";
                        break;
                    case constants.discoveryStatus.scheduled + '_' + constants.discoveryStatus.pending:
                        img.alt = 'Scheduled';
                        img.title = 'PreDiscovery Scheduled';
                        //img.image = "images/disc-readiness-in-progress-44x39.png";
                        img.image = "images/discovery-readiness-in-progress.svg";
                        break;
                    case constants.discoveryStatus.inProgress + '_' + constants.discoveryStatus.pending:
                        img.alt = 'In Progress';
                        img.title = 'PreDiscovery In Progress';
                        //img.image = "images/disc-readiness-in-progress-44x39.png";
                        img.image = "images/discovery-readiness-in-progress.svg";
                        break;
                    default:
                        //If none of the above status, show below default image
                        img.alt = 'Default';
                        img.title = 'Default';
                        //img.image = 'images/disc-readiness-in-progress-44x39.png';
                        img.image = "images/discovery-readiness-in-progress.svg";
                }
                return img;
            };
        
        self.loadDiscoveryJobs();

    }
    return discoveryModule;
});
