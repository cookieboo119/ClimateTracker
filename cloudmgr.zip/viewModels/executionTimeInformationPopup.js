/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * task log module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton'], function (oj, ko, actionsHelper, popupHelper, constants) {
    /**
     * The view model for the main content view template
     */
    function executionInformationPopupViewModel()
    {
        var self = this;
        
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        
        self.handleExecutionInformationPopupClose = function ()
        {
           
            var popup = document.querySelector(constants.divTags.executionTimeInformationPopup);
            popup.close();
        };

        self.handleExecutionInformationPopupOpen = function ()
        {
            var popup = document.querySelector(constants.divTags.executionTimeInformationPopup);
            popup.open(document.getElementById('execInfoPopupImg'));
           
        };

    }

    return executionInformationPopupViewModel;
});
