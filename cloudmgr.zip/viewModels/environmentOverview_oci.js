/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * environmentDetails module
 */
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper','ojs/ojasyncvalidator-numberrange', 'jquery', 'ojs/ojknockout', 'ojs/ojbutton', 'ojs/ojselectcombobox',
    'ojs/ojmenu', 'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojaccordion', 'ojs/ojoffcanvas',
    'ojs/ojpopup', 'ojs/ojmodule', 'ojs/ojarraytabledatasource', 'ojs/ojcollapsible', 'ojs/ojoffcanvas', 'ojs/ojinputnumber',
    'ojs/ojradioset', 'ojs/ojinputtext'
], function (oj, ko, constants, popupHelper, actionsHelper, AsyncNumberRangeValidator) {
    /**
     * The view model for the main content view template
     */
    function environmentOverviewContentViewModel() {

        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
        var envName = rootViewModel.currentEnvName();
        self.singleVM = rootViewModel.disableAdministrationTabForEnvionment();
        self.envDetailViewModule = ko.dataFor(document.getElementById('envDetailsPageTopDiv'));
        var appUrl = rootViewModel.url();

        var bearerToken = rootViewModel.authToken();
        if (bearerToken) {
            sessionStorage.setItem('bearerToken', bearerToken);
        } else {
            bearerToken = sessionStorage.getItem('bearerToken');
        }

        $.ajaxSetup({
            headers: {
                'Authorization': bearerToken
            },
            error: function (jxhr, event, data) {
                var status = jxhr.status;
                console.log('status ' + status);
                if (status === 401) {
                    oj.Router.rootInstance.go('login');
                }
            }
        });

        self.tracker = ko.observable();

        self.confirmDeleteMsg = ko.observable(oj.Translations.getTranslatedString("confirmPopup.deleteAppTierNodeConfirmMsg"));

        self.numOfAdditionalNodes = ko.observable('1');
        self.addlnNodeShapeValue = ko.observable('OC3 - 1.0 OCPU, 7.5 GB RAM');
        self.fileSystemModeValue = ko.observable('Shared');
        self.appsPassword = ko.observable('');
        self.weblogicPassword = ko.observable('');
        self.IPReservationsValue = ko.observable('N');
        self.IPReservationsDisabled = ko.observable(true);
        self.appTierIPResValue = ko.observable();
        self.appTierIPResList = ko.observableArray();

        self.shapeChoiceOptionsList = ko.observableArray([
            {shapeChoiceOptionValue: 'oc3', shapeChoiceOptionLabel: 'OC3 - 1.0 OCPU, 7.5 GB RAM'},
            {shapeChoiceOptionValue: 'oc4', shapeChoiceOptionLabel: 'OC4 - 2.0 OCPU, 15.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc5', shapeChoiceOptionLabel: 'OC5 - 4.0 OCPU, 30.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc6', shapeChoiceOptionLabel: 'OC6 - 8.0 OCPU, 60.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc7', shapeChoiceOptionLabel: 'OC7 - 16.0 OCPU, 120.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc1m', shapeChoiceOptionLabel: 'OC1m - 1.0 OCPU, 15.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc2m', shapeChoiceOptionLabel: 'OC2m - 2.0 OCPU, 30.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc3m', shapeChoiceOptionLabel: 'OC3m - 4.0 OCPU, 60.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc4m', shapeChoiceOptionLabel: 'OC4m - 8.0 OCPU, 120.0 GB RAM'},
            {shapeChoiceOptionValue: 'oc5m', shapeChoiceOptionLabel: 'OC5m - 16.0 OCPU, 240.0 GB RAM'}
        ]);

        self.IPReservationsOptionChanged = function (event, ui) {
            var value = ui['value'];
            if (value === 'Y') {
                self.IPReservationsDisabled(false);
                self.IPReservationsValue('Y');
            } else {
                self.IPReservationsDisabled(true);
                self.IPReservationsValue('N');
                self.appTierIPResValue('');
            }
        };

        self.invokeDeleteNodeConfirmationPopup = function (event, ui) {
            rootViewModel.currentAppNodeNameForDelete = '';
            var nameOfAppNode = '';
            if (event !== null && typeof (event.target) !== 'undefined' && typeof(event.target.id) !== 'undefined')
            {
                nameOfAppNode = event.target.id.substring(10);
            } 
            else
            {
                return;
            }
            rootViewModel.currentAppNodeNameForDelete = nameOfAppNode;
            var popup = document.querySelector(constants.divTags.deleteNodeConfirmationPopupTag);
            popup.open(event.target);
        };
        
        self.invokeAddNodePopup = function(event, ui)
        {
            var curZoneName = '';       
            var viewModelOfAddNodePopupModule = ko.dataFor(document.getElementById('addNodePopupRoot'));
            viewModelOfAddNodePopupModule.parentZoneData(''); //reset
            viewModelOfAddNodePopupModule.resetPopup();
            if (event !== null && typeof (event.target) !== 'undefined' && typeof(event.target.id) !== 'undefined')
            {
                curZoneName = event.target.id.substring(11);
            } 
            if(curZoneName == null || curZoneName == '') 
            {
                return;
            }
            
            //get zone data based on the zone name
            //var envDetailViewModule = ko.dataFor(document.getElementById('envDetailsPageTopDiv'));
            var logicalHostConfigured = self.envDetailViewModule.appsLogicalHostConfigured();
            if (logicalHostConfigured)
            {
                viewModelOfAddNodePopupModule.showLogicalHostname(true);
            } else
            {
                viewModelOfAddNodePopupModule.showLogicalHostname(false);
            }
            
            var zonesData = self.envDetailViewModule.zones();
            var curZone;
            if(zonesData)
            {
              //const matches = zonesData.filter(zone => zone.zoneName === curZoneName)
              const matches = zonesData.filter(function(zone){
                        return (zone.zoneName === curZoneName);
                    });
              if(matches && matches.length > 0)
              {
                  curZone = matches[0]; //only expect 1 matching zone
              }
            }
                          
            viewModelOfAddNodePopupModule.parentZoneData(curZone);
                        
            //check ebs version
            if (constants.ebsVersions.twelveone === self.envDetailViewModule.ebsVersion())
            {
                viewModelOfAddNodePopupModule.showWlsAdminPwd(false);
            } else
            {
                viewModelOfAddNodePopupModule.showWlsAdminPwd(true);
            }
            
            if(curZone)
            {   //set as default storage for now
                if(curZone.appsFileSystemMode === 'nonsfs')
                {
                  actionsHelper.getDefaultStorageForAppNode(envName, function (error, defaultStorage) 
                  {
                    if (error === '') 
                    {
                          var minBlockVolume = parseInt(defaultStorage.instanceBlockVolume);
                          viewModelOfAddNodePopupModule.baseVolumeSize(minBlockVolume);
                          viewModelOfAddNodePopupModule.enteredVolumeSize(minBlockVolume); 
                          viewModelOfAddNodePopupModule.openPopup(event, ui); 
                          console.log('Opened the Add Nodepopup!');
            
                    }
                  });
                }
                else
                {
                     viewModelOfAddNodePopupModule.baseVolumeSize(0);
                     viewModelOfAddNodePopupModule.enteredVolumeSize(0);
                     
                     viewModelOfAddNodePopupModule.openPopup(event, ui); 
                     console.log('Opened the Add Nodepopup!');
            
                }
            }

        };

        self.closeDeleteNodeConfirmationPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.deleteNodeConfirmationPopupTag);
            popup.close();
            rootViewModel.currentAppNodeNameForDelete = '';
        };
        
        self.deleteThisNodeFromListView = function(nodeNameToRemove){
           rootViewModel.currentAppNodeNameForDelete = '';
           /*var viewModelForAppNodes = ko.dataFor(document.getElementById('content'));
           var appNodesDO = viewModelForAppNodes.appTierNodes();
           var newListOfAppNodes = new Array();
           for(var i=0;i<appNodesDO.length;i++){
               var appNodeName = appNodesDO[i].nodeName;
               if(appNodeName === nodeNameToRemove){
                   
               }
               else{
                   newListOfAppNodes.push(appNodesDO[i]);
               }
           }
           viewModelForAppNodes.appTierNodes(newListOfAppNodes);*/
        };

        self.startAnimationListener = function (event, ui)
        {
            popupHelper.startAnimationListener(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.requestSubmittedConfirmationPopup_envDetailPG, data, event);
        };


        self.addNode = function (event, ui) {
            console.log("Adding apps tier node for env " + envName);
            var popup = document.querySelector('#addnodePopup');
            var trackerObj = self.tracker();
            trackerObj.showMessages();
            if (trackerObj.focusOnFirstInvalid()) {
                return;
            } else {
                //Invoke REST API to add node
                popup.close();
            }
        };

        self.startAnimationListener = function (data, event)
        {
            var ui = event.detail;
            if (!$(event.target).is("#addnodePopup"))
                return;

            if ("open" === ui.action)
            {
                event.preventDefault();
                var options = {"direction": "top"};
                oj.AnimationUtils.slideIn(ui.element, options).then(ui.endCallback);
            } else if ("close" === ui.action)
            {
                event.preventDefault();
                ui.endCallback();
            }
        };

    }



    return environmentOverviewContentViewModel;
});
