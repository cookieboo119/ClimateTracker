/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Review module
 */
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ojs/ojarraytreedataprovider', 'ebs/utils/createCloneTrainUtils', 'ojs/ojknockout', 'ojs/ojswitch', 'ojs/ojlabelvalue'
], function (oj, ko, constants, ArrayTreeDataProvider, createCloneTrainUtils) {
    /**
     * The view model for the main content view template
     */
    function ReviewContentViewModel() {
        var self = this;
        self.pageTitle = ko.observable(oj.Translations.getTranslatedString("confirmPopup.reviewEnvTitle"));
        self.pageSubTitle = ko.observable(oj.Translations.getTranslatedString("confirmPopup.reviewEnvSubTitle"));
        // Zones based UI.
        var trainElement = document.getElementById('train');
        self.isCreateEnvFlow = ko.observable(true); // For clone-standby and release-standby this will be treated equal to create for this module. 
        self.parentContainerViewModel = ko.observable('');
        self.tasksGrouping = ko.observableArray([]);
        self.customTasksExist = ko.observable(false);
        self.pausedTasksExist = ko.observable(false);
        self.nestedDataProvider = new ArrayTreeDataProvider(self.tasksGrouping, {keyAttributes: "name"});
        self.nestedDataProviderObservable = ko.observable(self.nestedDataProvider);
        self.pausedTasks = ko.observableArray([]);
        self.pausedTasksDataProvider = new ArrayTreeDataProvider(self.pausedTasks, {keyAttributes: "name"});
        self.pausedTasksDataProviderObservable = ko.observable(self.pausedTasksDataProvider);
        self.sshKeys_appTier = ko.observableArray([]);
        self.sshKeysDataProvider_appTier = new ArrayTreeDataProvider(self.sshKeys_appTier, {keyAttributes: "id"});
        self.sshKeysDataProviderObservable_appTier = ko.observable(self.sshKeysDataProvider_appTier);
        self.sshKeys_dbTier = ko.observableArray([]);
        self.sshKeysDataProvider_dbTier = new ArrayTreeDataProvider(self.sshKeys_dbTier, {keyAttributes: "id"});
        self.sshKeysDataProviderObservable_dbTier = ko.observable(self.sshKeysDataProvider_dbTier);
        self.sshKeysString_AppTier = ko.observable();
        self.sshKeysString_DBTier = ko.observable();
        self.sshKeyPresent_AppTier = ko.observable(false);
        self.sshKeyPresent_DBTier = ko.observable(false);
        self.firstStepHeader = ko.observable('create');
        self.startAppTierValue = ko.observable(false);
        self.dbLogicalFQDN = ko.observable();

        if (trainElement !== null)
        {
            self.parentContainerViewModel(ko.dataFor(trainElement));
        }

        self.isCloneEnvFlow = ko.observable(false);
        var cloneTrain = document.getElementById(constants.navModules.volumeCloneTrainModule);
        if (cloneTrain !== null)
        {
            self.isCreateEnvFlow(false);
            self.firstStepHeader('clone');
            self.isCloneEnvFlow(true);
            self.parentContainerViewModel(ko.dataFor(cloneTrain));
            self.pageTitle(oj.Translations.getTranslatedString("confirmPopup.reviewCloneEnvTitle"));
            self.pageSubTitle(oj.Translations.getTranslatedString("confirmPopup.reviewCloneEnvSubTitle"));
        }

        var releaseStandByEnvironmentTrain = document.getElementById('releaseStandByEnvironmentTrainElement');
        if (releaseStandByEnvironmentTrain !== null) {
            self.firstStepHeader('create');
            self.pageTitle(oj.Translations.getTranslatedString("confirmPopup.reviewReleaseStandByEnvTitle"));
            self.pageSubTitle(oj.Translations.getTranslatedString("confirmPopup.reviewReleaseStandByEnvSubTitle"));
        }

        var cloneStandByEnvironmentTrain = document.getElementById('cloneStandByEnvironmentTrainElement');
        if (cloneStandByEnvironmentTrain !== null) {
            self.firstStepHeader('clone');
            self.pageTitle(oj.Translations.getTranslatedString("confirmPopup.reviewCloneEnvTitle"));
            self.pageSubTitle(oj.Translations.getTranslatedString("confirmPopup.reviewCloneEnvSubTitle"));
        }

        self.reviewScreenUiSequence = ko.observable(0);
        self.zonesCleanedUpInReviewPG = false;
        self.reviewPGZoneContentModuleName = 'zoneModuleReview';
        //   if(self.parentContainerViewModel().dbLogicalHostNamePrefixValue() && self.parentContainerViewModel().dbLogicalDomainName())
        //      self.dbLogicalFQDN(self.parentContainerViewModel().dbLogicalHostNamePrefixValue().toLowerCase() + '.' + self.parentContainerViewModel().dbLogicalDomainName().toLowerCase());



        self.cleanupZoneInformationFromReviewScreen = function ()
        {
            self.zonesCleanedUpInReviewPG = false;
            var currentSequence = self.reviewScreenUiSequence();
            self.reviewScreenUiSequence(0); //reset sequence
            var cleaned = false;
            var reviewPGZonesRootContainer = document.getElementById('zoneReviewPGContainer');
            for (var i = 0; i < currentSequence; i++)
            {
                var containerElem = document.getElementById('reviewZoneInformation:' + i);
                if (containerElem !== null)
                {
                    reviewPGZonesRootContainer.removeChild(containerElem);
                    self.zonesCleanedUpInReviewPG = true;
                    cleaned = true;
                }
            }
            if (!cleaned)
            {
                self.zonesCleanedUpInReviewPG = false;
            }
        };

        self.prepareZoneInformationForReviewScreen = function ()
        {
            var topologyDetailsViewModel = ko.dataFor(document.getElementById('zonesListView'));
            self.startAppTierValue = topologyDetailsViewModel.startAppTier() ? 'Yes' : 'No';
            var zonesPostInformation = topologyDetailsViewModel.getZonePostData();
            var zonesLen = zonesPostInformation.length;

            var noOfZoneDetailChildren = document.getElementById('detailPageContainer').children.length;
            var detailChildContainer = document.getElementById('detailPageContainer');
            if (zonesLen !== noOfZoneDetailChildren)
            {
                console.log('Error in zone configuration/handling !');
            } else
            {
                var initialSequence = self.reviewScreenUiSequence();
                for (var i = 0; i < detailChildContainer.children.length; i++)
                {
                    var moduleHolder = detailChildContainer.children[i].children[0].children[0];
                    var viewModelOfDetailChild = ko.dataFor(moduleHolder);
                    console.log('View Model Of Detail Child => ' + typeof (viewModelOfDetailChild));
                    var containerElementForReviewSnippet = document.createElement('div');
                    var currentSequence = self.reviewScreenUiSequence();
                    containerElementForReviewSnippet.id = 'reviewZoneInformation:' + currentSequence;
                    var innerHTMLDataElement = document.createElement('div');
                    innerHTMLDataElement.innerHTML = "<div class=\"ebs-zone-border\" data-bind=\"ojModule:{name : reviewPGZoneContentModuleName, params:{index:" + currentSequence + ",initSeq:" + initialSequence + "}}\"></div>";
                    self.reviewScreenUiSequence(self.reviewScreenUiSequence() + 1);
                    containerElementForReviewSnippet.appendChild(innerHTMLDataElement);
                    document.getElementById('zoneReviewPGContainer').appendChild(containerElementForReviewSnippet);
                    if (self.zonesCleanedUpInReviewPG)
                    {
                        ko.applyBindings(self, containerElementForReviewSnippet);
                    }
                }
            }
        };
        self.prepareExecutionPlanDetailsInformation = function () {
            self.tasksGrouping([]);
            var viewModelOfExecPlanPG = ko.dataFor(document.getElementById('customTasksListingTab'));

            var viewModelOfTaskParamsForm = ko.dataFor(document.getElementById('taskParametersEntryForm'));
            if (typeof (viewModelOfExecPlanPG) !== 'undefined' && typeof(viewModelOfTaskParamsForm) !== 'undefined') {
                self.tasksGrouping(viewModelOfTaskParamsForm.tasksGrouping());

                if(self.tasksGrouping() !== null && self.tasksGrouping().length >0)
                   self.customTasksExist(true);
                else
                   self.customTasksExist(false);

                self.pausedTasks([]);
                var pausedTasksOrPhases = viewModelOfExecPlanPG.getAllPausedTasksOrPhaseLabels();
                var tempArray = new Array();
                if (pausedTasksOrPhases !== null && pausedTasksOrPhases.length > 0) {
                    self.pausedTasksExist(true);
                    for (var k = 0; k < pausedTasksOrPhases.length; k++) {
                        var pausedTaskOrPhase = pausedTasksOrPhases[k];
                        var pausedTaskOrPhaseUIObject = new Object();
                        pausedTaskOrPhaseUIObject.name = pausedTaskOrPhase;
                        tempArray.push(pausedTaskOrPhaseUIObject);

                    }
                    self.pausedTasks(tempArray);
                }
                else
                    self.pausedTasksExist(false);
            }
            else
            {
                self.customTasksExist(false);
                self.pausedTasksExist(false);
            }
        };

        self.prepareSSHKeysSection = function () {
            self.sshKeys_appTier([]);
            self.sshKeys_dbTier([]);
            self.sshKeyPresent_AppTier(false);
            self.sshKeyPresent_DBTier(false);

            var keyIndex = 0;
            var appTierkeysFound = false;
            var dbTierkeysFound = false;
            var appTierKeysArray = new Array();
            var dbTierKeysArray = new Array();
            var appTierSSHKeys = createCloneTrainUtils.getFormDataForAppTierSSHKeys();
            if (appTierSSHKeys !== null && appTierSSHKeys.length > 0) {
                for (var i = 0; i < appTierSSHKeys.length; i++) {
                    appTierkeysFound = true;
                    self.sshKeyPresent_AppTier(true);
                    var keyString = "User: " + appTierSSHKeys[i].osUserRole + ", Files: ";
                    var listOfFiles = appTierSSHKeys[i].fileNames;
                    for (var k = 0; k < listOfFiles.length; k++) {
                        keyString += listOfFiles[k] + ", ";
                    }
                    keyString = keyString.substring(0, keyString.length - 2);
                    var sshKeyUIObject = new Object();
                    sshKeyUIObject.id = keyIndex;
                    keyIndex++;
                    sshKeyUIObject.text = keyString;
                    appTierKeysArray.push(sshKeyUIObject);
                }
            }
            var dbTierSSHKeys = createCloneTrainUtils.getFormDataForDBTierSSHKeys();
            if (dbTierSSHKeys !== null && dbTierSSHKeys.length > 0) {
                for (var i = 0; i < dbTierSSHKeys.length; i++) {
                    dbTierkeysFound = true;
                    self.sshKeyPresent_DBTier(true);
                    var keyString = "User: " + dbTierSSHKeys[i].osUserRole + ", Files: ";
                    var listOfFiles = dbTierSSHKeys[i].fileNames;
                    for (var k = 0; k < listOfFiles.length; k++) {
                        keyString += listOfFiles[k] + ", ";
                    }
                    keyString = keyString.substring(0, keyString.length - 2);
                    var sshKeyUIObject = new Object();
                    sshKeyUIObject.id = keyIndex;
                    keyIndex++;
                    sshKeyUIObject.text = keyString;
                    dbTierKeysArray.push(sshKeyUIObject);
                }
            }

            self.sshKeysString_AppTier(oj.Translations.getTranslatedString("helpMsgs.SSHKeysToBeUploaded_appTier"));
            self.sshKeysString_DBTier(oj.Translations.getTranslatedString("helpMsgs.SSHKeysToBeUploaded_dbTier"));
            if (appTierkeysFound) {
                self.sshKeys_appTier(appTierKeysArray);
            } else {

            }
            if (dbTierkeysFound) {
                self.sshKeys_dbTier(dbTierKeysArray);
            } else {

            }
        };

        self.prepareDBTierInfo = function ()
        {
            var dbName = self.parentContainerViewModel().dbLogicalHostNamePrefixValue();
            var dbDomain = self.parentContainerViewModel().dbLogicalDomainName();
            if (self.isCloneEnvFlow() && !self.parentContainerViewModel().appsLogicalHostConfigured())
            {
                self.dbLogicalFQDN(constants.logicalHost.notAvailable);
            } else if (!dbName || dbName === '' || !dbDomain || dbDomain === '')
            {
                self.dbLogicalFQDN(constants.logicalHost.notAvailable);
            } else
            {
                self.dbLogicalFQDN(dbName.toLowerCase() + '.' + dbDomain.toLowerCase());
            }
        }

        self.handleAttached = function ()
        {
            console.log('Review Content View Model Attached.');
            self.prepareDBTierInfo();
            self.cleanupZoneInformationFromReviewScreen();
            self.prepareZoneInformationForReviewScreen();
            self.prepareExecutionPlanDetailsInformation();
            self.prepareSSHKeysSection();
        };

    }

    return ReviewContentViewModel;
});
