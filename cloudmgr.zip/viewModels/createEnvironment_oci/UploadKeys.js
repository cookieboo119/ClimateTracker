define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ojs/ojarraydataprovider', 'ebs/utils/lovUtils', 'jquery', 'ojs/ojinputtext', 'ojs/ojselectcombobox',
    'ojs/ojlistview', 'ojs/ojarraytabledatasource', 'ojs/ojinputnumber', 'ojs/ojbutton', 'ojs/ojfilepicker', 'ojs/ojmessages'
], function (oj, ko, constants, ArrayDataProvider, lovUtils) {
    function UploadKeysViewModel() {
        var self = this;
        console.log('Loading Upload Keys View Model .. ');
        self.acceptedExtensions = ko.observableArray([".pub"]);
        self.sequence = 0;
        self.prevSelectedDBOption = ko.observable();
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.columnsArray = [{"headerText": "Tier",
                "field": "tier",
                headerStyle: "font-weight: bold; text-align: left;",
                "template": "TierCellTemplate"},
            {"headerText": "OS User",
                headerStyle: "font-weight: bold;text-align: left;",
                "field": "user",
                "template": "OSUserCellTemplate"},
            {"headerText": "SSH Key",
                "field": "Key",
                headerStyle: "font-weight: bold;  text-align: left;",
                "template": "UploadKeysTemplate"},
            {"headerText": "File Name",
                "field": "fileName",
                headerStyle: "font-weight: bold;  text-align: left;",
                "template": "FileNameTemplate"},
            {"headerText": "Remove",
                "field": "",
                headerStyle: "font-weight: bold;  text-align: left;",
                "template": "DeleteCellTemplate"}];
        var keys = new Array();

        var tierOptions = new Array();
        tierOptions.push({
            'label': 'All Tiers',
            'value': 'ALL'
        });
        tierOptions.push({
            'label': 'Application Tier',
            'value': 'APP_TIER'
        });
        tierOptions.push({
            'label': 'Database Tier',
            'value': 'DB_TIER'
        });

        var tierOptionsForExa = new Array();
        tierOptionsForExa.push({
            'label': 'Application Tier',
            'value': 'APP_TIER'
        });

        var tierOptionsForSingleVM = new Array();
        tierOptionsForSingleVM.push({
            'label': 'Application Tier',
            'value': 'APP_TIER'
        });

        var osUserOptions = new Array();
        osUserOptions.push({
            'label': 'All Users',
            'value': 'ALL'
        });
        osUserOptions.push({
            'label': 'Operating System Administrator',
            'value': 'osadmin'
        });
        osUserOptions.push({
            'label': 'Application Administrator',
            'value': 'appsadmin'
        });

        self.users = ko.observableArray(osUserOptions);
        self.usersDataProvider = new ArrayDataProvider(self.users, {idAttribute: 'value'});
        self.addSSHKeyRow = function () {
            var row = new Object();
            row.id = self.sequence;
            row.tier = ko.observable();
            lovUtils.lovOptionsUpdated(self.tiers(), row.tier);
            row.user = ko.observable();
            lovUtils.lovOptionsUpdated(self.users(), row.user);
            row.key = ko.observable();
            row.fileName = ko.observable();
            row.IsValidFile = ko.observable(true);
            row.IsValidFileContent = ko.observable(true);
            self.keysObservableArray.push(row);
            self.sequence++;
        };

        self.keysObservableArray = ko.observableArray(keys);
        self.sshKeysDataProvider = new ArrayDataProvider(self.keysObservableArray, {idAttribute: 'id'});

        self.deleteKey = function (event) {
            var targetElem = event.target;
            if (targetElem !== null && typeof (targetElem.id) !== 'undefined' && targetElem.id !== null)
            {
                var tokens = targetElem.id.split('_');
                var index = tokens[1];
                var rowIndex = self.findRowIndexBySequence(parseInt(index));
                self.keysObservableArray.splice(rowIndex, 1);
            }
        };

        self.findRowIndexBySequence = function (seqNum) {
            for (var k = 0; k < self.keysObservableArray().length; k++) {
                var identifier = self.keysObservableArray()[k].id;
                if (identifier === seqNum) {
                    return k;
                }
            }
        };

        self.findRowBySequence = function (seqNum) {
            for (var k = 0; k < self.keysObservableArray().length; k++) {
                var identifier = self.keysObservableArray()[k].id;
                if (identifier === seqNum) {
                    return self.keysObservableArray()[k];
                }
            }
        };

        self.selectListener = function (event) {
            var seq = -1;
            var target = event.target || event.srcElement;
            var targetIdentifier = target.id;
            seq = targetIdentifier.split("_")[1];
            var row = self.findRowBySequence(parseInt(seq));
            row.IsValidFile(true);
            row.fileName('');
            row.key('');
            var fileName = event.detail.files[0].name;
            var fileNameTokens = fileName.split('.');
            if (fileNameTokens.length < 2) {
                row.IsValidFile(false);
                row.IsValidFileContent(false);
                row.fileName('');
                row.key('');
                return;
            } else {
                var lastToken = fileNameTokens[fileNameTokens.length - 1];
                if (lastToken !== 'pub' && lastToken !== 'PUB') {
                    row.IsValidFile(false);
                    row.IsValidFileContent(false);
                    row.fileName('');
                    row.key('');
                    return;
                }
            }
            self.readFile(event.detail.files[0], function (e) {
                row.IsValidFile(true);
                row.IsValidFileContent(true);
                row.fileName(fileName);
                row.key(e.target.result);

            });
        };

        self.isFormValid = function () {
            var isValid = true;
            var keysLength = self.keysObservableArray().length;
            for (var i = 0; i < keysLength; i++) {
                var key = self.keysObservableArray()[i];
                var validFile = key.IsValidFile();
                var validFileContent = key.IsValidFileContent();
                if (!validFile || !validFileContent) {
                    return false;
                }
            }
            return isValid;
        };

        self.readFile = function (file, onLoadCallback) {
            var reader = new FileReader();
            reader.onload = onLoadCallback;
            var start = 0;
            var stop = file.size - 1;
            var blob = file.slice(start, stop + 1);
            reader.readAsText(file);
        };

        self.initializeOptions = function () {
            var createTrainIdentifier = document.getElementById('train');
            if (createTrainIdentifier !== null) {
                var viewModelForCreateFlowMain = ko.dataFor(createTrainIdentifier);
                var dbTypeUsed = viewModelForCreateFlowMain.dbTypeUsed();
                var deploymentType = viewModelForCreateFlowMain.deploymentType();
                if ('SingleVM' === deploymentType) {
                    self.tiers = ko.observableArray(tierOptionsForSingleVM);
                } else if ('Exadata System' === dbTypeUsed) {
                    self.tiers = ko.observableArray(tierOptionsForExa);
                    self.tiersDataProvider = new ArrayDataProvider(self.tiers, {idAttribute: 'value'});
                } else {
                    self.tiers = ko.observableArray(tierOptions);
                    self.tiersDataProvider = new ArrayDataProvider(self.tiers, {idAttribute: 'value'});
                }
                self.prevSelectedDBOption(dbTypeUsed);
            } else {
                self.tiers = ko.observableArray(tierOptions);
                self.tiersDataProvider = new ArrayDataProvider(self.tiers, {idAttribute: 'value'});
            }
        };

        self.reInit = function () {
            var createTrainIdentifier = document.getElementById('train');
            var viewModelForCreateFlowMain = ko.dataFor(createTrainIdentifier);
            var dbTypeUsed = viewModelForCreateFlowMain.dbTypeUsed();
            if (dbTypeUsed === self.prevSelectedDBOption()) {
                // No need to initialize again.
            } else {
                self.tiers([]);
                self.tiersDataProvider = new ArrayDataProvider(self.tiers, {idAttribute: 'value'});
                self.keysObservableArray([]);
                self.initializeOptions();
            }
        };

        self.initializeOptions();
    }
    return UploadKeysViewModel;
});
