define(['ojs/ojcore', 'knockout', 'ebs/utils/deepLinkUtils', 'ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojknockout-validation'
], function (oj, ko, deepLinkUtils) {
    function loginContentViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
        var appUrl = rootViewModel.url();
        self.authURL = ko.observable(appUrl + 'cm/auth/validate');

        var url = location.search;
        var cookies = document.cookie;
        var cookieAvailable = false;
        var cookiesArray = cookies.split(';');
        for (var i = 0; i < cookiesArray.length; i++) {
            cookiesArray[i] = cookiesArray[i].trim();
            var cookieKeyValue = cookiesArray[i].split('=');
            if (cookieKeyValue[0] === 'idcs_user_assertion') {
                var cookieValue = cookieKeyValue[1];
                rootViewModel.authToken('Bearer ' + cookieValue);
                cookieAvailable = true;
                break;
            }
        }
        
        // If initialPage param exist in url, then fetch all url and set in local storage
        if (typeof deepLinkUtils.getUrlVars()['initialPage'] !== 'undefined') {
            // activity details page
            localStorage.setItem("jobIdParam", deepLinkUtils.getUrlVars()['jobId']);

            // environment details page
            localStorage.setItem("initialPageParam", deepLinkUtils.getUrlVars()['initialPage']);
            localStorage.setItem("initialTabParam", deepLinkUtils.getUrlVars()['initialTab']);
            localStorage.setItem("standByNameParam", deepLinkUtils.getUrlVars()['standByName']);
        }
        
        if (cookieAvailable) {
            $.ajax({
                type: "GET",
                url: appUrl + "ebs/user",
                async: false,
                headers: {
                    'Authorization': rootViewModel.authToken()
                },
                success: function (response, status, xhr) {
                    var httpStatus = xhr.status;
                    console.log("http status of userprofile is " + httpStatus);
                    //var apiKeySet = response.apiKeySet;
                    //if (apiKeySet === false || typeof apiKeySet === 'undefined') {
                    var isValidUser = response.isSSHKeysValid;
                    if (isValidUser === false || typeof isValidUser === 'undefined') {    
                        oj.Router.rootInstance.go('accountDetails_oci');
                    } else {
                        rootViewModel.tenancyNameValue(response.tenancyName);
                        rootViewModel.tenancyOCID(response.tenancyOCID);
                        rootViewModel.selectedRegionValue(response.region);
                        rootViewModel.userOCID(response.userOCID);
                        rootViewModel.username(response.username);
                        rootViewModel.fingerprint(response.fingerprint);
                        rootViewModel.isKeyValid(response.isSSHKeysValid);
                        //rootViewModel.apiKeySet(response.apiKeySet);

                        //If isAdmin is empty or null, assigning false
                        var isAdmin = (response.isAdmin === null || response.isAdmin === '') ? false : JSON.stringify(response.isAdmin);
                        console.log("isAdmin ::--" + isAdmin);
                        sessionStorage.setItem('cmAdmin', isAdmin);
                        oj.Router.rootInstance.go('landingModule_oci');
                    }
                },
                error: function (jxhr, event, data) {
                    var httpStatus = jxhr.status;
                    console.log("http status of user profile is " + httpStatus);
                    if (httpStatus === 401) {
                        window.location.replace(self.authURL());
                    }
                    oj.Router.rootInstance.go('accountDetails_oci');
                }
            });
        } else {
            // when we are in the activity details 
            var lastSelectedTab = sessionStorage.getItem('lastSelectedChildRouterFromLandingPage');
            if (lastSelectedTab !== null && "activityDetails_oci" === lastSelectedTab) {
                sessionStorage.removeItem('lastSelectedChildRouterFromLandingPage');
            }
            window.location.replace(self.authURL());
        }

        //cleanup session info
        sessionStorage.removeItem('lastSelectedCompartmentId');
        sessionStorage.removeItem('lastSelectedChildRouterFromLandingPage');
        sessionStorage.removeItem('isMenuInOpenState');
    }
    
    return loginContentViewModel;
});
