/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * GetAllQuotes - This class makes a getallquotes request for one minute interval.
 * It ensures that the request is being made for a weekday. This is followed by retrieve
 * getallquotes request to display data.
 */

package com.bloomberg.datalic.dlws;

import java.util.Calendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.AllQuotesInstrumentData;
import com.bloomberg.datalic.dlws.stubs.DateTimeRange;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.QRMQuote;
import com.bloomberg.datalic.dlws.stubs.QRMQuoteData;
import com.bloomberg.datalic.dlws.stubs.QuotesHeaders;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetAllQuotesRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetAllQuotesResponse;

public class GetAllQuotes {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            QuotesHeaders headers = new QuotesHeaders();
            headers.setProgramflag(programFlag);

            // Get nearest weekday
            Calendar calendar1 = Calendar.getInstance();
            calendar1.add(Calendar.DAY_OF_MONTH, -1);
            int dayOfWeek = calendar1.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == Calendar.SATURDAY) {
                calendar1.add(Calendar.DAY_OF_MONTH, -1);
            } else if (dayOfWeek == Calendar.SUNDAY) {
                calendar1.add(Calendar.DAY_OF_MONTH, -2);
            }
            calendar1.set(Calendar.HOUR_OF_DAY, 10);
            calendar1.set(Calendar.MINUTE, 10);
            calendar1.set(Calendar.SECOND, 0);

            // 1 minute's worth of ticks
            Calendar calendar2 = (Calendar) calendar1.clone();
            calendar2.set(Calendar.MINUTE, 11);

            XMLGregorianCalendar start = DatatypeFactory.newInstance().newXMLGregorianCalendar();
            start.setDay(calendar1.get(Calendar.DATE));
            // Adjust month value since 'Calendar' month value is 0-based,
            // example: 0 for January,
            // whereas 'XMLGregorianCalendar' month value is between 1 to 12.
            start.setMonth(calendar1.get(Calendar.MONTH) + 1);
            start.setYear(calendar1.get(Calendar.YEAR));
            start.setHour(calendar1.get(Calendar.HOUR));
            start.setMinute(calendar1.get(Calendar.MINUTE));
            start.setSecond(calendar1.get(Calendar.SECOND));

            XMLGregorianCalendar end = DatatypeFactory.newInstance().newXMLGregorianCalendar();
            end.setDay(calendar2.get(Calendar.DATE));
            end.setMonth(calendar2.get(Calendar.MONTH) + 1);
            end.setYear(calendar2.get(Calendar.YEAR));
            end.setHour(calendar2.get(Calendar.HOUR));
            end.setMinute(calendar2.get(Calendar.MINUTE));
            end.setSecond(calendar2.get(Calendar.SECOND));

            DateTimeRange dateTimeRange = new DateTimeRange();
            dateTimeRange.setStartDateTime(start);
            dateTimeRange.setEndDateTime(end);
            dateTimeRange.setRegion("NY");

            headers.setDatetimerange(dateTimeRange);

            // Setting instruments
            Instrument ticker = new Instrument();
            ticker.setId("IBM US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.EQUITY);
            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);

            // Construct and submit getallquotes request
            System.out.println("Sending submit getallquotes request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetAllQuotesRequest(headers, instruments, statusCode, requestId, responseId);
            System.out.println("Submit getallquotes request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve getallquotes
            RetrieveGetAllQuotesRequest rtvGetAllQuotesReq = new RetrieveGetAllQuotesRequest();
            rtvGetAllQuotesReq.setResponseId(responseId.value);
            RetrieveGetAllQuotesResponse rtvGetAllQuotesResp;
            System.out.println("Sending retrieve getallquotes request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetAllQuotesResp = ps.retrieveGetAllQuotesResponse(rtvGetAllQuotesReq);
            } while (rtvGetAllQuotesResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetAllQuotesResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve getallquotes request successful for responseId: "
                        + rtvGetAllQuotesResp.getResponseId());
                for (AllQuotesInstrumentData allQuotesInstrumentData : rtvGetAllQuotesResp
                        .getInstrumentDatas().getInstrumentData()) {
                    System.out.println("Data for "
                            + allQuotesInstrumentData.getInstrument().getId() + " "
                            + allQuotesInstrumentData.getInstrument().getYellowkey() + ":");
                    for (QRMQuote qrmQuote : allQuotesInstrumentData.getQuotes().getQuote()) {
                        for (QRMQuoteData qrmQuoteData : qrmQuote.getMatchedQuote()) {
                            System.out.println("  type = " + qrmQuoteData.getType() + ", price = "
                                    + qrmQuoteData.getPrice() + ", volume = "
                                    + qrmQuoteData.getVolume());
                        }
                    }
                }
            } else if (rtvGetAllQuotesResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
