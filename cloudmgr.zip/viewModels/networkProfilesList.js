/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * The view model is for the network profile listing page.
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/utils/dateTimeHelper', 'ebs/utils/userRole', 'ebs/utils/compartmentUtils', 
    'jquery', 'ojs/ojknockout', '', 'ojs/ojmenu', 'ojs/ojrouter', 'ojs/ojpopup', 'ojs/ojlistview',
    'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojoffcanvas', 'ojs/ojmodule', 'ojs/ojtrain', 'ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojselectcombobox', 'ojs/ojdialog',
    'ojs/ojarraytabledatasource', 'ojs/ojinputtext', 'ojs/ojcollectiontabledatasource', 'ojs/ojselectcombobox', 'ojs/ojoffcanvas', 'ojs/ojjsontreedatasource', 'ojs/ojlistitemlayout', 'ojs/ojinputsearch'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper, constants, dateTimeHelper, userRole, compartmentUtils) {
    /**
     * The view model for the main content view template
     */
    function networkProfilesListViewModel() {
        var self = this;
        console.log('Inside Network Profile List View');
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.networkProfiles'));
        rootViewModel.showContextHeader(false);
        rootViewModel.showNavTab(true);

        // Check if the user is not an admin, disable all the actions
        self.isAdminUser = userRole.isAdminUser();

        $(document).ready(function () {
            var displayPopupId = rootViewModel.displayPopupId();
            if (displayPopupId !== '') {
                $(constants.divTags.activityConfPopupTag).ojPopup('open', constants.divTags.rootBodyDivTag);
                rootViewModel.displayPopupId('');
            }
        });

        self.networkListLoaded = ko.observable(false);
        self.networkList = ko.observableArray();
        self.datasourceForNetwork = new oj.ArrayTableDataSource(self.networkList, {idAttribute: 'name'});
        self.dataSource = ko.observable();
        self.selectedListItem = ko.observable();

        self.loadNetworks = function (compartmentId) {
            if (document.getElementById('filterNetworkName') != null)
            {
                document.getElementById('filterNetworkName').value = '';
            }
            self.networkListLoaded(false);
            compartmentId = compartmentUtils.getCurrentSelectedCompartmentId(compartmentId);
            actionsHelper.getNetworkProfiles(compartmentId, function (error, networkProfile) {
                self.networkListLoaded(true);
                if (error === '') {
                    self.networkList([]);
                    // Iteration network profile response and setting date in GMT format
                    $.each(networkProfile, function () {
                        var network = {
                            name: this.name,
                            description: this.description,
                            ebsCompartment: this.ebsCompartment,
                            networkCompartment: this.networkCompartment,
                            region: this.region,
                            vcn: this.vcn,
                            availabilityDomain: this.availabilityDomain,
                            creationDate: dateTimeHelper.convertToUTC(this.creationDate),
                            status: this.status,
                            isDefault: this.isDefault
                        };
                        self.networkList.push(network);
                    });
                } else {
                    console.log("Error while loading network profiles.. ");
                    console.log("Error code : " + error.status + " Error Message : " + error.responseText);
                }
            });
        };

        // dynamic menu   
        self.menuOptions = ko.observableArray([]);
        self.currentMenuNetworkProfileName = ko.observable();
        // This is called before-menu-open so you can gather data from selected item.
        self.setupMenuOptions = function (event) {
            var target = event.detail.originalEvent.target;
            var context = document.getElementById('listview').getContextByNode(target);
            var key = null; //key: networkProfileName
            var index = -1; //index: row index in listview
            if (context) {
                index = context.index;
                key = context.key;
                // Setting the correct network profile name of the current row
                self.currentMenuNetworkProfileName(key);
            }
            self.getMenuItems(index, key);
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        }
        
        var resubmitEnabled = {id: constants.contextMenu.resubmit, label: oj.Translations.getTranslatedString('contextMenu.resubmit'), disabled: false};
        var resubmitDisabled = {id: constants.contextMenu.resubmit, label: oj.Translations.getTranslatedString('contextMenu.resubmit'), disabled: true};
        var deleteEnabled = {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.deleteNetworkProfile'), disabled: false};
        var deleteDisabled = {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.deleteNetworkProfile'), disabled: true};
        
        var actionsMap = [];
        actionsMap['resubmitEnabled'] = resubmitEnabled;
        actionsMap['resubmitDisabled'] = resubmitDisabled;
        actionsMap['deleteEnabled'] = deleteEnabled;
        actionsMap['deleteDisabled'] = deleteDisabled;
        
        // This is called from inside of the setupMenuOptions method to actually build the menu options from the data
        self.getMenuItems = function (index, networkName) {
            $.each(self.networkList(), function (i, value) {
                var networkProfileData = value;
                if (networkProfileData.name === networkName) {
                    var isDefault = networkProfileData.isDefault;
                    var status = networkProfileData.status;
                    
                    var actionsMenu = [];
                    if(self.isAdminUser){
                        if(isDefault === true || status === 'IN-PROGRESS'){
                            actionsMenu.push(actionsMap['resubmitDisabled']); 
                            actionsMenu.push(actionsMap['deleteDisabled']); 
                        }
                        if(isDefault !== true){
                            if(status === 'ACTIVE'){
                                actionsMenu.push(actionsMap['resubmitDisabled']); 
                                actionsMenu.push(actionsMap['deleteEnabled']); 
                            }
                            if(status !== 'ACTIVE' &&  status !== 'IN-PROGRESS'){
                                actionsMenu.push(actionsMap['resubmitEnabled']); 
                                actionsMenu.push(actionsMap['deleteEnabled']); 
                            }
                        }
                    }
                    
                    if (actionsMenu)
                        self.menuOptions(actionsMenu);

                    return false; //break the loop
                }
            });
            return;
        }

        self.networkActionMenuType = ko.observable();
        var lastSelectedCompartment = sessionStorage.getItem('lastSelectedCompartmentId');
        if (lastSelectedCompartment !== null)
        {
            self.loadNetworks(lastSelectedCompartment);
        } else
            self.loadNetworks('All');
        //self.loadNetworks();
        self.confirmDeleteMsg = ko.observable();
        self.dataSource(self.datasourceForNetwork);

        var name;
        self.networkProfilesActionsHandler = function (event, ui) {

            var localName = self.currentMenuNetworkProfileName();
            if (!localName)
                localName = self.selectedListItem()[0];
            
            name = localName ? localName : name;
            var actionTriggered = event.target.id;
            console.log('Network name --' + name + ' Action Triggered --' + actionTriggered);
            if (name !== null && name !== '' && actionTriggered === constants.contextMenu.delete) {
                console.log('Triggering delete action..');
                self.confirmDeleteMsg(oj.Translations.getTranslatedString("confirmPopup.deleteNetworkAssertMsg", {networkName: name}));
                var popup = document.querySelector(constants.divTags.networkListDelPopupTag);
                popup.open(event.target);
            } else if (name !== null && name !== '' && actionTriggered === constants.contextMenu.manageGroupAccess) {
                console.log('Triggering Manage Access action..');
                // var context = ko.contextFor(document.getElementById(constants.divTags.cloudMgrAdministrationSubTabIdentifier));
                var context = ko.contextFor(document.getElementById(constants.divTags.networkProfilesListPage));
                rootViewModel.currentNetworkName(name);
                rootViewModel.prevNetworkDetailsNavItem(constants.navModules.networkGroupAssignmentModule);
                pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileDetailsModule, '');
            } else if (name !== null && name !== '' && actionTriggered === constants.contextMenu.resubmit) {
                console.log('Triggering Resubmit Profile action..');
                rootViewModel.updateNetworkProfileFlow(true);
                rootViewModel.currentNetworkName(name);
                //var context = ko.contextFor(document.getElementById(constants.divTags.cloudMgrAdministrationSubTabIdentifier));
                var context = ko.contextFor(document.getElementById(constants.divTags.networkProfilesListPage));
                // context.$parent.showNavTab(false);  //comment out for menu change
                rootViewModel.showNavTab(false);
                pageNavigationHelper.navigateToPage(context, constants.navModules.createNetworkProfiletModule, '', false);
            }
        };

        var selectedNetworkName;
        self.selectionChanged = function (event, ui) {
            var currentSelectedItem = self.selectedListItem()[0];
            selectedNetworkName = currentSelectedItem ? currentSelectedItem : selectedNetworkName;
        };

        self.searchText = ko.observable('');
        self.handleSearchTextChange = function(event, ui)
        {
           event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleSearchCriteria(event, ui);
            }
        };
        self.handleSearchCriteria = function (event) {
            var filter = self.searchText();
            if (filter.length === 0) {
                self.dataSource(self.datasourceForNetwork);
            } else {
                if (self.filteredDataSource === undefined) {
                    self.collection = self.flattenArrayDS(self.networkList());
                    self.filteredCollection = self.collection.clone();
                    self.filteredDataSource = new oj.CollectionTableDataSource(self.filteredCollection);
                }
                var ret = self.collection.where({name: {value: filter, comparator: self.genericFilter}});
                self.filteredCollection.reset(ret);
                if (self.dataSource() === self.datasourceForNetwork) {
                    self.dataSource(self.filteredDataSource);
                }
            }
        };

        self.genericFilter = function (model, attr, value) {
            var name = (model.get('name')) ? model.get('name') : '';
            var ebsCompartment = (model.get('ebsCompartment')) ? model.get('ebsCompartment') : '';
            var networkCompartment = (model.get('networkCompartment')) ? model.get('networkCompartment') : '';
            var region = (model.get('region')) ? model.get('region') : '';
            var vcn = (model.get('vcn')) ? model.get('vcn') : '';
            var availabilityDomain = (model.get('availabilityDomain')) ? model.get('availabilityDomain') : '';
            var creationDate = (model.get('creationDate')) ? model.get('creationDate') : '';
            return ((name.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (ebsCompartment.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (networkCompartment.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (region.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (vcn.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (availabilityDomain.toLowerCase().indexOf(value.toLowerCase()) > -1) ||
                    (creationDate.toLowerCase().indexOf(value.toLowerCase()) > -1)
                    );
        };

        self.flattenArrayDS = function (data) {
            var collection = new oj.Collection();
            for (var i = 0; i < data.length; i++) {

                collection.add(data[i]);
            }
            return collection;
        };

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.networkProfileConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.networkProfileConfPopupTag, data, event);
        };

        self.deleteNetworkProfile = function (event, ui) {
            var popup = document.querySelector(constants.divTags.networkListDelPopupTag);
            popup.close();
            self.selectedListItem([]);
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteNetworkInfoMsg", {'networkName': name});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.delNetworkTitle");
            popupHelper.openInfoMsg(constants.divTags.networkProfileConfPopupTag, infoMsg, msgOrigin);

            actionsHelper.deleteNetworkProfile(name, function (error, success) {
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteNetworkConfirmMsg", {'networkName': name});
                    popupHelper.openSuccessMsg(constants.divTags.networkProfileConfPopupTag, successMsg, msgOrigin);
                    self.loadNetworks();
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.networkProfileConfPopupTag, response.message, msgOrigin);
                }
            });
        };

        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.networkListDelPopupTag);
            popup.close();
        };

        self.gotoNetworkDetails = function (isDefault, event) {
            oj.Router.rootInstance.store(event.name);
            rootViewModel.currentNetworkName(event.name);
            rootViewModel.isDefaultNetworkProfile(isDefault);
            // var context = ko.contextFor(document.getElementById(constants.divTags.cloudMgrAdministrationSubTabIdentifier));
            var context = ko.contextFor(document.getElementById(constants.divTags.networkProfilesListPage));
            pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileDetailsModule, constants.navModules.networkProfileDetailsModule);

        };

        self.createNetworkProfile = function (event, ui)
        {
            var createNetworkProfileOption = event.target.value;
            //var context = ko.contextFor(document.getElementById(constants.divTags.cloudMgrAdministrationSubTabIdentifier)); //comment out for menu chnage
            var context = ko.contextFor(document.getElementById(constants.divTags.networkProfilesListPage));
            // context.$parent.showNavTab(false);
            rootViewModel.showNavTab(false);
            pageNavigationHelper.navigateToPage(context, constants.navModules.createNetworkProfiletModule, '', false);
            //var topMenu = ko.dataFor(document.getElementById(constants.divTags.cloudMgrTopLevelMenuIdentifier));
            //topMenu.selectedNavItem(constants.navModules.cloudManagerAdministrationModule); //menu change
        };
    }
    return networkProfilesListViewModel;
});