/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * volumeClone module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/navigation/pageNavigationHelper', 'ojs/ojvalidator-regexp', 'ojs/ojasyncvalidator-numberrange',
    'ojs/ojarraydataprovider', 'ebs/utils/createCloneTrainUtils', 'jquery', 'ojs/ojmenu', 'ojs/ojpopup', 'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojselectcombobox', 'ojs/ojinputtext',
    'ojs/ojknockout-validation', 'ojs/ojradioset', 'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojmodule', 'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojcheckboxset'
], function (oj, ko, actionsHelper, popupHelper, constants, pageNavigationHelper, RegExpValidator, AsyncNumberRangeValidator, ArrayDataProvider, createCloneUtils) {
    /**
     * The view model for the main content view template
     */
    function volumeCloneContentViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
        rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.cloneEnvPageHeader'));
        var envName = rootViewModel.cloneSourceEnv();
        rootViewModel.showNavTab(false);
        var showCloneWlsAdminPwd = rootViewModel.showCloneWlsAdminPwd();

        self.environmentDetails = null;
        self.title = ko.observable('Clone Environment ' + envName);
        self.modulePath = ko.observable('volumeCloneChild_oci');
        self.prevPage = ko.observable('Environments');
        self.showVolCloneWlsAdminPwd = ko.observable(showCloneWlsAdminPwd === 'Yes' ? true : false);
        var _index = 0;
        self.additionalTags = ko.observableArray([
            {type: ["None"], tagKeyText: "", tagKeySelect: "", tagValue: "", tagValueSelect: "", id: _index++}]);



        self.handleBackLink = function (event, ui) {
            var context = ko.contextFor(document.getElementById(constants.divTags.envClonePage));
            pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
        };

        self.lbaasSelectionChanged = function (event) {
            console.log("LBAAS selection changed!");
            self.webEntryProtocolInputValue('https');
        };

        self.getParentTrainViewModel = function () {
            var cloneTrainElement = document.getElementById('volumeCloneTrain');
            if (cloneTrainElement !== null) {
                return ko.dataFor(cloneTrainElement);
            }
            var cloneStandByTrainElement = document.getElementById('cloneStandByEnvironmentTrainElement');
            if (cloneStandByTrainElement !== null) {
                return ko.dataFor(cloneStandByTrainElement);
            }
            var releaseStandByTrainElement = document.getElementById('releaseStandByEnvironmentTrainElement');
            if (releaseStandByTrainElement !== null) {
                return ko.dataFor(releaseStandByTrainElement);
            }
        };

        self.validateEntries = function () {
            var invalidsPresent = false;
            var envName = document.getElementById('envName');
            var appsPassword = document.getElementById('appsPassword');
            var wlsPassword = document.getElementById('wlsPassword');
            var tagKeyText = document.getElementById("tagKeyText0");
            var parentTrainViewModel = self.getParentTrainViewModel();

            if (parentTrainViewModel.networkName() === 'loading...' || parentTrainViewModel.networkName() === '')
            {
                invalidsPresent = true;
            }

            if (showCloneWlsAdminPwd === 'Yes') {
                if (wlsPassword.valid !== 'valid') {
                    wlsPassword.showMessages();
                }
            }


            if (envName.valid !== 'valid'
                    || appsPassword.valid !== 'valid'
                    ) {
                envName.showMessages();
                appsPassword.showMessages();
                invalidsPresent = true;
            }

            if (null !== tagKeyText && tagKeyText.valid !== 'valid') {
                tagKeyText.showMessages();
                invalidsPresent = true;
            }

            return invalidsPresent;
        };

        self.selectedTagNamespace = ko.observable('');
        self.selectedTagKeyText = ko.observable('');
        self.selectedTagKeySelect = ko.observable('');
        self.selectedTagValue = ko.observable('');

        var loading = oj.Translations.getTranslatedString('info.loading');
        self.tagNamespaceOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
        self.tagNamespaceOptionsDataProvider = new ArrayDataProvider(self.tagNamespaceOptionsList, {idAttribute: 'value'});
        self.tagKeyOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);
        self.tagKeyList = ko.observableArray([{'label': loading, 'value': ''}]);
        self.tagValueOptionsList = ko.observableArray([{'label': loading, 'value': ''}]);

        // Observable variable to show and hide tag key as textfield or combobox
        self.showTagText = ko.observable(true);
        self.showTagTextValue = ko.observable(true);

        // On change of tag namespace
        self.changeTagNamespace = function (event, current) {
            self.tagKeyOptionsList([]);
    
            if (self.tagKeyList().length > 0) {
                var returnKeysValues = createCloneUtils.changeTagNamespace(event, current, self.tagKeyList());
                if (returnKeysValues === "textfield") {
                    self.showTagText(true);
                } else {
                    self.showTagText(false);
                    self.tagKeyOptionsList(returnKeysValues);
                    // Set default value as first option of the options
                    self.selectedTagKeySelect(self.tagKeyOptionsList()[0].value);
                }
            }
        };
    
        // On change of tag key
        self.changeTagKey = function (event, current) {
            self.selectedTagValue('');
            if (self.tagKeyOptionsList().length > 0) {
                var returnKeysValues = createCloneUtils.changeTagKey(event, self.tagKeyOptionsList());
                if (returnKeysValues === "textfield") {
                    self.showTagTextValue(true);
                } else {
                    self.showTagTextValue(false);
                    self.tagValueOptionsList(returnKeysValues);
                    self.selectedTagValue(self.tagValueOptionsList()[0].value);
                }
            }
        }

        // Env name validation
        self.envNameValidator = ko.observableArray(
                [new RegExpValidator(
                            {pattern: '^[a-zA-Z]([a-zA-Z0-9]){1,19}$',
                                label: 'IPv4CIDR',
                                messageDetail: oj.Translations.getTranslatedString('validationMsgs.cloneEnvNameMsg')
                            })]);

        // Port number validation
        self.portNumberValidator = [
            new AsyncNumberRangeValidator({
                min: 1, max: 65534,
                hint: {inRange: oj.Translations.getTranslatedString('validationMsgs.portNumberMsg')}
            })];

        //remove white space for tag value
        self.changeTagValue = function (event, current) {
            self.selectedTagValue(event.detail.value ? event.detail.value.trim() : event.detail.value);
        };
    }

    return volumeCloneContentViewModel;
});
