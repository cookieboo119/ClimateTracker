/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/* GetHistoryMacro - This class submits a gethistory request by specifying
 * the instruments as macros and fields for the request parameters. This is followed
 * by retrieve gethistory response to get the data for the fields.
 * This class also illustrates handling invalid macros in the response.
 */

package com.bloomberg.datalic.dlws;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.DateRange;
import com.bloomberg.datalic.dlws.stubs.Duration;
import com.bloomberg.datalic.dlws.stubs.Fields;
import com.bloomberg.datalic.dlws.stubs.GetHistoryHeaders;
import com.bloomberg.datalic.dlws.stubs.HistInstrumentData;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.Macro;
import com.bloomberg.datalic.dlws.stubs.MacroType;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.PrimaryQualifier;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetHistoryRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetHistoryResponse;
import com.bloomberg.datalic.dlws.stubs.SecondaryQualifier;
import com.bloomberg.datalic.dlws.stubs.SecondaryQualifierOperator;
import com.bloomberg.datalic.dlws.stubs.SecondaryQualifierType;

public class GetHistoryMacro {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            GetHistoryHeaders headers = new GetHistoryHeaders();
            headers.setProgramflag(programFlag);
            DateRange dateRange = new DateRange();
            Duration duration = new Duration();
            duration.setDays(3);
            dateRange.setDuration(duration);
            headers.setDaterange(dateRange);

            // Setting macro for the instrument
            PrimaryQualifier primaryQualifier = new PrimaryQualifier();
            primaryQualifier.setPrimaryQualifierType(MacroType.SECTYP);
            primaryQualifier.setPrimaryQualifierValue("OPT_CHAIN");
            Macro macro1 = new Macro();
            macro1.setPrimaryQualifier(primaryQualifier);
            SecondaryQualifier secondaryQualifier = new SecondaryQualifier();
            secondaryQualifier = new SecondaryQualifier();
            secondaryQualifier.setSecondaryQualifierOperator(SecondaryQualifierOperator
                    .fromValue("Equals"));
            secondaryQualifier.setSecondaryQualifierType(SecondaryQualifierType.TICKER);
            secondaryQualifier.setSecondaryQualifierValue("AAPL US Equity");
            macro1.getSecondaryQualifier().add(secondaryQualifier);

            // Setting an incorrect macro
            PrimaryQualifier invalidPrimaryQualifier = new PrimaryQualifier();
            invalidPrimaryQualifier.setPrimaryQualifierType(MacroType.SECTYP);
            invalidPrimaryQualifier.setPrimaryQualifierValue("NOCHAIN");
            Macro macro2 = new Macro();
            macro2.setPrimaryQualifier(invalidPrimaryQualifier);
            SecondaryQualifier invalidSecondaryQualifier = new SecondaryQualifier();
            invalidSecondaryQualifier = new SecondaryQualifier();
            invalidSecondaryQualifier.setSecondaryQualifierOperator(SecondaryQualifierOperator
                    .fromValue("Equals"));
            invalidSecondaryQualifier.setSecondaryQualifierType(SecondaryQualifierType.TICKER);
            invalidSecondaryQualifier.setSecondaryQualifierValue("SPX Index");
            macro2.getSecondaryQualifier().add(invalidSecondaryQualifier);

            Instruments instruments = new Instruments();
            instruments.getMacro().add(macro1);
            instruments.getMacro().add(macro2);

            // Setting fields
            Fields fields = new Fields();
            fields.getField().add("PX_LAST");

            // Construct and submit gethistory request
            System.out.println("Sending submit gethistory request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetHistoryRequest(headers, fields, instruments, statusCode, requestId,
                    responseId);
            System.out.println("Submit gethistory request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve gethistory
            RetrieveGetHistoryRequest rtvGetHistoryReq = new RetrieveGetHistoryRequest();
            rtvGetHistoryReq.setResponseId(responseId.value);
            RetrieveGetHistoryResponse rtvGetHistoryResp;
            System.out.println("Sending retrieve gethistory request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetHistoryResp = ps.retrieveGetHistoryResponse(rtvGetHistoryReq);
            } while (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve gethistory request successful for responseId: "
                        + rtvGetHistoryResp.getResponseId());
                for (HistInstrumentData histIntrumentData : rtvGetHistoryResp.getInstrumentDatas()
                        .getInstrumentData()) {
                    if (histIntrumentData.getCode().equals("0")) {
                        System.out.println("Data for " + histIntrumentData.getInstrument().getId()
                                + " " + histIntrumentData.getInstrument().getYellowkey() + ":");
                        if (histIntrumentData.getDate() != null) {
                            System.out.println(histIntrumentData.getDate());
                            for (int i = 0; i < histIntrumentData.getData().size(); i++) {
                                System.out.println("  " + fields.getField().get(i) + ": "
                                        + histIntrumentData.getData().get(i).getValue());
                            }
                        }
                    } else {
                        System.out.println("\n\nError Code " + histIntrumentData.getCode()
                                + ": incorrect macro. The Macro object is as follows:");
                        System.out.println("Primary Qualifier: ");
                        System.out.println("Primary Qualifier type: "
                                + histIntrumentData.getMacro().getPrimaryQualifier()
                                        .getPrimaryQualifierType().toString());
                        System.out.println("Primary Qualifier Value: "
                                + histIntrumentData.getMacro().getPrimaryQualifier()
                                        .getPrimaryQualifierValue().toString());
                        System.out.println("Secondary Qualifier: ");
                        for (SecondaryQualifier secondaryQualifier2 : histIntrumentData.getMacro()
                                .getSecondaryQualifier()) {
                            System.out.println("Secondary Qualifier type: "
                                    + secondaryQualifier2.getSecondaryQualifierType());
                            System.out.println("Secondary Qualifier Operator: "
                                    + secondaryQualifier2.getSecondaryQualifierOperator());
                            System.out.println("Secondary Qualifier value: "
                                    + secondaryQualifier2.getSecondaryQualifierValue());
                        }
                    }
                }
            } else if (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
