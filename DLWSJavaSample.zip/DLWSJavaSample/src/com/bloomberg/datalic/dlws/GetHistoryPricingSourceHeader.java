/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * GetHistoryPricingSourceHeader - This class submits a gethistory request with
 * the Pricing source header set to true. This is followed by retrieve gethistory request,
 * to get the values for the fields and the pricing source for the security.
 */

package com.bloomberg.datalic.dlws;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.Fields;
import com.bloomberg.datalic.dlws.stubs.GetHistoryHeaders;
import com.bloomberg.datalic.dlws.stubs.HistInstrumentData;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetHistoryRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetHistoryResponse;

public class GetHistoryPricingSourceHeader {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            GetHistoryHeaders headers = new GetHistoryHeaders();
            headers.setProgramflag(programFlag);
            headers.setDisplayPricingSrc(Boolean.TRUE);

            // Setting instruments
            Instrument ticker = new Instrument();
            ticker.setId("IBM US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.EQUITY);

            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);

            // Setting fields
            Fields fields = new Fields();
            fields.getField().add("PX_LAST");

            // Construct and submit gethistory request
            System.out.println("Sending submit gethistory request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetHistoryRequest(headers, fields, instruments, statusCode, requestId,
                    responseId);
            System.out.println("Submit gethistory request status: "
                    + statusCode.value.getDescription().toString() + ", responseId: "
                    + responseId.value);

            // Submit retrieve gethistory
            RetrieveGetHistoryRequest rtvGetHistoryReq = new RetrieveGetHistoryRequest();
            rtvGetHistoryReq.setResponseId(responseId.value);
            RetrieveGetHistoryResponse rtvGetHistoryResp;
            System.out.println("Sending retrieve gethistory request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetHistoryResp = ps.retrieveGetHistoryResponse(rtvGetHistoryReq);
            } while (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve gethistory request successful for responseId: "
                        + rtvGetHistoryResp.getResponseId());
                for (HistInstrumentData histInstrumentData : rtvGetHistoryResp.getInstrumentDatas()
                        .getInstrumentData()) {
                    System.out.println("Data for " + histInstrumentData.getInstrument().getId()
                            + " " + histInstrumentData.getInstrument().getYellowkey() + ":");
                    System.out.println("Date: " + histInstrumentData.getDate());
                    System.out.println("Pricing Source: " + histInstrumentData.getPricingSource());
                    for (int i = 0; i < histInstrumentData.getData().size(); i++) {
                        System.out.println(fields.getField().get(i) + ": "
                                + histInstrumentData.getData().get(i).getValue());
                    }
                }
            } else if (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
