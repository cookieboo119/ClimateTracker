define(['ojs/ojcore', 'knockout', 'jquery', 'ebs/actions/actionsHelper', 'ebs/utils/backupEnvironmentHelper', 'ebs/popup/popupHelper',
    'ebs/constants', 'ojs/ojvalidator-regexp', 'ebs/navigation/pageNavigationHelper', 'ojs/ojarraydataprovider', 'ebs/utils/lovUtils', 'ojs/ojinputtext', 'ebs/utils/compartmentsLov', 'ojs/ojdialog',
    'ojs/ojarraydataprovider', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojfilepicker', 'ojs/ojtable', 'ojs/ojswitch', 'ojs/ojmessages'],
        function (oj, ko, $, actionsHelper, backupEnvironmentHelper, popupHelper, constants, RegExpValidator, pageNavigationHelper, ArrayDataProvider, lovUtils) {

            function TaskCreateViewModel() {
                var self = this;
                console.log('Loading Task Popup View Model');
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.taskPopupTitle = ko.observable('Create Task');
                self.taskName = ko.observable();
                self.taskIdentifier = ko.observable();
                self.taskNameReadOnly = ko.observable(false);
                self.taskDescription = ko.observable('');
                var loadingOption = new Array();
                loadingOption.push({
                    'label': 'loading...',
                    'value': ''
                });

                self.executeOnNodesList = ko.observableArray(loadingOption);
                self.executeOnNodesDataProvider = new ArrayDataProvider(self.executeOnNodesList, {idAttribute: 'value'});
                self.scriptToExecute = ko.observable();
                self.executeOnNodeSelected = ko.observable();
                self.associatedActivitySelected = ko.observable();
                self.disableUploader = ko.observable(true);
                self.acceptedExtensions = ko.observableArray([".zip"]);
                self.allTaskList = new Array();

                var TaskNameValidator = function ()
                {};
                oj.Object.createSubclass(TaskNameValidator, oj.Validator, "TaskNameValidator");
                self.taskNameValidater = [new TaskNameValidator()];

                self.uploadedFileName = ko.observable('');
                self.isEditFlow = ko.observable(false);
                self.isLCMActivity = ko.observable(false);
                self.displayStatus = ko.observable(false);
                self.status = ko.observable('');
                self.scriptToExecute = ko.observable('');
                self.disableCreateBtn = ko.observable(true);
                self.sequence = ko.observable(1);



                self.confirmationDialogText = ko.observable('');
                self.confirmationCallBackFunctionSuccess = null;
                self.confirmationDialogTitle = ko.observable('Confirm');
                self.yesButtonText = ko.observable('Yes');
                self.isNoButtonRendered = ko.observable(true);
                self.noButtonText = ko.observable('No');

                var params = new Array();
                self.nodesObservableArray = ko.observableArray(params);
                self.InputParametersDataProvider = new ArrayDataProvider(self.nodesObservableArray, {idAttribute: 'sequence'});
                self.columnArray = [{"headerText": "* Name",
                        "field": "ParamName",
                        "template": "NameTemplate"},
                    {"headerText": "* Label",
                        "field": "ParamLabel",
                        "template": "LabelTemplate"},
                    {"headerText": "Sensitive",
                        "field": "ParamSensitive",
                        "template": "SensitiveTemplate"},
                    {"headerText": "Default Value",
                        "field": "ParamDefaultValue",
                        "template": "DefaultValueTemplate"}, {"headerText": "Action",
                        "field": "Delete",
                        "template": "DeleteParameterTemplate"}];

                self.startAnimationListener = function (event, ui) {
                    popupHelper.startAnimationListener(constants.divTags.taskCreatePGConfirmPopupTag, event, ui);
                };

                self.confirmationPopupCloseHandler = function (data, event) {
                    popupHelper.confmPopuCloseHandler(constants.divTags.taskCreatePGConfirmPopupTag, data, event);
                };



                self.createTaskSubmission = function () {
                    var valid = self.isValidForm();
                    if (!valid) {
                        return;
                    } else {
                        console.log('Submitting task.');
                        var requestBody = null;
                        
                        if (self.isEditFlow())
                        {
                            requestBody = {
                                "label": self.taskDescription(),
                                "executeOn": self.executeOnNodeSelected(),
                                "libraryName": self.uploadedFileName(),
                                "executableName": self.scriptToExecute(),
                                "isLCMActivity": self.isLCMActivity(),
                                "parameters": []
                            };
                        } else {
                            requestBody = {"name": self.taskName(),
                                "label": self.taskDescription(),
                                "executeOn": self.executeOnNodeSelected(),
                                "libraryName": self.uploadedFileName(),
                                "executableName": self.scriptToExecute(),
                                "isLCMActivity": self.isLCMActivity(),
                                "parameters": []
                            };
                        }



                        for (var j = 0; j < self.nodesObservableArray().length; j++) {
                            var paramObject = new Object();
                            paramObject.name = self.nodesObservableArray()[j].ParamName();
                            paramObject.label = self.nodesObservableArray()[j].ParamLabel();
                            paramObject.defaultValue = self.nodesObservableArray()[j].ParamDefaultValue();
                            paramObject.isSensitive = self.nodesObservableArray()[j].ParamSensitive();
                            requestBody.parameters.push(paramObject);
                        }

                        var jsonContent = JSON.stringify(requestBody);
                        var infoMsg = '';
                        if (self.isEditFlow()) {
                            infoMsg = oj.Translations.getTranslatedString("confirmPopup.customTaskUpdateInfoMsg", {'customTaskName': self.taskName()});
                        } else {
                            infoMsg = oj.Translations.getTranslatedString("confirmPopup.customTaskCreateInfoMsg", {'customTaskName': self.taskName()});
                        }


                        var msgOrigin = '';
                        if (self.isEditFlow()) {
                            msgOrigin = oj.Translations.getTranslatedString("confirmPopup.customTaskUpdateTitle");
                        } else {
                            msgOrigin = oj.Translations.getTranslatedString("confirmPopup.customTaskCreateTitle");
                        }

                        popupHelper.openInfoMsg(constants.divTags.taskCreatePGConfirmPopupTag, infoMsg, msgOrigin);

                        actionsHelper.createOrUpdateTask(self.isEditFlow(), self.taskIdentifier(), jsonContent, function (error)
                        {
                            if (error === '')
                            {
                                var msgOrigin = '';
                                if (self.isEditFlow())
                                    msgOrigin = oj.Translations.getTranslatedString("confirmPopup.customTaskUpdateTitle");
                                else
                                    msgOrigin = oj.Translations.getTranslatedString("confirmPopup.customTaskCreateTitle");
                                rootViewModel.displayPopupId(constants.divTags.taskCreatePGConfirmPopupTag);
                                var confirmationSuccessMsg = '';
                                if (self.isEditFlow()) {
                                    confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.customTaskUpdateSuccessMsg", {'customTaskName': self.taskName()});
                                } else {
                                    confirmationSuccessMsg = oj.Translations.getTranslatedString("confirmPopup.customTaskCreateSuccessMsg", {'customTaskName': self.taskName()});
                                }
                                popupHelper.setSuccessPopupMsg(confirmationSuccessMsg, msgOrigin);

                                setTimeout(function () {
                                    var context = ko.contextFor(document.getElementById('TaskPGRoot'));
                                    self.cleanUpRootVariables();
                                    rootViewModel.displayPopupId('');  /* After redirecting to the task list page, if the environments link is clicked, still we see confirm msg. */
                                    pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkModule, constants.navModules.executionFrameworkModule);
                                    rootViewModel.initialAdministrationSubTab = constants.navModules.executionFrameworkModule;
                                }, 2000);
                            } else
                            {
                                var responseText = error.responseText;
                                var response = JSON.parse(responseText);
                                popupHelper.openErrorMsg(constants.divTags.taskCreatePGConfirmPopupTag, response.message, msgOrigin);
                            }

                        });
                    }
                };

                self.addRow = function () {
                    var paramRow = {Sequence: self.sequence(), ParamName: ko.observable(''), ParamLabel: ko.observable(''), ParamSensitive: ko.observable(false), ParamDefaultValue: ko.observable(''), Delete: ko.observable('')};
                    self.nodesObservableArray.push(paramRow);
                    self.sequence(self.sequence() + 1);
                };

                TaskNameValidator.prototype.validate = function (value)
                {
                    console.log('Task name Validater Called');
                    var regularExp = new RegExp("^([a-zA-Z0-9_ ]{1,50})$");
                    if (regularExp.test(value))
                    {
                        if (value === null || value === '') {
                            self.disableUploader(true);
                            return false;
                        } else {
                            var isDuplicateName = self.isDuplicateTaskName(value);
                            if (isDuplicateName) {
                                self.disableUploader(false);
                                var taskNameDuplicateValidationMsg = oj.Translations.getTranslatedString('validationMsgs.taskNameDuplicateValidationMsg');
                                throw new Error(taskNameDuplicateValidationMsg);
                                return false;
                            } else {
                                self.disableUploader(false);
                                return true;
                            }
                        }
                    } else
                    {
                        self.disableUploader(true);
                        var taskNameIncorrectValidationMsg = oj.Translations.getTranslatedString('validationMsgs.taskNameValidationMsg');
                        throw new Error(taskNameIncorrectValidationMsg);
                        return false;
                    }

                };

                self.isDuplicateTaskName = function (currentName) {
                    for (var i = 0; i < self.allTaskList.length; i++) {
                        var taskName = self.allTaskList[i].name;
                        if (taskName === currentName) {
                            return true;
                        }
                    }
                    return false;
                };

                self.removeParameter = function () {
                    var targetElem = event.target;
                    if (targetElem !== null && typeof (targetElem.id) !== 'undefined' && targetElem.id !== null)
                    {
                        var tokens = targetElem.id.split('_');
                        var index = tokens[1];
                        var rowIndex = self.findCorrectRowIndexFromSequence(parseInt(index));
                        if (rowIndex !== -1) {
                            self.nodesObservableArray.splice(rowIndex, 1);
                        }
                    }
                };

                self.findCorrectRowIndexFromSequence = function (sequence) {
                    for (var i = 0; i < self.nodesObservableArray().length; i++) {
                        var node = self.nodesObservableArray()[i];
                        var nodeSeq = node.Sequence;
                        if (nodeSeq === sequence) {
                            return i;
                        }
                    }
                    return -1;
                };

                self.cleanUpRootVariables = function () {
                    rootViewModel._drillDownTaskName = '';
                    rootViewModel._drillDownTaskId = '';
                };


                self.cancelCreateTask = function () {
                    var context = ko.contextFor(document.getElementById('TaskPGRoot'));
                    self.cleanUpRootVariables();
                    pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkModule, constants.navModules.executionFrameworkModule);
                    rootViewModel.initialAdministrationSubTab = constants.navModules.executionFrameworkModule;
                };

                self.handleUploadedFile = function (event) {

                    var files = event.detail.files;
                    if (files === null || files.length === 0) {
                        console.log('No Files.');
                        return;
                    }

                    var fileName = files[0].name;
                    var fileNameTokens = fileName.split('.');
                    if (fileNameTokens.length < 2) {
                        return;
                    } else {
                        var lastToken = fileNameTokens[fileNameTokens.length - 1];
                        if (lastToken !== 'zip' && lastToken !== 'ZIP') {
                            self.uploadedFileName(fileName);
                            self.displayStatus(true);
                            self.status('Failure');
                            self.disableCreateBtn(true);

                            return;
                    }
                    }

                    var taskNameField = document.getElementById('TaskName');
                    var validation = taskNameField.validate();

                    validation.then(
                            function (val) {
                                var field = document.getElementById('TaskName');
                                if (self.isEditFlow() || field.readonly) {
                                    val = 'valid';
                                }
                                if (val === 'invalid') {
                                    self.disableUploader(true);
                                    return;
                                } else {
                                    self.displayStatus(true);
                                    self.status('InProgress');
                                    var fd = new FormData(document.getElementById('codeLibraryUploadForm'));
                                    var fileObject = files[0];
                                    self.uploadedFileName(fileObject.name);
                                    fd.append('taskName', self.taskName());
                                    fd.append('libraryName', fileObject);

                                    actionsHelper.postCodeLibraryZipFile(fd, function (error, response) {
                                        if (error !== null && error !== '') {
                                            self.displayStatus(true);
                                            self.status('Failure');
                                            self.disableCreateBtn(true);
                                        } else {
                                            self.displayStatus(true);
                                            self.status('Success');
                                            self.disableCreateBtn(false);
                                            self.taskNameReadOnly(true);
                                        }
                                    });
                                }
                            });
                };

                self.isValidForm = function () {
                    var isValid = true;
                    var taskNameField = document.getElementById('TaskName');
                    if (taskNameField.valid !== 'valid')
                    {
                        taskNameField.showMessages();
                        isValid = false;
                    }
                    var executeOnField = document.getElementById('executeOn');
                    if (executeOnField.valid !== 'valid')
                    {
                        executeOnField.showMessages();
                        isValid = false;
                    }
                    var scriptToExecuteField = document.getElementById('ScriptToExecute');
                    if (scriptToExecuteField.valid !== 'valid')
                    {
                        scriptToExecuteField.showMessages();
                        isValid = false;
                    }

                    /* Validate table rows */
                    for (var k = 0; k < self.nodesObservableArray().length; k++) {
                        var paramObject = self.nodesObservableArray()[k];
                        var paramName = paramObject.ParamName();
                        var paramLabel = paramObject.ParamLabel();
                        if (paramName === null || paramLabel === '') {
                            isValid = false;
                            self.openInformationDialog(oj.Translations.getTranslatedString('warningOrConfirmationMsgs.taskParameterNameOrLabelMissing'),
                                    function () {
                                        return false;
                                    });
                            break;
                        }
                    }
                    return isValid;
                };

                self.openInformationDialog = function (content, callBackFunc)
                {
                    self.confirmationCallBackFunctionSuccess = callBackFunc;
                    self.confirmationDialogText(content);
                    self.isNoButtonRendered(false);
                    self.yesButtonText('OK');
                    self.confirmationDialogTitle('Warning');
                    document.getElementById('confirmDialog').open();
                };
                self.okConfirmationDialog = function ()
                {
                    document.getElementById('confirmDialog').close();
                    self.confirmationCallBackFunctionSuccess();
                };
                self.NotokConfirmationDialog = function ()
                {
                    document.getElementById('confirmDialog').close();
                    self.confirmationCallBackFunctionFailure();
                };

                self.initializePageData = function () {
                    actionsHelper.getAllTasks(function (error, taskLists) {
                        self.allTaskList = taskLists;
                    });
                    var executeOnNode = new Array();
                    executeOnNode.push({
                        'label': 'All Nodes',
                        'value': 'AllNodes'
                    },
                            {
                                'label': 'Primary Application Tier Node',
                                'value': 'PrimaryAppNode'
                            },
                            {
                                'label': 'All Application Tier Nodes',
                                'value': 'AllAppNodes'
                            },
                            {
                                'label': 'All Database Nodes',
                                'value': 'AllDbNodes'
                            });
                    self.executeOnNodesList(executeOnNode);
                    self.executeOnNodesDataProvider = new ArrayDataProvider(self.executeOnNodesList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.executeOnNodesList(), self.executeOnNodeSelected);
                    var taskInRootModel = rootViewModel._drillDownTaskName;
                    var taskIdInRootModel = rootViewModel._drillDownTaskId;
                    if (taskInRootModel !== null && typeof (taskInRootModel) !== 'undefined' && taskInRootModel !== '') {
                        self.initializeFromTaskDetails(taskInRootModel, taskIdInRootModel);
                    }

                };

                self.initializeFromTaskDetails = function (taskName, taskIdentifier) {
                    actionsHelper.getTaskDetail(taskIdentifier, function (error, taskDetail) {
                        if (error === null || error === '') {
                            self.taskIdentifier(taskIdentifier);
                            self.taskName(taskDetail.name);
                            self.disableUploader(false);
                            self.taskDescription(taskDetail.label);
                            self.scriptToExecute(taskDetail.executableName);
                            self.executeOnNodeSelected(taskDetail.executeOn);
                            lovUtils.lovOptionsUpdated(self.executeOnNodesList(), self.executeOnNodeSelected);
                            self.isLCMActivity(taskDetail.isLCMActivity);
                            self.uploadedFileName(taskDetail.libraryName);
                            self.displayStatus(true);
                            self.status('Success');
                            self.disableCreateBtn(false);
                            var parameters = taskDetail.parameters;
                            if (typeof (parameters) !== 'undefined' && parameters !== null) {
                                for (var i = 0; i < parameters.length; i++) {
                                    var node = new Object();
                                    node.Sequence = self.sequence();
                                    node.ParamName = ko.observable(parameters[i].name);
                                    node.ParamLabel = ko.observable(parameters[i].label);
                                    node.ParamSensitive = ko.observable(parameters[i].isSensitive);
                                    node.ParamDefaultValue = ko.observable(parameters[i].defaultValue);
                                    self.nodesObservableArray.push(node);
                                    self.sequence(self.sequence() + 1);
                                }
                            }
                            self.taskNameReadOnly(true);
                        }
                    });
                    self.isEditFlow(true);
                };
                self.initializePageData();
                
                self.ScriptToExecuteValidator = [
                    new RegExpValidator({
                        pattern: "^[A-Za-z0-9]+\.sh$",
                        hint: oj.Translations.getTranslatedString('validationMsgs.scriptToExecuteValidationMsg'),
                        messageDetail: oj.Translations.getTranslatedString('validationMsgs.scriptToExecuteValidationMsg')
                    })
                ];
                
                self.InputParameterNameValidator = [
                    new RegExpValidator({
                        pattern: "^[A-Za-z0-9_]*",
                        hint: oj.Translations.getTranslatedString('validationMsgs.inputParameterNameHintMsg'),
                        messageDetail: oj.Translations.getTranslatedString('validationMsgs.inputParameterNameValidationMsg')
                    })
                ];
                
            }
            return TaskCreateViewModel;
        });
