/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * association module
 */
define(['ojs/ojcore', 'knockout', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/actions/actionsHelper',
    'ebs/navigation/pageNavigationHelper'],
        function (oj, ko, popupHelper, constants, actionsHelper, pageNavigationHelper) {
            /**
             * The view model for the main content view template
             */
            function associationContentViewModel() {
                var self = this;
                console.log('Loading Association Content Popup View Model');

                var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
                var name = rootViewModel.currentNetworkName();
                self.headerName = ko.observable('Add Group to ' + name);

                self.associationList = ko.observableArray([{
                        'label': 'loading...',
                        'value': ''
                    }]);
                self.selectedGroup = ko.observableArray('');

                //cross button
                self.createGroupPopupCloseCleanUpHandler = function () {
                };

                self.createGroup = function () {
                    var createGroupRequestBody = null;

                    createGroupRequestBody = {
                        "networkProfile": name,
                        "associationType": "GROUP",
                        "associations": []
                    };

                    // Iterating groups selected by user.
                    for (var i = 0; i < self.selectedGroup().length; i++) {
                        var associations = self.associationList();
                        var len = associations.length;

                        // Iterating original list of LOV to retrieve selected label based on value
                        for (var j = 0; j < len; j++) {
                            if (associations[j].value === self.selectedGroup()[i]) {

                                // Creating json to send to rest flow
                                createGroupRequestBody.associations.push({
                                    name: associations[j].label,
                                    OCID: self.selectedGroup()[i]
                                });
                                break;
                            }
                        }
                    }

                    var requestBodyJSON = JSON.stringify(createGroupRequestBody);

                    console.log('Create association request JSON =>' + requestBodyJSON);
                    var context = null;
                    actionsHelper.createNetworkProfileAssociation(requestBodyJSON, function (error, success) {
                        if (error === '') {
                            context = ko.contextFor(document.getElementById(constants.divTags.networkDetailsPage));
                            // Navigating to network list page
                            rootViewModel.prevNetworkDetailsNavItem(constants.navModules.networkGroupAssignmentModule);
                            context.$parent.childRouterKO(constants.navModules.networkGroupAssignmentModule);
                            pageNavigationHelper.navigateToPage(context, constants.navModules.networkProfileDetailsModule, '');
                        } else {
                            var response = JSON.parse(error.responseText);
                            console.log(response);
                            //popupHelper.openErrorMsg(constants.divTags.networkDetailsPage, response.message, "Create Association Failed");
                        }
                    });
                };


                self.closeGroupCreationPopup = function (event, ui) {
                    var popup = document.getElementById('associationCreatePopup');
                    popup.close();
                };

                // Group list based on network
                actionsHelper.getGroupsListUnderNetwork(name, function (error, associationList) {
                    if (error !== null && error !== '') {
                        console.log('Error in fetching groups =>' + error);
                    } else {
                        self.associationList.removeAll();
                        self.associationList(associationList);
                    }
                });
            }

            return associationContentViewModel;
        });