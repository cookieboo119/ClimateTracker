define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/popup/popupHelper',
    'ebs/constants', 'ebs/utils/dateTimeHelper', 'ebs/utils/scheduleUtils', 'ebs/utils/compartmentUtils', 'ojs/ojarraydataprovider',
    , 'ojs/ojaccordion', 'ojs/ojinputtext', 'ojs/ojpopup', 'ojs/ojrowexpander', 'ojs/ojflattenedtreetabledatasource',
    'ojs/ojjsontreedatasource', 'ojs/ojtable', 'ojs/ojmessages', 'ojs/ojswitch', 'ojs/ojbutton', 'ojs/ojformlayout', 'ojs/ojmessages'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper, constants, dateTimeHelper, scheduleUtils, compartmentUtils, ArrayDataProvider) {

    function policyDetailsViewModel() {
        var self = this;
        var jobId = oj.Router.rootInstance.retrieve();
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.policyName = ko.observable('');
        self.createdBy = ko.observable('');
        self.dateCreated = ko.observable('');
        self.policyIdentifier = ko.observable('');
        self.scheduleListLoaded = ko.observable(false);
        self.compartmentName = ko.observable('');
        self.pageLevelMessages = ko.observableArray();
        self.messagesDataprovider = new ArrayDataProvider(self.pageLevelMessages);
        self.prevPage = ko.observable('Policies');
        self.newScheduleSequence = ko.observable(0);
        self.areEnvsAssociated = ko.observable(false);
        self.policyDeleteWarningText1 = ko.observable('');
        self.policyDeleteWarningText2 = ko.observable('');
        self.scheduleTableColumns = [
            {headerText: 'Schedule Type',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 8em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                field: 'type_display',
                sortable: 'enabled',
                template: 'textCellTemplate',
                sortProperty: 'type_display'},
            {headerText: 'Start Time',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 8em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                field: 'startTime',
                sortable: 'enabled',
                template: 'startTimeTemplate',
                sortProperty: 'startTime'}
            , {headerText: 'Actions',
                template: 'menuCellTemplate',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 8em; width: 8em; text-align: left;",
                field: 'menu',
                sortable: 'disabled'}
        ];
        self.schedules = ko.observableArray([]);
        self.scheduleDataSource = new oj.ArrayTableDataSource(
                self.schedules,
                {idAttribute: 'id'});
        self.scheduleDataSourceObservable = ko.observable(self.scheduleDataSource);
        var editScheduleEnabled = {id: 'EditSchedule', label: 'Edit', disabled: false};
        var deleteScheduleEnabled = {id: 'DeleteSchedule', label: 'Delete', disabled: false};
        self.menuOptions = ko.observableArray([]);
        self.ebsCompartment = ko.observable('');
        self.policyName = ko.observable('');
        self.compartments = ko.observableArray();
        self.currentItemIdentifier = ko.observable("");
        self.confirmDeleteScheduleMsg = ko.observable('');
        self.confirmDeletePolicyMsg = ko.observable('');
        self.listOfEnvironmentsUsingThisPolicy = ko.observableArray();

        var messageForDeletingSchedule = {
            category: 'Message',
            severity: 'info',
            summary: oj.Translations.getTranslatedString("confirmPopup.schedulePolicyDeleted")
        };

        var messageForUpdatingSchedule = {
            category: 'Message',
            severity: 'info',
            summary: oj.Translations.getTranslatedString("confirmPopup.schedulePolicyUpdated")
        };

        var messageForAddingSchedule = {
            category: 'Message',
            severity: 'info',
            summary: oj.Translations.getTranslatedString("confirmPopup.schedulePolicyAdded")
        };
        var messageForNoSchedule = {
            severity: 'error',
            summary: oj.Translations.getTranslatedString("confirmPopup.noSchedulePolicy")
        };

        self.savePolicy = function () {
            if (self.schedules().length < 1) {
                var messages = new Array();
                messages.push(messageForNoSchedule);
                self.pageLevelMessages([]);
                self.pageLevelMessages(messages);
                return;
            }
            var schedules = new Array();
            for (var i = 0; i < self.schedules().length; i++) {
                var scheduleObject = new Object();
                var schedule = self.schedules()[i];
                var schedulePeriod = schedule.type_value();
                scheduleObject.period = schedulePeriod;
                if (schedulePeriod === 'EVERY_DAY') {
                    scheduleObject.hourOfDay = schedule.hourOfDay();
                } else if (schedulePeriod === 'EVERY_WEEK') {
                    scheduleObject.hourOfDay = schedule.hourOfDay();
                    scheduleObject.dayOfWeek = schedule.dayOfWeek();
                } else if (schedulePeriod === 'EVERY_MONTH') {
                    scheduleObject.hourOfDay = schedule.hourOfDay();
                    scheduleObject.dayOfMonth = schedule.dayOfMonth();
                } else if (schedulePeriod === 'EVERY_YEAR') {
                    scheduleObject.hourOfDay = schedule.hourOfDay();
                    scheduleObject.dayOfMonth = schedule.dayOfMonth();
                    scheduleObject.month = schedule.month();
                }
                schedules.push(scheduleObject);
            }
            var requestBodyJSON = JSON.stringify(schedules);
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.updatePolicyInfoMsg", {'policyName': self.policyName()});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.updatePolicyTitle");
            popupHelper.openInfoMsg(constants.divTags.policyDetailsPGConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.updatePolicy(constants.policies.Backup, self.policyIdentifier(), requestBodyJSON, function (error, success) {
                if (error === null || error === '') {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.updatePolicyConfirmMsg", {'policyName': self.policyName()});
                    popupHelper.openSuccessMsg(constants.divTags.policyDetailsPGConfPopupTag, successMsg, msgOrigin);
                    var context = ko.contextFor(document.getElementById("PolicyDetailPG"));
                    pageNavigationHelper.clearGlobalVarBeforeNavigationToNetworkListPG(rootViewModel);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.policyListingPG, constants.navModules.policyListingPG);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.policyDetailsPGConfPopupTag, response.message, msgOrigin);
                }
            });

        };

        self.deletePolicyAssertion = function () {
            if (self.listOfEnvironmentsUsingThisPolicy() !== null && self.listOfEnvironmentsUsingThisPolicy().length > 0) {
                self.areEnvsAssociated(true);
                var deletePolicyTextMap = scheduleUtils.getDeletePolicyWarningText(self.listOfEnvironmentsUsingThisPolicy());
                self.policyDeleteWarningText1(deletePolicyTextMap.get("Text1"));
                self.policyDeleteWarningText2(deletePolicyTextMap.get("Text2"));
            } else {
                self.areEnvsAssociated(false);
                self.policyDeleteWarningText1('');
                self.policyDeleteWarningText2("");
            }
            self.confirmDeletePolicyMsg(oj.Translations.getTranslatedString("confirmPopup.deletePolicyAssertMsg", {policyName: self.policyName()}));
            var popup = document.querySelector(constants.divTags.policyListDelPopupTag);
            popup.open();
        };

        self.deletePolicy = function () {
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deletePolicyInfoMsg", {'policyName': self.policyName()});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.deletePolicyTitle");
            popupHelper.openInfoMsg(constants.divTags.policyDetailsPGConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.deletePolicy(constants.policies.Backup, self.policyIdentifier(), function (error, success) {
                if (error === null || error === '') {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deletePolicyConfirmMsg", {'policyName': self.policyName()});
                    popupHelper.openSuccessMsg(constants.divTags.policyDetailsPGConfPopupTag, successMsg, msgOrigin);
                    var context = ko.contextFor(document.getElementById("PolicyDetailPG"));
                    pageNavigationHelper.clearGlobalVarBeforeNavigationToNetworkListPG(rootViewModel);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.policyListingPG, constants.navModules.policyListingPG);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.policyDetailsPGConfPopupTag, response.message, msgOrigin);
                }
            });
        };

        self.closeConfirmDeletePolicyPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.policyListDelPopupTag);
            popup.close();
        };


        self.fetchPolicyDetails = function () {
            var policyIdentifier = rootViewModel._drillDownPolicyId;
            var createdBy = rootViewModel._policyCreatedBy;
            var dateCreated = rootViewModel._policyCreationDate;
            self.createdBy(createdBy);
            self.dateCreated(dateCreated);
            self.newScheduleSequence(0);
            self.policyIdentifier(policyIdentifier);
            self.scheduleListLoaded(false);
            self.schedules([]);

            actionsHelper.getCompartmentListForTenancy(function (error, compartmentsList) {
                if (error !== null && error !== '') {
                    console.log('Error in fetching Compartment List for tenancy =>' + error);
                } else {
                    self.compartments(compartmentsList);
                    actionsHelper.getPolicyDetails(constants.policies.Backup, policyIdentifier, function (error, policyDetail) {
                        if (error === null || error === '') {
                            var name = policyDetail.name;
                            self.policyName(name);
                            var compartmentIdentifier = policyDetail.compartmentId;
                            var compartmentName = compartmentUtils.getCompartmentNameFromOCID(compartmentIdentifier, self.compartments());
                            self.ebsCompartment(compartmentName);
                            var schedules = policyDetail.schedules;
                            var listOfSchedules = [];
                            $.each(schedules, function () {
                                var schedule = {
                                    id: this.id,
                                    type_display: ko.observable(scheduleUtils.getUserFriendlyNameForPeriod(this.period)),
                                    type_value: ko.observable(this.period),
                                    hourOfDay: ko.observable(parseInt(this.hourOfDay)),
                                    dayOfWeek: ko.observable(parseInt(this.dayOfWeek)),
                                    dayOfMonth: ko.observable(parseInt(this.dayOfMonth)),
                                    month: ko.observable(this.month),
                                    startTime: ko.observable(self.getStartTimeString(this.period, this.hourOfDay, this.dayOfWeek, this.dayOfMonth, this.month)),
                                    menu: self.menuOptions,
                                    handleEventsFromMenu: self.handleEventsFromMenu,
                                    setupMenuOptions: self.setupMenuOptions,
                                    openNextScheduleInformationPopup: self.openNextScheduleInformationPopup
                                };
                                if (typeof (schedule) === 'undefined' || typeof (schedule.id) === 'undefined' || schedule.id === null || schedule.id === '') {
                                    // skip this schedule.
                                } else {
                                    listOfSchedules.push(schedule);
                                }
                            });
                            self.schedules(listOfSchedules);
                        }
                    });
                }

            });

            actionsHelper.getEnvironmentsUsingPolicy(self.policyIdentifier(), function (error, envList) {
                self.listOfEnvironmentsUsingThisPolicy(envList);
            });

            self.scheduleListLoaded(true);
        };

        self.setupMenuOptions = function (event, ui) {
            var index = ui.index;
            var identifier = ui.row.id;
            self.currentItemIdentifier(identifier);
            self.menuOptions([]);
            self.menuOptions.push(editScheduleEnabled);
            self.menuOptions.push(deleteScheduleEnabled);
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        };

        self.closeConfirmDeleteSchedulePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.scheduleDelPopupTag);
            popup.close();
        };

        self.openNextScheduleInformationPopup = function (viewModel, event) {
            var targetElement = event.target || event.srcElement || event.currentTarget;
            var identifier = targetElement.id;
            var scheduleIdentifier = identifier.split("_")[1];
            var scheduleEntry = self.getScheduleItemFromList(scheduleIdentifier);
            var period = scheduleEntry.type_value();
            var hrOfDay = scheduleEntry.hourOfDay();
            var dayOfWeek = scheduleEntry.dayOfWeek();
            var dayOfMonth = scheduleEntry.dayOfMonth();
            var month = scheduleEntry.month();
            var viewModelOfNextScheduleInformationPopup = ko.dataFor(document.getElementById("nextScheduleInformationPopupRoot"));
            viewModelOfNextScheduleInformationPopup.displayPopup(period, hrOfDay, dayOfWeek, dayOfMonth,month);
        };

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.policyDetailsPGConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.policyDetailsPGConfPopupTag, data, event);
        };

        self.getStartTimeString = function (period, hourOfDay, dayOfWeek, dayOfMonth, month) {
            return scheduleUtils.getStartTimeStringFromSchedule(period, hourOfDay, dayOfWeek, dayOfMonth, month);
        };

        self.clearRootViewModelVariables = function () {
            rootViewModel._drillDownPolicyId = null;
        };

        self.handleBackLink = function () {
            var context = ko.contextFor(document.getElementById("PolicyDetailPG"));
            pageNavigationHelper.clearGlobalVarBeforeNavigationToNetworkListPG(rootViewModel);
            pageNavigationHelper.navigateToPage(context, constants.navModules.policyListingPG, constants.navModules.policyListingPG);
        };

        self.handleAddSchedule = function () {
            var viewModelOfPopupModule = ko.dataFor(document.getElementById(constants.divTags.scheduleCreatePopupRoot));
            viewModelOfPopupModule.openPopup(true, self.policyIdentifier());
        };

        self.getScheduleItemFromList = function (id) {
            for (var i = 0; i < self.schedules().length; i++) {
                var scheduleItemIdentifier = self.schedules()[i].id;
                if (scheduleItemIdentifier === id) {
                    return self.schedules()[i];
                }
            }
        };

        self.handleEventsFromMenu = function (event, ui) {
            var eventSourceName = event.target.value;
            var currentItemIdentifier = self.currentItemIdentifier();
            var scheduleEntry = self.getScheduleItemFromList(currentItemIdentifier);
            if ('EditSchedule' === eventSourceName) {
                var viewModelOfPopupModule = ko.dataFor(document.getElementById(constants.divTags.scheduleCreatePopupRoot));
                viewModelOfPopupModule.openPopup(false, self.policyIdentifier(), scheduleEntry.id, scheduleEntry.type_value(), scheduleEntry.hourOfDay(), scheduleEntry.dayOfWeek(), scheduleEntry.dayOfMonth(), scheduleEntry.month());
            } else if ('DeleteSchedule' === eventSourceName) {
                self.confirmDeleteScheduleMsg(oj.Translations.getTranslatedString("confirmPopup.deleteScheduleAssertMsg"));
                var popup = document.querySelector(constants.divTags.scheduleDelPopupTag);
                popup.open(event.target);
            }
        };

        self.addSchedule = function (periodValue, hourOfDay, dayOfWeek, dayOfMonth, month) {
            var newSchedule = new Object();
            newSchedule.id = 'UISchedule_' + self.newScheduleSequence();
            self.newScheduleSequence(self.newScheduleSequence() + 1);
            newSchedule.type_display = ko.observable(scheduleUtils.getUserFriendlyNameForPeriod(periodValue));
            newSchedule.type_value = ko.observable(periodValue);
            newSchedule.hourOfDay = ko.observable(hourOfDay);
            newSchedule.dayOfWeek = ko.observable(dayOfWeek);
            newSchedule.dayOfMonth = ko.observable(dayOfMonth);
            newSchedule.month = ko.observable(month);
            newSchedule.startTime = ko.observable(self.getStartTimeString(periodValue, hourOfDay, dayOfWeek, dayOfMonth, month));
            newSchedule.menu = self.menuOptions;
            newSchedule.handleEventsFromMenu = self.handleEventsFromMenu;
            newSchedule.setupMenuOptions = self.setupMenuOptions;
            newSchedule.openNextScheduleInformationPopup = self.openNextScheduleInformationPopup;
            self.schedules.push(newSchedule);
            var messages = new Array();
            messages.push(messageForAddingSchedule);
            self.pageLevelMessages([]);
            self.pageLevelMessages(messages);
        };

        self.editSchedule = function (scheduleId, periodValue, hourOfDay, dayOfWeek, dayOfMonth, month) {
            var scheduleEntry = self.getScheduleItemFromList(scheduleId);
            scheduleEntry.type_display('');
            scheduleEntry.type_value('');
            scheduleEntry.hourOfDay('');
            scheduleEntry.dayOfWeek('');
            scheduleEntry.dayOfMonth('');
            scheduleEntry.month('');
            scheduleEntry.startTime('');
            scheduleEntry.type_display(scheduleUtils.getUserFriendlyNameForPeriod(periodValue));
            scheduleEntry.type_value(periodValue);
            if (periodValue === 'EVERY_DAY') {
                scheduleEntry.hourOfDay(hourOfDay);
                scheduleEntry.startTime(self.getStartTimeString(periodValue, hourOfDay, null, null, null));
            } else if (periodValue === 'EVERY_WEEK') {
                scheduleEntry.hourOfDay(hourOfDay);
                scheduleEntry.dayOfWeek(dayOfWeek);
                scheduleEntry.startTime(self.getStartTimeString(periodValue, hourOfDay, dayOfWeek, null, null));
            } else if (periodValue === 'EVERY_MONTH') {
                scheduleEntry.hourOfDay(hourOfDay);
                scheduleEntry.dayOfMonth(dayOfMonth);
                scheduleEntry.startTime(self.getStartTimeString(periodValue, hourOfDay, null, dayOfMonth, null));
            } else {
                scheduleEntry.hourOfDay(hourOfDay);
                scheduleEntry.dayOfMonth(dayOfMonth);
                scheduleEntry.month(month);
                scheduleEntry.startTime(self.getStartTimeString(periodValue, hourOfDay, null, dayOfMonth, month));
            }

            var messages = new Array();
            messages.push(messageForUpdatingSchedule);
            self.pageLevelMessages([]);
            self.pageLevelMessages(messages);
        };

        self.getModifiedScheduledListByRemovingItem = function (itemIdentifier) {
            var newList = new Array();
            for (var k = 0; k < self.schedules().length; k++) {
                var scheduleItemIdentifier = self.schedules()[k].id;
                if (scheduleItemIdentifier === itemIdentifier) {
                    // skip
                } else {
                    newList.push(self.schedules()[k]);
                }
            }
            return newList;
        };

        self.deleteSchedule = function () {
            var popup = document.querySelector(constants.divTags.scheduleDelPopupTag);
            popup.close();
            var currentItemIdentifier = self.currentItemIdentifier();
            var newList = self.getModifiedScheduledListByRemovingItem(currentItemIdentifier);
            self.schedules([]);
            self.schedules(newList);
            var messages = new Array();
            messages.push(messageForDeletingSchedule);
            self.pageLevelMessages([]);
            self.pageLevelMessages(messages);
        };


        self.fetchPolicyDetails();
    }

    return policyDetailsViewModel;
});
