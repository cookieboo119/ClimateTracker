/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * DBTierDetails module
 */
define(['ojs/ojcore', 'knockout', 'ojs/ojinputnumber', 'ojs/ojconverter-number', 'ojs/ojvalidation-number'
], function (oj, ko, inputNumber, NumberConverter) {
    /**
     * The view model for the main content view template
     */
    function DBTierDetailsContentViewModel() {
        var self = this;

        self.groupingRemover = new NumberConverter.IntlNumberConverter({
            useGrouping: false
        });

        self.validateEntries = function () {
            var invalidsPresent = false;
            var dbsid = document.getElementById("dbsid");
            var vmShape = document.getElementById("vmShape");
            if (vmShape.valid !== 'valid' || dbsid.valid !== 'valid')
            {
                dbsid.showMessages();
                vmShape.showMessages();
                invalidsPresent = true;
            }
            var adminPwd = document.getElementById('backupAdminPwd');
            var reEnterAdminPwd = document.getElementById('backupReEnterAdminPwd');
            if (adminPwd.valid !== 'valid' || reEnterAdminPwd.valid !== 'valid')
            {
                adminPwd.showMessages();
                reEnterAdminPwd.showMessages();
                invalidsPresent = true;
            }

            var logicalFields = new Array();
            logicalFields.push('dbLogicalHostPrefix');
            logicalFields.push('dbLogicalDomain');
            for (var i = 0; i < logicalFields.length; i++)
            {
                var htmlElement = document.getElementById(logicalFields[i]);
                if (htmlElement !== null)
                    htmlElement.validate();
                if (htmlElement !== null && htmlElement.valid !== 'valid')
                {
                    invalidsPresent = true;
                    // htmlElement.showMessages();
                }
            }

            /* For release-standby we check active database admin pwd field and active db wallet pwd field */
            var releaseStandByTrainElement = document.getElementById('releaseStandByEnvironmentTrainElement');
            if (releaseStandByTrainElement !== null) {
                var activeDatabaseAdminPwd = document.getElementById('releaseStandby_adminPwd');
                var activeDatabaseWalletPwd = document.getElementById('releaseStandby_walletPwd');
                if (activeDatabaseAdminPwd.valid !== 'valid' || activeDatabaseWalletPwd.valid !== 'valid')
                {
                    activeDatabaseAdminPwd.showMessages();
                    activeDatabaseWalletPwd.showMessages();
                    invalidsPresent = true;
                }
            }
            /* For clone-standby we check standby database admin pwd field and standby db wallet pwd field and storage field */
            else {
                var standbyDatabaseAdminPwd = document.getElementById('cloneStandby_adminPwd');
                var standbyDatabaseWalletPwd = document.getElementById('cloneStandby_walletPwd');
                var storage = document.getElementById('additionalStorageForToBeClonedDB');
                if (standbyDatabaseAdminPwd.valid !== 'valid' || standbyDatabaseWalletPwd.valid !== 'valid' || storage.valid !== 'valid')
                {
                    standbyDatabaseAdminPwd.showMessages();
                    standbyDatabaseWalletPwd.showMessages();
                    storage.showMessages();
                    invalidsPresent = true;
                }
            }
            return invalidsPresent;
        };
    }

    return DBTierDetailsContentViewModel;
});
