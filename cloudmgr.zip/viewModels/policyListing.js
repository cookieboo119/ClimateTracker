
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/navigation/pageNavigationHelper', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper',
    'ojs/ojlistdataproviderview', 'ojs/ojarraydataprovider', 'ebs/utils/scheduleUtils', 'ebs/utils/dateTimeHelper', 'ojs/ojarraytabledatasource', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojtable', 'ojs/ojlistview'
            , 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojinputsearch'
], function (oj, ko, constants, pageNavigationHelper, actionsHelper, popupHelper, ListDataProviderView, ArrayDataProvider, scheduleUtils, dateTimeHelper) {
    /**
     * The view model for the main content view template
     */
    function PolicyListViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.policyListLoaded = ko.observable(false);
        self.filter = ko.observable();
        self.policies = ko.observableArray([]);

        self.policyListDataProvider = ko.computed(function () {
            var filterRegEx = new RegExp(self.filter(), 'i');
            var filterCriterion = {
                op: '$or',
                criteria: [{op: '$regex', value: {name: filterRegEx}},
                    {op: '$regex', value: {jobType: filterRegEx}},
                    {op: '$regex', value: {createdBy: filterRegEx}},
                    {op: '$regex', value: {dateCreated: filterRegEx}}]
            };
            var arrayDataProvider = new ArrayDataProvider(self.policies(), {keyAttributes: 'id',
                    sortComparators: { comparators: new Map().set("dateCreated", dateTimeHelper.dateComparator)}});
            return new ListDataProviderView(arrayDataProvider, {filterCriterion: filterCriterion});
        }, self);

        self.policyIdentifierToEnvsMap = new Map();
        self.currentItemIndex = ko.observable();
        self.areEnvsAssociated = ko.observable(false);
        self.policyDeleteWarningText1 = ko.observable('');
        self.policyDeleteWarningText2 = ko.observable('');
        self.policyNameForAction = ko.observable('');
        self.policyIdForAction = ko.observable('');

        self.confirmDeleteMsg = ko.observable();
        self.policyListColumns = [
            {headerText: 'Name',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                field: 'name',
                sortable: 'enabled',
                template: 'nameCellTemplate',
                sortProperty: 'name'},
            {headerText: 'Type',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                field: 'jobType',
                sortable: 'enabled',
                template: 'textCellTemplate',
                sortProperty: 'jobType'},
            {headerText: 'Created By',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                field: 'createdBy',
                template: 'textCellTemplate',
                sortable: 'enabled',
                sortProperty: 'createdBy'},
            {headerText: 'Date Created',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: top;",
                field: 'dateCreated',
                template: 'textCellTemplate',
                sortable: 'enabled'}
            , {headerText: 'Actions',
                template: 'menuCellTemplate',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                field: 'menu',
                sortable: 'disabled'}
        ];


              
        var editPolicyEnabled = {id: 'EditPolicy', label: 'Edit', disabled: false};
        var deletePolicyEnabled = {id: 'DeletePolicy', label: 'Delete', disabled: false};
        self.menuOptions = ko.observableArray([]);

        self.handleCreatePolicyButtonClick = function (event) {
            var viewModelOfPopupModule = ko.dataFor(document.getElementById(constants.divTags.policyCreatePopupRoot));
            viewModelOfPopupModule.openPolicyCreationPopup(event);
        };
        
        self.searchText = ko.observable('');
        self.handleSearchTextChange = function(event, ui)
        {
           event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleValueChanged(event, ui);
            }
        }
        self.handleValueChanged = function () {
            self.filter(self.searchText());
        };

        self.displayPolicyDetails = function (viewModel, event) {
            var buttonIdentifier = event.target.id;
            var policyIdentifier = buttonIdentifier.split("~")[1];
            var policyObject = self.getPolicyObjectFromList(policyIdentifier);
            var policyName = policyObject.name;
            var jobType = policyObject.jobType;
            var viewModelOfPolicyDetailPopup = ko.dataFor(document.getElementById('PolicyDetailPopupRoot'));
            viewModelOfPolicyDetailPopup.openPopup(policyName, policyIdentifier, jobType, event);
        };

        self.getPolicyObjectFromList = function (policyIdentifier) {
            var allPolicies = self.policies();
            for (var i = 0; i < allPolicies.length; i++) {
                var policy = allPolicies[i];
                var policyId = policy.id;
                if (policyId === policyIdentifier) {
                    return policy;
                }
            }
        };

        self.gotoPolicyDetailsPG = function (viewModel, event) {
            var buttonIdentifier = event.target.id;
            var policyIdentifier = buttonIdentifier.split("~")[1];
            var policyObject = self.getPolicyObjectFromList(policyIdentifier);
            var policyName = policyObject.name;
            rootViewModel._drillDownPolicyId = policyIdentifier;
            rootViewModel._policyCreationDate = policyObject.dateCreated;
            rootViewModel._policyCreatedBy = policyObject.createdBy;
            var context = ko.contextFor(document.getElementById("policyListingPG"));
            pageNavigationHelper.navigateToPage(context, constants.navModules.policyDetailsModule, constants.navModules.policyDetailsModule);

        };

        self.preparePolicyIdentifierToEnvsMap = function (policyIdentifier) {
            actionsHelper.getEnvironmentsUsingPolicy(policyIdentifier, function (error, envList) {
                self.policyIdentifierToEnvsMap.set(policyIdentifier, envList);
            });
        };


        self.handleEventsFromMenu = function (event, ui) {
            var policyIdx = self.currentItemIndex();
            var policyName = self.policies()[policyIdx].name;
            self.policyNameForAction(policyName);
            var policyIdentifier = self.policies()[policyIdx].id;
            self.policyIdForAction(policyIdentifier);
            var eventSourceName = event.target.value;
            if ('EditPolicy' === eventSourceName) {
                rootViewModel._drillDownPolicyId = policyIdentifier;
                rootViewModel._policyCreationDate = self.policies()[policyIdx].dateCreated;
                rootViewModel._policyCreatedBy = self.policies()[policyIdx].createdBy;
                var context = ko.contextFor(document.getElementById("policyListingPG"));
                pageNavigationHelper.navigateToPage(context, constants.navModules.policyDetailsModule, constants.navModules.policyDetailsModule);
            } else if ('DeletePolicy' === eventSourceName) {
                var envList = self.policyIdentifierToEnvsMap.get(policyIdentifier);
                if (envList !== null && envList.length > 0) {
                    self.areEnvsAssociated(true);
                    var deletePolicyTextMap = scheduleUtils.getDeletePolicyWarningText(envList);
                    self.policyDeleteWarningText1(deletePolicyTextMap.get("Text1"));
                    self.policyDeleteWarningText2(deletePolicyTextMap.get("Text2"));
                } else {
                    self.areEnvsAssociated(false);
                    self.policyDeleteWarningText1('');
                    self.policyDeleteWarningText2("");
                }
                self.confirmDeleteMsg(oj.Translations.getTranslatedString("confirmPopup.deletePolicyAssertMsg", {policyName: policyName}));
                var popup = document.querySelector(constants.divTags.policyListDelPopupTag);
                popup.open(event.target);
            }
        };

        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.policyListDelPopupTag);
            popup.close();
        };

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.policyListingPGConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.policyListingPGConfPopupTag, data, event);
        };

        self.clearFilterInput = function () {
            if (document.getElementById('filterPolicySet') !== null) {
                document.getElementById('filterPolicySet').value = '';
            }
            self.filter('');
        };



        self.deletePolicy = function (event, ui) {
            var popup = document.querySelector(constants.divTags.policyListDelPopupTag);
            popup.close();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deletePolicyInfoMsg", {'policyName': self.policyNameForAction()});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.deletePolicyTitle");
            popupHelper.openInfoMsg(constants.divTags.policyListingPGConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.deletePolicy(constants.policies.Backup, self.policyIdForAction(), function (error, success) {
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deletePolicyConfirmMsg", {'policyName': self.policyNameForAction()});
                    popupHelper.openSuccessMsg(constants.divTags.policyListingPGConfPopupTag, successMsg, msgOrigin);
                    self.loadPolicies();
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.policyListingPGConfPopupTag, response.message, msgOrigin);
                }
            });
        };

        self.setupMenuOptions = function (event, ui) {
            var index = ui.index;
            self.currentItemIndex(index);
            self.menuOptions([]);
            self.menuOptions.push(editPolicyEnabled);
            self.menuOptions.push(deletePolicyEnabled);
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        };

        self.loadPolicies = function (compartmentOCIDSelected) {
            self.clearFilterInput();
            self.policyListLoaded(false);
            var compartmentFilter = null;
            if (compartmentOCIDSelected === null || compartmentOCIDSelected === '' || typeof(compartmentOCIDSelected) === 'undefined') {
                var compartmentFilter = 'All';
                var landingModuleContentDOMElement = document.getElementById('landingModulePageContent');
                if (landingModuleContentDOMElement !== null) {
                    var landingPageViewModel = ko.dataFor(landingModuleContentDOMElement);
                    var selectedCompartmentGlobally = landingPageViewModel.selectedCompartment();
                    if (selectedCompartmentGlobally !== null && selectedCompartmentGlobally !== '') {
                        compartmentFilter = selectedCompartmentGlobally;
                    }
                }
            }
            else{
                compartmentFilter = compartmentOCIDSelected;
            }
            actionsHelper.getAllPolicies(compartmentFilter, function (error, policyLists) {
                if (error !== null && error !== '')
                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelMessage('error', 'Error in retrieving policies.', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelMessage('error', 'Error in retrieving policies.', messageContent);
                    }
                }
                var listOfPolicies = [];
                $.each(policyLists, function () {
                    var task = {
                        id: this.id,
                        name: this.name,
                        jobType: this.jobType,
                        executeOn: this.executeOn,
                        dateCreated: dateTimeHelper.convertToUTC(this.createdOn),
                        createdBy: this.createdBy,
                        menu: self.menuOptions,
                        handleEventsFromMenu: self.handleEventsFromMenu,
                        setupMenuOptions: self.setupMenuOptions,
                        gotoPolicyDetails: self.gotoPolicyDetailsPG
                    };

                    listOfPolicies.push(task);
                });
                self.policies(listOfPolicies);
                self.policyListLoaded(true);

                for (var k = 0; k < self.policies().length; k++) {
                    self.preparePolicyIdentifierToEnvsMap(self.policies()[k].id);
                }
            });
        };

        self.loadPolicies();
    }
    return PolicyListViewModel;

});
