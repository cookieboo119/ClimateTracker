/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *  module
 */

define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/constants', 'ebs/popup/popupHelper'
], function (oj, ko, actionsHelper, constants, popupHelper) {

    /**
     * The view model for group assignment
     */
    function networkGroupAssignmentContentViewModel() {

        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        var networkName = rootViewModel.currentNetworkName();

        // Context Menu
        self.networkAssociationMenuItemsWithDelete = [
            {id: constants.contextMenu.removeGroup, label: oj.Translations.getTranslatedString('contextMenu.removeGroup'), disabled: false}
        ];

        self.networkAssociationMenuItemsDisabled = [
            {id: constants.contextMenu.removeGroup, label: oj.Translations.getTranslatedString('contextMenu.removeGroup'), disabled: true}
        ];

        self.associationList = ko.observableArray();
        self.datasourceForNetwork = new oj.ArrayTableDataSource(self.associationList, {idAttribute: 'name'});
        self.dataSource = ko.observable();
        self.dataSource(self.datasourceForNetwork);

        // Variable to check if group list is loaded
        self.groupListLoaded = ko.observable(false);

        self.loadGroups = function () {
            self.groupListLoaded(false);
            actionsHelper.getNetworkProfileAssociation(networkName, function (error, networkProfile) {
                self.groupListLoaded(true);
                if (error === '') {
                    self.associationList(networkProfile.associations);
                }
            });
        };

        self.selectedListItem = ko.observable();
        var associationName;
        self.selectionChanged = function (event, ui) {
            var currentSelectedItem = self.selectedListItem()[0];
            associationName = currentSelectedItem ? currentSelectedItem : associationName;
        };

        self.loadGroups();

        // Search
        self.handleSearchCriteria = function (event) {
            var filter = event.detail.value;
            if (filter.length === 0) {
                self.dataSource(self.datasourceForNetwork);
            } else {
                if (self.filteredDataSource === undefined) {
                    self.collection = self.flattenArrayDS(self.associationList());
                    self.filteredCollection = self.collection.clone();
                    self.filteredDataSource = new oj.CollectionTableDataSource(self.filteredCollection);
                }
                var ret = self.collection.where({name: {value: filter, comparator: self.genericFilter}});
                self.filteredCollection.reset(ret);
                if (self.dataSource() === self.datasourceForNetwork) {
                    self.dataSource(self.filteredDataSource);
                }
            }
        };

        self.genericFilter = function (model, attr, value) {
            var name = (model.get('name') !== null) ? model.get('name') : '';
            return ((name.toLowerCase().indexOf(value.toLowerCase()) > -1)
                    );
        };

        self.flattenArrayDS = function (data) {
            var collection = new oj.Collection();
            for (var i = 0; i < data.length; i++) {
                collection.add(data[i]);
            }
            return collection;
        };

        // Create association
        self.createNetworkProfileAssociation = function (event, ui) {
            var popup = document.querySelector(constants.divTags.associationCreatePopup);
            popup.open(event.target);
        };

        // Context menu actions triggered
        self.confirmDeleteMsg = ko.observable();
        self.networkAssociationActionsHandler = function (event, ui) {
            var localAssociationName = self.selectedListItem()[0];
            associationName = localAssociationName ? localAssociationName : associationName;
            var actionTriggered = ui.item[0].id;
            console.log('association name --' + associationName + ' Action Triggered --' + actionTriggered);
            if (associationName !== null && associationName !== '' && actionTriggered === constants.contextMenu.removeGroup) {
                console.log('Triggering delete action..');
                self.confirmDeleteMsg(oj.Translations.getTranslatedString("confirmPopup.deleteGroupAssertMsg", {associationName: associationName}));
                var popup = document.querySelector(constants.divTags.associationDelPopupTag);
                popup.open(event.target);
            }
        };

        self.deleteGroup = function () {
            var deleteGroupRequestBody = null;

            deleteGroupRequestBody = {
                "networkProfile": networkName,
                "associationType": "GROUP",
                "associations": [
                ]
            };

            var associations = self.associationList();
            var len = associations.length;

            // Iterating original list of LOV to retrieve selected label based on value
            for (var j = 0; j < len; j++) {
                if (associations[j].name === associationName) {
                    // Creating json to send to rest flow
                    deleteGroupRequestBody.associations.push({
                        name: associations[j].name,
                        OCID: associations[j].OCID
                    });
                    break;
                }
            }
            var requestBodyJSON = JSON.stringify(deleteGroupRequestBody);
            console.log('Delete association request JSON =>' + requestBodyJSON);

            var popup = document.querySelector(constants.divTags.associationDelPopupTag);
            popup.close();
            self.selectedListItem([]);
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteGroupInfoMsg", {'associationName': associationName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.deleteAssociationTitle");
            popupHelper.openInfoMsg(constants.divTags.networkAssociationConfPopupTag, infoMsg, msgOrigin);

            actionsHelper.deleteNetworkProfileAssociation(requestBodyJSON, function (error, success) {
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteGroupConfirmMsg", {'associationName': associationName});
                    popupHelper.openSuccessMsg(constants.divTags.networkAssociationConfPopupTag, successMsg, msgOrigin);
                    self.loadGroups();
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.networkAssociationConfPopupTag, response.message, msgOrigin);
                }
            });
        };

        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.associationDelPopupTag);
            popup.close();
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.networkAssociationConfPopupTag, data, event);
        };

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.networkAssociationConfPopupTag, event, ui);
        };
    }
    return networkGroupAssignmentContentViewModel;
});