
define(['ojs/ojcore', 'knockout', 'ebs/constants'
], function (oj, ko, constants) {
    /**
     * The view model for the main content view template
     */
    function ExecutionFrameworkViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        var currentStateOfTheRouter = oj.Router.rootInstance.currentState();
        var globalChildRouter = currentStateOfTheRouter._router._childRouters[4];
        self.selectedSubTabExecFwk = ko.observable();
        self.selectedSubTab_execFwk_navBar = ko.observable();

        self.initializeSubTabSelection = function ()
        {
            var initialExecFwkSubTab = rootViewModel.initialExecutionFwkSubTab;
            if (typeof (initialExecFwkSubTab) !== 'undefined' && initialExecFwkSubTab !== null) {
                self.selectedSubTabExecFwk(initialExecFwkSubTab);
                self.selectedSubTab_execFwk_navBar(initialExecFwkSubTab);
                rootViewModel.initialExecutionFwkSubTab = null;
            } else {
                var taskModuleId = globalChildRouter.states[0].id;
                self.selectedSubTabExecFwk(taskModuleId);
                self.selectedSubTab_execFwk_navBar(taskModuleId);
            }
        };

        self.execFwkSubTabSelectionHandler = function (event)
        {
            if (constants.divTags.execFwkMenuListIdentifier === event.target.id && event.detail.originalEvent)
            {
                // router takes care of changing the selection
                event.preventDefault();
                self.selectedSubTabExecFwk(event.detail.key);
                self.selectedSubTab_execFwk_navBar(event.detail.key);
                
            }
        };

        self.buildSubTabs = function () {
            console.log('Building Sub Tab Data');
            var jsonData = [];
            globalChildRouter.states.forEach(function (state) {

                jsonData.push({
                    'attr': {
                        id: state.id,
                        label: state.label,
                        href: "?root=" + state.id
                    }
                });

            });
            return jsonData;
        };

        self.execFwkSubTabs = new oj.JsonTreeDataSource(self.buildSubTabs());
        self.initializeSubTabSelection();
    }
    return ExecutionFrameworkViewModel;

})
