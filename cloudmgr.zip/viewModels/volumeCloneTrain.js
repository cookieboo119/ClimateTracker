/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * wizard module
 */

define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper',
    'ebs/navigation/pageNavigationHelper', 'ebs/utils/dateTimeHelper', 'ebs/utils/networkProfileHelper',
    'ojs/ojarraydataprovider', 'ebs/utils/helpMenu', 'ojs/ojvalidator-regexp', 'ebs/utils/versionUtils', 'ebs/utils/createCloneTrainUtils',
    'ebs/utils/lovUtils', 'ojs/ojasyncvalidator-numberrange', 'jquery', 'ojs/ojmenu', 'ojs/ojpopup', 'ojs/ojtoolbar', 'ojs/ojnavigationlist',
    'ojs/ojselectcombobox', 'ojs/ojinputtext', 'ojs/ojknockout-validation', 'ojs/ojradioset', 'ojs/ojknockout',
    'ojs/ojtrain', 'ojs/ojmodule', 'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojcheckboxset', 'ojs/ojmessages', 'ojs/ojtable', 'ojs/ojvalidationgroup'],
        function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper, dateTimeHelper,
                networkProfileHelper, ArrayDataProvider, helpMenu, RegExpValidator, versionUtils, createCloneUtils, lovUtils)
        {

            function volumeCloneTrainViewModel()
            {
                var self = this;

                /**
                 * Existing env details
                 */
                var existingEnvName;
                self.sourceEnvironmentName = ko.observable();
                var ebsVersion;
                var dbVersion;
                var networkProfileName;
                var dbName;

                var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
                rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.cloneEnvPageHeader'));
                var envName = rootViewModel.cloneSourceEnv();
                rootViewModel.showNavTab(false);

                var isDetailPG = rootViewModel.isDetailPG();
                self.title = ko.observable('Clone Environment ' + envName);
                self.traincontext = ko.observable('clone');

                self.disableNextBtn = ko.observable(false);
                self.disablePrevBtn = ko.observable(false);

                self.selected = ko.observable(constants.navModules.volumeCloneModule);
                self.currentStep = ko.observable(constants.navModules.volumeCloneModule);
                self.tracker = ko.observable();
                self.focusListItemInReviewPage = ko.observable(false);
                self.prevPage = ko.observable(oj.Translations.getTranslatedString('pageHeader.cloneEnvPageHeader'));
                self.currentModule = ko.observable(self.currentStep());

                self.disableSubmitBtn = ko.observable(false);

                self.topologyMessages = ko.observableArray([]);
                self.cloneZonesData = ko.observableArray([]);

                self.loadBalancerOptionEnabled = ko.observable(false);
                self.lbaasOptions = ko.observableArray([{'label': 'New Load Balancer (LBaaS)', 'value': 'DEPLOY_NEW'}, {'label': 'Manually Configured Load Balancer', 'value': 'USE_EXISTING'}, {'label': 'Application Tier Node', 'value': 'NO_LOAD_BALANCER'}]);
                self.lbaasOptionsWithoutAppTierWebEntry = ko.observableArray([{'label': 'New Load Balancer (LBaaS)', 'value': 'DEPLOY_NEW'}, {'label': 'Manually Configured Load Balancer', 'value': 'USE_EXISTING'}]);
                self.lbaasOptionValue = ko.observable('DEPLOY_NEW');
                self.lbShapes = ko.observableArray([{'label': 'Loading....', 'value': ''}]);

                self.disableLbaasOptions = ko.observable(false);
                self.networkName = ko.observable('loading...');
                self.compartment = ko.observable('loading...');
                self.envNameInputValue = ko.observable('');
                self.selectedEbsVerValue = ko.observable('');
                self.selectedPurposeValue = ko.observable('');
                self.selectedDBReleaseValue = ko.observable('');
                self.isInstallationTypeUsed = ko.observable('Clone');
                self.selectedNetworkProfileName = ko.observable('');

                self.appsPassword = ko.observable('');
                self.weblogicPassword = ko.observable('');
                self.lbaasShape = ko.observable('');
                self.loadBalancerTypeSelected = ko.observable('PUBLIC');
                self.disableSubmit = ko.observable(false);

                self.zonesEditDone = ko.observable(false);
                //clone review page detail
                self.dbTypeUsed = ko.observable('');
                // This is required in SSH keys step to identify single or multi vm
                self.deploymentType = ko.observable('');
                self.showPDBPromptForCompute = ko.observable('No');
                self.dbShape = ko.observable('');
                self.dbNameValue = ko.observable('');
                self.enableTDEFlagForComputeInReviewScreen = ko.observable(false);
                self.vmdbNodeCount = ko.observable('');
                self.softEditionDispValue = ko.observable('');
                self.vmdbLicenseType = ko.observable('');
                self.clusterName = ko.observable('');
                self.totalStorage = ko.observable('');
                self.vmDBSoftwareEdition = ko.observable('');
                self.dbShapeValue = ko.observable('');
                self.vmDBPDBName = ko.observable('');
                self.computePDBName = ko.observable('');
                self.dbNodesArray = ko.observableArray([]);
                self.dbNodesDataProvider = new ArrayDataProvider(self.dbNodesArray, {keyAttributes: 'RowId'});

                self.dbLogicalDomainName = ko.observable('');
                self.dbLogicalHostNamePrefixValue = ko.observable('');
                self.appShapeChoiceOptionsList = ko.observableArray();
                self.appsLogicalDomainName = ko.observable('');
                self.appsLogicalHostConfigured = ko.observable(true);
                self.dbLogicalHostConfigured = ko.observable(true);

                self.pageLevelMessages = ko.observableArray([]);

                self.stepArray = ko.observableArray([
                    {label: oj.Translations.getTranslatedString('pageHeader.cloneEnvPageHeader'), id: constants.navModules.volumeCloneModule, rank: 0, disabled: false},
                    {label: oj.Translations.getTranslatedString('pageHeader.topology'), id: constants.navModules.topologyDetailsModule, rank: 1, disabled: false},
                    {label: oj.Translations.getTranslatedString('pageHeader.postProvisioningOptions'), id: constants.navModules.postProvisioningStepsModule, rank: 2, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.uploadKeys'), id: constants.navModules.uploadKeysModule, rank: 3, disabled: true},
                    {label: oj.Translations.getTranslatedString('pageHeader.review'), id: constants.navModules.reviewModule, rank: 4, disabled: true}
                ]);

                self.nameToRankMap = new Map();
                for (var i = 0; i < self.stepArray().length; i++)
                {
                    self.nameToRankMap.set(self.stepArray()[i].id, self.stepArray()[i].rank);
                }

                self.modulePath = ko.pureComputed(function ()
                {
                    console.log('Getting Module Path..');
                    createCloneUtils.disableTrainSteps(self.currentModule(), self.stepArray(), self.zonesEditDone());
                    // Adding context as 'volumeClone' instead of self.currentModule() as each steps of train pointing to same help doc
                    helpMenu.addElementAndRemoveDuplicate('volumeClone');
                    return (constants.navModules.createEnvironmentModule + '/' + self.currentModule());
                });


                self.handleBackLink = function (event, ui)
                {
                    var context = ko.contextFor(document.getElementById(constants.divTags.envCloneTrainPage));
                    var prevModule = (isDetailPG !== '' && isDetailPG) ? constants.navModules.envDetailsModule : constants.navModules.envListModule;
                    if (prevModule === constants.navModules.envDetailsModule)
                    {
                        rootViewModel.prevEnvDetailsNavItem(constants.navModules.envDetailsModule);
                    }
                    pageNavigationHelper.navigateToPage(context, prevModule, prevModule, true);
                };

                self.optionChangeHandler = function (event, ui)
                {
                    var toStep = event.detail.toStep;
                    var fromStep = event.detail.fromStep;
                    var newOption = toStep.id;
                    var newOptionRank = toStep.rank;
                    var previousOption = event.detail.fromStep.id;
                    var previousOptionRank = fromStep.rank;
                    if (newOptionRank > previousOptionRank)
                    {
                        self.validateAndGotoNextStep(previousOption, newOption, event);
                    } else
                    {
                        self.clearPageLevelMessagesOnNavigation();
                        self.selected(newOption);
                        self.currentStep(newOption);
                        self.currentModule(self.currentStep());
                    }
                };

                self.addPageLevelMessage = function (pageName, messageSeverity, messageSummary, messageDetail, clearAllPrevMessages)
                {
                    var newPageMessageObject = new Object();
                    newPageMessageObject.severity = messageSeverity;
                    newPageMessageObject.summary = messageSummary;
                    newPageMessageObject.detail = messageDetail;
                    if (typeof (clearAllPrevMessages) !== 'undefined' && clearAllPrevMessages) {
                        var tempArray = new Array();
                        tempArray.push(newPageMessageObject);
                        self.pageLevelMessages(tempArray);
                    } else {
                        var tempArray = self.pageLevelMessages();
                        tempArray.push(newPageMessageObject);
                        self.pageLevelMessages(tempArray);
                    }

                };
                self.clearPageLevelMessagesOnNavigation = function ()
                {
                    self.pageLevelMessages([]);
                };

                self.postOptionChangeHandler = function (event, ui)
                {

                };

                self.prevStep = function ()
                {
                    var prev = $('#train').ojTrain('previousSelectableStep');
                    if (prev !== null)
                    {
                        self.selected(prev);
                        self.currentStep(prev);
                        console.log('current step in the train (prev clicked)' + self.selected());
                        createCloneUtils.disableTrainSteps(self.selected(), self.stepArray(), self.zonesEditDone());
                        if (prev === constants.navModules.volumeCloneModule)
                        {
                            self.disableNextBtn(false);
                        }
                        self.currentModule(self.currentStep());
                    }
                };

                self.nextStep = function ()
                {
                    var next = $('#train').ojTrain('nextSelectableStep');
                    self.selected(next);
                };

                self.topologyPageValid = function ()
                {
                    var zonesListViewElement = document.getElementById('zonesListView');
                    var viewModuleOfTopologyPG = ko.dataFor(zonesListViewElement);
                    return viewModuleOfTopologyPG.isTopologyValid();
                };
                
                self.validateAndGotoNextStep = function (previousStep, nextStep, trainSelectionEvent)
                {
                    var invalid = false;
                    if (nextStep !== null)
                    {
                        createCloneUtils.disableTrainSteps(self.selected(), self.stepArray(), self.zonesEditDone());
                        if (previousStep === constants.navModules.volumeCloneModule)
                        {
                            if (!this.installationDetailsPageValid())
                            {
                                invalid = true;
                            } else
                            {
//                                self.stepArray()[2].disabled = false;
//                                self.stepArray()[3].disabled = false;
//                                self.stepArray()[4].disabled = false;
                                if (!self.zonesEditDone())
                                {
                                    self.stepArray()[2].disabled = true;
                                    self.disableNextBtn(true);
                                } else
                                {
                                    self.stepArray()[2].disabled = false;
                                    self.disableNextBtn(false);
                                }
                            }
                        }
       
                       if (previousStep === constants.navModules.postProvisioningStepsModule)
                       {
                           var execPlanCustomizationViewModel = ko.dataFor(document.getElementById('customTasksListingTab'));
                           if (typeof (execPlanCustomizationViewModel) !== 'undefined') {
                               var isExecPlanPageValid = execPlanCustomizationViewModel.isFormValid();
                               if (!isExecPlanPageValid)
                               {
                                   console.log('Errors found ..');
                                   invalid = true;
                               }
                           }
                       }
                        
                        if (previousStep === constants.navModules.uploadKeysModule) {
                            var uploadKeysViewModel = ko.dataFor(document.getElementById('uploadKeysPGForm'));
                            if (typeof (uploadKeysViewModel) !== 'undefined') {
                                var isUploadKeysPageValid = uploadKeysViewModel.isFormValid();
                                if (!isUploadKeysPageValid) {
                                    console.log('Errors found in upload keys module.');
                                    invalid = true;
                                }
                            }
                        }
                        
                        if (previousStep === constants.navModules.topologyDetailsModule && !this.topologyPageValid())
                        {
                            console.log('Errors found ..');
                            invalid = true;
                        } else if (nextStep === constants.navModules.reviewModule)
                        {

                        }
                        if (invalid)
                        {
                            if (!$.isEmptyObject(trainSelectionEvent))
                            {
                                trainSelectionEvent.preventDefault();
                            }
                            self.stayInSameStep(previousStep);
                        } else
                        {
                            console.log('No client side errors found..proceeding to server side validations..');
                            console.log('current step in the train (next clicked) ' + self.selected());
                            self.performServerSideValidations(previousStep, nextStep, trainSelectionEvent);

                        }
                    }
                };

                self.performServerSideValidations = function (prevStep, nextStep, trainSelectionEvent)
                {
                    var proceed = false;
                    if (prevStep === constants.navModules.uploadKeysModule)
                    {
                        self.disableNextBtn(true);
                        createCloneUtils.performSSHKeysPGServerValidation(self, prevStep, nextStep, trainSelectionEvent);
                    } else
                    {
                        proceed = true;
                    }
                    if (proceed)
                    {
                        self.proceeedToNextStep(prevStep, nextStep, trainSelectionEvent);
                    }

                };

                self.installationDetailsPageValid = function ()
                {
                    var envName = document.getElementById("envName");
                    var wlsPassword = document.getElementById("wlsPassword");
                    var appsPassword = document.getElementById("appsPassword");
                    var tagKeyText = document.getElementById("tagKeyText0");
                    var invalidsPresent = false;
                    if (envName.valid !== 'valid')
                    {
                        envName.showMessages();
                        invalidsPresent = true;
                    }
                    if (appsPassword.valid !== 'valid')
                    {
                        appsPassword.showMessages();
                        invalidsPresent = true;
                    }
                    if (wlsPassword && wlsPassword.valid !== 'valid')
                    {
                        wlsPassword.showMessages();
                        invalidsPresent = true;
                    }
                    if (null !== tagKeyText && tagKeyText.valid !== 'valid') {
                        tagKeyText.showMessages();
                        invalidsPresent = true;
                    }

                    return !invalidsPresent;
                };


                self.stayInSameStep = function (prevStep)
                {
                    self.selected(prevStep);
                    self.currentStep(prevStep);
                    self.currentModule(self.currentStep());
                };

                self.proceeedToNextStep = function (prevStep, nextStep, trainSelectionEvent)
                {
                    var prevStepRank = self.nameToRankMap.get(prevStep);
                    var nextStepRank = self.nameToRankMap.get(nextStep);

                    if (nextStepRank - prevStepRank > 1)
                    {
                        // We are not allowed to skip steps at this moment. so go to next step.
                        var prevStepIdx = self.findIndexOfATrainStep(prevStep);
                        if (prevStepIdx !== -1)
                        {
                            if (!$.isEmptyObject(trainSelectionEvent))
                            {
                                trainSelectionEvent.preventDefault();
                            }
                            var newIdxToMove = prevStepIdx + 1;
                            nextStep = self.stepArray()[newIdxToMove].id;
                        }

                    }
                    self.clearPageLevelMessagesOnNavigation();
                    self.selected(nextStep);
                    self.currentStep(nextStep);
                    self.currentModule(self.currentStep());
                };

                self.findIndexOfATrainStep = function (stepName)
                {
                    for (var i = 0; i < self.stepArray().length; i++)
                    {
                        var currentStepName = self.stepArray()[i].id;
                        if (currentStepName === stepName)
                        {
                            return i;
                        }
                    }
                    return -1;
                };


                actionsHelper.getOCIShapes(function (error, envMetadata)
                {
                    if (error !== null && error !== '')
                    {
                        if (error.status === 504)
                        {
                            var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                            self.addPageLevelMessage('Installation', 'error', 'Error in fetching OCI Shapes.', messageContent);
                        } else
                        {
                            var errorCode = error.responseJSON.code;
                            if (error.responseJSON.code === null || error.responseJSON.code === '')
                            {
                                errorCode = error.status;
                            }
                            var messageContent = 'Error Message : ' + error.responseJSON.message;
                            self.addPageLevelMessage('Installation', 'error', 'Error in fetching OCI Shapes', messageContent);
                        }
                        return;
                    }
                    self.appShapeChoiceOptionsList(envMetadata.app);
                    self.lbShapes(envMetadata.lb);
                });

                actionsHelper.getEnvDetails(envName, function (error, envs) {
                    var nodeCount = -1;
                    if (error === '') {
                        self.environmentDetails = envs;
                        existingEnvName = envs.name;
                        self.sourceEnvironmentName(existingEnvName);
                        ebsVersion = envs.version;
                        dbVersion = envs.dbTier.version;
                        dbName = envs.dbTier.databaseName;

                        self.selectedEbsVerValue(ebsVersion);
                        self.selectedDBReleaseValue(dbVersion);
                        self.deploymentType(envs.deploymentType);

                        var isDBMajorVersion19AndAbove = versionUtils.isDBMajorVersionGreaterThanOrEqualToNineteen(dbVersion);
                        if (isDBMajorVersion19AndAbove)
                        {
                            self.showPDBPromptForCompute('Yes');
                        } else
                        {
                            self.showPDBPromptForCompute('No');
                        }

                        //DB Tier Info               
                        self.dbNameValue(dbName);
                        self.dbShapeValue(envs.dbTier.shape);
                        if (envs.dbTier.clusterName)
                            self.clusterName(envs.dbTier.clusterName);

                        var serviceTypeValue = envs.dbTier.serviceType.value;
                        if (constants.dbTypes.computeds === serviceTypeValue)
                        {
                            self.dbTypeUsed('Compute');
                            self.enableTDEFlagForComputeInReviewScreen(envs.dbTier.tdeEnabled);
                            self.computePDBName(envs.dbTier.pdbName);
                        } else if (constants.dbTypes.vmdbsystem === serviceTypeValue)
                        {
                            self.dbTypeUsed('VMDB System');
                            self.vmDBSoftwareEdition(envs.dbTier.edition);
                            self.vmDBPDBName(envs.dbTier.pdbName);

                        } else if (constants.dbTypes.exadatadbsystem === serviceTypeValue)
                        {
                            self.dbTypeUsed('Exadata System');

                        }
                        self.dbLogicalHostConfigured(envs.dbTier.logicalHostConfigured);
                        
                        var dbNodes = [];
                        if (envs.dbTier.nodes)
                        {
                            self.vmdbNodeCount(envs.dbTier.nodes.length);
                            for (var i = 0; i < envs.dbTier.nodes.length; i++)
                            {
                                dbNodes.push({RowId: i + 1, faultDomain: envs.dbTier.nodes[i].faultDomain})
                            }

                            if (envs.dbTier.nodes[0].logicalFqdn && envs.dbTier.nodes[0].logicalFqdn.indexOf('.') > 0)
                            {
                                var dbLogicalHost = envs.dbTier.nodes[0].logicalFqdn.substring(0, envs.dbTier.nodes[0].logicalFqdn.indexOf('.'));
                                var dbLogicalDomain = envs.dbTier.nodes[0].logicalFqdn.substring(envs.dbTier.nodes[0].logicalFqdn.indexOf('.') + 1);
                                self.dbLogicalHostNamePrefixValue(dbLogicalHost);
                                self.dbLogicalDomainName(dbLogicalDomain);
                            }
                            self.dbNodesArray(dbNodes);
                        }
                        self.totalStorage = ko.observable('');


                        //Apps Tier Info
                        var appNodes = envs.appTier.groups ? envs.appTier.groups[0].nodes : envs.appTier.zones[0].nodes;

                        self.appsLogicalHostConfigured(envs.appTier.logicalHostConfigured);

                        //zone support
                        var zonesData = [];
                        var sequence = 1; //seq starts from 1
                        $.each(envs.appTier.zones, function () {
                            var zone = this;

                            var zoneNodes = zone.nodes;
                            var fileSystemType = zone.fileSystemType.value;
                            var rowObject = new Object();
                            rowObject.identifier = sequence;
                            rowObject.name = ko.observable(zone.name);
                            console.log("zoneName=" + zone.name);
                            rowObject.type = ko.observable(zone.type);
                            rowObject.appNodesCount = ko.observable(zoneNodes.length);
                            rowObject.editStatus = ko.observable(false);
                            rowObject.isPrimaryExternalZone = ko.observable(false);
                            rowObject.lbaasOptionValue = self.lbaasOptionValue;
                            rowObject.fileSystemType = ko.observable(fileSystemType);
                            rowObject.webEntryURL = ko.observable('');
                            rowObject.webEntryType = ko.observable('');
                            rowObject.port = ko.observable('');
                            rowObject.protocol = ko.observable('');
                            rowObject.hostName = ko.observable('');
                            rowObject.domain = ko.observable('');
                            rowObject.enableDeleteOption = ko.observable(false);
                            var zoneAppNodes = [];
                            //Add Zone app nodes                 
                            for (var j = 0; j < rowObject.appNodesCount(); j++)
                            {
                                var appNode = zoneNodes[j];
                                var appsLogicalHost = '';
                                var appsLogicalDomain = '';
                                if (appNode.logicalFqdn && appNode.logicalFqdn.indexOf('.') > 0)
                                {
                                    appsLogicalHost = appNode.logicalFqdn.substring(0, appNode.logicalFqdn.indexOf('.'));
                                    if (j == 0)
                                    {
                                        appsLogicalDomain = appNode.logicalFqdn.substring(appNode.logicalFqdn.indexOf('.') + 1);
                                        self.appsLogicalDomainName(appsLogicalDomain);
                                    }
                                }
                                var eachNodeEntry = new Object();
                                eachNodeEntry.AppNodeName = appNode.nodeName;
                                eachNodeEntry.Storage = appNode.volumeSize;
                                eachNodeEntry.Shape = appNode.shape;
                                eachNodeEntry.OrigShape = appNode.shape;
                                eachNodeEntry.FaultDomain = appNode.faultDomain;
                                eachNodeEntry.AdditionalStorage = '';
                                eachNodeEntry.FileSystemMode = fileSystemType;
                                eachNodeEntry.logicalHostname = appsLogicalHost;

                                zoneAppNodes.push(eachNodeEntry);
                            }
                            rowObject.AppNodesData = zoneAppNodes;
                            zonesData.push(rowObject);
                            sequence++;
                        });

                        self.cloneZonesData(zonesData);

                        nodeCount = appNodes.length;

                        if (nodeCount > 1)
                        {
                            self.lbaasOptions(self.lbaasOptionsWithoutAppTierWebEntry());
                        }

                        if (envs.networkProfile === null || envs.networkProfile === '' || typeof (envs.networkProfile) === 'undefined')
                        {
                            self.disableSubmit(true);
                        } else
                        {
                            networkProfileName = envs.networkProfile;
                            self.networkName(envs.networkProfile);
                            self.selectedNetworkProfileName(envs.networkProfile);
                            actionsHelper.getNetworkProfileDetails(networkProfileName, function (error, details)
                            {

                                self.compartment(details.ebsCompartment);
                                var lbaasSection = details.lbaas;
                                if (lbaasSection === null || typeof (lbaasSection) === 'undefined' || lbaasSection === '')
                                {
                                    console.log('Disabling LBAAS');
                                    self.loadBalancerOptionEnabled(false);
                                    self.lbaasOptionValue("USE_EXISTING");
                                }
                                var lbaasSubnetOCID = lbaasSection.internal.subnetOCID;
                                if (lbaasSubnetOCID === null || typeof (lbaasSubnetOCID) === 'undefined' || lbaasSubnetOCID === '')
                                {

                                    console.log('Disabling LBAAS');
                                    self.loadBalancerOptionEnabled(false);
                                    self.lbaasOptionValue("USE_EXISTING");
                                } else
                                {
                                    self.loadBalancerOptionEnabled(true);
                                    console.log('Enabling LBAAS');
                                    self.lbaasOptionValue("DEPLOY_NEW");
                                }

                            });

                            // Retrieve tag namespace options 
                            actionsHelper.getTagNamespaceInformation(networkProfileName, function (error, tagDetails) {
                                console.log('networkProfileName:' + networkProfileName);
                                var cloneModuleVM = ko.dataFor(document.getElementById(constants.divTags.envClonePage));
                                if (cloneModuleVM)
                                    cloneModuleVM.tagNamespaceOptionsList.removeAll();
                                var tagDetailsLen = tagDetails.length;
                                if (null !== tagDetails && tagDetailsLen > 0) {
                                    var tagOptions = new Array();
                                    var optionData = new Object();
                                    optionData.label = 'None (add a free-form tag)';
                                    optionData.value = 'none';
                                    tagOptions.push(optionData);
                                    for (var i = 0; i < tagDetailsLen; i++) {
                                        var metaData = tagDetails[i];
                                        if (null !== metaData.label && metaData.label.length > 0) {
                                            var optionData = new Object();
                                            optionData.label = metaData.label;
                                            optionData.value = metaData.value;
                                            tagOptions.push(optionData);
                                        }
                                    }
                                    if (cloneModuleVM)
                                    {
                                        cloneModuleVM.tagNamespaceOptionsList(tagOptions);
                                        lovUtils.lovOptionsUpdated(cloneModuleVM.tagNamespaceOptionsList(), cloneModuleVM.selectedTagNamespace);
                                        cloneModuleVM.tagKeyList(tagDetails);
                                    }
                                }
                            });
                        }
                    }
                });

                self.cancel = function () {
                    var context = ko.contextFor(document.getElementById(constants.divTags.envCloneTrainPage));
                    pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                };

                self.startAnimationListener = function (event, ui)
                {
                    popupHelper.startAnimationListener(constants.divTags.envCloneConfPopupTag, event, ui);
                };

                self.confirmationPopupCloseHandler = function (data, event) {
                    popupHelper.confmPopuCloseHandler(constants.divTags.envCloneConfPopupTag, data, event);
                };
                
                self.myName = function(){
                   return "clone"; 
                };


                self.submitCloneEnv = function () {
                    var infoMsg = oj.Translations.getTranslatedString("confirmPopup.cloneEnvInfoMsg", {'envName': envName});
                    var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.cloneEnvTitle");
                    popupHelper.openInfoMsg(constants.divTags.envCloneConfPopupTag, infoMsg, msgOrigin);
                    self.postClone();
                    console.log("about to submit clone ");
                };

                self.postClone = function () {

                    // Variables for tag module
                    var selTagName = '';
                    var selTagKeyText = '';
                    var selTagKeySelect = '';
                    var selFreeTagValue = '';
                    var selTagValue = '';

                    var clonePGViewModule = ko.dataFor(document.getElementById(constants.divTags.envClonePage));

                    // Logic to set values for tag module
                    if (clonePGViewModule.selectedTagNamespace() === 'none') {
                        selFreeTagValue = clonePGViewModule.selectedTagValue();
                        selTagKeyText = clonePGViewModule.selectedTagKeyText();
                    } else {
                        selTagName = clonePGViewModule.selectedTagNamespace();
                        selTagKeySelect = clonePGViewModule.selectedTagKeySelect();
                        selTagValue = clonePGViewModule.selectedTagValue();
                    }

                    var topologyDetailsViewModel = ko.dataFor(document.getElementById('zonesListView'));
                    var startAppTierService = topologyDetailsViewModel.startAppTier();

                    var cloneRequestBody = {
                        "source": {
                            "credentials": {
                                "environment": {
                                    "appsPassword": self.appsPassword(),
                                    "weblogicPassword": self.weblogicPassword()
                                }
                            },
                            "environment": {
                                "name": existingEnvName
                            }
                        },
                        "target": {
                            "credentials": {
                                "ssh": {
                                    "appTier": [

                                    ],
                                    "dbTier": [

                                    ]
                                }
                            },
                            "environment": {
                                "name": self.envNameInputValue(),
                                "networkProfile": networkProfileName,
                                "appTier": {
                                    "zones": [],
                                    "startServices": (startAppTierService? "yes" : "no")
                                },
                                "tags": {
                                    "freeFloat": [
                                        {
                                            "key": selTagKeyText,
                                            "value": selFreeTagValue
                                        }
                                    ],
                                    "defined": [
                                        {
                                            "namespace": selTagName,
                                            "key": selTagKeySelect,
                                            "value": selTagValue
                                        }
                                    ]
                                }
                            }
                        }
                    };

                    var executionFrameworkPGViewModel = ko.dataFor(document.getElementById('customTasksListingTab'));
                    if (typeof (executionFrameworkPGViewModel) !== 'undefined') {
                        var formDataForSubmit = executionFrameworkPGViewModel.getExtensibleTasksFormData();
                        cloneRequestBody.extensibleTasks = formDataForSubmit;
                        var pausedTasks = executionFrameworkPGViewModel.getPausedTasksFormData();
                        if (pausedTasks !== null) {
                            cloneRequestBody.pauseAt = pausedTasks;
                        }
                    }


                    var appTierSSHKeys = createCloneUtils.getFormDataForAppTierSSHKeys();
                    if (appTierSSHKeys !== null && appTierSSHKeys.length > 0) {
                        cloneRequestBody.target.credentials.ssh.appTier = appTierSSHKeys;
                    }
                    var dbTierSSHKeys = createCloneUtils.getFormDataForDBTierSSHKeys();
                    if (dbTierSSHKeys !== null && dbTierSSHKeys.length > 0) {
                        cloneRequestBody.target.credentials.ssh.dbTier = dbTierSSHKeys;
                    }

                    //New refactored API  
                    var applicationTierGroups = cloneRequestBody.target.environment.appTier.zones;
                    var zonesPostInformation = topologyDetailsViewModel.getZonePostData();
                    if (zonesPostInformation !== null && zonesPostInformation.length > 0)
                    {
                        for (var i = 0; i < zonesPostInformation.length; i++)
                        {
                            applicationTierGroups.push(zonesPostInformation[i]);
                        }
                    }
                    self.disableSubmitBtn(true); //block submit during request submission
                    var requestBodyJSON = JSON.stringify(cloneRequestBody);
                    var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.cloneEnvTitle");
                    actionsHelper.cloneEnv(requestBodyJSON, function (error, success) {
                        if (error === '') {
                            var context = ko.contextFor(document.getElementById(constants.divTags.envCloneTrainPage));
                            var successMsg = oj.Translations.getTranslatedString("confirmPopup.cloneEnvSuccessMsg", {'envName': envName});
                            rootViewModel.displayPopupId(constants.divTags.envCloneConfPopupTag);
                            popupHelper.setSuccessPopupMsg(successMsg, msgOrigin);
                            pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                        } else {
                            self.disableSubmitBtn(false);
                            var responseText = error.responseText;
                            var response = JSON.parse(responseText);
                            popupHelper.openErrorMsg(constants.divTags.envCloneConfPopupTag, response.message, msgOrigin);
                        }
                        rootViewModel.cloneSourceEnv('');
                    });

                };

            }

            return volumeCloneTrainViewModel;
        });
