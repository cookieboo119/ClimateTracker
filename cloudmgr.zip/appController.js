/**
 * Copyright (c) 2014, 2017, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Application Code will go here.
 */
define(['ojs/ojcore', 'knockout', 'ojs/ojrouter', 'ojs/ojknockout', 'ojs/ojarraytabledatasource',
    'ojs/ojoffcanvas'],
        function (oj, ko) {
            function ControllerViewModel() {
                var self = this;
                // Media queries for repsonsive layouts
                var smQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY);
                self.smScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);
                var mdQuery = oj.ResponsiveUtils.getFrameworkQuery(oj.ResponsiveUtils.FRAMEWORK_QUERY_KEY.MD_UP);
                self.mdScreen = oj.ResponsiveKnockoutUtils.createMediaQueryObservable(mdQuery);
                var pageTitle = "E-Business Suite Cloud Manager";
                // Router setup
                self.router = oj.Router.rootInstance;
                self.router.configure({
                    'introduction': {label: pageTitle},
                    'login': {label: pageTitle, isDefault: true},
                    'landingModule_oci': {label: pageTitle},
                    'environmentDetails_oci': {
                        label: pageTitle,
                        value: self.router.createChildRouter('environmentDetailSubTabs', 'environmentDetails_oci').
                                configure(
                                        {
                                            'environmentOverview_oci': {label: oj.Translations.getTranslatedString("navListTitle.environmentTopology"), isDefault: true},
                                            'backupDetailsCommon_oci': {label: oj.Translations.getTranslatedString("navListTitle.environmentBackups")},
                                            'environmentSpecificActivities': {label: oj.Translations.getTranslatedString("navListTitle.environmentActivities")},
                                            'standbyEnvSyncDetails': {label: oj.Translations.getTranslatedString("navListTitle.standbyEnvSyncDetails")},
                                        })
                    },
                    'createEnvironment_oci': {label: pageTitle},
                    'createQuickEnvironment_oci': {label: pageTitle},
                    'accountDetails_oci': {label: pageTitle},
                    'volumeClone_oci': {label: pageTitle},
                    'releaseStandByEnvironment': {label: pageTitle},
                    'activityDetails_oci': {label: pageTitle},
                    'executionFrameworkTemplate':{label:'Create Execution Template'},
                    'executionFrameworkTask':{label:'Create Task'},
                    'policyDetailsPG':{label:'Edit Policy Details'},
                    'networkProfileDetails_oci': {
                        label: pageTitle,
                        value: self.router.createChildRouter('networkProfileDetailSubTabs', 'networkProfileDetails_oci')
                                .configure(
                                        {
                                            'networkAssignment_oci': {label: oj.Translations.getTranslatedString("navListTitle.networkAssignment"), isDefault: true},
                                            'networkGroupAssignment_oci': {label: oj.Translations.getTranslatedString("navListTitle.networkGroupAssignment")}
                                        })
                    }
                });

                self.router.createChildRouter('rootTabsOfCloudMgr', 'environmentsList_oci').
                        configure(
                                {
                                    'environmentsList_oci': {label: 'Environments', isDefault: true},
                                    'environmentBackups_oci': {label: 'Backups'},
                                    'environmentActivities_oci': {label: 'Activities'},
                                    'cloudManagerAdministration': {label: 'Administration'}
                                }
                        );

                self.router.createChildRouter('cloudMgrAdministrationSubTabs', 'networkProfilesList').
                        configure(
                                {
                                    'networkProfilesList': {label: 'Network Profiles', isDefault: true},
                                    'executionFramework': {label: 'Extensibility'},
                                    'discovery': {label: 'Discovery'},
                                    'policyListing':{label:'Scheduling Policies'}
                                }
                        );

                self.router.createChildRouter('executionFrameworkSubTabs', 'executionFramework').
                        configure(
                                {
                                    'executionFrameworkTaskList': {label: 'Tasks', isDefault: true},
                                    'executionFrameworkTemplateList': {label: 'Extended Activity Plans'}
                                }
                        );

                oj.Router.defaults['urlAdapter'] = new oj.Router.urlParamAdapter();

                
                // Footer
                function footerLink(name, id, linkTarget) {
                    this.name = name;
                    this.linkId = id;
                    this.linkTarget = linkTarget;
                }
                self.footerLinks = ko.observableArray([
                    new footerLink('About Oracle', 'aboutOracle', 'http://www.oracle.com/us/corporate/index.html#menu-about'),
                    new footerLink('Contact Us', 'contactUs', 'http://www.oracle.com/us/corporate/contact/index.html'),
                    new footerLink('Legal Notices', 'legalNotices', 'http://www.oracle.com/us/legal/index.html'),
                    new footerLink('Terms Of Use', 'termsOfUse', 'http://www.oracle.com/us/legal/terms/index.html'),
                    new footerLink('Your Privacy Rights', 'yourPrivacyRights', 'http://www.oracle.com/us/legal/privacy/index.html')
                ]);
            }

            return new ControllerViewModel();
        }
);
