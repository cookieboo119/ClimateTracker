/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A  PARTICULAR
 * PURPOSE.
 */

/*
 * GetActions - This class makes getactions request. This is followed by retrieve
 * getactions request to display data.
 */
package com.bloomberg.datalic.dlws;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.Actions;
import com.bloomberg.datalic.dlws.stubs.ActionsDate;
import com.bloomberg.datalic.dlws.stubs.ActionsInstrumentData;
import com.bloomberg.datalic.dlws.stubs.Data;
import com.bloomberg.datalic.dlws.stubs.DateRange;
import com.bloomberg.datalic.dlws.stubs.Duration;
import com.bloomberg.datalic.dlws.stubs.GetActionsHeaders;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetActionsRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetActionsResponse;

public class GetActions {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            GetActionsHeaders headers = new GetActionsHeaders();
            headers.setProgramflag(programFlag);
            headers.setActionsDate(ActionsDate.fromValue("both"));
            Actions actions = new Actions();
            actions.getAction().add("CAPITAL_CHANGE");
            actions.getAction().add("CORPORATE_EVENTS");
            actions.getAction().add("DISTRIBUTIONS");
            headers.setActions(actions);

            DateRange dateRange = new DateRange();
            Duration duration = new Duration();
            duration.setDays(7);
            dateRange.setDuration(duration);
            headers.setDaterange(dateRange);

            // Setting instruments
            Instrument ticker = new Instrument();
            ticker.setId("IBM US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.EQUITY);
            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);

            // Construct and submit getactions request
            System.out.println("Sending submit getactions request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetActionsRequest(headers, instruments, statusCode, requestId, responseId);
            System.out.println("Submit getactions request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve getactions
            RetrieveGetActionsRequest rtvGetActionsReq = new RetrieveGetActionsRequest();
            rtvGetActionsReq.setResponseId(responseId.value);
            RetrieveGetActionsResponse rtvGetActionsResp;
            System.out.println("Sending retrieve getactions request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetActionsResp = ps.retrieveGetActionsResponse(rtvGetActionsReq);
            } while (rtvGetActionsResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetActionsResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve getactions request successful for responseId: "
                        + rtvGetActionsResp.getResponseId());
                for (ActionsInstrumentData actionsInstrumentData : rtvGetActionsResp
                        .getInstrumentDatas().getInstrumentData()) {
                    System.out.println("Data for " + actionsInstrumentData.getInstrument().getId()
                            + " " + actionsInstrumentData.getInstrument().getYellowkey()
                            + ", companyId = "
                            + actionsInstrumentData.getStandardFields().getCompanyId().toString()
                            + ", securityId = "
                            + actionsInstrumentData.getStandardFields().getSecurityId().toString()
                            + ", actionId = "
                            + actionsInstrumentData.getStandardFields().getActionId() + ":");
                    for (Data data : actionsInstrumentData.getData()) {
                        System.out.println("  field = " + data.getField() + ", value = "
                                + data.getValue());
                    }
                }
            } else if (rtvGetActionsResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
