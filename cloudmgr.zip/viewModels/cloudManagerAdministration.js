
define(['ojs/ojcore', 'knockout', 'ebs/constants'
], function (oj, ko, constants) {
    /**
     * The view model for the main content view template
     */
    function CloudMgrAdministrationViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        var currentStateOfTheRouter = oj.Router.rootInstance.currentState();
        var globalChildRouter = currentStateOfTheRouter._router._childRouters[3];
        self.selectedSubTab_navBar = ko.observable();
        self.selectedSubTab = ko.observable();

        self.initializeSubTabSelection = function ()
        {
            var initialSubTab = rootViewModel.initialAdministrationSubTab;
            if (typeof(initialSubTab) !== 'undefined' &&  initialSubTab !== null) {
                self.selectedSubTab(initialSubTab);
                self.selectedSubTab_navBar(initialSubTab);
                rootViewModel.initialAdministrationSubTab = null;
            } else {
                var ntwkProfileTabId = globalChildRouter.states[0].id;
                self.selectedSubTab(ntwkProfileTabId);
                self.selectedSubTab_navBar(ntwkProfileTabId);
            }
        };

        self.subTabSelectionHandler = function (event)
        {
            if (constants.divTags.cloudMgrAdministrationSubMenuListIdentifier === event.target.id && event.detail.originalEvent)
            {
                // router takes care of changing the selection
                event.preventDefault();
                self.selectedSubTab(event.detail.key);
                self.selectedSubTab_navBar(event.detail.key);
            }
        };

        self.buildSubTabs = function () {
            console.log('Building Sub Tab Data');
            var jsonData = [];
            globalChildRouter.states.forEach(function (state) {

                jsonData.push({
                    'attr': {
                        id: state.id,
                        label: state.label,
                        href: "?root=" + state.id
                    }
                });

            });
            return jsonData;
        };

        self.subTabs = new oj.JsonTreeDataSource(self.buildSubTabs());
        self.initializeSubTabSelection();
    }
    return CloudMgrAdministrationViewModel;

})
