/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * GetDataPricingSourceHeader - This class submits a getdata request by specifying
 * the instruments and fields for the request parameters, and also enabling pricing source
 * header to true. This is followed by retrieve getdata request, to get the values for the
 * fields and the pricing source for the security.
 */

package com.bloomberg.datalic.dlws;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.Fields;
import com.bloomberg.datalic.dlws.stubs.GetDataHeaders;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentData;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataResponse;

public class GetDataPricingSourceHeader {

    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            GetDataHeaders headers = new GetDataHeaders();
            headers.setProgramflag(programFlag);
            headers.setClosingvalues(Boolean.TRUE);
            headers.setSecmaster(Boolean.TRUE);
            headers.setDerived(Boolean.TRUE);
            headers.setPricingSource("BVAL");

            // Setting instruments
            Instrument ticker = new Instrument();
            ticker.setId("IBM US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.EQUITY);
            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);

            // Setting fields
            Fields fields = new Fields();
            fields.getField().add("TICKER");
            fields.getField().add("PX_LAST");
            fields.getField().add("PX_ASK");
            fields.getField().add("PX_BID");
            fields.getField().add("PRICING_SOURCE");

            // Construct and submit getdata request
            System.out.println("Sending submit getdata request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetDataRequest(headers, null, fields, instruments, statusCode, requestId,
                    responseId);
            System.out.println("Submit getdata request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve getdata
            RetrieveGetDataRequest rtvGetDataReq = new RetrieveGetDataRequest();
            rtvGetDataReq.setResponseId(responseId.value);
            RetrieveGetDataResponse rtvGetDataResp;
            System.out.println("Sending retrieve getdata request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetDataResp = ps.retrieveGetDataResponse(rtvGetDataReq);
            } while (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve getdata request successful for responseId: "
                        + rtvGetDataResp.getResponseId());
                for (InstrumentData instrumentData : rtvGetDataResp.getInstrumentDatas()
                        .getInstrumentData()) {
                    System.out.println("Data for " + instrumentData.getInstrument().getId() + " "
                            + instrumentData.getInstrument().getYellowkey() + ":");
                    for (int i = 0; i < instrumentData.getData().size(); i++) {
                        System.out.println("  " + rtvGetDataResp.getFields().getField().get(i)
                                + ": " + instrumentData.getData().get(i).getValue());
                    }
                }
            } else if (rtvGetDataResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
