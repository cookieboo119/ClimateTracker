/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * introduction module
 */
define(['ojs/ojcore', 'knockout', 'ojs/ojmasonrylayout'
], function (oj, ko) {
    /**
     * The view model for the main content view template
     */
    function introductionContentViewModel() {
        var self = this;
        self.configureHeading = ko.observable('Configure');
        self.configureMessage = ko.observable(oj.Translations.getTranslatedString("confirmPopup.configureMessage"));
        self.configureStatusLabel = ko.observable('Configuration Status :');
        self.configureStatus = ko.observable('Not Configured');
        self.provisionManageHeading = ko.observable('Provision and Manage');
        self.provisionManageMessage = ko.observable(oj.Translations.getTranslatedString("confirmPopup.provisionManageMessage"));
        self.provisionManageStatusLabel = ko.observable('Status :');
        self.provisionManageStatus = ko.observable('Unavailable');
        self.gotoConfiguration = function(){
            oj.Router.rootInstance.go('accountDetails');
        };
        self.gotoEnvList = function(){
            oj.Router.rootInstance.go('environmentsList');
        };
        self.introductionTiles = ko.observableArray([{
                'heading': 'Configure',
                'message' : oj.Translations.getTranslatedString("confirmPopup.configureMessage"),
                'statusLabel': 'Configuration Status :'
            },
            {
                'heading': 'Provision and Manage',
                'message' : oj.Translations.getTranslatedString("confirmPopup.provisionManageMessage"),
                'statusLabel': 'Status :'
            }
        ]);
        

    }
    
    return introductionContentViewModel;
});
