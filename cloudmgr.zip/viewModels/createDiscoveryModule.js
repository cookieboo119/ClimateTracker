/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * create discovery module
 */
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/actions/actionsHelper', 'ebs/utils/validationHelper', 'ebs/utils/progressHelper', 'ebs/popup/popupHelper', 'ojs/ojarraydataprovider',
 'ebs/utils/lovUtils', 'ojs/ojlabel', 'ojs/ojformlayout', 'ojs/ojlabelvalue', 'ojs/ojbutton', 'ojs/ojinputtext',  'ojs/ojselectcombobox', 'ojs/ojselectsingle','ojs/ojvalidator-regexp','ojs/ojmessages',  "jet-composites/compartment-lov/loader", 
], function (oj, ko, constants, actionsHelper, validationHelper, progressHelper, popupHelper, ArrayDataProvider, lovUtils) {
    /**
     * The view model for the main content view template
     */
    function createDiscoveryModule() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.readonlyMode = ko.observable(false);
        self.createDiscoveryTitle = oj.Translations.getTranslatedString("confirmPopup.discoveryTitle");
        self.discoveryName = ko.observable();
        self.compartmentList = ko.observableArray([{
                    'label': 'loading...',
                    'value': ''
                  }]);
        self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, {idAttribute: 'value'});
        self.selectedCompartment = ko.observable('');
        self.selectedNetworkProfile = ko.observable();
        var loading = oj.Translations.getTranslatedString('info.loading');
        self.networkProfileList = ko.observableArray([]);
        self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
        self.networkProfileDisabled = ko.observable(true);
        self.discoveryNameValidationMsg = ko.observableArray([]);
        self.networkProfileNameValidationMsg = ko.observableArray([]);
        self.dbNodeIpValidationMsg = ko.observableArray([]);
        self.dbContextFilePathValidationMsg = ko.observableArray([]);
        self.dbStageDirectoryValidationMsg = ko.observableArray([]);
        self.dbNodeIp = ko.observable();
        self.dbContextFilePath = ko.observable();
        self.dbNodeStageDirectory = ko.observable();
        self.enteredAppsPwd = ko.observable();
        self.disableSubmitBtn = ko.observable(false);
        self.disableCancelBtn = ko.observable(false);
        self.contextPathHint = oj.Translations.getTranslatedString('helpMsgs.discoveryContextPathHint');
        self.nodeIpHint = oj.Translations.getTranslatedString('helpMsgs.discoveryNodeIpHint');
        self.formLabelEdge = "start"; //start, top, inside
        self.labelEdge = "provided"; //"provided" "inside"
        var UniqueNameValidator = function(){};
        oj.Object.createSubclass(UniqueNameValidator, oj.Validator, "UniqueNameValidator");
        self.requestNameValidator = [new UniqueNameValidator()]; 
        var IPAddressValidator = function(){};
        oj.Object.createSubclass(IPAddressValidator, oj.Validator, "IPAddressValidator");
        self.dbNodeIPValidator = [new IPAddressValidator()]; 
        self.parentViewModule = ko.dataFor(document.getElementById(constants.divTags.discoveryPage));
        self.showProgressBar = ko.observable("none");
        self.showSubmitProgressBar = ko.observable("none");
        self.discoveryNameHintMsg =  ko.observable(oj.Translations.getTranslatedString('validationMsgs.discoveryNameHint', {'maxLen': constants.installationDetails.discoveryNameLength}));
        
        self.addInlineMessage = function (messageSeverity, messageSummary, messageDetail)
        {
            self.clearInlineMessage();
            var newPageMessageObject = new Object();
            newPageMessageObject.severity = messageSeverity;
            newPageMessageObject.summary = messageSummary;
            newPageMessageObject.detail = messageDetail;
            newPageMessageObject.closeAffordance = "none";


            var tempArray = self.inlineMessages();
            tempArray.push(newPageMessageObject);
            self.inlineMessages(tempArray);

        };
        
        self.clearInlineMessage = function()
        {
             self.inlineMessages([]);
        };
        
        self.inlineMessages = ko.observableArray([]);
        self.categoryOption = { category: 'none' };
        
        self.displayInlineMessage = ko.computed(function(){
            if(self.inlineMessages().length > 0) return true;
            else return false;
        });
        
         self.inlineMessagesDataprovider = new ArrayDataProvider(self.inlineMessages);
        
      
       self.getCompartmentList = function()
       {
        actionsHelper.getCompartmentListForTenancy(function(error, compartmentsList) {
          if (error != null && error != '') {
            console.log('Error in fetching Compartment List for tenancy =>' + error);
          } else {
            self.compartmentList.removeAll();
            self.compartmentDataProvider = null;
            //var hierarchialList = getCompartmentLOVHierarchy(compartmentsList,  rootViewModel.tenancyOCID());
            var hierarchialList = getFlatListFromHierarchicalLov(compartmentsList,  rootViewModel.tenancyOCID());
            self.compartmentList(hierarchialList);
            self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.compartmentList(), self.selectedCompartment);
          }
          console.log('Compartment List after the fetch -' + self.compartmentList());
        });
       };

        self.compartmentValueHandler = function(event, ui)
        {
            var value = event['detail'].value;
            if(!value || value === '')
                return;
            //enable network profile input
            self.networkProfileDisabled(false);
            self.networkProfileNameValidationMsg([]);
            self.networkProfileList([{'label': loading, 'value': 'LOADING'}]);
            self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
            lovUtils.lovOptionsUpdated(self.networkProfileList(), self.selectedNetworkProfile);
            actionsHelper.getNetworkProfilesForUser(value, function (error, networkProfileList)
            {
                self.networkProfileList.removeAll();
                self.networkProfileDataProvider = null;
                var list = new Array();
                for (var i = 0; i < networkProfileList.length; i++)
                {
                    var profileName = networkProfileList[i];
                    var listEntry = new Object();
                    listEntry.label = profileName;
                    listEntry.value = profileName;
                    list[i] = listEntry;
                }
                if (list.length > 0)
                {
                    self.networkProfileList(list);
                    self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
                    lovUtils.lovOptionsUpdated(self.networkProfileList(), self.selectedNetworkProfile);
                }
                else 
                {
                   self.networkProfileList([{'label': 'NOT_FOUND', 'value': 'LOADING'}]);
                   self.networkProfileDataProvider = new ArrayDataProvider(self.networkProfileList, {idAttribute: 'value'});
                   lovUtils.lovOptionsUpdated(self.networkProfileList(), self.selectedNetworkProfile);
                   var networkProfileNameValidationCustomMsg = oj.Translations.getTranslatedString('validationMsgs.lovValueNotFoundMsg', {lovName: 'network profile'});
                   var validationMsg = {summary: networkProfileNameValidationCustomMsg,
                            detail: networkProfileNameValidationCustomMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                   self.networkProfileNameValidationMsg([validationMsg]);
                }
            });
        };
                
                
        UniqueNameValidator.prototype.validate = function (value)
        {
            if(!value || (value === '')) return true;
            //name format validation
            value = value.trim();
            var maxLen = constants.installationDetails.discoveryNameLength;
                    var patternMaxLen = maxLen - 1;
                    var re = new RegExp('^[a-zA-Z]([a-zA-Z0-9\s]){1,' + patternMaxLen + '}$');
                    if (null !== value && value.length > 0 && !re.test(value)) {
                        var errorMessages = new Array();
                        var validationCustomMsg = {summary: oj.Translations.getTranslatedString('validationMsgs.discoveryName', {'maxLen': maxLen}),
                            detail: oj.Translations.getTranslatedString('validationMsgs.discoveryName', {'maxLen': maxLen}), severity: oj.Message.SEVERITY_TYPE.ERROR};
                        errorMessages.push(validationCustomMsg);
                        self.discoveryNameValidationMsg(errorMessages);
                    }
            //check uniqueness
            var allJobs = self.parentViewModule.discoveryJobs();
            var foundMatch = false;
            $.each(allJobs, function(i, req){
                if(req.name === value)
                {
                    foundMatch = true;
                    return false;
                }
            });

            if (foundMatch)
            {
                var errorMessages = new Array();
                var validationCustomMsg = {summary: oj.Translations.getTranslatedString('validationMsgs.sameDiscoveryName'),
                        detail: oj.Translations.getTranslatedString('validationMsgs.sameDiscoveryName'), severity: oj.Message.SEVERITY_TYPE.ERROR};
                errorMessages.push(validationCustomMsg);
                self.discoveryNameValidationMsg(errorMessages);
            }

            return true;
        };
        
        IPAddressValidator.prototype.validate = function (value)
        {
           if(!value || (value === '')) return true;
           value = value.trim();
           var regex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            if(regex.test(value))
           {
               return true;
           }
           else
           {
               var errorMessages = new Array();
               var validationCustomMsg = {summary: oj.Translations.getTranslatedString('validationMsgs.invalidIPAddress'),
                        detail: oj.Translations.getTranslatedString('validationMsgs.invalidIPAddress'), severity: oj.Message.SEVERITY_TYPE.ERROR};
               errorMessages.push(validationCustomMsg);
               self.dbNodeIpValidationMsg(errorMessages);
           }
           
           return true;
        };

        self.closeNewDiscoveryPopup= function(event, ui)
        {          
           var popup = document.getElementById(constants.divTags.newDiscoveryPopup);
           popup.close();
        };
        
        self.openPopup = function (event, ui)
        {
           
            var popup = document.getElementById(constants.divTags.newDiscoveryPopup);
            self.resetPopupContent();
            popup.refresh();
            self.getCompartmentList();
            popup.open(event.target);
        };
       

                
       self.appsPwdValidationMsg = ko.observable([]);
       
       self.serverValidateProgressConfig = progressHelper.getProgressConfig('validateProgress', -1, 'Input validation is in progress.' , self.showProgressBar);
       self.submitProgressConfig = progressHelper.getProgressConfig('submitProgress', -1, 'Submitting request.' , self.showSubmitProgressBar);
       
        self.performServerSideValidations = function()
        {
            console.log('Performing server side validations for new discovery request.');
            self.disableSubmitBtn(true);
            self.disableCancelBtn(true);
            self.showProgressBar("");
            var inputsToValidateFromServer =
                    [
                        {"id": "discoveryName", "internalId": "discoveryNameInput", "customMsgObject": self.discoveryNameValidationMsg, "value": self.discoveryName().trim()},
                        {"id": "networkProfile", "internalId": "networkProfile", "customMsgObject": self.networkProfileNameValidationMsg, "value": self.selectedNetworkProfile()},
                        {"id": "dbNodeIp", "internalId": "dbIp", "customMsgObject": self.dbNodeIpValidationMsg, "value": self.dbNodeIp().trim()},
                        {"id": "dbContextFile", "internalId": "dbContextPath", "customMsgObject": self.dbContextFilePathValidationMsg, "value": self.dbContextFilePath().trim()},
                        {"id": "dbNodeStageDirectory", "internalId": "dbStageDirectory", "customMsgObject": self.dbStageDirectoryValidationMsg, "value": self.dbNodeStageDirectory().trim()},
                        {"id": "credentials.environment.appsPassword", "internalId": "appsPwd", "customMsgObject": self.appsPwdValidationMsg, "value": self.enteredAppsPwd().trim()}
                    ];
            
            //Sprint2: temporarily comment out server validation code, as it's been deferred to sprint 3
            validationHelper.validatePreDiscoveryRequestOnServer(inputsToValidateFromServer,  self.submitNewDiscoveryRESTRequest, self.serverValidationFailed);
            //directly invoke submit skipping server validation
            //self.submitNewDiscoveryRESTRequest();
      
        };
        
        self.serverValidationFailed = function(error)
        {
            self.disableSubmitBtn(false);
            self.disableCancelBtn(false);
            self.showProgressBar("none");  
            if (error != null && error != '')
            {
                if (error.status === 504)
                {
                    var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                    self.addInlineMessage('error', 'Error in validating prediscovery request inputs.', messageContent);
                } else
                {
                    var errorCode = error.responseJSON.code;
                    if (error.responseJSON.code === null || error.responseJSON.code === '')
                    {
                        errorCode = error.status;
                    }
                    var messageContent = 'Error Message : ' + error.responseJSON.message;
                    self.addInlineMessage('error', 'Error in validating prediscovery request inputs.', messageContent);
                }
            }
        }   
        
        self.submitNewDiscoveryRequest = function ()
        {
            self.clearInlineMessage();
            var validationsFailed = self.validateContents();
            if (validationsFailed)
            {
                return;
            }
            console.log("proceed with pwd validations");
            self.performServerSideValidations();
            
        };

       self.submitNewDiscoveryRESTRequest = function()
       {
           self.clearInlineMessage();
           self.showProgressBar("none");  
           self.showSubmitProgressBar("");
              /* Add Node Post JSON Content Preparation */
            var postJsonData = {
                "credentials": {
                    "environment": {
                        "appsPassword": ""
                    }
                },

                "discoveryName": self.discoveryName() ? self.discoveryName().trim() : self.discoveryName(),
                "networkProfile": self.selectedNetworkProfile(),
                "dbNodeIp": self.dbNodeIp().trim(),
                "dbNodeStageDirectory": self.dbNodeStageDirectory() ? self.dbNodeStageDirectory().trim() : self.dbNodeStageDirectory(),
                "dbContextFile": self.dbContextFilePath() ? self.dbContextFilePath().trim() : self.dbContextFilePath()
            };

            postJsonData.credentials.environment.appsPassword = self.enteredAppsPwd();
            
            var requestBodyJSON = JSON.stringify(postJsonData);

           // self.closeAddNodePopup();
           // var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.newDiscoveryConfirmationMsg", {'discoveryName': self.discoveryName()});
            //var infoMsg = oj.Translations.getTranslatedString("confirmPopup.newDiscoveryInfoMsg", {'discoveryName': self.discoveryName()});
          //  popupHelper.openSuccessMsg(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, infoMsg, msgOrigin);
            actionsHelper.createDiscovery(requestBodyJSON, function (error, success) {
                var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.newDiscoveryConfirmationMsgTitle"); 
                if (error === '') {
                    self.closeNewDiscoveryPopup();
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.newDiscoveryConfirmationMsg", {'discoveryName': self.discoveryName()});
                    var context = ko.contextFor(document.getElementById(constants.divTags.discoveryPage));
                    self.parentViewModule.loadDiscoveryJobs();
                    popupHelper.openSuccessMsg(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, successMsg, msgOrigin);

                } else {
                    self.showSubmitProgressBar("none");
                    self.disableCancelBtn(false);
                    self.disableSubmitBtn(false);
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    //popupHelper.openErrorMsg(constants.divTags.requestSubmittedConfirmationPopup_discoveryPG, response.message, msgOrigin);
                     var messageContent = response.message;
                    self.addInlineMessage('error', 'Error', messageContent);
                    
                }
            });
       };
   
        self.validateContents = function ()
        {
            var invalidsPresent = false;
            var name = document.getElementById("discoveryNameInput");
            var networkProfile = document.getElementById('networkProfile');
            var dbNodeIp = document.getElementById('dbIp');
            var dbContextFile = document.getElementById('dbContextPath');
            var dbStageDir = document.getElementById('dbStageDirectory');
            var appsPwd = document.getElementById('appsPwd');
            
            if (name.valid !== 'valid')
            {
                name.showMessages();
                invalidsPresent = true;
            }
            if (networkProfile.valid !== 'valid')
            {
                networkProfile.showMessages();
                invalidsPresent = true;
            }
            if(networkProfile.value === "LOADING")
            {

                var networkProfileNameValidationCustomMsg = oj.Translations.getTranslatedString('validationMsgs.lovValueNotSelectedMsg', {lovName: 'network profile'});
                var validationMsg = {summary: networkProfileNameValidationCustomMsg,
                        detail: networkProfileNameValidationCustomMsg, severity: oj.Message.SEVERITY_TYPE.ERROR};

                self.networkProfileNameValidationMsg([validationMsg]);
                invalidsPresent = true;
            }    
            if (dbNodeIp.valid !== 'valid')
            {
                dbNodeIp.showMessages();
                invalidsPresent = true;
            }
            if (dbContextFile.valid !== 'valid')
            {
                dbContextFile.showMessages();
                invalidsPresent = true;
            }
            if (dbStageDir.valid !== 'valid')
            {
                dbStageDir.showMessages();
                invalidsPresent = true;
            }
            if (appsPwd.valid !== 'valid')
            {
                appsPwd.showMessages();
                invalidsPresent = true;
            }
            return invalidsPresent;
        };
       
        self.resetPopupContent = function(event, ui)
        {
            //reset all the parameters to original state
            self.clearInlineMessage();
            self.discoveryName('');
            self.dbNodeIp('');
            self.dbContextFilePath('');
            self.dbNodeStageDirectory('');
            self.enteredAppsPwd('');
            self.showProgressBar("none");
            self.showSubmitProgressBar("none");
            self.disableSubmitBtn(false);
            self.disableCancelBtn(false);  
            self.appsPwdValidationMsg([]);
            self.discoveryNameValidationMsg([]);
            self.networkProfileNameValidationMsg([]);
            self.dbNodeIpValidationMsg([]);
            self.dbContextFilePathValidationMsg([]);
            self.dbStageDirectoryValidationMsg([]);
        };
    }
    
    return createDiscoveryModule;
});
