@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.bloomberg.com/datalicense/dlws/ps/20071001", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bloomberg.datalic.dlws.stubs;
