/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * Cancel - This class sends 2 different getdata requests. This is followed
 * by sending cancel request which takes the response id of the two requests. The class
 * then makes a retrieve cancel request.
 */
package com.bloomberg.datalic.dlws;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.CancelHeaders;
import com.bloomberg.datalic.dlws.stubs.CancelResponseStatus;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveCancelRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveCancelResponse;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetDataResponse;

public class Cancel {

    // NOTE: The programFlag argument is ignored for this sample
    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Send couple of recurring getdata requests, then cancel them
            RetrieveGetDataResponse rtvGetDataResponse1 = GetData.submitRecurringGetDataRequest(ps);
            RetrieveGetDataResponse rtvGetDataResponse2 = GetData.submitRecurringGetDataRequest(ps);

            if (rtvGetDataResponse1 != null && rtvGetDataResponse2 != null
                    && rtvGetDataResponse1.getStatusCode().getCode() == PerSecurity.SUCCESS
                    && rtvGetDataResponse2.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out
                        .println("Submit and retrieve getdata request successful for responseId1: "
                                + rtvGetDataResponse1.getResponseId());
                System.out
                        .println("Submit and retrieve getdata request successful for responseId2: "
                                + rtvGetDataResponse2.getResponseId());

                // Construct and submit cancel request
                List<String> responseIds = new ArrayList<String>();
                responseIds.add(rtvGetDataResponse1.getResponseId());
                responseIds.add(rtvGetDataResponse2.getResponseId());
                RetrieveCancelResponse rtvCancelResp = submitAndRetrieve(ps, responseIds);

                // Display data
                if (rtvCancelResp != null) {
                    if (rtvCancelResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                        System.out.println("Retrieve cancel request successful");
                        display(rtvCancelResp);
                    } else if (rtvCancelResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                        System.out.println("Error in the retrieve cancel request");
                    }
                }
            } else {
                System.out.println("Error in the submitRecurringGetDataRequest(s).");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Submit cancel request and retrieve response
    static RetrieveCancelResponse submitAndRetrieve(PerSecurityWS ps, List<String> responseIds) {
        RetrieveCancelResponse rtvCancelResp = null;
        try {
            System.out.println("Sending cancel request for responseIds: " + responseIds);
            CancelHeaders headers = new CancelHeaders();
            headers.setProgramflag(ProgramFlag.fromValue("daily"));
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();

            ps.submitCancelRequest(responseIds, headers, statusCode, requestId, responseId);
            System.out.println("Submit cancel request status: " + statusCode.value.getDescription()
                    + ", responseId: " + responseId.value);

            // Submit retrieve cancel
            RetrieveCancelRequest rtvCancelReq = new RetrieveCancelRequest();
            rtvCancelReq.setResponseId(responseId.value);
            System.out.println("Sending retrieve cancel request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvCancelResp = ps.retrieveCancelResponse(rtvCancelReq);
            } while (rtvCancelResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return rtvCancelResp;
    }

    // Submit cancel request and retrieve response
    static RetrieveCancelResponse submitAndRetrieve(PerSecurityWS ps, String responseId) {
        List<String> responseIds = new ArrayList<String>();
        responseIds.add(responseId);
        return submitAndRetrieve(ps, responseIds);
    }

    // Display RetrieveCancelResponse object
    static void display(RetrieveCancelResponse rtvCancelResp) {
        for (CancelResponseStatus cancelRespStatus : rtvCancelResp.getCancelResponseStatus()) {
            System.out.println("The cancel status for responseId "
                    + cancelRespStatus.getResponseId() + " is: "
                    + cancelRespStatus.getCancelStatus().toString());
        }
    }

}
