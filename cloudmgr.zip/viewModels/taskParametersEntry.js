define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/actions/actionsHelper', 'ojs/ojarraytreedataprovider',
    'ebs/utils/createCloneTrainUtils', 'jquery', 'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojbutton',
    'ojs/ojselectcombobox', 'ojs/ojknockout-validation', 'ojs/ojradioset'
], function (oj, ko, constants, actionsHelper, ArrayTreeDataProvider, createCloneTrainUtils) {
    /**
     * The view model for the main content view template
     */
    function taskParametersEntryViewModel() {
        var self = this;
        self.tasksGrouping = ko.observableArray([]);
        self.nestedDataProvider = new ArrayTreeDataProvider(self.tasksGrouping, { keyAttributes: "name" });
        self.nestedDataProviderObservable = ko.observable(self.nestedDataProvider);
        self.taskDescriptionInPopup = ko.observable('');
        var loadingOption = new Array();
        loadingOption.push({
            'label': 'loading...',
            'value': 'loading...'
        });
        self.executionTemplatesList = ko.observableArray(loadingOption);
        self.executionTemplateName = ko.observable();
        self.isDetailsPG = ko.observable(false);
        self.showLoaderInDetailsPG = ko.observable(true);

        self.openTaskDescription = function (event, ui) {
            var targetId = ui.currentTarget.id;
            console.log("openTaskDesc invokeed: " + targetId);
            var taskKey = targetId.substring(0, targetId.indexOf("_descIcon"));
            var tabSectionElement = document.getElementById('tabSection');
            var task = null;
            var desc = null;
            var parentViewModelReference = null;
            if (tabSectionElement !== null) {
                parentViewModelReference = ko.dataFor(tabSectionElement);
                task = parentViewModelReference.getTaskDataFromFlattenedArray(taskKey);
                desc = task.attr.description;
            }
            else {
                for (var i = 0; i < self.tasksGrouping().length; i++) {
                    var taskElement = self.tasksGrouping()[i];
                    var taskKeyVal = taskElement.id;
                    if (taskKeyVal === taskKey) {
                        task = taskElement;
                        desc = task.description;
                    }
                }
            }

            if (task) {

                self.taskDescriptionInPopup(desc);
                var popup = document.getElementById("taskDescPopup");
                popup.open('#' + self.escapeId(targetId));
            }
        };

        self.handleExecutionPlanChange = function (event) {
            var executionPlanName = event['detail'].value;
            if (typeof (executionPlanName) === 'undefined' || executionPlanName === null || executionPlanName === '' || executionPlanName === 'loading...') {
                return;
            }
            self.showLoaderInDetailsPG(true);
            actionsHelper.fetchExecutionTemplateBasedOnName(executionPlanName, function (error, executionplanDataJSON) {
                self.tasksGrouping([]);
                var tasksGroupingLocal = new Array();
                var utilResults = createCloneTrainUtils.parseExecutionPlanTemplateJSON(executionplanDataJSON);
                tasksGroupingLocal = utilResults.tasksGrouping;
                self.tasksGrouping(tasksGroupingLocal);
                self.showLoaderInDetailsPG(false);
            });
        };

        self.escapeId = function (s) {
            return s.replace(/(:|\.|\[|\])/g, "\\$1");
        };

        self.isFormValid = function () {
            var isValid = true;
            var tasksGrouping = self.tasksGrouping();
            if (tasksGrouping === null || tasksGrouping.length < 1) {
                return true;
            } else {
                for (var i = 0; i < tasksGrouping.length; i++) {
                    var taskElement = tasksGrouping[i];
                    var taskName = taskElement.name;
                    var parameterChildren = taskElement.children;
                    if (typeof (parameterChildren) !== 'undefined' && parameterChildren.length > 0) {
                        for (var j = 0; j < parameterChildren.length; j++) {
                            var paramChildElement = parameterChildren[j];
                            var parameterChildName = taskName + "_" + paramChildElement.name;
                            var paramElem = document.getElementById(parameterChildName);
                            if (paramElem !== null && paramElem.valid !== 'valid') {
                                paramElem.showMessages();
                                isValid = false;
                            }
                        }
                    }
                }

                return isValid;
            }
        };

        self.getExtensibleTasksFormData = function () {
            var extensibleTasks = new Object();
            extensibleTasks.templateId = self.executionTemplateName();
            var tasksGrouping = self.tasksGrouping();
            var inputs = new Array();
            extensibleTasks.inputs = inputs;
            if (tasksGrouping === null || tasksGrouping.length < 1) {
                // Nothing to send.
            } else {
                for (var i = 0; i < tasksGrouping.length; i++) {
                    var taskElement = tasksGrouping[i];
                    var taskName = taskElement.name;
                    var taskId = taskElement.id;
                    var parameterChildren = taskElement.children;
                    if (typeof (parameterChildren) !== 'undefined' && parameterChildren.length > 0) {
                        var input = new Object();
                        input.taskId = taskId;
                        var paramsArray = new Array();
                        input.parameters = paramsArray;
                        for (var j = 0; j < parameterChildren.length; j++) {
                            var paramChildElement = parameterChildren[j];
                            var parameterChildName = taskName + "_" + paramChildElement.name;
                            var paramElem = document.getElementById(parameterChildName);
                            if (paramElem !== null) {
                                var paramValue = paramElem.value;
                                var param = new Object();
                                param.name = paramChildElement.name;
                                param.value = paramValue;
                            }
                            paramsArray.push(param);
                        }
                        inputs.push(input);
                    }
                }

            }

            return extensibleTasks;
        };

        self.openTaskParametersFormDialogForDetailsPG = function (event) {
            self.isDetailsPG(true);
            self.tasksGrouping([]);
            actionsHelper.fetchExecutionTemplatesForLCMFlow(function (error, execTemplatesList) {
                self.executionTemplatesList(execTemplatesList);
                var execPlanName = execTemplatesList[0].value;
                actionsHelper.fetchExecutionTemplateBasedOnName(execPlanName, function (error, executionplanDataJSON) {
                    var tasksGroupingLocal = new Array();
                    var utilResults = createCloneTrainUtils.parseExecutionPlanTemplateJSON(executionplanDataJSON);
                    tasksGroupingLocal = utilResults.tasksGrouping;
                    self.tasksGrouping(tasksGroupingLocal);
                    var popup = document.querySelector(constants.divTags.lcmTaskParamsPopup);
                    popup.open(event.target);
                    self.showLoaderInDetailsPG(false);
                });
            });

        };

    }
    return taskParametersEntryViewModel;
});