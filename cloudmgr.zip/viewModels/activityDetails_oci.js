
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper',
    'ebs/popup/popupHelper', 'ebs/constants', 'ebs/utils/dateTimeHelper', 'ojs/ojarraydataprovider',
    , 'ojs/ojaccordion', 'ojs/ojinputtext', 'ojs/ojpopup', 'ojs/ojrowexpander', 'ojs/ojflattenedtreetabledatasource',
    'ojs/ojjsontreedatasource', 'ojs/ojtable', 'ojs/ojmessages', 'ojs/ojswitch', 'ojs/ojbutton', 'ojs/ojformlayout', 'ojs/ojmessages'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper, constants, dateTimeHelper, ArrayDataProvider) {

    function jobDetailsContentViewModel() {
        var self = this;
        var jobId = oj.Router.rootInstance.retrieve();
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));

        rootViewModel.showContextHeader(true);
        rootViewModel.showNavTab(false);
        sessionStorage.setItem('lastSelectedChildRouterFromLandingPage', 'activityDetails_oci');

        var MAX_LEVELS_TO_ITERATE = 10;
        self.execPlanDataAvailable = ko.observable(true);
        self.activityDetailsMessages = ko.observableArray([]);
        self.activityName = ko.observable('');
        self.entityLabel = ko.observable('');
        self.disableLogFileDownload = ko.observable(true);
        self.mainExecutionHighlightTaskName = ko.observable('');
        self.taskIdToDetailsMapExecutionPlan = new Map();
        self.templateName = ko.observable('');
        self.firstTaskFailedOrInProgressOrPausedInExecutionPlan = null;
        self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan = null;
        self.firstTaskWithWarningInExecutionPlan = null;
        self.previousStageSeperatorRow = '';
        self.parentId = ko.observable('');
        self.rootId = ko.observable('');
        self.childId = ko.observable('');
        self.ExecutionPlanDataJSON = ko.observable();
        self.mainExecutionHdrRow = ko.observable('');
        self.currentStageName = ko.observable('');
        self.headerNodesParsedSoFar = 0;
        self.ExecutionPlanData = ko.observable();
        self.isLoading = ko.observable(false);
        self.prevPage = ko.observable(oj.Translations.getTranslatedString('pageHeader.activities'));
        self.confirmRestartPage = ko.observable();
        self.confirmResumePage = ko.observable();
        self.restartable = ko.observable(false);
        self.resumable = ko.observable(false);
        self.planStructureLoaded = ko.observable(false);
        self.lastRefreshTime = ko.observable('');
        self.entityName = ko.observable('');
        self.downloadFileName = ko.observable('');
        self.startTime = ko.observable('');
        self.preValidationStatus = ko.observable('');
        self.mainExecutionStatus = ko.observable('');
        self.overallJobStatus = ko.observable('');
        self.createdBy = ko.observable('');
        self.parentJobId = ko.observable('');
        self.childJobId = ko.observable('');
        self.endTime = ko.observable('');

        self.initialPlanTab = ko.observable('ExecutionPlan');
        self.AUTO_REFRESH_INTERVAL = 20000;
        self.intervalTimerCode = '';
        self.autoRefresh = ko.observable(false);
        self.isLastRefreshTextRendered = ko.observable(false);
        self.hasParsingErrors = false;
        self.entityTypesList = ko.observableArray();
        self.disableMoreAction = ko.computed(function () {
            return true;
        });

        var emptyTableRow = new Object();
        emptyTableRow.attr = new Object();

        emptyTableRow.attr.hasLog = false;
        emptyTableRow.attr.id = 'EmptyRow';
        emptyTableRow.attr.isHeader = false;
        emptyTableRow.attr.label = '';
        emptyTableRow.attr.stage = '';
        emptyTableRow.attr.startTime = '';
        emptyTableRow.attr.status = '';
        emptyTableRow.attr.totalTime = '';

        var emptyDataArray = new Array();
        emptyDataArray.push(emptyTableRow);

        self.warningMessage = ko.observable('');
        self.errorOrWarningMsgs = ko.observableArray([]);
        self.pageErrorMessagesProvider = new ArrayDataProvider(self.errorOrWarningMsgs);

        self.columnsArray = [{"headerText": "", "sortable": "disabled", "headerStyle": "font-weight:bold"},
            {"headerText": "Name", "sortable": "disabled", "headerStyle": "font-weight:bold"},
            {"headerText": "Status", "sortable": "disabled", "headerStyle": "font-weight:bold"},
            {"headerText": "Log", "sortable": "disabled", "headerStyle": "font-weight:bold"}];

        self.moreActionsHandler = function (event, ui) {
        };

        self.scrollToHighlightedTaskRow = function ()
        {
            var failedElement = self.firstTaskFailedOrInProgressOrPausedInExecutionPlan;
            if (failedElement === null)
            {
                return;
            }
            var failedElementDOM = document.getElementById('Label:' + failedElement);
            if (failedElementDOM === null)
            {
                var options = [];
                var options =
                        {
                            'expanded': '',
                            'rowHeader': 'id',

                        };
                var nodesToExpand = self.initializeExpansion();
                if (nodesToExpand !== null)
                    options.expanded = nodesToExpand;
                console.log('Expnaded nodes : ' + nodesToExpand)

                self.ExecutionPlanData(new oj.FlattenedTreeTableDataSource(
                        new oj.FlattenedTreeDataSource(
                                new oj.JsonTreeDataSource(self.ExecutionPlanDataJSON()), options)
                        ))
                        ;
                window.setTimeout(function () {
                    self.scrollFailedRowIntoViewPort(failedElement);
                }, 500);
                return;
            } else
            {
                self.scrollFailedRowIntoViewPort(failedElement);
            }

        };

        self.scrollFailedRowIntoViewPort = function (failedElement)
        {
            var rowKeyToFocus = failedElement;
            var failedElementDOM = document.getElementById('Label:' + failedElement);
            document.getElementById('execPlanTable').selection = [{startKey: {"row": rowKeyToFocus}, endKey: {"row": rowKeyToFocus}}];
            failedElementDOM.scrollIntoView();
            document.documentElement.scrollTop = parseInt(document.documentElement.scrollTop) - 100;
        };

        self.expandAllItems = function ()
        {
            if (self.ExecutionPlanDataJSON !== null && self.ExecutionPlanDataJSON() !== null && self.ExecutionPlanDataJSON().length >= 1)
            {
                var options = [];
                var options =
                        {
                            'expanded': 'all',
                            'rowHeader': 'id',

                        };
                self.ExecutionPlanData(new oj.FlattenedTreeTableDataSource(
                        new oj.FlattenedTreeDataSource(
                                new oj.JsonTreeDataSource(self.ExecutionPlanDataJSON()), options)
                        ))
                        ;
            }
        };

        self.collapseAllItems = function ()
        {
            if (self.ExecutionPlanDataJSON !== null && self.ExecutionPlanDataJSON() !== null && self.ExecutionPlanDataJSON().length >= 1)
            {
                var options = [];
                var options =
                        {
                            'expanded': '',
                            'rowHeader': 'id',

                        };
                self.ExecutionPlanData(new oj.FlattenedTreeTableDataSource(
                        new oj.FlattenedTreeDataSource(
                                new oj.JsonTreeDataSource(self.ExecutionPlanDataJSON()), options)
                        ))
                        ;
            }
        };




        self.parseJSONData = function ()
        {
            if (typeof (self.ExecutionPlanDataJSON()) === 'undefined' || self.ExecutionPlanDataJSON().length < 1)
            {
                return;
            }
            self.recurseNodes(self.ExecutionPlanDataJSON(), "ROOT");
            if (self.firstTaskFailedOrInProgressOrPausedInExecutionPlan === null && self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan !== null)
            {
                self.firstTaskFailedOrInProgressOrPausedInExecutionPlan = self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan.pop();
            }

        };

        self.recurseNodes = function (parentElementNode, isTopLevel)
        {
            var allChildElements = null;
            var parentElementIdentifer = null;
            var nonApplicableElements = new Array();

            if (parentElementNode.attr) {
                var isPauseSetupAtThisLevel = parentElementNode.attr.isPauseEnabled;
                if (typeof (isPauseSetupAtThisLevel) !== 'undefined' && isPauseSetupAtThisLevel !== '' && isPauseSetupAtThisLevel) {
                    parentElementNode.attr.isDesignTimePaused = true;
                } else {
                    parentElementNode.attr.isDesignTimePaused = false;
                }
            }

            if (isTopLevel === "ROOT")
            {
                allChildElements = parentElementNode;
                parentElementIdentifer = "ROOT";
            } else
            {
                if (parentElementNode.children === null || typeof (parentElementNode.children) === 'undefined' || parentElementNode.children.length < 1)
                {
                    return;
                }
                allChildElements = parentElementNode.children;
            }
            for (var j = 0; j < allChildElements.length; j++)
            {
                if (parentElementIdentifer === null)
                {
                    parentElementIdentifer = parentElementNode.attr.id;
                }
                var child = allChildElements[j].children;
                var parentElement = (child !== null && typeof (child) !== 'undefined' && child.length > 0);
                var identifier = allChildElements[j].attr.id;
                var statusOfTask = allChildElements[j].attr.status;
                var label = allChildElements[j].attr.label;
                var logFile = allChildElements[j].attr.hasLog;
                var isHdr = allChildElements[j].attr.isHeader;

                if (statusOfTask === constants.executionStatus.notApplicable && identifier !== null)
                {
                    nonApplicableElements.push(identifier);
                }

                if (typeof (allChildElements[j].attr.id) === 'undefined')
                {
                    console.log("Parsing Error : For Task with ID - " + identifier + " the mandatory attribute " + "id" + " is missing.");
                    self.hasParsingErrors = true;
                }
                if (typeof (allChildElements[j].attr.status) === 'undefined')
                {
                    console.log("Parsing Error : For Task with ID - " + identifier + " the mandatory attribute " + "status" + " is missing.");
                    self.hasParsingErrors = true;
                }
                if (typeof (allChildElements[j].attr.children) !== 'undefined' && (allChildElements[j].attr.children === null || allChildElements[j].attr.children === 'null'))
                {
                    console.log("Parsing Error : For Task with ID - " + identifier + " the children attribute " + "is null.");
                    self.hasParsingErrors = true;
                }
                if (typeof (allChildElements[j].attr.totalTime) === 'undefined')
                {
                    console.log("Parsing Error : For Task with ID - " + identifier + " the mandatory attribute " + "totalTime" + " is missing.");
                    self.hasParsingErrors = true;
                }
                if (typeof (allChildElements[j].attr.label) === 'undefined')
                {
                    console.log("Parsing Error : For Task with ID - " + identifier + " the mandatory attribute " + "label" + " is missing.");
                    self.hasParsingErrors = true;
                }
                if (typeof (allChildElements[j].attr.isHeader) === 'undefined')
                {
                    console.log("Parsing Error : For Task with ID - " + identifier + " the mandatory attribute " + "isHeader" + " is missing.");
                    self.hasParsingErrors = true;
                }
                if (typeof (self.taskIdToDetailsMapExecutionPlan.get(identifier)) !== 'undefined')
                {
                    console.log("Parsing Error : There already exists a task with identifier - " + identifier + " . Duplicate element exists in the JSON document.");
                    self.hasParsingErrors = true;
                }
                if (!isHdr && self.headerNodesParsedSoFar === 0)
                {
                    console.log("Parsing Error : We reached a child node without any header so far while parsing task - " + identifier + " . JSON document is broken.");
                    self.hasParsingErrors = true;
                }

                if (isHdr)
                {
                    self.headerNodesParsedSoFar++;
                    var hdrNodeStageName = allChildElements[j].attr.stage;
                    if (typeof (hdrNodeStageName) === 'undefined')
                    {
                        console.log("Parsing Error : Node is header but stage is not present while parsing task - " + identifier + " . JSON document is broken.");
                        self.hasParsingErrors = true;
                    } else
                    {
                        self.currentStageName(hdrNodeStageName);
                    }
                }

                /* If we have 2 header nodes, then we will do a visual seperator */
                if (self.headerNodesParsedSoFar === 2 && self.mainExecutionHdrRow() === '')
                {
                    self.mainExecutionHdrRow(identifier);
                }
                self.taskIdToDetailsMapExecutionPlan.set(identifier, {"isChild": !parentElement, "parentElement": parentElementIdentifer, "name": label, "logFile": logFile, "stage": self.currentStageName()});
                if (!parentElement &&
                        self.firstTaskFailedOrInProgressOrPausedInExecutionPlan === null
                        && (statusOfTask === constants.executionStatus.failed ||
                                statusOfTask === constants.executionStatus.inProgress ||
                                statusOfTask === constants.executionStatus.paused))
                {
                    self.firstTaskFailedOrInProgressOrPausedInExecutionPlan = identifier;
                } else if (!parentElement &&
                        self.firstTaskWithWarningInExecutionPlan === null
                        && (statusOfTask === constants.executionStatus.warning))
                {
                    self.firstTaskWithWarningInExecutionPlan = identifier;
                }
                else if (parentElement &&
                        (statusOfTask === constants.executionStatus.failed ||
                                statusOfTask === constants.executionStatus.inProgress ||
                                statusOfTask === constants.executionStatus.paused))
                {
                    if (self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan === null)
                    {
                        self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan = new Array();
                        self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan.push(identifier);
                    } else
                    {
                        self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan.push(identifier);
                    }
                }
                self.recurseNodes(allChildElements[j], null);

            }

            if (nonApplicableElements.length > 0 && allChildElements.length > 1)
            {
                var modifiedChildrenElement = new Array();
                for (var i = 0; i < allChildElements.length; i++)
                {
                    var childElementId = allChildElements[i].attr.id;
                    if (self.doesArrayContainElement(nonApplicableElements, childElementId))
                    {
                        console.log('Skipping the element  ' + childElementId + ' that is not applicable.');
                    } else
                    {
                        modifiedChildrenElement.push(allChildElements[i]);
                    }
                }

                if (modifiedChildrenElement !== null && modifiedChildrenElement.length >= 0)
                {
                    console.log('Modified the parent element :: ' + parentElementNode.attr.id + " as it has not applicable children.");
                    parentElementNode.children = modifiedChildrenElement;
                }
            }

        };

        self.doesArrayContainElement = function (array, searchElement)
        {
            for (var k = 0; k < array.length; k++)
            {
                if (array[k] === searchElement)
                {
                    return true;
                }
            }
            return false;
        };

        self.handleLogFileClickEvent = function (event, ui)
        {
            var taskIdentifier = event.id;
            var taskNameArray = new Array();
            var taskNameIndex = 0;
            var taskName = '';
            var mapToUse = self.taskIdToDetailsMapExecutionPlan;
            var currentParent = mapToUse.get(taskIdentifier);
            var stage = currentParent.stage;
            for (var j = 0; j < MAX_LEVELS_TO_ITERATE; j++)
            {
                taskNameArray[taskNameIndex++] = currentParent.name;
                if (currentParent.parentElement === "ROOT")
                {
                    break;
                } else
                {
                    currentParent = mapToUse.get(currentParent.parentElement);
                }
            }

            if (taskNameArray.length === 1)
            {
                taskName = taskNameArray[0];
            } else
            {
                for (var j = taskNameArray.length - 1; j >= 1; j--)
                {
                    taskName += taskNameArray[j] + " > ";
                }
                taskName += taskNameArray[0];
            }

            var viewModelOfPopupModule = ko.dataFor(document.getElementById('taskLogPopupRoot'));
            viewModelOfPopupModule.handleTaskLogPopupOpen(event, ui, taskIdentifier, taskName, jobId, stage);
        };

        self.activityMenuItemsWithoutRestart = [
            {
                id: constants.contextMenu.restart,
                label: oj.Translations.getTranslatedString('contextMenu.retry'),
                disabled: true
            },
        ];
        self.activityMenuItemsWithRestart = [
            {
                id: constants.contextMenu.restart,
                label: oj.Translations.getTranslatedString('contextMenu.retry'),
                disabled: false
            },
        ];

        self.isLoading(true);

        self.downloadLogFile = function ()
        {
            console.log('Code to download all log files..');

            actionsHelper.getLogZipFile(jobId, self.downloadFileName(), function (error, validResponse)
            {
                if (error === '')
                {
                    // Nothing here. The content will be downloaded from restHelper.js.
                } else
                {
                    self.addPageLevelMessage('error', 'Error downloading log files for this activity.', '');
                }
            });
        };

        self.addPageLevelMessage = function (messageSeverity, messageSummary, messageDetail)
        {
            var newPageMessageObject = new Object();
            newPageMessageObject.severity = messageSeverity;
            newPageMessageObject.summary = messageSummary;
            newPageMessageObject.detail = messageDetail;
            var tempArray = self.activityDetailsMessages();
            tempArray.push(newPageMessageObject);
            self.activityDetailsMessages(tempArray);

        };

        self.cleanupLocalVariablesForComponentRefresh = function ()
        {
            self.taskIdToDetailsMapExecutionPlan = new Map();
            self.firstTaskFailedOrInProgressOrPausedInExecutionPlan = null;
            self.allParentTaskFailedOrInProgressOrPausedInExecutionPlan = null;
            self.lastValidationTaskInExecutionPlan = ko.observable('');
            self.headerNodesParsedSoFar = 0;
            self.activityDetailsMessages([]);
        };

        self.enableAutoRefresh = function ()
        {
            self.intervalTimerCode = '';
            self.loadDataForThisPage();
            self.intervalTimerCode = window.setInterval(function () {
                self.loadDataForThisPage();
            }, self.AUTO_REFRESH_INTERVAL);
            self.isLastRefreshTextRendered(true);
        };

        self.disableAutoRefresh = function ()
        {
            window.clearInterval(self.intervalTimerCode);
            self.intervalTimerCode = '';
            self.isLastRefreshTextRendered(false);
        };

        self.handleAutoRefreshToggle = function (event, ui)
        {
            if (event === null || typeof (event) === 'undefined')
            {
                return;
            }
            if (event.detail === null || typeof (event.detail) === 'undefined')
            {
                return;
            }
            if (event.detail.value === null || typeof (event.detail.value) === 'undefined')
            {
                return;
            }
            var currentVal = event.detail.value;
            if (currentVal)
            {
                self.enableAutoRefresh();
            } else
            {
                self.disableAutoRefresh();
            }
        };

        self.handleExpansion = function (event)
        {
            self.addSeparatorBetweenValidationAndExecution(1000);
        };

        self.findEntityLabelForEntityValue = function (entityValueInput) {
            for (var i = 0; i < self.entityTypesList().length; i++) {
                var entity = self.entityTypesList()[i];
                var entityValue = entity.value;
                if (entityValue === entityValueInput) {
                    return entity.label;
                }
            }
            return '';
        };

        self.setSessionValue = function (fromPage) {
            sessionStorage.setItem("activityDetailsParentPage", fromPage);
        };


        self.getSessionValue = function () {
            return sessionStorage.getItem("activityDetailsParentPage");
        };


        self.clearSessionValue = function () {
            sessionStorage.removeItem("activityDetailsParentPage");
            rootViewModel.activityDetailsParentPage('');
        };

        
        self.loadDataForThisPage = function ()
        {
            self.cleanupLocalVariablesForComponentRefresh();
            actionsHelper.getEntityTypesList(function (error, list) {
                self.entityTypesList(list);
                actionsHelper.getExecutionPlanForJob(jobId, function (error, jobPlanJSONData)
                {
                    if (error === '')
                    {
                        self.initialPlanTab('ExecutionPlan');
                        self.hasParsingErrors = false;
                        var jobExecData = jobPlanJSONData.validationAndExecutionPlan;
                        var jobGeneralInfo = jobPlanJSONData.info;
                        var options = [];
                        var options =
                                {
                                    'expanded': [],
                                    'rowHeader': 'id',

                                };

                        if (typeof (jobGeneralInfo) === 'undefined' || jobGeneralInfo === null)
                        {
                            self.addPageLevelMessage('error', 'Failed to retrieve information about this activity.', '');
                            return;
                        }



                        self.entityName(jobGeneralInfo.entityName);
                        self.startTime(dateTimeHelper.convertToUTC(jobGeneralInfo.startTime));
                        self.mainExecutionStatus(jobGeneralInfo.executionStatus);
                        self.preValidationStatus(jobGeneralInfo.validationStatus);
                        self.overallJobStatus(jobGeneralInfo.status);
                        self.activityName(jobGeneralInfo.jobName ? jobGeneralInfo.jobName : (jobGeneralInfo.action + " on " + jobGeneralInfo.entityName));
                        // filename format : <environment name>-<action>-<jobid>.zip
                        self.downloadFileName(jobGeneralInfo.entityName + "-" + jobGeneralInfo.action + "-" + jobId);
                        self.createdBy(jobGeneralInfo.createdBy);
                        self.templateName(jobGeneralInfo.templateName);
                        if (typeof (jobGeneralInfo.parentJobId) !== 'undefined')
                        {
                            if (jobGeneralInfo.parentJobId === null)
                            {
                                self.parentJobId('');
                            } else
                            {
                                self.parentJobId(jobGeneralInfo.parentJobId);
                            }
                        }
                        if (typeof (jobGeneralInfo.childJobId) !== 'undefined')
                        {
                            if (jobGeneralInfo.childJobId === null)
                            {
                                self.childJobId('');
                            } else
                            {
                                self.childJobId(jobGeneralInfo.childJobId);
                            }
                        }
                        if (typeof (jobGeneralInfo.endTime) !== 'undefined')
                            self.endTime(dateTimeHelper.convertToUTC(jobGeneralInfo.endTime));

                        self.entityLabel(self.findEntityLabelForEntityValue(jobGeneralInfo.entityType));


                        if ((typeof (jobGeneralInfo.entityName) === 'undefined' || jobGeneralInfo.entityName === null || jobGeneralInfo.entityName === '') ||
                                (typeof (jobGeneralInfo.executionStatus) === 'undefined' || jobGeneralInfo.executionStatus === null || jobGeneralInfo.executionStatus === '') ||
                                (typeof (jobGeneralInfo.validationStatus) === 'undefined' || jobGeneralInfo.validationStatus === null || jobGeneralInfo.validationStatus === '') ||
                                (typeof (jobGeneralInfo.status) === 'undefined' || jobGeneralInfo.status === null || jobGeneralInfo.status === '')
                                )
                        {
                            self.addPageLevelMessage('error', 'Failed to retrieve information about this activity.', '');
                            return;
                        }

                        if (typeof (jobExecData) === 'undefined' || jobExecData === null)
                        {
                            self.addPageLevelMessage('info', 'No tasks to display.', '');
                            try
                            {
                                   self.ExecutionPlanData(new oj.FlattenedTreeTableDataSource(
                                        new oj.FlattenedTreeDataSource(
                                                new oj.JsonTreeDataSource([]), null)
                                        )
                                        );
                            } catch (e)
                            {

                            }
                        } else
                        {
                            self.ExecutionPlanDataJSON(jobExecData);
                            self.parseJSONData();

                            var hasWarning = jobGeneralInfo.hasWarning;
                            self.errorOrWarningMsgs([]);
                            var warningMsg = new Array();
                            if (hasWarning)
                            {
                                self.warningMessage(jobGeneralInfo.warningMessage);
                                var tempMsg = new Object();
                                tempMsg.severity = 'warning';
                                tempMsg.summary = jobGeneralInfo.warningMessage;
                                tempMsg.closeAffordance = "none";
                                warningMsg.push(tempMsg);
                            }
                            
                            var warningInExecPlanFlow = self.firstTaskWithWarningInExecutionPlan;
                            if(warningInExecPlanFlow !== null && warningInExecPlanFlow !== ''){
                                  var tempMsg = new Object();
                                  tempMsg.severity = 'warning';
                                  tempMsg.summary = oj.Translations.getTranslatedString('validationMsgs.executionPlanSuccessfullyCompletedWithWarnings');
                                  tempMsg.closeAffordance = "none";
                                  warningMsg.push(tempMsg);
                            }
                            if (warningMsg.length > 0)
                                self.errorOrWarningMsgs(warningMsg);
                              
                            if (self.hasParsingErrors)
                            {
                                try
                                {
                                    self.ExecutionPlanData(new oj.FlattenedTreeTableDataSource(
                                            new oj.FlattenedTreeDataSource(
                                                    new oj.JsonTreeDataSource(emptyDataArray), null)
                                            )
                                            );
                                } catch (e)
                                {

                                }
                            } else
                            {
                                if (jobGeneralInfo.executionStatus === constants.executionStatus.failed ||
                                        jobGeneralInfo.executionStatus === constants.executionStatus.inProgress ||
                                        jobGeneralInfo.executionStatus === constants.executionStatus.paused ||
                                        jobGeneralInfo.validationStatus === constants.executionStatus.failed ||
                                        jobGeneralInfo.validationStatus === constants.executionStatus.inProgress ||
                                        ( jobGeneralInfo.executionStatus === constants.executionStatus.success &&
                                          self.firstTaskWithWarningInExecutionPlan !== null &&
                                          self.firstTaskWithWarningInExecutionPlan !== ''
                                        )
                                   )
                                {
                                    var nodesToExpand = self.initializeExpansion();
                                    if (nodesToExpand !== null)
                                        options.expanded = nodesToExpand;
                                }

                                self.lastRefreshTime(new Date().toGMTString());
                                self.ExecutionPlanData(new oj.FlattenedTreeTableDataSource(
                                        new oj.FlattenedTreeDataSource(
                                                new oj.JsonTreeDataSource(jobExecData), options)
                                        )
                                        );

                            }
                        }
                        if (self.hasParsingErrors)
                        {
                            self.addPageLevelMessage('error', 'Error in parsing JSON data. Check the browser developer console for more details.', '');
                        }

                        if (self.ExecutionPlanData().length === 0)
                        {
                            try
                            {
                                self.planStructureLoaded(true);
                                self.execPlanDataAvailable(true);
                                self.isLoading(false);
                            } catch (e)
                            {
                                // Eat up all exceptions from JET component when the array is empty.
                            }
                        } else
                        {
                            self.planStructureLoaded(true);
                            self.execPlanDataAvailable(true);
                            self.isLoading(false);
                        }

                        if (jobGeneralInfo.restartable !== null && typeof (jobGeneralInfo.restartable) !== 'undefined' && jobGeneralInfo.restartable)
                        {
                            self.restartable(true);
                        }

                        if (typeof (jobGeneralInfo.resumable) !== 'undefined' && jobGeneralInfo.resumable === true)
                        {
                            self.resumable(true);
                        }

                        if (jobGeneralInfo.status !== constants.executionStatus.inProgress
                                && jobGeneralInfo.status !== constants.provStatus.inputValidationInProgress
                                && jobGeneralInfo.status !== constants.provStatus.scheduled) {
                            self.disableLogFileDownload(false);
                        }

                        if (jobGeneralInfo.status === constants.executionStatus.failed ||
                                jobGeneralInfo.executionStatus === constants.executionStatus.failed ||
                                jobGeneralInfo.validationStatus === constants.executionStatus.failed
                                || jobGeneralInfo.executionStatus === constants.executionStatus.inProgress ||
                                jobGeneralInfo.validationStatus === constants.executionStatus.inProgress ||
                                jobGeneralInfo.validationStatus === constants.executionStatus.paused)
                        {
                            self.selectFailedOrInProgressOrPaused(jobGeneralInfo.executionStatus, jobGeneralInfo.validationStatus);
                            var failedOrInProgressOrPausedTask = self.firstTaskFailedOrInProgressOrPausedInExecutionPlan;
                            if ((failedOrInProgressOrPausedTask !== null && typeof (failedOrInProgressOrPausedTask) !== 'undefined') && jobGeneralInfo.executionStatus === constants.executionStatus.failed)
                            {
                                var failedOrInProgressOrPausedTaskInfo = self.taskIdToDetailsMapExecutionPlan.get(failedOrInProgressOrPausedTask);
                                if (failedOrInProgressOrPausedTaskInfo !== null && typeof (failedOrInProgressOrPausedTaskInfo) !== 'undefined')
                                {
                                    self.mainExecutionHighlightTaskName(failedOrInProgressOrPausedTaskInfo.name);
                                }
                            }
                        } else
                        {
                            self.selectFirstTask(jobExecData);
                        }

                        self.addSeparatorBetweenValidationAndExecution(250);


                    } else
                    {
                        self.execPlanDataAvailable(false);
                        if (error !== null && error !== '')
                        {
                            if (error.status === 504)
                            {
                                var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                self.addPageLevelMessage('error', 'Error in getting activity plan tasks.', messageContent);
                            } else
                            {
                                var errorCode = error.responseJSON.code;
                                if (error.responseJSON.code === null || error.responseJSON.code === '')
                                {
                                    errorCode = error.status;
                                }
                                var messageContent = 'Error Message : ' + error.responseJSON.message;
                                self.addPageLevelMessage('error', 'Error in gettig activity plan tasks.', messageContent);
                            }
                            return;
                        }
                    }


                });
            });

        };

        self.loadDataForThisPage();

        var fromPage = rootViewModel.activityDetailsParentPage();
        if (fromPage === '') {
            fromPage = self.getSessionValue();
        }

        if (fromPage !== '') {
            if (fromPage === constants.navModules.envListModule) {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.envListPageHeader'));
            } else if (fromPage === constants.navModules.envAdministrationModule) {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.envAdminPageHeader'));
            } else if (fromPage === constants.navModules.envDetailsModule) {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.envDetails'));
            } else if (fromPage === constants.navModules.discoveryModule) {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.discovery'));
            } else {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.activities'));
            }
            self.setSessionValue(fromPage);
        }

        self.addSeparatorBetweenValidationAndExecution = function (timerInterval)
        {
            window.setTimeout(function () {
                if (self.mainExecutionHdrRow() !== null && self.mainExecutionHdrRow() !== '')
                {
                    var mainExecTaskHdrDOMElement = document.getElementById('Label:' + self.mainExecutionHdrRow());
                    if (mainExecTaskHdrDOMElement !== null)
                    {
                        var rowElementParent = null;
                        var currentParentNode = mainExecTaskHdrDOMElement.parentNode;
                        for (var i = 0; i < 10; i++)
                        {
                            if (currentParentNode !== null && currentParentNode.tagName === 'TR')
                            {
                                rowElementParent = currentParentNode;
                                break;
                            } else if (currentParentNode !== null && currentParentNode.tagName === 'BODY')
                            {
                                break;
                            }
                            currentParentNode = currentParentNode.parentNode;
                        }
                        if (rowElementParent !== null)
                        {
                            if (self.previousStageSeperatorRow !== '')
                            {
                                self.previousStageSeperatorRow.style = '';
                            }
                            self.previousStageSeperatorRow = rowElementParent.previousElementSibling;
                            rowElementParent.previousElementSibling.style.borderBottomWidth = '2px';
                            rowElementParent.previousElementSibling.style.borderBottomColor = 'darkgreen';
                        }
                    }
                }
            }, timerInterval);
        }

        self.initializeExpansion = function ()
        {
            var failedOrInProgressOrPausedTask = null;
            var map = null;
            failedOrInProgressOrPausedTask = self.firstTaskFailedOrInProgressOrPausedInExecutionPlan;
            if(failedOrInProgressOrPausedTask === null){
                failedOrInProgressOrPausedTask = self.firstTaskWithWarningInExecutionPlan;
            }
            map = self.taskIdToDetailsMapExecutionPlan;
            if (failedOrInProgressOrPausedTask === null)
            {
                return null;
            } else
            {
                var pathToRoot = new Array();
                var counter = 0;
                var failedOrInProgressOrPausedTaskInfo = map.get(failedOrInProgressOrPausedTask);
                if (failedOrInProgressOrPausedTaskInfo === null)
                {
                    return null;
                } else
                {
                    var child = failedOrInProgressOrPausedTaskInfo.isChild;
                    if (!child)
                    {
                        pathToRoot[counter++] = failedOrInProgressOrPausedTaskInfo;
                    }
                    var currentTask = failedOrInProgressOrPausedTask;

                    for (var y = 0; y < MAX_LEVELS_TO_ITERATE; y++)
                    {
                        currentTask = map.get(currentTask).parentElement;
                        if (currentTask === null || currentTask === "ROOT")
                        {
                            break;
                        } else
                        {
                            pathToRoot[counter++] = currentTask;
                        }
                    }
                    return pathToRoot;
                }
            }
        };


        self.selectFirstTask = function (jobExecData)
        {
            if (jobExecData !== null && typeof (jobExecData) !== 'undefined' && jobExecData.length > 0)
            {
                console.log('Row Key to focus ::' + jobExecData[0].attr.id);
                document.getElementById('execPlanTable').selection = [{startKey: {"row": jobExecData[0].attr.id}, endKey: {"row": jobExecData[0].attr.id}}];
            }
        };

        self.selectFailedOrInProgressOrPaused = function (execStatus, validationStatus)
        {
            if (execStatus === constants.executionStatus.failed
                    || execStatus === constants.executionStatus.inProgress
                    || execStatus === constants.executionStatus.paused
                    || validationStatus === constants.executionStatus.failed
                    || validationStatus === constants.executionStatus.inProgress)
            {
                var rowKeyToFocus = self.firstTaskFailedOrInProgressOrPausedInExecutionPlan;
                if (rowKeyToFocus === null)
                {
                    return;
                }
                console.log('Row Key to focus ::' + rowKeyToFocus + ' @ ' + new Date());
                document.getElementById('execPlanTable').selection = [{startKey: {"row": rowKeyToFocus}, endKey: {"row": rowKeyToFocus}}];
            }
        };

        self.gotoChildJobDetails = function () {
            var gotoJobId = self.childJobId();
            console.log("details for job " + gotoJobId);
            oj.Router.rootInstance.store(gotoJobId);
            var context = ko.contextFor(document.getElementById(constants.divTags.activityDetailsPage));
            self.disableAutoRefresh();
            pageNavigationHelper.refreshPage(context, constants.navModules.activityDetailsModule);
        };

        self.gotoParentJobDetails = function () {
            var gotoJobId = self.parentJobId();
            console.log("details for job " + gotoJobId);
            oj.Router.rootInstance.store(gotoJobId);
            var context = ko.contextFor(document.getElementById(constants.divTags.activityDetailsPage));
            self.disableAutoRefresh();
            pageNavigationHelper.refreshPage(context, constants.navModules.activityDetailsModule);
        };

        self.restartActivity = function (event, ui) {
            console.log('Triggering restart action..');
            if (self.warningMessage() === '') {
                self.confirmRestartPage(oj.Translations.getTranslatedString("confirmPopup.restartJobAssertMsg", {activityName: self.activityName()}));
            } else {
                self.confirmRestartPage(self.warningMessage() + oj.Translations.getTranslatedString("confirmPopup.restartJobAssertMsg", {activityName: self.activityName()}));
            }
            var popup = document.querySelector(constants.divTags.activityRestartConfPopupTag);
            popup.open(event.target);
        };

        self.resumeActivity = function (event, ui) {
            console.log('Triggering resume action..');
            if (self.warningMessage() === '') {
                self.confirmResumePage(oj.Translations.getTranslatedString("confirmPopup.resumeJobAssertMsg", {activityName: self.activityName()}));
            } else {
                self.confirmResumePage(self.warningMessage() + oj.Translations.getTranslatedString("confirmPopup.resumeJobAssertMsg", {activityName: self.activityName()}));
            }
            var popup = document.querySelector(constants.divTags.activityResumeConfPopupTag);
            popup.open(event.target);
        };

        self.activityActionsHandler = function (event, ui) {
            console.log('Triggering restart action..');
            self.confirmResumePage(oj.Translations.getTranslatedString("confirmPopup.restartJobAssertMsg", {activityName: self.activityName()}));
            var popup = document.querySelector(constants.divTags.activityRestartConfPopupTag);
            popup.open(event.target);
        };

        self.handleBackLink = function (event, ui) {
            var context = ko.contextFor(document.getElementById(constants.divTags.activityDetailsPage));
            var toModule = self.getModuleToNavigateFromThisPage();
            self.disableAutoRefresh();
            self.clearSessionValue();
            //Important: reset the session value during breadcrumb click; however
            //excluding env details page, as there is dependency on global variables
            //to load env details page successfully
            var sessionToModule = toModule;
            if (toModule && toModule === constants.navModules.envDetailsModule)
            {
                sessionToModule = '';
            }
            sessionStorage.setItem('lastSelectedChildRouterFromLandingPage', sessionToModule);
            pageNavigationHelper.navigateToPage(context, toModule, toModule);
        };

        self.closeConfirmRestartPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.activityRestartConfPopupTag);
            popup.close();
        };

        self.closeConfirmResumePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.activityResumeConfPopupTag);
            popup.close();
        };

        self.startAnimationListener = function (event, ui)
        {
            popupHelper.startAnimationListener(constants.divTags.activityDetailsConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.activityDetailsConfPopupTag, data, event);
        };

        self.restartJob = function (event, ui) {
            var popup = document.querySelector(constants.divTags.activityRestartConfPopupTag);
            popup.close();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.restartJobInfoMsg", {'jobName': self.activityName()});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.restartJobTitle");
            popupHelper.openInfoMsg(constants.divTags.activityDetailsConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.restartActivity(jobId, function (error, success) {
                if (error === '') {
                    var context = ko.contextFor(document.getElementById(constants.divTags.activityDetailsPage));
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.restartJobSuccessMsg", {'jobName': self.activityName()});
                    rootViewModel.displayPopupId(constants.divTags.envDetailsConfPopupTag);
                    popupHelper.setSuccessPopupMsg(successMsg, msgOrigin);
                    self.disableAutoRefresh();

                    var toModule = self.getModuleToNavigateFromThisPage();
                    self.clearSessionValue();
                    pageNavigationHelper.navigateToPage(context, toModule, toModule);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.activityDetailsConfPopupTag, response.message, msgOrigin);
                }
            });
        };

        self.getModuleToNavigateFromThisPage = function () {
            // Added logic to identify previous page
            // Similar to handleBackLink logic
            var toModule;
            if (self.prevPage() === oj.Translations.getTranslatedString('pageHeader.envListPageHeader')) {
                toModule = constants.navModules.envListModule;
            } else if (self.prevPage() === oj.Translations.getTranslatedString('pageHeader.envAdminPageHeader')) {
                toModule = constants.navModules.envDetailsModule;
                rootViewModel.prevEnvDetailsNavItem(constants.navModules.envAdministrationModule);
            } else if (self.prevPage() === oj.Translations.getTranslatedString('pageHeader.envDetails')) {
                toModule = constants.navModules.envDetailsModule;
            } else if (self.prevPage() === oj.Translations.getTranslatedString('pageHeader.discovery')) {
                toModule = constants.navModules.discoveryModule;
            } else {
                toModule = constants.navModules.envActivitiesModule;
            }
            return toModule;
        };

        self.resumeJob = function (event, ui) {
            var popup = document.querySelector(constants.divTags.activityResumeConfPopupTag);
            popup.close();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.resumeJobInfoMsg", {'jobName': self.activityName()});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.resumeJobTitle");
            popupHelper.openInfoMsg(constants.divTags.activityResumeConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.resumeActivity(jobId, function (error, success) {
                if (error === '') {
                    var context = ko.contextFor(document.getElementById(constants.divTags.activityDetailsPage));
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.resumeJobSuccessMsg", {'jobName': self.activityName()});
                    rootViewModel.displayPopupId(constants.divTags.envDetailsConfPopupTag);
                    popupHelper.setSuccessPopupMsg(successMsg, msgOrigin);
                    self.disableAutoRefresh();
                    var toModule = self.getModuleToNavigateFromThisPage();
                    self.clearSessionValue();
                    pageNavigationHelper.navigateToPage(context, toModule, toModule);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.activityDetailsConfPopupTag, response.message, msgOrigin);
                }
            });
        };


    }


    window.openExecutionTimeInformationMessage = function ()
    {
        var execInfoPopupVieModel = ko.dataFor(document.getElementById('execTimeInfoPopupRoot'));
        execInfoPopupVieModel.handleExecutionInformationPopupOpen();
    }

    return jobDetailsContentViewModel;
});
