define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/popup/popupHelper', 'ebs/constants', 'ebs/utils/dateTimeHelper', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider'
            , 'ojs/ojaccordion', 'ojs/ojinputtext', 'ojs/ojpopup', 'ojs/ojrowexpander', 'ojs/ojflattenedtreetabledatasource', 'ojs/ojjsontreedatasource', 'ojs/ojtable', 'ojs/ojmessages', 'ojs/ojswitch', 'ojs/ojbutton'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper, constants, dateTimeHelper, FlattenedTreeDataProviderView, ArrayTreeDataProvider) {
    /**
     * The view model for the main content view template
     */
    function ExecutionFrameworkTemplateDetailPopup() {
        var self = this;
        self.tableDataObject = ko.observable();
        self.tableDataProvider = ko.observable();
        self.templateLoaded = ko.observable(false);
        self.position = ko.observable();
        self.jsonForUITable = null;
        self.execTemplatePopupTitle = ko.observable('Execution Plan Details');

        self.tableColumnsArray = [{"headerText": "Phase", "sortable": "disabled", "headerStyle": "font-weight:bold"},
            {"headerText": "Type", "sortable": "disabled", "headerStyle": "font-weight:bold"}

        ];
        self.position({my: {horizontal: 'left', vertical: 'top'},
            at: {horizontal: 'left', vertical: 'top'},
            offset: {y: 50, x: 100},
            collision: 'fit',
            of: 'window'}
        );

        self.openPopup = function (templateIdentifier, templateName, event) {
            self.execTemplatePopupTitle(templateName + " details");
            var popup = document.getElementById("ExecPlanDetailTop");
            popup.open(event.target);
            self.templateLoaded(false);
            self.tableDataProvider();
            self.tableDataObject();
            actionsHelper.fetchExecutionTemplate(templateIdentifier, function (error, BaseExecutionPlanJSONData)
            {
                if (error === '') {
                    var untransformedExecData = BaseExecutionPlanJSONData;
                    self.prepareJsonForTableView(untransformedExecData);
                    self.tableDataObject(self.jsonForUITable);
                    self.refreshTable(true);
                    self.templateLoaded(true);
                } else
                {
                    // Implement.
                }
            });
        };

        self.refreshTable = function () {
            var options = [];
            var options =
                    {
                        'expanded': 'all',
                        'rowHeader': 'id',
                    };

            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                    new oj.FlattenedTreeDataSource(
                            new oj.JsonTreeDataSource(self.tableDataObject()), options)
                    ))
                    ;
        };
        
        self.expandAllItems = function(){
             var options = [];
            var options =
                    {
                        'expanded': 'all',
                        'rowHeader': 'id',
                    };

            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                    new oj.FlattenedTreeDataSource(
                            new oj.JsonTreeDataSource(self.tableDataObject()), options)
                    ))
                    ;
        };
        
        self.collapseAllItems = function(){
             var options = [];
            var options =
                    {
                        'expanded': '',
                        'rowHeader': 'id',
                    };

            self.tableDataProvider(new oj.FlattenedTreeTableDataSource(
                    new oj.FlattenedTreeDataSource(
                            new oj.JsonTreeDataSource(self.tableDataObject()), options)
                    ))
                    ;
        };

        self.prepareJsonForTableView = function (executionPlan) {
            var allPhasesAndTasks = new Array();
            for (var i = 0; i < executionPlan.length; i++) {
                var phase = executionPlan[i];
                var UIPhase = new Object();
                UIPhase.attr = new Object();
                UIPhase.attr.id = phase.attr.id;
                UIPhase.attr.isSeeded = phase.attr.isSeeded;
                UIPhase.attr.label = phase.attr.label;
                var children = phase.children;
                if (typeof (children) !== 'undefined' && children !== null && children.length > 0) {
                    var UITasksObject = new Array();
                    for (var k = 0; k < children.length; k++) {
                        var taskChild = children[k];
                        var UITaskChild = new Object();
                        UITaskChild.attr = new Object();
                        UITaskChild.attr.id = taskChild.attr.id;
                        UITaskChild.attr.label = taskChild.attr.label;
                        UITaskChild.attr.isSeeded = taskChild.attr.isSeeded;
                        UITasksObject.push(UITaskChild);
                    }
                    UIPhase.children = UITasksObject;
                    allPhasesAndTasks.push(UIPhase);
                } else {
                    allPhasesAndTasks.push(UIPhase);
                }
            }
            self.jsonForUITable = allPhasesAndTasks;
        };
    }
    return ExecutionFrameworkTemplateDetailPopup;

});
