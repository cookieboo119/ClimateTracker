
/** This is the back up module - From main branch **/


define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/utils/backupEnvironmentHelper',
    'ebs/popup/popupHelper', 'ebs/constants', 'ojs/ojvalidator-regexp', 'ebs/utils/validationHelper', 'ebs/utils/progressHelper', 'ojs/ojarraydataprovider', 'ebs/utils/lovUtils', 'ebs/utils/compartmentsLov',
    'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojswitch', 'ojs/ojmessages', 'ojs/ojinputnumber', "jet-composites/compartment-lov/loader"],
        function (oj, ko, actionsHelper, backupEnvironmentHelper, popupHelper, constants, RegExpValidator, validationHelper, progressHelper, ArrayDataProvider, lovUtils ) {
            function backupContentViewModel() {
                var self = this;
                console.log('Loading Back Up Content Popup View Model');
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.isAssignBackupPolicy = ko.observable(false);
                self.policyList = ko.observableArray([]);
                self.policyDataProvider = new ArrayDataProvider(self.policyList, {idAttribute: 'value'});
                self.selectedPolicy = ko.observable('');
                self.disableBackupPolicy = ko.observable(false);
                self.backupPolicyCustomMsg = ko.observableArray([]);
                self.tenancyId = rootViewModel.tenancyOCID();
                self.backupName = ko.observable('');
                self.encryptionPwd = ko.observable('');
                self.confirmEncryptionPwd = ko.observable('');
                self.appsPwd = ko.observable('');
                self.wlsPwd = ko.observable('');
                self.backupNotAvailableInformationContent = ko.observable('');
                self.currentEnvironmentActive = ko.observable('');
                self.swiftPwd = ko.observable('');
                self.isWlsPwdRequired = ko.observable(true);
                self.authToken = ko.observable('');
                self.isWalletPwdRequired = ko.observable(false);
                self.walletPwd = ko.observable('');
                var passwdMismatchMsg = oj.Translations.getTranslatedString('validationMsgs.passwordMismatch');
                var BackUpPwdValidator = function () {};
                oj.Object.createSubclass(BackUpPwdValidator, oj.Validator, "BackUpPwdValidator");
                self.backUpPwdValidator = [new BackUpPwdValidator()];
                var BackUpReEnterPwdValidator = function () {};
                oj.Object.createSubclass(BackUpReEnterPwdValidator, oj.Validator, "BackUpReEnterPwdValidator");
                self.backUpReEnterPwdValidator = [new BackUpReEnterPwdValidator()];
                self.backupTitle = ko.observable('');
                self.compartmentList = ko.observableArray([{
                        'label': 'loading...',
                        'value': ''
                    }]);
                self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, {idAttribute: 'value'});
                self.selectedCompartment = ko.observable('');
                lovUtils.lovOptionsUpdated(self.compartmentList(), self.selectedCompartment);
                self.compressionAlgorithmMsg = ko.observable();
                self.dbServiceType = ko.observable('');
                self.selectedRMANBackupChannelCount = ko.observable(0);
                self.advancedOptionsDisplayed = ko.observable(false);
                self.SHOW_ADVANCED_OPTIONS_TEXT = "Show Advanced Options";
                self.HIDE_ADVANCED_OPTIONS_TEXT = "Hide Advanced Options";
                self.advancedOptionsAnchorText = ko.observable(self.SHOW_ADVANCED_OPTIONS_TEXT);
                self.validateDBOptionValue = ko.observable(false);
                self.compressionAlgorithmsList = ko.observableArray([{
                        'label': 'Basic',
                        'value': 'Basic'
                    }, {
                        'label': 'Low',
                        'value': 'Low'
                    }, {
                        'label': 'Medium',
                        'value': 'Medium'
                    },
                    {
                        'label': 'High',
                        'value': 'High'
                    }]);
                self.compressionAlgorithmsDataProvider = new ArrayDataProvider(self.compressionAlgorithmsList, {idAttribute: 'value'});
                self.selectedCompressionAlgorithm = ko.observable('Basic');
                self.rmanSectionSizeList = ko.observableArray([{
                        'label': 'loading...',
                        'value': ''
                    }]);
                self.rmanSectionSizeDataProvider = new ArrayDataProvider(self.rmanSectionSizeList, {idAttribute: 'value'});
                self.selectedRMANSectionSize = ko.observable();

                self.enteredRmanFilesPerSet = ko.observable();
                self.enteredRmanMaxOpenFiles = ko.observable();

                self.enteredRmanRate = ko.observable();
                self.rmanRateUnitList = ko.observableArray([{
                        'label': 'K',
                        'value': 'K'
                    }, {
                        'label': 'M',
                        'value': 'M'
                    },
                    {
                        'label': 'G',
                        'value': 'G'
                    }]);
                self.rmanRateUnitDataProvider = new ArrayDataProvider(self.rmanRateUnitList, {idAttribute: 'value'});
                self.selectedRmanRateUnit = ko.observable('');
                self.enteredRmanDataFieldAllowedMaxCorruptOption = ko.observable();
                //  self.enteredCustomRmanScriptPath = ko.observable();
                
                        
                self.addInlineMessage = function (messageSeverity, messageSummary, messageDetail)
                {
                    self.clearInlineMessage();
                    var newPageMessageObject = new Object();
                    newPageMessageObject.severity = messageSeverity;
                    newPageMessageObject.summary = messageSummary;
                    newPageMessageObject.detail = messageDetail;
                    newPageMessageObject.closeAffordance = "none";


                    var tempArray = self.inlineMessages();
                    tempArray.push(newPageMessageObject);
                    self.inlineMessages(tempArray);

                };

                self.clearInlineMessage = function()
                {
                     self.inlineMessages([]);
                };

                self.inlineMessages = ko.observableArray([]);
                self.categoryOption = { category: 'none' };

                self.displayInlineMessage = ko.computed(function(){
                    if(self.inlineMessages().length > 0) return true;
                    else return false;
                });

                self.inlineMessagesDataprovider = new ArrayDataProvider(self.inlineMessages);

   
                self.showProgressBar = ko.observable("none");
                self.showSubmitProgressBar = ko.observable("none");
                self.disableSubmitBtn = ko.observable(false);
                self.disableCancelBtn = ko.observable(false); 
                self.appsPwdValidationMsg = ko.observable([]);
                self.wlsPwdValidationMsg = ko.observable([]);
                self.walletPwdValidationMsg = ko.observable([]);

                self.pwdValidateProgressConfigBkp = progressHelper.getProgressConfig('validateProgress', -1, 'Password validation is in progress.' , self.showProgressBar);
                self.submitProgressConfigBkp = progressHelper.getProgressConfig('submitProgress', -1, 'Submitting request.' , self.showSubmitProgressBar);

                 self.performServerSidePwdValidationsForBackup = function(isAssignPolicy)
                 {
                     console.log('Performing server side validations for backup');
                     self.disableSubmitBtn(true);
                     self.disableCancelBtn(true);
                     self.showProgressBar("");
                     var inputsToValidateFromServer =
                             [
                                 {"id": "credentials.environment.appsPassword", "internalId": "AppsPwd", "customMsgObject": self.appsPwdValidationMsg, "value": self.appsPwd()},
                             ];


                     var isWlsPwdRequired = self.isWlsPwdRequired();
                     if (isWlsPwdRequired)
                     {
                         inputsToValidateFromServer.push({"id": "credentials.environment.weblogicPassword", "internalId": "WLSAdminPwd", "customMsgObject": self.wlsPwdValidationMsg, "value": self.wlsPwd()});
                     }
                     var isWalletPwdRequired = self.isWalletPwdRequired();
                     if (isWalletPwdRequired)
                     {
                         inputsToValidateFromServer.push({"id": "credentials.backup.sourceTDEPassword", "internalId": "walletPwd", "customMsgObject": self.walletPwdValidationMsg, "value": self.walletPwd()});
                     }
                     if(!isAssignPolicy)
                       validationHelper.validateCredentialsOnServer(self.currentEnvironmentActive(), inputsToValidateFromServer,  self.pwdValidationSuccessBkpCreation, self.pwdValidationFailedBkp);
                     else
                       validationHelper.validateCredentialsOnServer(self.currentEnvironmentActive(), inputsToValidateFromServer,  self.pwdValidationSuccessAssignPolicy, self.pwdValidationFailedBkp);
      
                 }
                 
                 self.pwdValidationSuccessBkpCreation = function()
                 {
                     self.showProgressBar("none");  
                     self.showSubmitProgressBar("");  
                     backupEnvironmentHelper.postBackupRequst(self);
                 }
                 
                 self.pwdValidationSuccessAssignPolicy = function()
                 {
                     self.showProgressBar("none");  
                     self.showSubmitProgressBar("");  
                     backupEnvironmentHelper.postScheduleBackup(self);
                 }
                 
                 self.pwdValidationFailedBkp = function(error)
                 {
                     self.disableSubmitBtn(false);
                     self.disableCancelBtn(false);
                     self.showProgressBar("none");  

                     if (error != null && error != '')
                     {
                         if (error.status === 504)
                         {
                             var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                             self.addInlineMessage('error', 'Error in validating add node request inputs.', messageContent);
                         } else
                         {
                             var errorCode = error.responseJSON.code;
                             if (error.responseJSON.code === null || error.responseJSON.code === '')
                             {
                                 errorCode = error.status;
                             }
                             var messageContent = 'Error Message : ' + error.responseJSON.message;
                             self.addInlineMessage('error', 'Error in validating add node request inputs.', messageContent);
                         }
                     }
                 }

                

                BackUpPwdValidator.prototype.validate = function (value) {
                    self.encryptionPwd(value);
                    var reEnterEncrypPwdFieldValue = document.getElementById('ReEnterEncryptionPwd|input').value;
                    if (reEnterEncrypPwdFieldValue !== null && reEnterEncrypPwdFieldValue !== '') {
                        if (value === reEnterEncrypPwdFieldValue) {
                            /* User entered re-enter encryption pwd value first and then enter encryption pwd value, 
                             * they are matching, clear the error from re enter encryption pwd field.
                             */
                            document.getElementById('ReEnterEncryptionPwd').reset();
                            self.confirmEncryptionPwd(value);
                        } else {
                            document.getElementById('ReEnterEncryptionPwd').validate();
                        }
                    }
                    return true;
                };

                self.initializeBackupChannelCountAndSectionSizeList = function (envName, dbServiceType) {
                    self.dbServiceType(dbServiceType);
                    if (dbServiceType === constants.dbTypes.exadatadbsystem) {
                        self.selectedRMANBackupChannelCount(constants.rman.defaultChannelCountForExa);
                    } else {
                        actionsHelper.getBackupChannelCountForEnvironment(envName, function (error, backupChannelCountData) {
                            if (error !== null && error !== '') {
                                console.log('Error in getting back up channel count : ' + error);
                            } else {
                                self.selectedRMANBackupChannelCount(backupChannelCountData.default);
                            }
                        });
                    }


                    actionsHelper.getBackupSectionSize(function (error, backupSectionSizeList) {
                        if (error !== null && error !== '') {
                            console.log('Error in getting back up Section Size  : ' + error);
                        } else {
                            self.rmanSectionSizeList(backupSectionSizeList);
                            self.rmanSectionSizeDataProvider = new ArrayDataProvider(self.rmanSectionSizeList, {idAttribute: 'value'});
                            var defaultValue = '';
                            for (var k = 0; k < backupSectionSizeList.length; k++) {
                                var element = backupSectionSizeList[k];
                                var isDefault = element.isDefault;
                                if (isDefault) {
                                    defaultValue = element.value;
                                }
                            }


                            if (defaultValue !== null && defaultValue !== '') {
                                self.selectedRMANSectionSize(defaultValue);
                            }
                        }
                    });


                };

                self.compressionAlgorithmChangedEvent = function () {
                    var newValue = event['detail'].value;
                    if (newValue !== 'Basic')
                    {
                        var translatedMsgForCompressionAlgo = oj.Translations.getTranslatedString("validationMsgs.CompressionAlgorithmLicensingMsg", {'compressionLevel': newValue});
                        var validationCustomMsgForTDEEnablement = {summary: translatedMsgForCompressionAlgo,
                            detail: translatedMsgForCompressionAlgo, severity: oj.Message.SEVERITY_TYPE.INFO};
                        self.compressionAlgorithmMsg([validationCustomMsgForTDEEnablement]);
                    } else
                    {
                        self.compressionAlgorithmMsg([]);
                    }
                };
                BackUpReEnterPwdValidator.prototype.validate = function (value) {
                    backupEnvironmentHelper.reEnterPwdValidator(value, self.encryptionPwd(), passwdMismatchMsg);
                };

                self.createBackUpPopupCloseCleanUpHandler = function () {

                };

                self.validateBackUpCreationContents = function () {
                    var wlsPwdRequired = self.isWlsPwdRequired();
                    var walletPwdRequired = self.isWalletPwdRequired();
                    return backupEnvironmentHelper.validateBackUpCreationContents(wlsPwdRequired, walletPwdRequired, self);
                };

                self.handleBackupMenuClickEvent = function (envName, ebsVersion, event, ui, dbServiceType) {
                    self.resetPopupContent();
                    self.initializeBackupChannelCountAndSectionSizeList(envName, dbServiceType);
                    backupEnvironmentHelper.handleBackupMenuClickEvent(envName, ebsVersion, self, event, ui);
                };
                
                self.createEnvironmentBackupSubmission = function () {
                    backupEnvironmentHelper.submitBackupCreation(self);
                };

                self.closeBackUpInformationPopup = function (event, ui) {
                    backupEnvironmentHelper.closeBackUpInformationPopup(event, ui);
                };

                self.closeBackUpCreationPopup = function (event, ui) {
                    backupEnvironmentHelper.closeBackUpCreationPopup(event, ui);
                };

                self.defaultBackupName = function (envName) {
                      backupEnvironmentHelper.defaultBackupName(self, envName);
                };

                self.resetPopupContent = function ()
                {
                    self.backupName('');
                    self.encryptionPwd('');
                    self.confirmEncryptionPwd('');
                    var confirmEncryptPwd = document.getElementById('ReEnterEncryptionPwd');
                    if (confirmEncryptPwd)
                        confirmEncryptPwd.reset();
                    self.appsPwd('');
                    self.swiftPwd('');
                    self.wlsPwd('');
                    self.walletPwd('');
                    self.selectedCompressionAlgorithm('Basic');
                    self.advancedOptionsAnchorText(self.SHOW_ADVANCED_OPTIONS_TEXT);
                    self.compressionAlgorithmMsg([]);
                    self.selectedRMANBackupChannelCount('');
                    self.rmanSectionSizeList([]);
                    self.rmanSectionSizeDataProvider = new ArrayDataProvider(self.rmanSectionSizeList, {idAttribute: 'value'});
                    self.selectedRMANSectionSize('');
                    self.validateDBOptionValue(false);
                    self.enteredRmanMaxOpenFiles(null);
                    self.enteredRmanFilesPerSet(null);
                    self.enteredRmanRate(null);
                    self.selectedRmanRateUnit('K');
                    self.enteredRmanDataFieldAllowedMaxCorruptOption('');
                    self.selectedRMANBackupChannelCount(0);
                    //self.enteredCustomRmanScriptPath('');
                    self.advancedOptionsDisplayed(false);
                    self.backupPolicyCustomMsg([]);
                    self.clearInlineMessage();
                    self.showProgressBar("none");
                    self.showSubmitProgressBar("none");
                    self.disableSubmitBtn(false);
                    self.disableCancelBtn(false);
                    self.wlsPwdValidationMsg([]);
                    self.appsPwdValidationMsg([]);
                };

                console.log('Compartment List while loading view model -' + self.compartmentList());

                self.prepareCompartmentList = function(){
                    actionsHelper.getCompartmentListForTenancy(function (error, compartmentsList) {
                        if (error != null && error != '') {
                            console.log('Error in fetching Compartment List for tenancy =>' + error);
                        } else {
                            self.compartmentList.removeAll();
                            self.compartmentDataProvider = null;
                            //var hierarchialList = getCompartmentLOVHierarchy(compartmentsList, self.tenancyId);
                            var flatList = getFlatListFromHierarchicalLov(compartmentsList, self.tenancyId);
                            self.compartmentList(flatList);
                            self.compartmentDataProvider = new ArrayDataProvider(self.compartmentList, {idAttribute: 'value'});
                            lovUtils.lovOptionsUpdated(self.compartmentList(), self.selectedCompartment);
                        }
                        console.log('Compartment List after the fetch -' + self.compartmentList());
                    });
                };
            
                if (typeof self.tenancyId === 'undefined'){
                    actionsHelper.getUserProfile(function (error, userprofile) {
                    if (error === '') {
                        if (userprofile.isSSHKeysValid) {
                            self.tenancyId = userprofile.tenancyOCID;
                           }
                       }

                        self.prepareCompartmentList();
                    });
                }
                else
                {
                    self.prepareCompartmentList();
                }

                window.handleAdvancedOptionChange = function () {
                    if (self.advancedOptionsDisplayed()) {
                        self.advancedOptionsDisplayed(false);
                        self.advancedOptionsAnchorText(self.SHOW_ADVANCED_OPTIONS_TEXT);
                    } else {
                        self.advancedOptionsDisplayed(true);
                        self.advancedOptionsAnchorText(self.HIDE_ADVANCED_OPTIONS_TEXT);
                    }
                     
                    var module = document.getElementById("backupCreatePopup");
                    oj.Components.subtreeShown(module);
                };

                // Backup name validation
                self.backupNameValidator = ko.computed(function(){
                if(self.isAssignBackupPolicy())
                    return [new RegExpValidator(
                                    {pattern: '[A-Za-z][a-zA-Z0-9_]{0,17}',
                                        messageDetail: oj.Translations.getTranslatedString('validationMsgs.assignBackupNameValidationMsg')})];
                 else 
                     return [new RegExpValidator(
                                    {pattern: '[A-Za-z][a-zA-Z0-9_]{0,30}',
                                        messageDetail: oj.Translations.getTranslatedString('validationMsgs.backupNameValidationMsg')})];
                });
                
                self.backupNameHint = ko.computed(function(){
                 if(self.isAssignBackupPolicy())
                   return oj.Translations.getTranslatedString('validationMsgs.assignBackupNameValidationMsg');
                 else
                   return oj.Translations.getTranslatedString('validationMsgs.backupNameValidationMsg');
                });
                                
                self.handleScheduleBackupMenuClickEvent = function (envName, ebsVersion, event, ui, dbServiceType) {
                    self.resetPopupContent();
                    self.initializeBackupChannelCountAndSectionSizeList(envName, dbServiceType);
                    backupEnvironmentHelper.handleScheduleBackupMenuClickEvent(envName, ebsVersion, self, event, ui);
                };

                self.scheduleEnvironmentBackup = function () {
                    backupEnvironmentHelper.submitScheduleBackup(self);
                };
                
                self.compartmentValueHandler = function(event, ui)
                {
                    var compartmentValue = event['detail'].value;
                    if (!compartmentValue || compartmentValue === '')
                        return;
                    
                    self.disableBackupPolicy(false);
                    self.backupPolicyCustomMsg([]);
                    //self.policyList([]);
                    self.policyList([{'label':  oj.Translations.getTranslatedString('info.loading'), 'value': 'LOADING'}]);
                    self.policyDataProvider = new ArrayDataProvider(self.policyList, {idAttribute: 'value'});
                    actionsHelper.getAllPolicies(compartmentValue, function (error, policies) {
                        if (error !== null && error !== '')
                        {
                            if (error.status === 504)
                            {
                                var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                                self.addPageLevelMessage('error', 'Error in retrieving policies.', messageContent);
                            } else
                            {
                                var errorCode = error.responseJSON.code;
                                if (error.responseJSON.code === null || error.responseJSON.code === '')
                                {
                                    errorCode = error.status;
                                }
                                var messageContent = 'Error Message : ' + error.responseJSON.message;
                                self.addPageLevelMessage('error', 'Error in retrieving policies.', messageContent);
                            }
                        }
                        var listOfPolicies = [];
                        $.each(policies, function () {
                            var listEntry = new Object();
                            listEntry.label = this.name;
                            listEntry.value = this.id;
                            listOfPolicies.push(listEntry);
                        });
                        
                        if(listOfPolicies.length > 0)
                        {
                           self.policyList(listOfPolicies);
                           self.policyDataProvider = new ArrayDataProvider(self.policyList, {idAttribute: 'value'});
                        }
                        else
                        {                           
                           self.policyList([{'label': '', 'value': 'LOADING'}]);
                           self.policyDataProvider = new ArrayDataProvider(self.policyList, {idAttribute: 'value'});
                           var backupCustomMsg = oj.Translations.getTranslatedString('validationMsgs.lovValueNotFoundMsg', {lovName: 'policy'});
                           var validationMsg = {summary: backupCustomMsg,
                                    detail: backupCustomMsg, severity: oj.Message.SEVERITY_TYPE.WARNING};
                           self.backupPolicyCustomMsg([validationMsg]);
                        }
                    });
                };
            }

            return backupContentViewModel;
        });
