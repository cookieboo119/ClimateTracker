/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 * PURPOSE.
 */

/*
 * GetHistory - This class submits a gethistory request by specifying
 * the instruments and fields for the request parameters. This is followed
 * by retrieve gethistory response to get the values for the fields.
 */
package com.bloomberg.datalic.dlws;

import java.util.Calendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import com.bloomberg.datalic.dlws.stubs.DateRange;
import com.bloomberg.datalic.dlws.stubs.Fields;
import com.bloomberg.datalic.dlws.stubs.GetHistoryHeaders;
import com.bloomberg.datalic.dlws.stubs.HistInstrumentData;
import com.bloomberg.datalic.dlws.stubs.Instrument;
import com.bloomberg.datalic.dlws.stubs.InstrumentType;
import com.bloomberg.datalic.dlws.stubs.Instruments;
import com.bloomberg.datalic.dlws.stubs.MarketSector;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.Period;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;
import com.bloomberg.datalic.dlws.stubs.ResponseStatus;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetHistoryRequest;
import com.bloomberg.datalic.dlws.stubs.RetrieveGetHistoryResponse;

public class GetHistory {
    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Setting headers
            GetHistoryHeaders headers = new GetHistoryHeaders();
            headers.setProgramflag(programFlag);
            DateRange dateRange = new DateRange();
            Period period = new Period();
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE, -5);
            XMLGregorianCalendar start = DatatypeFactory.newInstance().newXMLGregorianCalendar();

            start.setDay(calendar.get(Calendar.DATE));
            // Adjust month value since 'Calendar' month value is 0-based,
            // example: 0 for January,
            // whereas 'XMLGregorianCalendar' month value is between 1 to 12.
            start.setMonth(calendar.get(Calendar.MONTH) + 1);
            start.setYear(calendar.get(Calendar.YEAR));
            period.setStart(start);

            calendar = Calendar.getInstance();
            XMLGregorianCalendar end = DatatypeFactory.newInstance().newXMLGregorianCalendar();
            end.setDay(calendar.get(Calendar.DATE));
            end.setMonth(calendar.get(Calendar.MONTH) + 1);
            end.setYear(calendar.get(Calendar.YEAR));
            period.setEnd(end);
            dateRange.setPeriod(period);
            headers.setDaterange(dateRange);

            // Setting instruments
            Instrument ticker = new Instrument();
            ticker.setId("IBM US");
            ticker.setType(InstrumentType.TICKER);
            ticker.setYellowkey(MarketSector.EQUITY);

            Instrument bbUniqueId = new Instrument();
            bbUniqueId.setId("EQ0000000002815382");
            bbUniqueId.setType(InstrumentType.BB_UNIQUE);

            Instruments instruments = new Instruments();
            instruments.getInstrument().add(ticker);
            instruments.getInstrument().add(bbUniqueId);

            // Setting fields
            Fields fields = new Fields();
            fields.getField().add("PX_LAST");
            fields.getField().add("PX_HIGH");
            fields.getField().add("PX_LOW");

            // Construct and submit gethistory request
            System.out.println("Sending submit gethistory request");
            Holder<ResponseStatus> statusCode = new Holder<ResponseStatus>();
            Holder<String> requestId = new Holder<String>();
            Holder<String> responseId = new Holder<String>();
            ps.submitGetHistoryRequest(headers, fields, instruments, statusCode, requestId,
                    responseId);
            System.out.println("Submit gethistory request status: "
                    + statusCode.value.getDescription() + ", responseId: " + responseId.value);

            // Submit retrieve gethistory
            RetrieveGetHistoryRequest rtvGetHistoryReq = new RetrieveGetHistoryRequest();
            rtvGetHistoryReq.setResponseId(responseId.value);
            RetrieveGetHistoryResponse rtvGetHistoryResp;
            System.out.println("Sending retrieve gethistory request");

            // Keep polling for response till the data is available
            do {
                Thread.sleep(PerSecurity.POLL_FREQUENCY);
                rtvGetHistoryResp = ps.retrieveGetHistoryResponse(rtvGetHistoryReq);
            } while (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE);

            // Display data
            if (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("Retrieve gethistory request successful for responseId: "
                        + rtvGetHistoryResp.getResponseId());
                for (HistInstrumentData histInstrumentData : rtvGetHistoryResp.getInstrumentDatas()
                        .getInstrumentData()) {
                    String yellowKey = "";
                    if (histInstrumentData.getInstrument().getYellowkey() != null) {
                        yellowKey = " " + histInstrumentData.getInstrument().getYellowkey().toString();
                    }
                    System.out.println("Data for " + histInstrumentData.getInstrument().getId()
                            + yellowKey + ":");
                    System.out.println(histInstrumentData.getDate());
                    for (int i = 0; i < histInstrumentData.getData().size(); i++) {
                        System.out.println("  " + fields.getField().get(i) + ": "
                                + histInstrumentData.getData().get(i).getValue());
                    }
                }
            } else if (rtvGetHistoryResp.getStatusCode().getCode() == PerSecurity.REQUEST_ERROR) {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
