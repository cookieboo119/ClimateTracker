define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/actions/actionsHelper',
    'jquery', 'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojbutton', 'ojs/ojselectcombobox', 'ojs/ojknockout-validation', 'ojs/ojradioset'
], function (oj, ko, constants, actionsHelper) {
    /**
     * The view model for the main content view template
     */
    function tagViewModel() {
        var self = this;
        var _index = 0;
        self.selectedTagId;
        // self.tagObsArray = ko.observableArray([]);

        self.additionalTags = ko.observableArray([
            {type: ["None"], tagKeyText: "", tagKeySelect: "", tagValue: "", tagValueSelect: "", id: _index++}]);

        // Add new row
        // self.addAdditionalTag = function () {
        // self.additionalTags.unshift({type: [], tagKey: "", tagKeySelect: "", tagValue: "", id: _index++});
        // };

        // Removes current row
        // self.removeAdditionalTag = function (event, current) {
        // self.additionalTags.remove(function (tagId) {
        // return tagId.id === current.data.id;
        // });
        // };

        // To fetch current row selected from textfield or combobox
        self.changeTagKey = function (event, current) {
            console.log('changeTagKey current.data.id:' + current.data.id);
            self.selectedTagId = current.data.id;
        };

        var TagKeyTextValidator = function () {};
        oj.Object.createSubclass(TagKeyTextValidator, oj.Validator, "TagKeyTextValidator");
        self.tagKeyTextValidator = [new TagKeyTextValidator()];

        TagKeyTextValidator.prototype.validate = function (value) {
            var patt = /(\s|\.)/;
            if (patt.test(value)) {
                throw new Error(oj.Translations.getTranslatedString('validationMsgs.tagKeyTextValidationMsg'));
            }
        };

        // Commented Validate multiple rows
        self.rowValidators = {
            validate: function (value) {
//                        var currentRowIndex;
//                        if (typeof (self.selectedTagId) !== 'undefined') {
//                            currentRowIndex = self.selectedTagId;
//                        }
//                        self.tagObsArray([]);
//                        for (var i = 0; i < _index; i++) {
//                            if (currentRowIndex === i) {
//                                continue;
//                            }
//                            var currentTagNamespace = document.getElementById('tagNamespace' + i).value;
//                            var currentTagKeySelect = document.getElementById('tagKeySelect' + i).value;
//                            var currentTagKeyText = document.getElementById('tagKeyText' + i).value;
//
//                            var tagKeySelectStyle = document.getElementById('tagKeySelect' + i).style.display;
//                            var tagKeyTextStyle = document.getElementById('tagKeyText' + i).style.display;
//
//                            var isTextActive = false;
//                            if (null !== tagKeySelectStyle && '' === tagKeySelectStyle) {
//                                isTextActive = false;
//                            } else if (null !== tagKeyTextStyle && '' === tagKeyTextStyle) {
//                                isTextActive = true;
//                            }
//
//                            if (isTextActive) {
//                                if (null !== currentTagKeyText) {
//                                    var obj = new Object();
//                                    obj.key = currentTagNamespace + "." + currentTagKeyText;
//                                    self.tagObsArray.push(obj);
//                                }
//                            } else {
//                                if (null !== currentTagKeySelect && currentTagKeySelect.length > 0) {
//                                    var obj = new Object();
//                                    obj.key = currentTagNamespace + "." + currentTagKeySelect;
//                                    self.tagObsArray.push(obj);
//                                }
//                            }
//                        }
//
//                        if (self.tagObsArray() && self.tagObsArray().length > 0 && value) {
//                            var count = 1;
//                            var currentSelTagNamespace = document.getElementById('tagNamespace' + currentRowIndex).value;
//                            var currentTagNameSpaceKey = currentSelTagNamespace + "." + value;
//                            console.log('obs array ' + JSON.stringify(self.tagObsArray()));
//
//                            self.tagObsArray().forEach(tagKeyVal => {
//                                if (tagKeyVal.key.localeCompare(currentTagNameSpaceKey) === 0) {
//                                    count += 1;
//                                }
//                            });
//                            if (count > 1) {
//                                throw new Error(oj.Translations.getTranslatedString('validationMsgs.tagInformation'));
//                            } else {
//                                return;
//                            }
//                        }
            }

        };
    }
    return tagViewModel;
});