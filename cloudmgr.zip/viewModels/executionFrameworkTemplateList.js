
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/navigation/pageNavigationHelper', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ojs/ojlistdataproviderview', 'ojs/ojarraydataprovider', 'ebs/utils/dateTimeHelper', 'ojs/ojmenu', 'ojs/ojinputsearch'
], function (oj, ko, constants, pageNavigationHelper, actionsHelper, popupHelper, ListDataProviderView, ArrayDataProvider, dateTimeHelper) {
    /**
     * The view model for the main content view template
     */
    function ExecutionFrameworkTemplateListViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.executionPlanListLoaded = ko.observable(false);
        self.executionPlans = ko.observableArray([]);
        self.filter = ko.observable();
        self.runningDeleteFlowValidations = ko.observable(false);
        self.validationChecks = oj.Translations.getTranslatedString("validationMsgs.ValidatingUsages");
        self.deleteTemplateCurrentStatus = ko.observable();
        self.runningEditFlowValidations = ko.observable(false);
        self.editTemplateCurrentStatus = ko.observable();
        self.deleteAdditionalInformation = ko.observable();
        self.editAdditionalInformation = ko.observable();
        self.deleteItemName = null;
        self.confirmDeleteMsg = ko.observable();
        self.confirmEditMsg = ko.observable();
        self.disableServerSideValidation = false;

        self.executionPlanDataProvider = ko.computed(function () {
            var filterRegEx = new RegExp(self.filter(), 'i');
            var filterCriterion = {
                op: '$or',
                criteria: [{op: '$regex', value: {name: filterRegEx}},
                    {op: '$regex', value: {flow: filterRegEx}},
                    {op: '$regex', value: {createdBy: filterRegEx}},
                    {op: '$regex', value: {dateCreated: filterRegEx}}]
            };
            var arrayDataProvider = new ArrayDataProvider(self.executionPlans(), {keyAttributes: 'id',     
                sortComparators: { comparators: new Map().set("dateCreated", dateTimeHelper.dateComparator)}});
            return new ListDataProviderView(arrayDataProvider, {filterCriterion: filterCriterion});
        }, self);


        self.menuOptions = ko.observableArray([]);
        self.currentItemIndex = ko.observable();
        self.executionPlanColumns = [
            {headerText: '',
                field: 'image',
                style:"width: 50px; max-width: 50px;",
                template: 'iconTemplate'}, 
            {headerText: 'Name',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'name',
                sortable: 'enabled',
                template: 'nameCellTemplate',
                sortProperty: 'name'},
            {headerText: 'Base Plan',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'flow',
                sortable: 'enabled',
                template: 'textCellTemplate',
                sortProperty: 'flow'},
            {headerText: 'Created By',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'createdBy',
                template: 'textCellTemplate',
                sortable: 'enabled',
                sortProperty: 'createdBy'}, 
            {headerText: 'Date Created',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left;",
                style: "white-space:normal;word-wrap:break-word; text-align: left;vertical-align: center;",
                field: 'dateCreated',
                template: 'textCellTemplate',
                sortable: 'enabled'},
            {headerText: 'Actions',
                headerStyle: "font-weight: bold; min-width: 8em; max-width: 16em; width: 8em; text-align: left; vertical-align: center;",
                template: 'menuCellTemplate',
                field: 'menu',
                sortable: 'disabled'}
        ];


        self.handleCreateExecutionTemplateButtonClick = function () {
            rootViewModel._currentExecutionPlanForEdit = '';
            rootViewModel._currentExecutionPlanDescForEdit = '';
            var context = ko.contextFor(document.getElementById(constants.divTags.execFwkMainPG));
            pageNavigationHelper.navigateToPage(context, constants.navModules.createExecutionTemplateModule, '', false);
        };

        self.setupMenuOptions = function (event, ui) {
            var index = ui.index;
            self.getMenuItems(index);
            self.currentItemIndex(index);
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        };
        self.getMenuItems = function (index) {
            var data = self.executionPlans()[index];
            var actionsMenu = self.getActionMenu(data);
            if (actionsMenu)
                self.menuOptions(actionsMenu);

            return;
        };

        self.confirmationDialogText = ko.observable('');
        self.confirmationCallBackFunctionSuccess = null;
        self.confirmationCallBackFunctionFailure = null;
        self.isNoButtonRendered = ko.observable(true);

        self.startAnimationListener = function (event, ui) {
            popupHelper.startAnimationListener(constants.divTags.execPlanListPGConfirmPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.execPlanListPGConfirmPopupTag, data, event);
        };

        self.getActionMenu = function (execPlanData)
        {
            var menu = [];
            menu.push({id: 'edit', label: 'Edit', disabled: false});
            menu.push({id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: false});

            return menu;
        };
        
        self.getExecPlanIndexFromExecPlanId = function(execPlanId){
            for (var k = 0; k < self.executionPlans().length; k++) {
                var execPlanIdentifier = self.executionPlans()[k].id;
                if (execPlanIdentifier === execPlanId) {
                    return k;
                }
            }
        };
        
        
        self.actionMenuHandler = function (event, ui)
        {
            self.deleteItemName = null;
            rootViewModel._currentExecutionPlanForEdit = null;
            rootViewModel._currentExecutionPlanDescForEdit = null;
            rootViewModel._currentExecutionPlanIdForEdit = null;
            rootViewModel._currentExecutionPlanAssociatedFlowLabel = null;
            var action = event.target.id;
            var currentItemIdx = self.getExecPlanIndexFromExecPlanId(ui.key);
            var itemName = self.executionPlans()[currentItemIdx].name;
            var itemDescription = self.executionPlans()[currentItemIdx].description;
            var itemId = self.executionPlans()[currentItemIdx].id;
            var associatedFlowLabel = self.executionPlans()[currentItemIdx].flow;
            console.log('Performing action :' + action);
            if ("delete" === action) {
                var deleteConfirmationMsg = oj.Translations.getTranslatedString("warningOrConfirmationMsgs.sureToDeleteExecutionPlan", {executionPlan: itemName});
                self.deleteItemName = itemName;
                self.confirmDeleteMsg(deleteConfirmationMsg);
                var popup = document.querySelector(constants.divTags.templateListDelPopupTag);
                popup.open(event.target);
                self.runningDeleteFlowValidations(true);
                if (!self.disableServerSideValidation) {
                    actionsHelper.getExecutionPlanLCMActivites(itemId, function (error, lcmActivities) {
                        self.runningDeleteFlowValidations(false);
                        var detailsFound = false;
                        for (var k = 0; k < lcmActivities.length; k++) {
                            var lcmName = lcmActivities[k].name;
                            if (lcmName === 'delete') {
                                detailsFound = true;
                                var deleteAllowed = lcmActivities[k].allowed;
                                if (deleteAllowed) {
                                    var isWarningPresent = lcmActivities[k].hasWarning;
                                    if (isWarningPresent) {
                                        self.deleteTemplateCurrentStatus("allowed_with_warning");
                                        var message = lcmActivities[k].message;
                                        if (typeof (message) === 'undefined') {
                                            message = "No Additional Information.";
                                        }
                                        self.deleteAdditionalInformation(message);
                                    } else {
                                        self.deleteTemplateCurrentStatus("allowed");
                                    }
                                } else {
                                    self.deleteTemplateCurrentStatus("not_allowed");
                                    var message = lcmActivities[k].message;
                                    if (typeof (message) === 'undefined') {
                                        message = "No Additional Information.";
                                    }
                                    self.deleteAdditionalInformation(message);
                                }
                            }
                        }
                        if (!detailsFound) {
                            self.deleteTaskCurrentStatus("not_allowed");
                            message = "No Additional Information.";
                            self.deleteAdditionalInformation(message);
                        }
                    });
                } else {
                    self.runningDeleteFlowValidations(false);
                    self.deleteTemplateCurrentStatus("allowed");
                }
            } else if ("edit" === action) {
                rootViewModel._currentExecutionPlanForEdit = itemName;
                rootViewModel._currentExecutionPlanDescForEdit = itemDescription;
                rootViewModel._currentExecutionPlanIdForEdit = itemId;
                rootViewModel._currentExecutionPlanAssociatedFlowLabel = associatedFlowLabel;
                self.runningEditFlowValidations(true);
                self.confirmEditMsg(oj.Translations.getTranslatedString("confirmPopup.editTemplateAssertMsg", {templateName: itemName}));
                var popup = document.querySelector(constants.divTags.templateListEditPopupTag);
                popup.open(event.target);
                if (!self.disableServerSideValidation) {
                    actionsHelper.getExecutionPlanLCMActivites(itemId, function (error, lcmActivities) {
                        self.runningEditFlowValidations(false);
                        var detailsFound = false;
                        for (var k = 0; k < lcmActivities.length; k++) {
                            var lcmName = lcmActivities[k].name;
                            if (lcmName === 'update') {
                                detailsFound = true;
                                var editAllowed = lcmActivities[k].allowed;
                                if (editAllowed) {
                                    var isWarningPresent = lcmActivities[k].hasWarning;
                                    if (isWarningPresent) {
                                        self.editTemplateCurrentStatus("allowed_with_warning");
                                        var message = lcmActivities[k].message;
                                        if (typeof (message) === 'undefined') {
                                            message = "No Additional Information.";
                                        }
                                        self.editAdditionalInformation(message);
                                    } else {
                                        self.confirmEditTemplate();
                                    }
                                } else {
                                    self.editTemplateCurrentStatus("not_allowed");
                                    var message = lcmActivities[k].message;
                                    if (typeof (message) === 'undefined') {
                                        message = "No Additional Information.";
                                    }
                                    self.editAdditionalInformation(message);
                                }
                            }
                        }
                        if (!detailsFound) {
                            self.editTemplateCurrentStatus("not_allowed");
                            message = "No Additional Information.";
                            self.editAdditionalInformation(message);
                        }
                    });
                } else {
                    self.runningEditFlowValidations(false);
                    self.confirmEditTemplate();
                }

            }
        };

        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.templateListDelPopupTag);
            popup.close();
        };

        self.closeConfirmEditPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.templateListEditPopupTag);
            popup.close();
        };

        self.deleteTemplate = function () {
            self.closeConfirmDeletePopup();
            self.deleteExecutionPlan(self.deleteItemName);
            console.log('Delete Template Called..');
        };

        self.confirmEditTemplate = function () {
            var context = ko.contextFor(document.getElementById(constants.divTags.execFwkMainPG));
            pageNavigationHelper.navigateToPage(context, constants.navModules.createExecutionTemplateModule, '', false);
        };

        self.deleteExecutionPlan = function (executionPlanName) {
            var executionPlanIdentifier = self.getExecutionPlanIDForName(executionPlanName);
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteExecPlanInfoMsg", {'execPlanName': executionPlanName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.deleteExecPlanTitle");
            popupHelper.openInfoMsg(constants.divTags.execPlanListPGConfirmPopupTag, infoMsg, msgOrigin);
            actionsHelper.deleteExecutionPlan(executionPlanIdentifier, function (error, success) {
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteExecPlanConfirmMsg", {'execPlanName': executionPlanName});
                    popupHelper.openSuccessMsg(constants.divTags.execPlanListPGConfirmPopupTag, successMsg, msgOrigin);
                    //self.clearFilterInput();
                    self.loadExecutionPlans();
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.execPlanListPGConfirmPopupTag, response.message, msgOrigin);
                }
            });
        };


        self.searchText = ko.observable('');
        self.handleSearchTextChange = function (event, ui)
        {
            event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleValueChanged(event, ui);
            }
        }
        self.handleValueChanged = function () {
            self.filter(self.searchText());
        };

        self.clearFilterInput = function () {
            if (document.getElementById('filterExecSet'))
                document.getElementById('filterExecSet').value = '';
            self.filter('');
        };


        self.loadExecutionPlans = function () {
            self.executionPlanListLoaded(false);
            self.clearFilterInput();
            actionsHelper.getListOfExecutionPlans(function (error, execPlanList) {

                if (error !== null && error !== '')
                {
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        self.addPageLevelMessage('error', 'Error in retrieving execution plan list.', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        self.addPageLevelMessage('error', 'Error in retrieving execution  plan list.', messageContent);
                    }

                }

                var execPlanArray = [];

                $.each(execPlanList, function () {
                    var plan = {
                        flow: this.jobType,
                        name: this.name,
                        id: this.id,
                        description: this.description,
                        createdBy: this.createdBy,
                        dateCreated: dateTimeHelper.convertToUTC(this.createdOn),
                        deleteEnabled: this.deleteEnabled,
                        menu: self.menuOptions,
                        menuActionHandler: self.actionMenuHandler,
                        setupMenuHandler: self.setupMenuOptions,
                        showDetailsPopup: self.showDetailsPopup
                    };
                    execPlanArray.push(plan);
                });
                self.executionPlans(execPlanArray);

                self.executionPlanListLoaded(true);

            });
        };

        self.getExecutionPlanIDForName = function (searchExecPlanName) {
            for (var i = 0; i < self.executionPlans().length; i++) {
                var execPlanName = self.executionPlans()[i].name;
                if (execPlanName === searchExecPlanName) {
                    return self.executionPlans()[i].id;
                }
            }
        };

        self.showDetailsPopup = function (viewModel, event) {
            var buttonIdentifier = event.target.id;
            var rowName = buttonIdentifier.split("~")[1];
            var execPlanIdentifier = self.getExecutionPlanIDForName(rowName);
            var viewModelOfExecPlanDetailPopup = ko.dataFor(document.getElementById('CustomExecutionPlanPopupPGTop'));
            viewModelOfExecPlanDetailPopup.openPopup(execPlanIdentifier, rowName, event);

        };

        self.loadExecutionPlans();
    }
    return ExecutionFrameworkTemplateListViewModel;

});
