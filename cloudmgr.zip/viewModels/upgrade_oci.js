/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Upgrade DB popup module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper','ebs/constants','ebs/utils/compartmentsLov', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton'], 
function(oj, ko, actionsHelper, popupHelper, constants) {
  /**
   * The view model for the main content view template
   */
  function DBUpgradeContentViewModel() {
    var self = this;
    var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
    self.envListViewModel = ko.observable('');
    self.currentEnvironmentName = ko.observable('');
    self.appsPwd = ko.observable('');
    self.wlsPwd = ko.observable('');
    self.systemPwd = ko.observable('');
    self.DBAdminPwd = ko.observable('');
    self.isWlsPwdRequired = ko.observable(true);
    self.authToken = ko.observable('');
    self.isWalletPwdRequired = ko.observable(false);
    self.walletPwd = ko.observable('');
    self.confirmUpgradeMsg = ko.observable('');
    self.upgradeDBTitle = ko.observable('');
    self.confirmUpgradeDBTitle = ko.observable('');
    self.dbVersionList = ko.observableArray([{
      'label': '19c',
      'value': '19c'
    },
    {
      'label': '20c',
      'value': '20c'
    }]);

    self.selectedDBVersion = ko.observable('19c');
    
    self.closeConfirmUpgradePopup = function (event, ui) {
        var popup = document.getElementById(constants.divTags.envListUpgradePopupTag);
        popup.close();

    };

    self.closeUpgradeDBVersionPopup = function(){
        var popup = document.getElementById(constants.divTags.upgradeDBVerPopup);
        popup.close();
    };

    self.validateUpgradeDBPopupContent = function()
    {
        var appsPwd = document.getElementById("UpgradeAppsPwd");
        var wlsAdminPwd = document.getElementById("UpgradeWLSAdminPwd");
        var dbAdminPwd = document.getElementById("DBAdminPwd");
        var srcWalletPwd = document.getElementById("WalletPwd");
        var systemPwd = document.getElementById("SystemPwd");

        var validContent = true;

        if(self.isWalletPwdRequired())
        {
            if(srcWalletPwd.valid !== 'valid')
            {
                srcWalletPwd.showMessages();
                validContent = false;
            }
        }

        if (self.isWlsPwdRequired()) {
             if (wlsAdminPwd.valid  !== 'valid') {
                wlsAdminPwd.showMessages();
                validContent = false;
            }
        } 
        
        if (appsPwd.valid !== 'valid') {
                appsPwd.showMessages();
                validContent = false;
        }
        
        if (dbAdminPwd.valid !== 'valid') {
                dbAdminPwd.showMessages();
                validContent = false;
        }
        
        if (systemPwd.valid !== 'valid') {
                systemPwd.showMessages();
                validContent = false;
        }
        
        return validContent;
    };

    self.upgradePopupCloseCleanUpHandler= function () {
        self.appsPwd('');  
        self.wlsPwd(''); 
        self.DBAdminPwd('');
        self.walletPwd('');
        self.systemPwd('');
        self.currentEnvironmentName('');
        self.isWlsPwdRequired(true);
        self.authToken('');
        self.isWalletPwdRequired(false);
    };


    self.confirmUpgradeDB = function (event, ui) {
        if (!self.validateUpgradeDBPopupContent()) return;
           
        var envName = self.currentEnvironmentName();
        var dbVersion = self.selectedDBVersion();
        self.confirmUpgradeDBTitle(oj.Translations.getTranslatedString("confirmPopup.confirmUpgradeTitle"));
        if (envName !== null && envName !== '') {
            self.confirmUpgradeMsg(oj.Translations.getTranslatedString("confirmPopup.upgradeAssertMsg", {'envName': envName, 'dbVersion': dbVersion}));
            var popup = document.getElementById(constants.divTags.envListUpgradePopupTag);
            popup.open(); 
        }
    };

    self.upgradeEnv = function (event, ui) {
        var reqBody = {
            "credentials": {
                "environment": {
                    "appsPassword": self.appsPwd(),
                     "weblogicPassword": (self.isWlsPwdRequired()? self.wlsPwd() : null),
                     "systemPassword": self.systemPwd(),
                     "databaseAdminPassword": self.DBAdminPwd(),
                     "tdeWalletPassword": self.isWalletPwdRequired()? self.walletPwd() : null
                }
            }
        };
        
        console.log("isWalletPwd reqired=" + self.isWalletPwdRequired() + "; walletPwd=" + self.walletPwd());

        var reqBodyJSON = JSON.stringify(reqBody);
        console.log('Upgrade DB request JSON =>' + reqBody);

        var envName = self.currentEnvironmentName();
        var dbVersion = self.selectedDBVersion(); //hard code to 19c for now
        var infoMsg = oj.Translations.getTranslatedString("confirmPopup.upgradeInfoMsg", {'envName': envName, 'dbVersion': dbVersion});
        var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.upgradeEnvTitle");
        popupHelper.openInfoMsg(constants.divTags.envListConfPopupTag, infoMsg, msgOrigin);
               
        var popup = document.getElementById(constants.divTags.upgradeDBVerPopup);
        popup.close();
        popup = document.getElementById(constants.divTags.envListUpgradePopupTag);
        popup.close();
        
        actionsHelper.upgradeEnv(envName, dbVersion, reqBodyJSON, function (error, success) { //placeholder  
            if (error === null || error === '') {
                var successMsg = oj.Translations.getTranslatedString("confirmPopup.upgradeConfirmMsg", {'envName': envName, 'dbVersion': dbVersion});
                popupHelper.openSuccessMsg(constants.divTags.envListConfPopupTag, successMsg, msgOrigin);
                self.envListViewModel().loadData(rootViewModel.selectedCompartment());
            } else {
                var responseText = error.responseText;
                var response = oj.Translations.getTranslatedString("confirmPopup.upgradeErrMsg", {'envName': envName, 'dbVersion': dbVersion});
                try
                {
                    if(responseText)
                    {
                        response = JSON.parse(responseText).message;
                    }
                }catch(e){}
                popupHelper.openErrorMsg(constants.divTags.envListConfPopupTag, response, msgOrigin);
            }
        });
    };

    self.handleDBUpgradeClick = function(viewModel, envName, ebsVersion, event, ui) {
        self.currentEnvironmentName(envName);
        self.envListViewModel(viewModel);
        console.log('Triggering upgrade db action..');
        self.upgradeDBTitle(oj.Translations.getTranslatedString("confirmPopup.upgradeEnvDBTitle", {'envName': envName}));
        //var popup = document.getElementById(constants.divTags.upgradeDBVerPopup);
        self.confirmUpgradeMsg(oj.Translations.getTranslatedString("confirmPopup.upgradeAssertMsg", {'envName': envName, 'dbVersion': self.selectedDBVersion()}));

        // Find if the environment is TDE Enabled. If so, then show the wallet pwd.
        actionsHelper.getEnvDetails(envName, function(error, envDetails)
        {
            var isTDEEnabled = envDetails.dbTier.tdeEnabled;
            if(isTDEEnabled !== null && typeof(isTDEEnabled) !== 'undefined' && isTDEEnabled !== '')
            {
                self.isWalletPwdRequired(isTDEEnabled);
            }
            else
            {
                self.isWalletPwdRequired(false); // Default value.
        }
            self.isWlsPwdRequired(ebsVersion === constants.ebsVersions.twelveone ? false : true);
            console.log('Is WLS Pwd required =>' + self.isWlsPwdRequired());

            var popup = document.getElementById(constants.divTags.upgradeDBVerPopup);
            popup.open();
        });

        };

  }

  return DBUpgradeContentViewModel;
});
