
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper', 'ebs/utils/dateTimeHelper', 'ebs/utils/networkProfileHelper', 'ojs/ojarraydataprovider', 'ebs/utils/helpMenu', 'ojs/ojvalidator-regexp', 'ojs/ojasyncvalidator-numberrange', 'ebs/utils/versionUtils', 'jquery', 'ojs/ojmenu', 'ojs/ojpopup', 'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojselectcombobox', 'ojs/ojinputtext',
    'ojs/ojknockout-validation', 'ojs/ojradioset', 'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojmodule', 'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojcheckboxset', 'ojs/ojmessages', 'ojs/ojtable', 'ojs/ojvalidationgroup'],
        function (oj, ko, constants, popupHelper, actionsHelper, pageNavigationHelper, dateTimeHelper, networkProfileHelper, arrayDataProvider, helpMenu, RegExpValidator, AsyncNumberRangeValidator, versionUtils)
        {

            function ExecutionFrameworkTemplateViewModel()
            {
                var self = this;
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.submitButtonDisabled = ko.observable(true);
                self.selectedStepValue = ko.observable(constants.navModules.executionFrameworkTemplateCreateChooseBaseTemplate);
                self.stepArray = ko.observableArray([
                    {label: 'Activity Plan', id: constants.navModules.executionFrameworkTemplateCreateChooseBaseTemplate, rank: 0, disabled: false},
                    {label: 'Activity Plan Details', id: constants.navModules.executionFrameworkTemplateCreateCustomizeTemplate, rank: 1, disabled: false},
                    {label: 'Review', id: constants.navModules.executionFrameworkTemplateCreateReviewCustomTemplate, rank: 2, disabled: false}
                ]);
                self.isEditMode = ko.observable(false);
                 var execPlanForEdit = rootViewModel._currentExecutionPlanForEdit;
                 if (execPlanForEdit !== null && execPlanForEdit !== '') {
                     self.isEditMode(true);
                 }

                self.execTemplateCreateFlowModulePath = ko.pureComputed(function ()
                {
                    console.log('Getting Module Path..');
                    helpMenu.addElementAndRemoveDuplicate(self.selectedStepValue());
                    return (constants.navModules.executionFrameworkModule + '/' + self.selectedStepValue());
                });

                self.changeTrainModule = function (event, ui, fromStepIdentifier, toStepRankValue, toStepIdenfitier) {
                    var train = document.getElementById('ExecutionFrameworkCreateTrain');
                    var fromStep = '';
                    var toStepRank = '';
                    if (event !== null) {
                        fromStep = event.detail.fromStep.id;
                        toStepRank = event.detail.toStep.rank;
                    } else {
                        fromStep = fromStepIdentifier;
                        toStepRank = toStepRankValue;
                    }

                    if (fromStep === 'chooseBaseTemplate') {
                        if (document.getElementById('CustomExecutionPlanDefinePGTop') !== null) {
                            var viewModuleOfCustomizationTemplate = ko.dataFor(document.getElementById('CustomExecutionPlanDefinePGTop'));
                            var viewModelOfBaseTemplatePG = ko.dataFor(document.getElementById('TemplateParametersEntryForm'));
                            var execPlanForEdit = rootViewModel._currentExecutionPlanForEdit;
                            if (execPlanForEdit !== null && execPlanForEdit !== '') {
                                // No checks.
                            } else {
                                var lastFetchedExecTemplate = viewModuleOfCustomizationTemplate._lastLoadedTemplate;
                                if (lastFetchedExecTemplate !== viewModelOfBaseTemplatePG.executionPlanTemplateSelected()) {
                                    self.selectedStepValue(constants.navModules.executionFrameworkTemplateCreateCustomizeTemplate);
                                    if (typeof (event) !== 'undefined' && event !== null)
                                    {
                                        event.preventDefault();
                                    }
                                    viewModuleOfCustomizationTemplate.initializeTableData();
                                    return;
                                }
                            }
                        }
                    }

                    if (toStepRank === 1 && fromStep === 'chooseBaseTemplate') {
                        var viewModelOfBaseTemplateParams = ko.dataFor(document.getElementById('TemplateParametersEntryForm'));
                        
                        var isFormValid = viewModelOfBaseTemplateParams.isFormValid();
                        if (!isFormValid) {
                            self.selectedStepValue(fromStep);
                            if (typeof (event) !== 'undefined' && event !== null)
                            {
                                event.preventDefault();
                            }
                            return false;
                        }
                        self.submitButtonDisabled(true);
                    } else if (toStepRank === 2) {
                        if (document.getElementById('execPlanTableReview') !== null) {
                            var viewModuleOfReviewTemplate = ko.dataFor(document.getElementById('execPlanTableReview'));
                            viewModuleOfReviewTemplate.initializeTableData();
                        }
                        self.submitButtonDisabled(false);
                    } else {
                        self.submitButtonDisabled(true);
                    }
                    if (event !== null) {
                        self.selectedStepValue(event.detail.toStep.id);
                    } else {
                        self.selectedStepValue(toStepIdenfitier);
                    }
                };

                self.handleCancelButton = function () {
                    var context = ko.contextFor(document.getElementById('ExecutionFrameworkCreateTrain'));
                    //pageNavigationHelper.navigateToPage(context, constants.navModules.cloudManagerAdministrationModule, constants.navModules.cloudManagerAdministrationModule);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.executionFrameworkModule, constants.navModules.executionFrameworkModule);
                    rootViewModel.initialAdministrationSubTab = constants.navModules.executionFrameworkModule;
                    rootViewModel.initialExecutionFwkSubTab = constants.navModules.executionTemplatesListingModule;
                };

                self.nextStep = function ()
                {
                    console.log('Need to go to next step..');
                    var fromStepIdentifier = self.selectedStepValue();
                    var fromStepRank = self.getRankForStepID(fromStepIdentifier);
                    var toStepRank = fromStepRank + 1;
                    var toStepIdentifier = self.stepArray()[toStepRank].id;
                    self.changeTrainModule(null, null, fromStepIdentifier, toStepRank, toStepIdentifier);
                };

                self.prevStep = function ()
                {
                    console.log('Go to Previous Step..');
                    var fromStepIdentifier = self.selectedStepValue();
                    var fromStepRank = self.getRankForStepID(fromStepIdentifier);
                    var toStepRank = fromStepRank - 1;
                    var toStepIdentifier = self.stepArray()[toStepRank].id;
                    self.changeTrainModule(null, null, fromStepIdentifier, toStepRank, toStepIdentifier);
                };

                self.getRankForStepID = function (stepId) {
                    var steps = self.stepArray();
                    for (var i = 0; i < steps.length; i++) {
                        var stepIdentifier = steps[i].id;
                        if (stepId === stepIdentifier) {
                            return steps[i].rank;
                        }
                    }
                };

                self.handleCustomTemplateSubmitButton = function () {
                    var tableElement = document.getElementById('execPlanTable');
                    var execPlanDetailsForm = document.getElementById('TemplateParametersEntryForm');
                    var reviewPGTable = document.getElementById('execPlanTableReview');
                    var viewModelOfReviewPG = ko.dataFor(reviewPGTable);
                    var viewModelOfExecTemplateDetails = ko.dataFor(execPlanDetailsForm);
                    var viewModelOfExecPlan = ko.dataFor(tableElement);
                    var tableDataObject = viewModelOfExecPlan.tableDataObject();
                    var customPhases = new Array();

                    for (var i = 0; i < tableDataObject.length; i++) {
                        var phaseData = tableDataObject[i];
                        var phaseTypeSeeded = phaseData.attr.isSeeded;
                        if (!phaseTypeSeeded) {
                            var taskChildren = phaseData.children;
                            if (taskChildren !== null && taskChildren.length > 0 && i > 0) {
                                var customPhase = new Object();
                                customPhase.predecessorId = tableDataObject[i - 1].attr.id;
                                var tasks = new Array();
                                customPhase.tasks = tasks;
                                for (var j = 0; j < taskChildren.length; j++) {
                                    tasks.push(taskChildren[j].attr._taskIDForSubmit);
                                }
                                customPhases.push(customPhase);
                            }
                        }
                    }

                    var postData = new Object();
                    postData.templateName = viewModelOfExecTemplateDetails.executionPlanNameEntered();
                    postData.description = viewModelOfExecTemplateDetails.executionPlanDescriptionEntered();
                    postData.jobType = viewModelOfExecTemplateDetails.executionPlanTemplateSelected();
                    postData.customPhases = customPhases;
                    var requestBodyJSON = JSON.stringify(postData);

                    console.log('Request Body JSON --' + requestBodyJSON);
                    viewModelOfReviewPG.submitExecutionPlan(requestBodyJSON, postData.templateName);

                };


            }

            return ExecutionFrameworkTemplateViewModel;
        });
