/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * envDetails module
 */
define(['ojs/ojcore', 'knockout', 'ebs/popup/popupHelper', 'ebs/actions/actionsHelper',
    'ebs/navigation/pageNavigationHelper', 'ebs/constants', 'ebs/utils/dateTimeHelper',
    'ojs/ojarraydataprovider', 'ebs/utils/lcmUtils', 'ojs/ojmodule-element-utils', 'jquery',
    'ojs/ojknockout', 'ojs/ojdialog', 'ojs/ojlistview', 'ojs/ojmenu',
    'ojs/ojmodule', 'ojs/ojrouter', 'ojs/ojnavigationlist', 'ojs/ojformlayout',
    'ojs/ojjsontreedatasource', 'text', 'ojs/ojpopup', 'ojs/ojinputtext', 'ojs/ojbutton', 'ojs/ojcollapsible'
], function (oj, ko, popupHelper, actionsHelper, pageNavigationHelper,
        constants, dateTimeHelper, ArrayDataProvider, lcmUtils, ModuleElementUtils) {
    /**
     * The view model for the main content view template
     */
    function environmentDetailsContentViewModel() {
        var self = this;
        self.ebsCompartment = ko.observable('');

        // Variable to hold true if data came from REST else false
        self.environmentDataAvailable = ko.observable(true);
        self.ModuleElementUtils = ModuleElementUtils;

        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        var envName = rootViewModel.currentEnvName();
        if (envName)
        {
            sessionStorage.setItem('lastVisitedEnvName', envName);
        } else
        {
            envName = sessionStorage.getItem('lastVisitedEnvName');
            rootViewModel.currentEnvName(envName);
        }

        self.isStandbyEnv = rootViewModel.isStandbyEnv();
        if (typeof self.isStandbyEnv === 'undefined')
        {
            self.isStandbyEnv = ("true" === sessionStorage.getItem('isLastVisitedEnvStandby'));
            rootViewModel.isStandbyEnv(self.isStandbyEnv);
        } else
        {
            sessionStorage.setItem('isLastVisitedEnvStandby', self.isStandbyEnv);
        }

        self.lastVisitedTab = sessionStorage.getItem('lastVisitedDetailTab');
        sessionStorage.removeItem('lastVisitedDetailTab');

        var isAdministrationTabDisabled = rootViewModel.disableAdministrationTabForEnvionment();
        var currentState = oj.Router.rootInstance.currentState();
        var globalChildRouter = currentState._router._childRouters[0];
        var childRouterName = globalChildRouter.states[0].id;
        var envOverviewRouter = globalChildRouter.states[0].id;
        var envAdminRouter = globalChildRouter.states[1].id;
        var envActRouter = globalChildRouter.states[2].id;
        var standbySyncRouter = globalChildRouter.states[3].id;
        self.childRouterKO = ko.observable(childRouterName);
        var prevNavItem = (self.lastVisitedTab !== null) ? self.lastVisitedTab : rootViewModel.prevEnvDetailsNavItem();
        if (prevNavItem === constants.navModules.envAdministrationModule) {
            self.selection = ko.observable(constants.navModules.envAdministrationModule);
            self.childRouterKO = ko.observable(envAdminRouter);
            // As of now, we will land in this condition only if we come from back button click on the
            // provision environment flow.
            rootViewModel.prevEnvDetailsNavItem('');
        } else if (prevNavItem === constants.navModules.envSpecificActivitiesModule) {
            self.selection = ko.observable(constants.navModules.envSpecificActivitiesModule);
            self.childRouterKO = ko.observable(envActRouter);
            rootViewModel.prevEnvDetailsNavItem('');
        } else if (prevNavItem === constants.navModules.envSpecificActivitiesModule) {
            self.selection = ko.observable(constants.navModules.envSpecificActivitiesModule);
            self.childRouterKO = ko.observable(envActRouter);
            rootViewModel.prevEnvDetailsNavItem('');
        } else if (prevNavItem === constants.navModules.standbyEnvSyncDetailsModule) {
            self.selection = ko.observable(constants.navModules.standbyEnvSyncDetailsModule);
            self.childRouterKO = ko.observable(standbySyncRouter);
            rootViewModel.prevEnvDetailsNavItem('');
        } else {
            self.selection = ko.observable(constants.navModules.envOverviewModule);
            self.childRouterKO = ko.observable(envOverviewRouter);
        }

        var serviceType;
        var psuName;
//        self.envName = ko.observable(envName);
        self.tracker = ko.observable();

        self.logFileContents = ko.observable();
        self.webEntryType = ko.observable();
        self.isLoading = ko.observable();
        self.noLogFileFound = ko.observable(false);

        self.walletPassword = ko.observable('');
        self.weblogicPassword = ko.observable('');
        self.dbTierStageDirectory = ko.observable('');
        self.appTierStageDirectory = ko.observable('');
        self.bkpEncryptionPwd = ko.observable('');
        self.bkpUniqueId = ko.observable('');
        self.confirmDeleteMsg = ko.observable(oj.Translations.getTranslatedString("confirmPopup.deleteAssertMsg", {envName: envName}));
        self.envDetailsLoaded = ko.observable(false);
        self.psuListLoaded = ko.observable(false);
        self.availablePatchesText = ko.observable(oj.Translations.getTranslatedString("labels.availablePatches"));
        self.dbPatchingInProgressText = ko.observable(oj.Translations.getTranslatedString("labels.patchingInProgress"));

        self.confirmPrecheckMsg = ko.observable('');
        self.confirmPatchMsg = ko.observable('');
        self.patchingSupported = ko.observable(true);
        self.patchingUnavailableText = ko.observable('');
        self.renderDatabasePatchingSection = ko.observable('false');

        self.appsLogicalHostConfigured = ko.observable(false);
        self.dbLogicalHostConfigured = ko.observable(false);

        self.allowedLCMActivities_env = ko.observableArray([]);

        self.singleVM = rootViewModel.disableAdministrationTabForEnvionment();


        var rootViewModel = ko.dataFor(document.getElementById('mainContent'));
        rootViewModel.showContextHeader(true);
        rootViewModel.currentPageHeader(envName);
        self.allowClone = ko.observable(false);
        self.allowBackup = ko.observable(false);
        self.allowDelete = ko.observable(false);
        self.allowReleaseStandby = ko.observable(false);

        self.noneBackupPolicyText = oj.Translations.getTranslatedString('labels.noneLabel');
        self.backupPolicyName = ko.observable('');
        self.backupPolicyId = ko.observable();

        self.isBackupPolicyAssigned = ko.computed(function ()
        {
            if (self.backupPolicyName() && self.backupPolicyName() !== '')
                return true;
            return false;
        });

        //Sprint4: bypass LCM activity for assign/unassign policy
        self.allowScheduleBackup = ko.observable(false);
        /*self.allowScheduleBackup =  ko.computed(function()
         {
         if(self.isBackupPolicyAssigned()) return false;
         return true;
         });*/
        self.allowCancelScheduledBackup = ko.observable(false);
        /*self.allowCancelScheduledBackup =  ko.computed(function()
         {
         if(!self.isBackupPolicyAssigned()) return false;
         return true;
         });*/

        self.disableClone = ko.computed(function ()
        {
            if (self.allowClone())
                return false;
            return true;
        });
        self.disableBackup = ko.computed(function ()
        {
            if (self.allowBackup())
                return false;
            return true;
        });
        self.disableDelete = ko.computed(function ()
        {
            if (self.allowDelete())
                return false;
            return true;
        });
        self.disableScheduleBackup = ko.computed(function ()
        {
            if (self.allowScheduleBackup())
                return false;
            return true;
        });
        self.disableCancelScheduledBackup = ko.computed(function ()
        {
            if (self.allowCancelScheduledBackup())
                return false;
            return true;
        });
        self.disableReleaseStandby = ko.computed(function ()
        {
            if (self.allowReleaseStandby())
                return false;
            return true;
        });
        self.disableMoreAction = ko.computed(function () {
            return true;
        });

        var currentDBVersion = rootViewModel.currentDbVersion();
        self.envActionsMenuItems = [
            {id: constants.contextMenu.clone, label: oj.Translations.getTranslatedString('contextMenu.clone'), disabled: self.disableClone},
            {id: constants.contextMenu.backup, label: oj.Translations.getTranslatedString('contextMenu.backup'), disabled: self.disableBackup},
            {id: constants.contextMenu.delete, label: oj.Translations.getTranslatedString('contextMenu.delete'), disabled: self.disableDelete}
            //   {id: constants.contextMenu.scheduleBackup, label: oj.Translations.getTranslatedString('contextMenu.scheduleBackup'), disabled: self.disableScheduleBackup},
            //   {id: constants.contextMenu.cancelScheduledBackup, label: oj.Translations.getTranslatedString('contextMenu.cancelScheduledBackup'), disabled: self.disableCancelScheduledBackup}
        ];

        self.setupMenuOptions = function (event) {
            document.getElementById(event.target.id).refresh();
            event.detail.originalEvent.stopPropagation();
        };

        self.prevPage = ko.observable(oj.Translations.getTranslatedString('pageHeader.envListPageHeader'));
        self.envType = ko.observable('');
        self.standbyType = ko.observable("standby");

        self.displayForStandby = ko.computed(function ()
        {
            return self.isStandbyEnv === true ? '' : 'none';
        });
        self.displayForNonStandby = ko.computed(function ()
        {
            return self.isStandbyEnv === true ? 'none' : '';
        });
        self.buildNavListData = function () {
            console.log('Building Navigation Data.. Is Admin Tab Disabled -> ' + isAdministrationTabDisabled);
            var jsonData = [];
            globalChildRouter.states.forEach(function (state) {
                if ((isAdministrationTabDisabled || self.isStandbyEnv) && state.id === "environmentAdministration_oci")
                {
                    // Do nothing.
                } else if (!self.isStandbyEnv && state.id === "standbyEnvSyncDetails")
                {
                    // Do not add 
                } else
                {
                    jsonData.push({
                        'attr': {
                            id: state.id,
                            label: state.label,
                            href: "?root=" + state.id
                        }
                    });
                }
            });
            return jsonData;
        };

        self.navListData = new oj.JsonTreeDataSource(self.buildNavListData());

        var defaultNavItem = (self.lastVisitedTab && self.lastVisitedTab !== '') ? self.lastVisitedTab : 'Overview';

        self.selectedNavItem = ko.observable(defaultNavItem);
        self.networkProfileName = ko.observable();

        self.numBackups = ko.observable('0');
        self.numSnapshots = ko.observable('0');
        self.loginPage = ko.observable(envName + " Login Page");
        self.loginURL = ko.observable();
        self.ebsVersion = ko.observable();
        self.createdOn = ko.observable();
        self.provStatus = ko.observable();
        self.dbNodes = ko.observable('-');
        self.ocpus = ko.observable();
        self.version = ko.observable();
        self.dbSystemName = ko.observable();
        self.dbServiceDetails = ko.observable();
        self.totalMemValue = ko.observable();
        self.totalMemUnits = ko.observable();
        self.appNodes = ko.observable('-');
        self.dbOn = ko.observable();
        self.lbaas = ko.observable();
        self.lbaasIP = ko.observable();
        self.adName = ko.observable();
        self.envName = ko.observable(envName);
        self.ebsBase = ko.observable();

        self.appsFileSystemMode = ko.observable();
        self.ociInstanceOCID = ko.observable();
        self.dbName = ko.observable();

        self.dbVersion = ko.observable();
        self.sqlnetPort = ko.observable();
        self.dbShape = ko.observable();
        self.dbEdition = ko.observable();

        self.dbCreatedOn = ko.observable();
        self.clusterName = ko.observable();
        self.pdbName = ko.observable();
        self.oracleHomeLocation = ko.observable();
        self.dbPSULevel = ko.observable();
        self.patchLevelTimeStamp = ko.observable();
        self.cloudManagerVersion = ko.observable();
        self.dbDiskRedundancy = ko.observable();


        self.totalStorageValue = ko.observable();
        self.totalStorageUnits = ko.observable();
        self.appTierNodes = ko.observableArray();
        self.dbTierNodes = ko.observableArray();
        self.isTdeEnabled = ko.observable('true');

        self.psuList = ko.observableArray();
        self.datasourceForPSU = new oj.ArrayTableDataSource(self.psuList, {idAttribute: 'patchId'});
        self.PSUDataSource = ko.observable();
        self.dbPatchingInProgress = ko.observable(false);
        self.selectedPSUListItem = ko.observable();

        self.snapShotMenuItems = [{id: 'Delete', label: 'Delete', disabled: false}];
        self.patchingMenuItems = [
            {id: 'precheck', label: 'Precheck', disabled: false},
            {id: 'patch', label: 'Patch', disabled: false}
        ];
        self.listDataForBackups = ko.observableArray();
        self.datasourceForBackups = new oj.ArrayTableDataSource(self.listDataForBackups, {idAttribute: 'name'});
        self.listDataForSnapshots = ko.observableArray();
        self.datasourceForSnapshots = new oj.ArrayTableDataSource(self.listDataForSnapshots, {idAttribute: 'name'});

        //env last activity
        self.envLastActivityClickable = ko.observable("none");
        self.envLastActivitytext = ko.observable("none");
        self.envLastActivityDisplay = ko.observable("none");
        self.envActivityCloudManagerVersion = ko.observable();
        self.envLastActivityLabel = ko.observable(oj.Translations.getTranslatedString('labels.lastActivityStatus'));
        self.envLastActivityName = ko.observable();
        self.envLastActivityStatus = ko.observable();
        self.envJobId = ko.observable();

        //standby sync details
        self.lastRetrievedTimestamp = ko.observable();
        self.rsyncStatus = ko.observable();
        self.lastRsyncTime = ko.observable();
        self.totalSyncedFileCount = ko.observable();
        self.createdFileCount = ko.observable(0);
        self.deletedFileCount = ko.observable(0);
        self.dbRole = ko.observable();
        self.dbUniqueName = ko.observable();
        self.dbOpenMode = ko.observable();
        self.dgStatus = ko.observable();
        self.lastSeqInPrimary = ko.observable();
        self.lastSeqInStandby = ko.observable();
        self.redoLogAppliedTime = ko.observable();
        self.lastTransportLag = ko.observable();
        self.lastApplyLag = ko.observable();
        self.protectionMode = ko.observable();
        self.standbyApplyStatus = ko.observable();
        self.syncDetailsLoaded = ko.observable(false);
        self.syncStatus = ko.observable();


        self.gotoEnvJobDetails = function () {
            console.log("details for job " + self.envJobId());
            oj.Router.rootInstance.store(self.envJobId());
            rootViewModel.activityDetailsParentPage(constants.navModules.envDetailsModule);
            var context = ko.contextFor(document.getElementById('envDetailsPageTopDiv'));
            pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, '', false);
        };


        //zone support
        self.zones = ko.observableArray();
        self.zonesDetail = new ArrayDataProvider(self.zones, {keyAttributes: 'zoneName'});

        self.envActionsHandler = function (event, ui) {
            //var actionTriggered = event.currentTarget.id;
            var actionTriggered = event.target.id;
            console.log('Env name --' + envName + ' Action Triggered --' + actionTriggered);
            if (envName !== null && envName !== '' && actionTriggered === 'delete') {
                console.log('Triggering actions..');
                var popup = document.querySelector(constants.divTags.envListDelPopupTag);
                popup.open(event.target);
            } else if (envName !== null && envName !== '' && actionTriggered === 'clone') {
                console.log('Triggering clone action..');
                rootViewModel.cloneSourceEnv(envName);
                var context = ko.contextFor(document.getElementById('envDetailsPageTopDiv'));
                pageNavigationHelper.navigateToPage(context, constants.navModules.volumeCloneTrainModule, '');
            } else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.backup) {
                var viewModelOfPopupModule = ko.dataFor(document.getElementById('backupPopupRoot'));
                viewModelOfPopupModule.handleBackupMenuClickEvent(envName, self.ebsVersion(), event, ui);
            } else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.scheduleBackup) {
                var viewModelOfPopupModule = ko.dataFor(document.getElementById('backupPopupRoot'));
                viewModelOfPopupModule.handleScheduleBackupMenuClickEvent(envName, self.ebsVersion(), event, ui);
            } else if (envName !== null && envName !== '' && actionTriggered === constants.contextMenu.releaseStandByEnvironment) {
                rootViewModel.standByEnvironmentName(envName);
                rootViewModel.showCloneWlsAdminPwd(self.ebsVersion() === constants.ebsVersions.twelveone ? 'No' : 'Yes'); // using the same root variable name to determine if we need to show wls pwd field.
                var context = ko.contextFor(document.getElementById('envDetailsPageTopDiv'));
                pageNavigationHelper.navigateToPage(context, constants.navModules.releaseStandByEnvironmentTrainModule, '', false);
            } else if (envName !== null && envName !== '' && actionTriggered === 'lcmTask') {
                var viewModelofTaskEntryForm = ko.dataFor(document.getElementById('taskParametersEntryForm'));
                if (envName === 'tstcmptde1')
                    viewModelofTaskEntryForm.openTaskParametersFormDialogForDetailsPG('executionPlan-create-ebs121-db11204-Template1');
                else
                    viewModelofTaskEntryForm.openTaskParametersFormDialogForDetailsPG('executionPlan-create-ebs121-db11204-Template2');
            }

        };

        self.handleAssignBackupPolicyClick = function (event, ui)
        {
            var viewModelOfPopupModule = ko.dataFor(document.getElementById('backupPopupRoot'));
            viewModelOfPopupModule.handleScheduleBackupMenuClickEvent(envName, self.ebsVersion(), event, ui);
        };

        self.handleUnassignBackupPolicyClick = function (event, ui)
        {
            var popup = document.getElementById('confirmUnassignPolicyPopup');
            popup.open(event.target);
        };

        self.confirmUnassignPolicyPopupTitle = ko.observable(oj.Translations.getTranslatedString('confirmPopup.confirmUnassignPolicyPopupTitle', {envName: envName}));
        self.confirmUnassignPolicyMsg = ko.observable(oj.Translations.getTranslatedString('confirmPopup.confirmUnassignPolicyMsg', {envName: envName}));
        self.disableUnassignPopupBtn = ko.observable(false);
        self.showUnassignPolicyProgressBar = ko.observable("none");


        self.closeUnassignPolicyPopup = function (event, ui)
        {
            var popup = document.getElementById('confirmUnassignPolicyPopup');
            popup.close();
        };


        self.confirmUnassignPolicyPopupTitle = ko.observable(oj.Translations.getTranslatedString('confirmPopup.confirmUnassignPolicyPopupTitle', {envName: envName}));
        self.confirmUnassignPolicyMsg = ko.observable(oj.Translations.getTranslatedString('confirmPopup.confirmUnassignPolicyMsg', {envName: envName}));
        self.disableUnassignPopupBtn = ko.observable(false);
        self.showUnassignPolicyProgressBar = ko.observable("none");

        self.handleUnassignPolicy = function (event, ui)
        {
            var envName = rootViewModel.currentEnvName();
            console.log('Submitting unassign policy ..');
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.unassignBackupPolicyInfoMsg", {envName: envName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.confirmUnassignPolicyPopupTitle", {envName: envName});
            popupHelper.openInfoMsg(constants.divTags.envListConfPopupTag, infoMsg, msgOrigin);

            self.closeUnassignPolicyPopup();
            actionsHelper.unScheduleBackupForEnv(envName, function (error, success) {
                if (error === null) {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.unassignBackupPolicyConfirmMsg", {envName: envName});
                    //self.deleteThisNodeFromListView(rootViewModel.currentAppNodeNameForDelete);
                    popupHelper.openSuccessMsg(constants.divTags.envListConfPopupTag, successMsg, msgOrigin);
                    self.getPolicyDetailForEnv(envName);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.envListConfPopupTag, response.message, msgOrigin);
                    self.getPolicyDetailForEnv(envName);
                }
            });
        };

        self.closeUnassignPolicyPopup = function (event, ui)
        {
            var popup = document.getElementById('confirmUnassignPolicyPopup');
            popup.close();
        };


        self.moreActionsHandler = function (event, ui) {
        };

        self.patchingActionsHandler = function (event, ui) {
            var localPSUName = self.selectedPSUListItem()[0];
            psuName = localPSUName ? localPSUName : psuName;
            var actionTriggered = event.currentTarget.id;
            console.log('Env name --' + envName + ' Action Triggered --' + actionTriggered);
            if (actionTriggered === 'precheck') {
                self.confirmPrecheckMsg(oj.Translations.getTranslatedString("confirmPopup.precheckPatchMsg", {psuName: psuName}));
                var popup = document.querySelector(constants.divTags.precheckPatchConfModalTag);
                popup.open(event.target);
            } else if (actionTriggered === 'patch') {
                self.confirmPatchMsg(oj.Translations.getTranslatedString("confirmPopup.patchApplyMsg", {psuName: psuName}));
                var popup = document.querySelector(constants.divTags.patchApplyConfModalTag);
                popup.open(event.target);
            }
            self.selectedPSUListItem([]);
        };

        self.PSUSelectionChanged = function (event, ui) {
            var currentPSUName = self.selectedPSUListItem()[0];
            psuName = currentPSUName ? currentPSUName : psuName;
        };

        self.selectHandler = function (event)
        {
            if ('menu' === event.target.id && event.detail.originalEvent)
            {
                // router takes care of changing the selection
                event.preventDefault();
                self.selection(event.detail.key);
                self.childRouterKO(event.detail.key);
            }
        };

        self.appTierDataSource = new oj.ArrayTableDataSource(
                self.appTierNodes,
                {idAttribute: 'appTierName'}

        );

        self.dbTierDataSource = new oj.ArrayTableDataSource(
                self.dbTierNodes,
                {idAttribute: 'dbTierName'}

        );

        self.handleBackLink = function (event, ui) {
            var context = ko.contextFor(document.getElementById(constants.divTags.envDetailsPageTopDiv));
            var toModule;
            var needCleanup = true;
            if (self.prevPage() === oj.Translations.getTranslatedString('pageHeader.envAdminPageHeader')) {
                needCleanup = false;
                toModule = constants.navModules.envDetailsModule;
                rootViewModel.prevEnvDetailsNavItem(constants.navModules.envAdministrationModule);
            } else if (self.prevPage() === oj.Translations.getTranslatedString('pageHeader.discovery')) {
                toModule = constants.navModules.discoveryModule;
            } else {
                toModule = constants.navModules.envListModule;
            }
            if (needCleanup)
            {
                // Clear off global variables before going back to environments list PG.
                // These were set when we came from list page to details pg.
                pageNavigationHelper.clearGlobalVariablesBeforeNavigationToEnvListPG(rootViewModel);
            }
            pageNavigationHelper.navigateToPage(context, toModule, toModule);
        };

        self.createOjbStorageBkp = function (event, ui) {
            var popup = document.querySelector('#objStorageBackup');
            var trackerObj = self.tracker();
            trackerObj.showMessages();
            if (trackerObj.focusOnFirstInvalid()) {
                return;
            } else {
                //Invoke REST API to create object storage
                console.log("creating object storage backup for env " + envName);
                popup.close();
            }
        };

        self.gotoJobDetails = function (psu, event) {
            var jobId = psu.lastPrecheckJobId;
            self.isLoading(true);
            actionsHelper.getJobLogFile(jobId, function (error, jobLog) {
                if (error === '') {
                    self.logFileContents(jobLog);
                } else {
                    self.noLogFileFound(true);
                }
                self.isLoading(false);
            });
            var popup = document.querySelector(constants.divTags.precheckLogPopup);
            popup.open(event.target);
        };

        self.closeConfirmDeletePopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.envListDelPopupTag);
            self.tracker('');
            popup.close();
        };

        self.closePrecheckPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.precheckLogPopup);
            self.tracker('');
            popup.close();
        };

        self.closeConfirmPatchPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.patchApplyConfModalTag);
            self.tracker('');
            popup.close();
        };

        self.closeConfirmPrecheckPopup = function (event, ui) {
            var popup = document.querySelector(constants.divTags.precheckPatchConfModalTag);
            self.tracker('');
            popup.close();
        };


        self.startAnimationListener = function (event, ui)
        {
            popupHelper.startAnimationListener(constants.divTags.envDetailsConfPopupTag, event, ui);
        };

        self.confirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.envDetailsConfPopupTag, data, event);
        };

        self.startPatchingPopupAnimationListener = function (event, ui)
        {
            popupHelper.startAnimationListener(constants.divTags.envPatchingPopup, event, ui);
        };

        self.patchingConfirmationPopupCloseHandler = function (data, event) {
            popupHelper.confmPopuCloseHandler(constants.divTags.envPatchingPopup, data, event);
        };

        self.deleteEnv = function () {
            var popup = document.querySelector(constants.divTags.envListDelPopupTag);
            popup.close();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.deleteInfoMsg", {'envName': envName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.delEnvTitle");
            popupHelper.openInfoMsg(constants.divTags.envDetailsConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.deleteEnv(envName, self.dbOn(), function (error, success) {
                if (error === null) {
                    var context = ko.contextFor(document.getElementById(constants.divTags.envDetailsPageTopDiv));
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.deleteConfirmMsg", {'envName': envName});
                    rootViewModel.displayPopupId(constants.divTags.envDetailsConfPopupTag);
                    popupHelper.setSuccessPopupMsg(successMsg, msgOrigin);
                    // Clear off global variables before going back to environments list PG.
                    // These were set when we came from list page to details pg.
                    pageNavigationHelper.clearGlobalVariablesBeforeNavigationToEnvListPG(rootViewModel);
                    pageNavigationHelper.navigateToPage(context, constants.navModules.envListModule, constants.navModules.envListModule);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.envDetailsConfPopupTag, response.message, msgOrigin);
                }
            }, self.envType());
        };

        self.precheckPatch = function () {

            var popup = document.querySelector(constants.divTags.precheckPatchConfModalTag);
            popup.close();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.precheckPatchInfoMsg", {'psuName': psuName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.patchEnvTitle");
            popupHelper.openInfoMsg(constants.divTags.envPatchingPopup, infoMsg, msgOrigin);
            actionsHelper.precheckPSU(envName, serviceType, psuName, function (error, success) {
                if (error === '') {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.precheckPatchSuccessMsg", {'psuName': psuName});
                    popupHelper.setSuccessPopupMsg(successMsg, msgOrigin);
                    popupHelper.openSuccessMsg(constants.divTags.envPatchingPopup, successMsg, msgOrigin);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.envPatchingPopup, response.message, msgOrigin);
                }
            });
        };

        self.drillDownToNetworkProfile = function (event)
        {
            var selectedNtwkProfileName = self.networkProfileName();
            if (selectedNtwkProfileName === '' || selectedNtwkProfileName === null || selectedNtwkProfileName === "Loading..." || selectedNtwkProfileName === "loading...")
            {
                return;
            }
            var viewModelOfPopupModule = ko.dataFor(document.getElementById('networkProfileDetailRoot'));
            viewModelOfPopupModule.popupOpen(self.networkProfileName(), event);
        };

        self.applyPatch = function () {

            var popup = document.querySelector(constants.divTags.patchApplyConfModalTag);
            popup.close();
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.patchApplyInfoMsg", {'psuName': psuName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.patchEnvTitle");
            popupHelper.openInfoMsg(constants.divTags.envPatchingPopup, infoMsg, msgOrigin);
            actionsHelper.applyPSU(envName, serviceType, psuName, function (error, success) {
                if (error === '') {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.patchApplySuccessMsg", {'psuName': psuName});
                    popupHelper.setSuccessPopupMsg(successMsg, msgOrigin);
                    popupHelper.openSuccessMsg(constants.divTags.envPatchingPopup, successMsg, msgOrigin);
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.envPatchingPopup, response.message, msgOrigin);
                }
            });
        };

        self.showDeleteNodePopup = function (event, ui) {
            console.log('Event --' + event);
            rootViewModel.currentAppNodeNameForDelete = '';
            var nameOfAppNode = '';
            if (event !== null && typeof (event.target) !== 'undefined' && typeof (event.target.id) !== 'undefined')
            {
                nameOfAppNode = event.target.id.substring(10);
            } else
            {
                return;
            }
            rootViewModel.currentAppNodeNameForDelete = nameOfAppNode;
            //     var popup = document.querySelector(constants.divTags.deleteNodeConfirmationPopupTag);
            //     popup.close();
            var viewModelOfDeleteNodePopupModule = ko.dataFor(document.getElementById('deleteNodePopupRoot'));
            viewModelOfDeleteNodePopupModule.resetPopup();
            //check ebs version
            var envDetailViewModule = ko.dataFor(document.getElementById('envDetailsPageTopDiv'));
            if (constants.ebsVersions.twelveone === envDetailViewModule.ebsVersion())
            {
                viewModelOfDeleteNodePopupModule.showWlsAdminPwd(false);
            } else
            {
                viewModelOfDeleteNodePopupModule.showWlsAdminPwd(true);
            }

            //check if this is last node in a zone
            var zonesData = self.zones();
            var isLastZoneWithLBaaS = false;
            var isLastNodeOfZone = false;
            var parentZone = '';
            if (zonesData)
            {
                $.each(zonesData, function () {
                    var zone = this;
                    var nodes = zone.zoneNodes.data;
                    //const matches = nodes.filter(node => node.nodeName === nameOfAppNode);
                    const matches = nodes.filter(function (node) {
                        return (node.nodeName === nameOfAppNode);
                    });
                    if (matches && matches.length > 0)
                    {
                        parentZone = zone.zoneName;
                        if (nodes.length === 1)
                        {
                            isLastNodeOfZone = true;
                        }
                        if ((nodes.length === 1) && (constants.webEntryTypeLookups.NewLBaaS === zone.webEntryType))
                        {
                            //find the parent zone of the deleted node
                            isLastZoneWithLBaaS = true;
                        }
                        return false; //break the loop
                    }
                });
            }
            viewModelOfDeleteNodePopupModule.zoneName(parentZone);
            if (isLastNodeOfZone)
                viewModelOfDeleteNodePopupModule.displayWarnMessage(true);
            else
                viewModelOfDeleteNodePopupModule.displayWarnMessage(false);
            if (isLastZoneWithLBaaS)
                viewModelOfDeleteNodePopupModule.displayRemoveLBaaS(true);
            else
                viewModelOfDeleteNodePopupModule.displayRemoveLBaaS(false);
            viewModelOfDeleteNodePopupModule.openPopup(event, ui);
            console.log('Opened the Delete Nodepopup!');

        };

        self.showBackupPolicyDetail = function (viewModel, event)
        {
            var viewModelOfPolicyDetailPopup = ko.dataFor(document.getElementById('PolicyDetailPopupRoot'));
            viewModelOfPolicyDetailPopup.openPopup(envName, self.backupPolicyName(), self.backupPolicyId(), 'backup', event);
        };

        self.getShortOCID = function (value)
        {
            if (!value || value === '')
                return constants.logicalHost.notAvailable;
            if (value && value.length > 6)
                return "..." + value.substring(value.length - 6);
            else
                return value;
        };

        self.getPolicyDetailForEnv = function (envName)
        {
            actionsHelper.getEnvironmentPolicySummary(envName, function (error2, policyList)
            {
                if (error2 === '') {
                    $.each(policyList, function () {
                        var policy = this;
                        if ('create-ossbackup' === policy.jobType)
                        {
                            self.backupPolicyName(policy.name);
                            self.backupPolicyId(policy.id);
                            return false; //only expect one backup policy
                        }
                    });
                }
            });
        };

        self.toggleAppsNodeOCID = function (ui, event)
        {
            var nameOfAppNode = '';
            if (event !== null && typeof (event.target) !== 'undefined' && typeof (event.target.id) !== 'undefined')
            {
                nameOfAppNode = event.target.id.substring(11);
            } else
            {
                return;
            }

            var zonesData = self.zones();
            if (zonesData)
            {
                $.each(zonesData, function () {
                    var zone = this;
                    var nodes = zone.zoneNodes.data;
                    //const matches = nodes.filter(node => node.nodeName === nameOfAppNode);
                    const matches = nodes.filter(function (node) {
                        return (node.nodeName === nameOfAppNode);
                    });
                    if (matches && matches.length > 0)
                    {
                        if (matches[0].appNodeOCIDShown())
                            matches[0].appNodeOCIDShown(false);
                        else
                            matches[0].appNodeOCIDShown(true);

                        return false; //break the loop
                    }
                });
            }

        };

        self.copyOCIDValue = function (ui, event)
        {
            var nameOfAppNode = '';
            if (event !== null && typeof (event.target) !== 'undefined' && typeof (event.target.id) !== 'undefined')
            {
                nameOfAppNode = event.target.id.substring(9);
            } else
            {
                return;
            }

            var OCIDValue = null;
            var zonesData = self.zones();
            if (zonesData)
            {
                $.each(zonesData, function () {
                    var zone = this;
                    var nodes = zone.zoneNodes.data;
                    //const matches = nodes.filter(node => node.nodeName === nameOfAppNode);
                    const matches = nodes.filter(function (node) {
                        return (node.nodeName === nameOfAppNode);
                    });
                    if (matches && matches.length > 0)
                    {
                        OCIDValue = matches[0].ociInstanceOCID;

                        return false; //break the loop
                    }
                });
            }

            if (OCIDValue != null)
            {
                var textArea = document.createElement("TextArea");
                textArea.value = OCIDValue;
                document.body.appendChild(textArea);
                textArea.select();
                var range = document.createRange();
                range.selectNodeContents(textArea);
                window.getSelection().addRange(range);
                document.execCommand("copy");
                window.getSelection().removeRange(range);
                textArea.remove();
            }

        };

        //breadcrumb handling
        if (rootViewModel.envDetailsParentPage() !== '') {
            var fromPage = rootViewModel.envDetailsParentPage();
            if (fromPage === constants.navModules.envListModule) {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.envListPageHeader'));
            } else if (fromPage === constants.navModules.envAdministrationModule) {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.envAdminPageHeader'));
            } else if (fromPage === constants.navModules.discoveryModule) {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.discovery'));
            } else {
                self.prevPage(oj.Translations.getTranslatedString('pageHeader.envListPageHeader'));
            }
        }

        //get env policy summary
        self.getPolicyDetailForEnv = function (envName)
        {
            actionsHelper.getEnvironmentPolicySummary(envName, function (error2, policyList)
            {
                if (error2 === '') {
                    var backupPolicyFound = false;
                    if (policyList && Array.isArray(policyList))
                    {
                        $.each(policyList, function () {
                            var policy = this;
                            if ('create-ossbackup' === policy.jobType)
                            {
                                self.backupPolicyName(policy.name);
                                self.backupPolicyId(policy.id);
                                backupPolicyFound = true;
                                return false; //only expect one backup policy
                            }
                        });
                    }
                    if (!backupPolicyFound)
                    {
                        self.backupPolicyName('');
                        self.backupPolicyId('');
                    }
                }
            });
        };

        self.refreshSyncDetails = function (event, ui)
        {
            self.getStandbySyncDetails(envName);
        };

        self.getStandbySyncDetails = function (envName)
        {
            self.syncDetailsLoaded(false);
            actionsHelper.getStandbyEnvSyncDetails(envName, function (error, syncDetails)
            {
                if (error === '') {
                    if (syncDetails)
                    {
                        self.lastRetrievedTimestamp(dateTimeHelper.convertToUTC(syncDetails.timeStamp));

                        if (syncDetails.appTier)
                        {
                            self.rsyncStatus(syncDetails.appTier.rsyncStatus);
                            self.lastRsyncTime(dateTimeHelper.convertToUTC(syncDetails.appTier.lastRsyncTimestamp));
                            self.totalSyncedFileCount(syncDetails.appTier.totalFiles);
                            self.createdFileCount(syncDetails.appTier.createdFiles);
                            self.deletedFileCount(syncDetails.appTier.deletedFiles);
                        }

                        if (syncDetails.dbTier)
                        {
                            self.dbRole(syncDetails.dbTier.databaseRole);
                            self.dbUniqueName(syncDetails.dbTier.databaseUniqueName);
                            self.dbOpenMode(syncDetails.dbTier.databaseOpenMode);
                            self.dgStatus(syncDetails.dbTier.dataguardStatus);
                            self.lastSeqInPrimary(syncDetails.dbTier.lastSequencePrimary);
                            self.lastSeqInStandby(syncDetails.dbTier.lastSequenceStandby);
                            self.redoLogAppliedTime(dateTimeHelper.convertToUTC(syncDetails.dbTier.lastRedoLogApplied));
                            self.lastTransportLag(syncDetails.dbTier.transportLag);
                            self.lastApplyLag(syncDetails.dbTier.applyLag);
                            self.protectionMode(syncDetails.dbTier.protectionMode);
                            self.standbyApplyStatus(syncDetails.dbTier.standbyApplyStatus);
                        }
                    }
                } else
                {
                    //TODO show error msg on the sync details tab
                    if (error.status === 504)
                    {
                        var messageContent = 'Error Message : ' + 'Gateway Time-out Error.';
                        //self.addInlineMessage('error', 'Error in validating discovery request inputs.', messageContent);
                    } else
                    {
                        var errorCode = error.responseJSON.code;
                        if (error.responseJSON.code === null || error.responseJSON.code === '')
                        {
                            errorCode = error.status;
                        }
                        var messageContent = 'Error Message : ' + error.responseJSON.message;
                        //self.addInlineMessage('error', 'Error in validating discovery request inputs.', messageContent);
                    }
                }

                self.syncDetailsLoaded(true);
            });
        };

        actionsHelper.getEnvDetails(envName, function (error, envDetails) {
            if (error === '') {
                self.environmentDataAvailable(true);
                console.log('Getting env details...');
                rootViewModel.showCloneWlsAdminPwd(envDetails.version === '12.1.3' ? 'No' : 'Yes');
                var cloudManagerVersion;
                if (envDetails.cloudManagerVersion === 'PRE18.3.1.') {
                    cloudManagerVersion = 'Pre-18.3.1';
                } else {
                    cloudManagerVersion = envDetails.cloudManagerVersion;
                }

                if (envDetails.type)
                {
                    self.envType(envDetails.type);
                }

                if (envDetails.allowedLCMActivities)
                {
                    self.allowedLCMActivities_env(envDetails.allowedLCMActivities);
                    var lcmActionsEnabled = lcmUtils.getLcmActionsEnabledFromREST(envDetails.allowedLCMActivities);

                    if (lcmActionsEnabled)
                    {
                        self.allowClone(lcmActionsEnabled[constants.contextMenu.clone]);
                        self.allowBackup(lcmActionsEnabled[constants.contextMenu.backup]);
                        self.allowDelete(lcmActionsEnabled[constants.contextMenu.delete]);
                        //Sprint 4: bypass LCM activity for assign policy until REST is ready
                        self.allowScheduleBackup(lcmActionsEnabled[constants.contextMenu.scheduleBackup]);
                        self.allowCancelScheduledBackup(lcmActionsEnabled[constants.contextMenu.cancelScheduledBackup]);
                        self.allowReleaseStandby(lcmActionsEnabled[constants.contextMenu.releaseStandByEnvironment]);

                    }
                }


                self.appsLogicalHostConfigured(envDetails.appTier.logicalHostConfigured);
                self.dbLogicalHostConfigured(envDetails.dbTier.logicalHostConfigured);

                if (envDetails.appTier.groups)
                    self.loginURL(envDetails.appTier.groups[0].webEntry.loginURL);
                self.networkProfileName(envDetails.networkProfile);
                var networkProfileName = envDetails.networkProfile;
                //get compartment information based on network profile
                if (networkProfileName !== '' && networkProfileName !== null)
                {
                    actionsHelper.getNetworkProfileDetails(networkProfileName, function (error1, details)
                    {
                        if (error1 === '') {
                            var ebsCompartment = details.ebsCompartment;
                            if (ebsCompartment && ebsCompartment != null && ebsCompartment !== '')
                            {
                                self.ebsCompartment(ebsCompartment);
                            }
                        }
                    });
                }


                self.getPolicyDetailForEnv(envName);

                if (self.isStandbyEnv)
                {
                    self.syncStatus(envDetails.standbyStatus);
                    self.getStandbySyncDetails(envName);
                }

                var webEntryTypeAttr = envDetails.appTier.groups ? envDetails.appTier.groups[0].webEntry.type : '';
                var reverseLookup = "";
                if (webEntryTypeAttr !== null && webEntryTypeAttr !== '')
                {
                    if (webEntryTypeAttr === 'LBaaS')
                    {
                        reverseLookup = constants.webEntryTypeLookups.NewLBaaS;
                    } else if (webEntryTypeAttr === 'UserLoadBalancer')
                    {
                        reverseLookup = constants.webEntryTypeLookups.UserLoadBalancer;
                        self.lbaasIP('Not Applicable');
                    } else
                    {
                        reverseLookup = constants.webEntryTypeLookups.AppTierWebEntry;
                        self.lbaasIP('Not Applicable');
                    }
                }
                self.webEntryType(reverseLookup);

                self.ebsVersion(envDetails.version);
                self.cloudManagerVersion(cloudManagerVersion);

                //env last activity
                if (envDetails.lastActivity)
                {
                    self.envLastActivityDisplay("");
                    var envCloudManagerVersion = envDetails.lastActivity.cloudManagerVersion;
                    self.envActivityCloudManagerVersion(envCloudManagerVersion);
                    if (envCloudManagerVersion !== null && typeof (envCloudManagerVersion) !== 'undefined' && envCloudManagerVersion !== '' && envCloudManagerVersion !== null)
                    {
                        self.envLastActivityClickable("");
                        self.envLastActivitytext("none");
                    } else {
                        self.envLastActivityClickable("none");
                        self.envLastActivitytext("");
                    }
                    self.envJobId(envDetails.lastActivity.jobId);
                    self.envLastActivityName(envDetails.lastActivity.name);
                    self.envLastActivityStatus(envDetails.lastActivity.status);
                }

                self.createdOn(dateTimeHelper.convertToUTC(envDetails.createdOn));
                self.provStatus('Ready');
                self.dbNodes(envDetails.overview.noOfDBNodes);
                //            self.ocpus(envDetails.overview.summary.ocpus);
                /**
                 * DB Tier details
                 */
                self.dbDiskRedundancy(envDetails.dbTier.diskRedundancy);
                self.dbSystemName(envDetails.dbTier.dbSystemName);
                self.dbOn(envDetails.dbTier.serviceType.value);
                self.dbName(envDetails.dbTier.databaseName);
                self.clusterName((envDetails.dbTier.clusterName && envDetails.dbTier.clusterName !== '') ? envDetails.dbTier.clusterName : constants.logicalHost.notAvailable);
                self.pdbName((envDetails.dbTier.pdbName && envDetails.dbTier.pdbName !== '') ? envDetails.dbTier.pdbName : constants.logicalHost.notAvailable);
                self.dbPSULevel(envDetails.dbTier.patchLevel);
                self.patchLevelTimeStamp(dateTimeHelper.convertToUTC(envDetails.dbTier.patchLevelTimeStamp));
                self.oracleHomeLocation(envDetails.dbTier.oracleHome);

                self.dbVersion(envDetails.dbTier.version);
                self.sqlnetPort(envDetails.dbTier.sqlnetPort);
                self.dbShape(envDetails.dbTier.shape);
                self.dbEdition(envDetails.dbTier.edition);
                self.dbCreatedOn(dateTimeHelper.convertToUTC(envDetails.dbTier.createdOn));


                self.appNodes(envDetails.overview.noOfAppNodes);
                var publicIpValue = envDetails.appTier.groups ? envDetails.appTier.groups[0].webEntry.ipAddress : '';
                if (typeof (publicIpValue) !== 'undefined' && publicIpValue !== '')
                {
                    self.lbaasIP(publicIpValue);
                }
                self.adName(envDetails.availabilityDomain);
                self.ebsBase(envDetails.appTier.baseDirectory);


                if (envDetails.dbTier.serviceType.value === 'exadatadbsystem' && envDetails.dbTier.version === '11.2.0.4') {
                    self.patchingSupported(false);
                    self.patchingUnavailableText(oj.Translations.getTranslatedString("confirmPopup.dbPatchNotAvailableMsg"));
                } else if (envDetails.dbTier.serviceType.value === 'Computeds') {
                    self.patchingSupported(false);
                    self.patchingUnavailableText(oj.Translations.getTranslatedString("confirmPopup.computeDbPatchNotAvailableMsg"));
                }

                //zone support
                var zonesData = [];
                var envOverviewViewModule;
                if (document.getElementById("envOverviewDiv"))
                    envOverviewViewModule = ko.dataFor(document.getElementById("envOverviewDiv"));

                var appsFileSystemValue = "";
                var fileSystemLabel = "";

                if (envDetails.appTier.zones)
                    $.each(envDetails.appTier.zones, function () {
                        var zone = this;
                        var webEntryType = "";
                        var lbaasDetailDisplay = "none";
                        var lbaasName = "";
                        var lbaasListener = "";
                        if (zone.webEntry)
                        {
                            if ('LBaaS' === zone.webEntry.type)
                            {
                                webEntryType = constants.webEntryTypeLookups.NewLBaaS;
                                lbaasDetailDisplay = "";
                                if (zone.webEntry.lbaas)
                                {
                                    if (zone.webEntry.lbaas.name)
                                        lbaasName = zone.webEntry.lbaas.name;
                                    if (zone.webEntry.lbaas.listener)
                                        lbaasListener = zone.webEntry.lbaas.listener;
                                }
                            } else if ('UserLoadBalancer' === zone.webEntry.type)
                            {
                                webEntryType = constants.webEntryTypeLookups.UserLoadBalancer;
                            } else
                            {
                                webEntryType = constants.webEntryTypeLookups.AppTierWebEntry;
                            }
                        }

                        //check for add node allowed
                        var zoneLcmActivities = zone.allowedLCMActivities;
                        var addNodeDisabled = true;
                        if (rootViewModel.lcmActivityFromREST && zoneLcmActivities)
                        {
                            addNodeDisabled = !lcmUtils.isAddNodeAllowedFromREST(zoneLcmActivities);
                        } else
                        {
                            //addNodeDisabled = envDetails.lastActivity? !lcmUtils.isAddNodeAllowedByLastActivity(envDetails.lastActivity) : false;
                        }

                        var nodes = [];
                        if (zone.fileSystemType)
                        {
                            self.appsFileSystemMode(zone.fileSystemType.label);
                            appsFileSystemValue = zone.fileSystemType.value;
                            fileSystemLabel = zone.fileSystemType.label;
                        }

                        if (zone.nodes)
                            $.each(zone.nodes, function () {
                                var node = this;
                                //check for delete node allowed
                                var nodeLcmActivities = node.allowedLCMActivities;
                                var deleteDisabled = true;
                                if (rootViewModel.lcmActivityFromREST && nodeLcmActivities)
                                {
                                    deleteDisabled = !lcmUtils.isDeleteNodeAllowedFromREST(nodeLcmActivities);
                                } else
                                {
                                    //deleteDisabled = envDetails.lastActivity? !lcmUtils.isDeleteNodeAllowedByLastActivity(envDetails.lastActivity, node.lastActivity) : false;
                                }
                                nodes.push({
                                    ociInstanceOCID: node.ociInstanceOCID && node.ociInstanceOCID !== '' ? node.ociInstanceOCID : constants.logicalHost.notAvailable,
                                    ociInstanceNameShort: self.getShortOCID(node.ociInstanceOCID),
                                    appNodeOCIDExist: ko.observable(node.ociInstanceOCID && node.ociInstanceOCID !== ''),
                                    appNodeOCIDShown: ko.observable(false),
                                    toggleOCIDDisplay: self.toggleAppsNodeOCID,
                                    copyOCIDValue: self.copyOCIDValue,
                                    hostname: node.physicalFqdn && node.physicalFqdn !== '' ? node.physicalFqdn : constants.logicalHost.notAvailable,
                                    privateIp: node.privateIp,
                                    publicIP: node.publicIp,
                                    primaryNode: node.primaryNode,
                                    nodeName: node.nodeName,
                                    shape: node.shape,
                                    storageValue: node.volumeSize,
                                    faultDomain: node.faultDomain,
                                    fileSystemType: fileSystemLabel,
                                    fileSystemTypeValue: appsFileSystemValue,
                                    deleteNodeHandler: self.showDeleteNodePopup,
                                    deleteButtonDisabled: deleteDisabled,
                                    allowedLCMActivities_node: nodeLcmActivities,
                                    appsLogicalHostConfigured: self.appsLogicalHostConfigured(),
                                    logicalFQDN: (node.logicalFqdn && node.logicalFqdn !== '') ? node.logicalFqdn : constants.logicalHost.notAvailable
                                });
                            });

                        zonesData.push({
                            zoneName: zone.name,
                            zoneType: zone.type,
                            webEntryType: webEntryType,
                            LBaasDetailDisplay: lbaasDetailDisplay,
                            LBaasName: lbaasName,
                            LBaasListener: lbaasListener,
                            webEntryLoginURL: zone.webEntry ? zone.webEntry.loginURL : "",
                            webEntryLoginPage: envName + " Login Page",
                            webEntryDomain: zone.webEntry ? zone.webEntry.domain : "",
                            webEntryHost: zone.webEntry ? zone.webEntry.host : "",
                            webEntryPort: zone.webEntry ? zone.webEntry.port : "",
                            webEntryProtocol: zone.webEntry ? zone.webEntry.protocol : "",
                            webEntryIPAddress: zone.webEntry ? zone.webEntry.ipAddress : "",
                            zoneNodes: new oj.ArrayTableDataSource(nodes, {idAttribute: 'nodeName'}),
                            addButtonDisabled: addNodeDisabled,
                            appsFileSystemMode: appsFileSystemValue,
                            allowedLCMActivities_zone: zoneLcmActivities
                        });

                        self.zones(zonesData);
                    });

                $.each(envDetails.dbTier.nodes, function () {
                    self.dbTierNodes.push({
                        publicIP: this.publicIp,
                        dbTierName: this.name,
                        hostname: this.physicalFqdn,
                        privateIP: this.privateIp,
                        faultDomain: this.faultDomain,
                        dbLogicalHostConfigured: self.dbLogicalHostConfigured(),
                        dbLogicalFQDN: (this.logicalFqdn && this.logicalFqdn !== '') ? this.logicalFqdn : constants.logicalHost.notAvailable
                    });
                });
                self.envDetailsLoaded(true);
                serviceType = envDetails.dbTier.serviceType.value;
                if (self.renderDatabasePatchingSection() === 'true')
                {
                    actionsHelper.getPSUListForEnv(envName, serviceType, function (error, psuList) {
                        self.dbPatchingInProgress(false);
                        if (error === '') {
                            $.each(psuList, function (index, value) {
                                psuList[index].lastPrecheckDate = dateTimeHelper.convertToUTC(psuList[index].lastPrecheckDate);
                                psuList[index].releaseDate = dateTimeHelper.convertToUTC(psuList[index].releaseDate);
                            });
                            self.psuList(psuList);
                            self.PSUDataSource(self.datasourceForPSU);
                        }
                        self.psuListLoaded(true);
                    });
                }
            } else {
                self.environmentDataAvailable(false);
            }
        }, self.isStandbyEnv);

    }

    return environmentDetailsContentViewModel;

});
