
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants','ebs/utils/scheduleUtils',
    'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojlabelvalue', 'ojs/ojformlayout', 'ojs/ojbootstrap',
    'ojs/ojlabelvalue', 'ojs/ojlabel'], function (oj, ko, actionsHelper, popupHelper, constants,scheduleUtils) {
    function nextScheduleInformationPopupViewModel()
    {
        var self = this;
        console.log('Next Schedule Information Popup View Model Loaded');
        self.informationText = ko.observable(oj.Translations.getTranslatedString("confirmPopup.informationTextMsg"));
        self.nextScheduleInformationPopupTitle = oj.Translations.getTranslatedString("confirmPopup.nextScheduleInformationPopupTitle");
        
        self.schedule1 = ko.observable('');
        self.schedule2 = ko.observable('');
        self.schedule3 = ko.observable('');

        self.displayPopup = function (period, hrOfDay, dayOfWeek, dayOfMonth,month) {
            var next3schedules = null;
            if("EVERY_DAY" === period){
               next3schedules = scheduleUtils.getNext3SchedulesForDailySchedule(hrOfDay);
            }
            else if("EVERY_WEEK" === period){
                  next3schedules = scheduleUtils.getNext3SchedulesForWeeklySchedule(dayOfWeek,hrOfDay);
            }
            else if("EVERY_MONTH" === period){
                next3schedules = scheduleUtils.getNext3SchedulesForMonthlySchedule(dayOfMonth,hrOfDay);
            }
            else if("EVERY_YEAR" === period){
                next3schedules = scheduleUtils.getNext3SchedulesForYearlySchedule(dayOfMonth,hrOfDay,month);
            }
            
            self.schedule1(next3schedules[0]);
            self.schedule2(next3schedules[1]);
            self.schedule3(next3schedules[2]);
              var popup = document.getElementById("nextScheduleInformationPopup");
            popup.open(event.target);
        };
        
        self.popupCloseHandler = function (event, ui)
        {
            var popup = document.getElementById("nextScheduleInformationPopup");
            popup.close();
        };

    }

    return nextScheduleInformationPopupViewModel;
});
