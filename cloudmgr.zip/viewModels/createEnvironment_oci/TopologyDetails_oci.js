/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * AppTierDetails module
 */
define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ojs/ojarraydataprovider','jquery', 'ojs/ojinputtext', 'ojs/ojlistview', 'ojs/ojarraytabledatasource', 'ojs/ojinputnumber', 'ojs/ojbutton', 'ojs/ojlabelvalue','ojs/ojmessages'
], function (oj, ko, constants,ArrayDataProvider) {
    /**
     * The view model for the main content view template
     */
    function AppTierDetailsContentViewModel() {
        var self = this;
        console.log('Loading App Tier Details Content View Model .. ');

        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));

        var trainIdentifier = document.getElementById('train');
        self.isCreateEnvFlow = ko.observable(false);
        self.parentContainerViewModel = ko.observable('');
        self.topologyPageLocalMessage = ko.observable('');
        self.startAppTier  = ko.observable(false);
        self.startAppTierMsg = ko.observable();
        self.startAppTierHandler = function(event, ui)
        {
          var value =  event['detail'].value; 
          if(value)
          {
              var msg = {summary:  oj.Translations.getTranslatedString('helpMsgs.startAppTierInfo'),
                         detail: oj.Translations.getTranslatedString('helpMsgs.startAppTierInfo'), severity: oj.Message.SEVERITY_TYPE.INFO};
              self.startAppTierMsg([msg]);
          }else
          {
              self.startAppTierMsg([]);
          }
        };
        
        /* create-ebs flow */
        if (trainIdentifier !== null)
        {
            self.isCreateEnvFlow(true);
            self.parentContainerViewModel(ko.dataFor(trainIdentifier));
        }

        /* clone flow */
        self.isCloneEnvFlow = ko.observable(false);
        var cloneTrain = document.getElementById(constants.navModules.volumeCloneTrainModule);
        if (cloneTrain !== null)
        {
            self.isCreateEnvFlow(false);
            self.isCloneEnvFlow(true);
            self.parentContainerViewModel(ko.dataFor(cloneTrain));
        }

        /*clone-standby flow */
        var cloneStandByTrain = document.getElementById('cloneStandByEnvironmentTrainElement');
        if (cloneStandByTrain !== null) {
            self.isCreateEnvFlow(true);
            self.parentContainerViewModel(ko.dataFor(cloneStandByTrain));
        }

        /*release-standby flow */
        var releaseStandByTrain = document.getElementById('releaseStandByEnvironmentTrainElement');
        if (releaseStandByTrain !== null) {
            self.isCreateEnvFlow(true);
            self.parentContainerViewModel(ko.dataFor(releaseStandByTrain));
        }

        /* Zone related changes */
        self.zones = ko.observableArray([]);
        self.isAddZoneEnabled = ko.observable(true);
        self.isZoneModuleLoading = ko.observable('No');
        self.zoneModuleName = 'zoneModule';
        self.sequence = ko.observable(0);
        self.showZonesListView = ko.observable(true);
        self.zonesListDataSource = ko.observable();
        self.zonesDataSource = new oj.ArrayTableDataSource(
                self.zones,
                {idAttribute: 'identifier'});
        self.zonesListDataSource(self.zonesDataSource);


        //clone flow
        self.currentZoneName = ko.observable('');
        self.currentZoneType = ko.observable('');
        self.currentZoneAppNodes = ko.observableArray([]);
        

        self.initializeTopologyPage = function () {
            var noOfZones = self.zonesListDataSource().data().length;
            if (noOfZones === 0) {
                self.openZoneDetailModuleForCreate();
            }
        };

        self.openZoneDetailModuleForClone = function (seq)
        {
            if (self.parentContainerViewModel() !== null && self.parentContainerViewModel() !== '')
            {
                self.parentContainerViewModel().disableNextBtn(true);
                self.parentContainerViewModel().disablePrevBtn(true);
            }
            self.showZonesListView(false);
            self.isZoneModuleLoading('Yes');
            var tableDataObject = self.zones();
            if (tableDataObject === null)
            {
                console.log('Error : Could not find the zones table data object.');
                return;
            }

            //before opening the zone detail, pre-populate the current zone info 
            //based on the current zone sequence
            //Important: for clone the sequence number will be derived based on
            //the id of the element, as self.sequence() will be set to the highest
            //index only.
            var zones = self.zones();
            var currZone = zones[seq - 1]; //sequence starts from 1
            if (currZone)
            {
                self.currentZoneName(currZone.name());
                console.log("currZN: " + self.currentZoneName());
                self.currentZoneType(currZone.type());
                self.currentZoneAppNodes(currZone.AppNodesData);
            }

            self.openModule(seq);

        };


        self.editZoneDetails = function (event)
        {
            console.log('Handling zone Edit Event');
            var currentTargetElem = event.currentTarget;
            if (currentTargetElem === null || typeof (currentTargetElem) === 'undefined')
            {
                return;
            } else
            {
                if (self.isCreateEnvFlow())
                {
                    var idOfTargetElement = currentTargetElem.id;
                    var sequenceOfThisRow = idOfTargetElement.split('_')[1];
                    var zonePopupRootElementId = document.getElementById('zoneModuleRoot_' + sequenceOfThisRow);
                    if (zonePopupRootElementId === null)
                    {
                        console.log('Zone Module Element is not found. Something went wrong!');
                    } else
                    {
                        console.log('Editing zone Module...');
                        self.openZoneDetailModuleForEdit(event, sequenceOfThisRow);
                    }
                } else if (self.isCloneEnvFlow())
                {
                    var idOfTargetElement = currentTargetElem.id;
                    var sequenceOfThisRow = parseInt(idOfTargetElement.split('_')[1]);
                    //IMPORTANT: for clone self.sequence() will always be set to the 
                    //highest index of all the rows
                    if(self.sequence() < sequenceOfThisRow)
                    self.sequence(sequenceOfThisRow);
                    self.openZoneDetailModuleForClone(sequenceOfThisRow);
                }
            }
        };

        self.deleteZone = function (event)
        {
            console.log('Handling zone Delete Event');
            var currentTargetElem = event.currentTarget;
            if (currentTargetElem === null || typeof (currentTargetElem) === 'undefined')
            {
                return;
            } else
            {
                var idOfTargetElement = currentTargetElem.id;
                var sequenceOfThisRow = idOfTargetElement.split('_')[1];
                console.log('Sequence of this row #  ' + sequenceOfThisRow);
                var basePageModuleHolder = document.getElementById('BasePageModuleHolder:' + sequenceOfThisRow);
                var parentElement = basePageModuleHolder.parentNode.parentNode;
                parentElement.removeChild(basePageModuleHolder.parentNode);

                for (var j = 0; j < self.zones().length; j++)
                {
                    var zoneInfo = self.zones()[j];
                    var zoneSequence = zoneInfo.identifier;
                    if (parseInt(zoneSequence) === parseInt(sequenceOfThisRow))
                    {
                        console.log('Removing visual row # ' + j);
                        self.zones.splice(j, 1);
                        break;
                    }
                }


            }
        };

        self.openZoneDetailModuleForEdit = function (event, sequenceOfThisRow)
        {
            if (self.parentContainerViewModel() !== null && self.parentContainerViewModel() !== '')
            {
                self.parentContainerViewModel().disableNextBtn(true);
                self.parentContainerViewModel().disablePrevBtn(true);
            }
            var viewModelOfPopupModule = ko.dataFor(document.getElementById('zoneModuleRoot_' + sequenceOfThisRow));
            if (viewModelOfPopupModule === null)
            {
                console.log('Error : Could not find the view model for this row.');
            }
            self.showZonesListView(false);
            self.clearDuplicateWebEntryErrorMessages();
            viewModelOfPopupModule.openZoneDetailModule(event, 'EDIT');
            console.log('Success : Restoring view model bindings and opening the module for edit!');
        };

        self.intervalTimerForOpeningZoneModule = '';

        self.openZoneDetailModuleForCreate = function (event)
        {
            if (self.parentContainerViewModel() !== null && self.parentContainerViewModel() !== '')
            {
                self.parentContainerViewModel().disableNextBtn(true);
                self.parentContainerViewModel().disablePrevBtn(true);
            }
            self.showZonesListView(false);
            self.isZoneModuleLoading('Yes');
            var tableDataObject = self.zones();
            if (tableDataObject === null)
            {
                console.log('Error : Could not find the zones table data object.');
                return;
            }

            if (self.isCreateEnvFlow())
            {
                var storageRequiredPerAppTierNodeValue = self.parentContainerViewModel().storagePerAppNode();
                console.log('Initial : Storage per app node :: ' + self.parentContainerViewModel().storagePerAppNode());
                console.log('Initial : Fault Domain Choice List Length ::  ' + self.parentContainerViewModel().faultDomainChoiceList().length);
                if (storageRequiredPerAppTierNodeValue === null || storageRequiredPerAppTierNodeValue === '' || self.parentContainerViewModel().faultDomainChoiceList().length === 0)
                {
                    self.intervalTimerForOpeningZoneModule = window.setInterval(function () {
                        self.waitForRequestsToComplete();
                    }, 100);

                } else
                {
                    // In case of clone-standby and release-standby the storage per app node and fault domains are pre populated.
                    // we need a timer to delay opening the module as the topology page need to be loaded.
                    var trainContext = self.parentContainerViewModel().traincontext();
                    if (trainContext === 'clone-standby' || trainContext === 'release-standby') {
                        window.setTimeout(function ()
                        {
                            self.openModule();
                        }, 1000);
                    } else {
                        self.openModule();
                    }
                }

            } else
            {
                self.openModule();
            }

        };


        self.waitForRequestsToComplete = function () {
            if (self.parentContainerViewModel().storagePerAppNode() !== null && self.parentContainerViewModel().storagePerAppNode() !== '' && self.parentContainerViewModel().faultDomainChoiceList().length > 0) {
                console.log('Final :Storage per app node :: ' + self.parentContainerViewModel().storagePerAppNode());
                console.log('Final : Fault Domain Choice List Length ::  ' + self.parentContainerViewModel().faultDomainChoiceList().length);
                window.clearInterval(self.intervalTimerForOpeningZoneModule);
                self.openModule();
            } else {
                console.log('Timer  : Waiting for requests to complete');
                console.log('Timer   :Storage per app node :: ' + self.parentContainerViewModel().storagePerAppNode());
                console.log('Timer : Fault Domain Choice List Length ::  ' + self.parentContainerViewModel().faultDomainChoiceList().length);
            }
        };

        self.clearDuplicateWebEntryErrorMessages = function(){
             self.topologyPageLocalMessage('');
        };

        self.openModule = function (seqNum)
        {
            self.clearDuplicateWebEntryErrorMessages();
            var currentSeqNum = self.sequence();
            var newSequenceNum = currentSeqNum + 1;
            var mode = 'CREATE';
            if (self.isCloneEnvFlow())
            { //for clone we don't want to increment the sequence
                newSequenceNum = seqNum;
                mode = 'CLONE';
            }
            self.setGlobalVariablesBeforeOpeningZoneModule(newSequenceNum);
            var detailPageContainerElement = document.getElementById('detailPageContainer');
            //first check if the module already exists or not
            if (document.getElementById('BasePageModuleHolder:' + newSequenceNum) === null)
            {
                var basePageModuleElement = document.createElement('div');
                var innerHTMLHoldingModule = "<div id='BasePageModuleHolder:" + newSequenceNum + "'" + " data-bind='ojModule:zoneModuleName'></div>";
                basePageModuleElement.innerHTML = innerHTMLHoldingModule;
                detailPageContainerElement.appendChild(basePageModuleElement);
                if (document.getElementById('BasePageModuleHolder:' + newSequenceNum) === null)
                {
                    console.log('Error : Base Page Module Container was not added successfully.');
                }
                ko.applyBindings(self, document.getElementById('BasePageModuleHolder:' + newSequenceNum));
            }
            window.setTimeout(function ()
            {
                self.isZoneModuleLoading('No');
                
                var viewModelOfZoneModule = ko.dataFor(document.getElementById('zoneModuleRoot_' + newSequenceNum));
                viewModelOfZoneModule.openZoneDetailModule(event, mode);
                console.log('Success : Applied view model bindings and opening the zone module after timeout!');

            }, 2000);
        };


        self.setGlobalVariablesBeforeOpeningZoneModule = function (zoneSequence)
        {
            var parentViewModel = self.parentContainerViewModel();
            if (self.isCreateEnvFlow()) {
                rootViewModel.zoneSequence = zoneSequence;
                rootViewModel.loadBalancerEnabled = parentViewModel.loadBalancerOptionEnabled();
                rootViewModel.loadBalancerOptionValue = parentViewModel.lbaasOptionValue();
                rootViewModel.loadBalancerShapesList = parentViewModel.lbShapes();
                rootViewModel.appTierShapesList = parentViewModel.appShapeChoiceOptionsList();
                rootViewModel.storagePerNode = parentViewModel.storagePerAppNode();
                rootViewModel.faultDomains = parentViewModel.faultDomainChoiceList();
                rootViewModel.isExternalZoneAllowed = parentViewModel.isExternalZoneAllowed();

            } else if (self.isCloneEnvFlow())
            {
                rootViewModel.zoneSequence = zoneSequence;
                rootViewModel.loadBalancerEnabled = parentViewModel.loadBalancerOptionEnabled();
                rootViewModel.appTierShapesList = parentViewModel.appShapeChoiceOptionsList();
                rootViewModel.loadBalancerOptionValue = parentViewModel.lbaasOptionValue();
                rootViewModel.loadBalancerShapesList = parentViewModel.lbShapes();
            }
        };


        self.clearGlobalVariablesBeforeClosingZonePopup = function ()
        {
            if (self.isCreateEnvFlow()) {
                rootViewModel.zoneSequence = '';
                rootViewModel.loadBalancerEnabled = '';
                rootViewModel.loadBalancerOptionValue = '';
                rootViewModel.loadBalancerShapesList = '';
                rootViewModel.appTierShapesList = '';
                rootViewModel.storagePerNode = '';
                rootViewModel.faultDomains = '';
                rootViewModel.isExternalZoneAllowed = '';
            }
            if (self.isCloneEnvFlow()) {
                rootViewModel.zoneSequence = '';
                rootViewModel.loadBalancerEnabled = '';
                rootViewModel.loadBalancerOptionValue = '';
                rootViewModel.loadBalancerShapesList = '';
                rootViewModel.appTierShapesList = '';
                rootViewModel.storagePerNode = '';
                rootViewModel.faultDomains = '';
            }
        };


        self.removeZoneFromDetailContainer = function (seqNum)
        {
            var detailRow = document.getElementById('BasePageModuleHolder:' + seqNum);
            if (detailRow !== null)
            {
                var parentRow = detailRow.parentNode;
                if(typeof(parentRow.remove) === 'undefined' && typeof(parentRow.parentNode.removeChild) === 'function'){
                    parentRow.parentNode.removeChild(parentRow);
                }
                else{
                   parentRow.remove();
                }
                var zonesLen = self.zones().length;
                var zonesTemp = new Array();

                for (var i = 0; i < zonesLen; i++)
                {
                    var zoneObject = self.zones()[i];
                    var seqNumRow = zoneObject.identifier;
                    if (seqNumRow === seqNum)
                    {
                        //skip.
                    } else
                    {
                        zonesTemp.push(zoneObject);
                    }
                }
                self.zones(zonesTemp);
            }
        };

        self.confirmationDialogText = ko.observable('');
        self.confirmationCallBackFunctionSuccess = null;
        self.confirmationCallBackFunctionFailure = null;
        self.isNoButtonRendered = ko.observable(true);
        self.confirmationDialogTitle = ko.observable('Confirm');
        self.yesButtonText = ko.observable('Yes');
        self.noButtonText = ko.observable('No');


        self.okConfirmationDialog = function ()
        {
            document.getElementById('confirmDialog').close();
            self.confirmationCallBackFunctionSuccess();
        };
        self.NotokConfirmationDialog = function ()
        {
            document.getElementById('confirmDialog').close();
            self.confirmationCallBackFunctionFailure();
        };

        self.openConfirmationDialog = function (questionaireText, callbackFunctionSuccess, callbackFunctionFailure)
        {
            self.confirmationCallBackFunctionSuccess = callbackFunctionSuccess;
            self.confirmationCallBackFunctionFailure = callbackFunctionFailure;
            self.confirmationDialogText(questionaireText);
            self.isNoButtonRendered(true);
            self.yesButtonText('Yes');
            self.noButtonText('No');
            self.confirmationDialogTitle('Confirm');
            document.getElementById('confirmDialog').open();
        };

        self.openInformationDialog = function (content, callBackFunc)
        {
            self.confirmationCallBackFunctionSuccess = callBackFunc;
            self.confirmationDialogText(content);
            self.isNoButtonRendered(false);
            self.yesButtonText('OK');
            self.confirmationDialogTitle('Warning');
            document.getElementById('confirmDialog').open();
        };


        self.updateDeleteEnabledFlagForFirstExternalZone = function () {
            var zonesLength = self.zones();
            if (zonesLength <= 1) {
                return;
            }
            // Check if we have more than 1 external zones.
            var noOfExternalZones = 0;
            for (var k = 0; k < self.zones().length; k++) {
                var typeOfZone = self.zones()[k].type();
                if (typeOfZone === 'External') {
                    noOfExternalZones++;
                }
            }
            if (noOfExternalZones > 1) {
                // Find the primary external zone and mark delete enabled flag = false.
                for (var k = 0; k < self.zones().length; k++) {
                    var primaryExternalZone = self.zones()[k].isPrimaryExternalZone();
                    if (primaryExternalZone) {
                        self.zones()[k].enableDeleteOption(false);
                        break;
                    }
                }
            }
        };

        self.updateAddZoneEnabledFlagBasedOnPrimaryZoneWebEntryType = function () {
            var zonesLength = self.zones();
            if (zonesLength < 1) {
                return;
            }
            var firstZoneData = self.zones()[0];
            var webEntryType = firstZoneData.lbaasOptionValue();
            if (webEntryType === 'NO_LOAD_BALANCER') {
                self.isAddZoneEnabled(false);
            } else {
                self.isAddZoneEnabled(true);
            }
        };

        self.getWebEntryURLforZone = function (rowObject) {
            if (rowObject.port() === null || rowObject.port() === '' || rowObject.protocol() === null || rowObject.protocol() === ''
                    || rowObject.hostName() === null || rowObject.hostName() === '' || rowObject.domain() === null ||
                    rowObject.domain() === '') {
                return "";
            } else {
                return rowObject.protocol() + "://" + rowObject.hostName() + "." + rowObject.domain() + ":" + rowObject.port();
            }
        };
        
        self.isRepeatingElementInArray = function(inputArray, elementToSearchFor){
           for(var k=0;k<inputArray.length;k++){
               var entry = inputArray[k];
               if(entry === elementToSearchFor){
                   return true;
               }
           }
           return false;
        };
        
        self.findParentElementZoneInfo = function(fqdnArray, currentFqdn, zoneInfoArray){
           for(var k=0;k<fqdnArray.length;k++){
               var entry = fqdnArray[k];
               if(entry === currentFqdn){
                   return zoneInfoArray[k];
               }
           }
           return null;
        };
        
        self.isTopologyValid = function(){
            var zonesList = self.zones();
            self.topologyPageLocalMessage('');
            var fqdn = new Array();
            var zoneObject = new Array(); // This zone object is used to get the load balancer info later on.
            var repeatingfqdn = new Array();
            if(zonesList < 1){
                return true;
            }
            else{
                for(var j=0;j<zonesList.length;j++){
                    var zoneElement = zonesList[j];
                    var hostNameForZone = zoneElement.hostName();
                    var domainNameForZone = zoneElement.domain();
                    var fqdnForZone = hostNameForZone + "." + domainNameForZone;
                    var isRepeatingfqdn = self.isRepeatingElementInArray(fqdn, fqdnForZone);
                    var zoneInformationOfParent = self.findParentElementZoneInfo(fqdn, fqdnForZone, zoneObject);
                    if(isRepeatingfqdn && zoneInformationOfParent !== null){
                        // If the current zone's load balancer name is the same as the checked zone, then repeating 
                        // domain + host is fine, If not this is an issue.
                        var zoneNameOfParent = zoneInformationOfParent.name();
                        var lbaasTypeOfCurrentZone = zoneElement.lbaasOptionValue();
                        if(lbaasTypeOfCurrentZone !== 'NO_LOAD_BALANCER' && lbaasTypeOfCurrentZone !== 'USE_EXISTING' && lbaasTypeOfCurrentZone !== 'NO_LOAD_BALANCER'){
                            if(zoneNameOfParent !== null && zoneNameOfParent === lbaasTypeOfCurrentZone){
                                continue;
                            }
                        }
                    }
                    if(isRepeatingfqdn){
                        var repeatfqdnInfo = new Object();
                        repeatfqdnInfo.fqdn = fqdnForZone;
                        repeatfqdnInfo.zoneName = zoneElement.name();
                        repeatingfqdn.push(repeatfqdnInfo);
                    }
                    else{
                        fqdn.push(fqdnForZone);
                        zoneObject.push(zoneElement);
                    }
                }
                // If there are repeating web entries, then throw the error and also indicate
                // the repeating web entries for the admin to correct the same.
                if(repeatingfqdn.length > 0){
                    var  duplicateWarningPreMessage = oj.Translations.getTranslatedString('validationMsgs.duplicateWebEntryPointsMsg');
                    var completeMessage = duplicateWarningPreMessage;
                    for(var i=0;i<repeatingfqdn.length;i++){
                         var fqdnInformation =  repeatingfqdn[i];
                         var fqdn = fqdnInformation.fqdn;
                         var zoneName = fqdnInformation.zoneName;
                         completeMessage += fqdn + "(" + zoneName + ")";
                         if(i !== repeatingfqdn.length-1){
                            completeMessage += ',';
                        }
                    }
                    completeMessage += '.';
                    self.topologyPageLocalMessage(completeMessage);
                    return false;
                }
                else{
                    return true;
                }
            }
        };


        self.updateListViewWithZoneDetailInformation = function (zoneDetailPGViewModule)
        {
            var mode = zoneDetailPGViewModule.mode();
            var rowObject = null;
            if ((mode === 'CREATE') && self.isCreateEnvFlow())
            {
                rowObject = new Object();
                rowObject.identifier = zoneDetailPGViewModule.sequence();
                rowObject.name = ko.observable(zoneDetailPGViewModule.zoneName());
                rowObject.type = ko.observable(zoneDetailPGViewModule.selectedZoneType());
                rowObject.appNodesCount = ko.observable(zoneDetailPGViewModule.nodesObservableArray().length);
                rowObject.editStatus = ko.observable(zoneDetailPGViewModule.zoneEditDone());
                rowObject.lbaasOptionValue = ko.observable(zoneDetailPGViewModule.lbaasOptionValue());
                rowObject.fileSystemType = ko.observable(zoneDetailPGViewModule.fileSystemModeSelected());
                rowObject.isPrimaryExternalZone = ko.observable(zoneDetailPGViewModule.isPrimaryExternalZone());
                rowObject.enableDeleteOption = ko.observable(true);
                rowObject.port = ko.observable(zoneDetailPGViewModule.webEntryPort());
                rowObject.protocol = ko.observable(zoneDetailPGViewModule.webEntryProtocolInputValue());
                rowObject.hostName = ko.observable(zoneDetailPGViewModule.webEntryHostname());
                rowObject.domain = ko.observable(zoneDetailPGViewModule.webEntryDomain());
                rowObject.webEntryURL = ko.observable(self.getWebEntryURLforZone(rowObject));
                rowObject.webEntryType = ko.observable(zoneDetailPGViewModule.lbaasSelectedOptionLabel());
                //logicalHost
                rowObject.logicalHostOption = ko.observable(zoneDetailPGViewModule.logicalHostOptionSelection());
                rowObject.logicalHostnamePrefix = ko.observable(zoneDetailPGViewModule.appsLogicalHostPrefixValue());
                rowObject.logicalDomain = ko.observable(zoneDetailPGViewModule.appsLogicalDomainValue());

                console.log('Is Primary External Zone =>' + rowObject.isPrimaryExternalZone());
                console.log('Created new row in zones list view with sequence # : ' + rowObject.identifier);
                console.log('Lbaas Option Value :' + rowObject.lbaasOptionValue());
                console.log('Web Entry Protocol : ' + rowObject.protocol());
                self.zones.push(rowObject);
                self.sequence(zoneDetailPGViewModule.sequence());
            } else
            {
                var zonesLen = self.zones().length;
                var updatedZones = self.zones();
                for (var i = 0; i < zonesLen; i++)
                {
                    var zoneObject = updatedZones[i];
                    var seqNum = zoneObject.identifier;
                    if (seqNum === zoneDetailPGViewModule.sequence())
                    {
                        rowObject = zoneObject;
                        rowObject.name(zoneDetailPGViewModule.zoneName());
                        rowObject.type(zoneDetailPGViewModule.selectedZoneType());
                        rowObject.appNodesCount(zoneDetailPGViewModule.nodesObservableArray().length);
                        rowObject.lbaasOptionValue(zoneDetailPGViewModule.lbaasOptionValue());
                        rowObject.fileSystemType(zoneDetailPGViewModule.fileSystemModeSelected());
                        rowObject.isPrimaryExternalZone(zoneDetailPGViewModule.isPrimaryExternalZone());
                        rowObject.port(zoneDetailPGViewModule.webEntryPort());
                        rowObject.protocol(zoneDetailPGViewModule.webEntryProtocolInputValue());
                        rowObject.enableDeleteOption(true);
                        rowObject.hostName(zoneDetailPGViewModule.webEntryHostname());
                        rowObject.domain(zoneDetailPGViewModule.webEntryDomain());
                        rowObject.webEntryURL(self.getWebEntryURLforZone(rowObject));
                        rowObject.webEntryType(zoneDetailPGViewModule.lbaasSelectedOptionLabel());
                        //Logical Host
                        rowObject.logicalHostOption = ko.observable(zoneDetailPGViewModule.logicalHostOptionSelection());
                        rowObject.logicalHostnamePrefix = ko.observable(zoneDetailPGViewModule.appsLogicalHostPrefixValue());
                        rowObject.logicalDomain = ko.observable(zoneDetailPGViewModule.appsLogicalDomainValue());

                        console.log('Lbaas Option Value :' + rowObject.lbaasOptionValue());
                        console.log('Is Primary External Zone =>' + rowObject.isPrimaryExternalZone());
                        console.log('Zone edit done : ' + zoneDetailPGViewModule.zoneEditDone());
                        console.log('Web Entry Protocol : ' + rowObject.protocol());
                        rowObject.editStatus(zoneDetailPGViewModule.zoneEditDone());

                    }
                }
            }
            var parentViewModel = self.parentContainerViewModel();

            if (self.isCloneEnvFlow())
            {
                var editDone = true;
                //need to check edit status of all zones
                //only enable next button if all zones are done editing
                for (var i = 0; i < self.zones().length; i++)
                {
                    var zoneObject = self.zones()[i];
                    if (!zoneObject.editStatus())
                    {
                        editDone = false;
                        break;
                    }
                }
                if (editDone)
                {
                    parentViewModel.disableNextBtn(false);
                    parentViewModel.zonesEditDone(true);
                    
                    // Enable 3rd step i.e. execution plan only if edit done successfully
                    var executionPlanTrainStep = parentViewModel.stepArray()[2];
                    executionPlanTrainStep.disabled = false;
                    document.getElementById("train").updateStep(executionPlanTrainStep.id, executionPlanTrainStep);
                } else
                {
                    parentViewModel.disableNextBtn(true);
                    parentViewModel.zonesEditDone(false);
                }
                parentViewModel.disablePrevBtn(false);
            } else if (parentViewModel !== null && parentViewModel !== '')
            {
                parentViewModel.disableNextBtn(false);
                parentViewModel.disablePrevBtn(false);
            }

            self.updateDeleteEnabledFlagForFirstExternalZone();
            self.updateAddZoneEnabledFlagBasedOnPrimaryZoneWebEntryType();
        };
        
        //Move initialization code inside lifecycle method handleAttached, 
        //to ensure it is only called upon the view is inserted into the DOM
        self.handleAttached = function ()
        {
            console.log('TopologyDetails View Model Attached.');
            if (self.isCreateEnvFlow()) {
            self.initializeTopologyPage();
            }

            if (self.isCloneEnvFlow()) {
                self.zones(self.parentContainerViewModel().cloneZonesData());
                self.initializeTopologyPage();
            }
        };
        
        self.getZonePostData = function ()
        {
            var zones = self.zones();
            var currentSequenceNum = self.sequence();
            var additionalStorageEntered = '';
            var firstRowAppNodeType = '';
            var zoneGroups = new Array();
            for (var k = 1; k <= currentSequenceNum; k++)
            {
                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                if (detailChildElemRoot !== null)
                {
                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                    if (detailModuleElemViewModel !== null)
                    {
                        var eachGroupNode = new Object();

                        var nameOfZone = detailModuleElemViewModel.zoneName();
                        eachGroupNode.nodes = new Array();
                        eachGroupNode.webEntry = new Object();

                        // Name and Type
                        eachGroupNode.name = nameOfZone;
                        var typeofZone = detailModuleElemViewModel.selectedZoneType();
                        if (typeofZone === 'Internal')
                        {
                            eachGroupNode.type = 'Internal';
                        } else
                        {
                            eachGroupNode.type = 'External';
                        }

                        // Web Entry
                        var lbaasConfigured = detailModuleElemViewModel.lbaasOptionValue() !== 'NO_LOAD_BALANCER' && detailModuleElemViewModel.lbaasOptionValue() !== 'USE_EXISTING';
                        var lbaasShape;

                        if (lbaasConfigured)
                        {
                            if (detailModuleElemViewModel.lbaasOptionValue() === 'DEPLOY_NEW')
                            {
                                lbaasShape = detailModuleElemViewModel.lbaasShape();
                            }
                        }
                        var type = "";
                        if (detailModuleElemViewModel.lbaasOptionValue() === 'NO_LOAD_BALANCER')
                        {
                            type = 'AppTierWebEntry';
                        } else if (detailModuleElemViewModel.lbaasOptionValue() === 'DEPLOY_NEW')
                        {
                            type = 'LBaaS';
                        } else if (detailModuleElemViewModel.lbaasOptionValue() === 'USE_EXISTING')
                        {
                            type = 'UserLoadBalancer';
                        } else
                        {
                            type = 'LBaaS';
                        }
                        var domain = detailModuleElemViewModel.webEntryDomain();
                        var host = detailModuleElemViewModel.webEntryHostname();
                        var protocol = detailModuleElemViewModel.webEntryProtocolInputValue();
                        var port = detailModuleElemViewModel.lbaasOptionValue() === 'NO_LOAD_BALANCER' ? (detailModuleElemViewModel.webEntryProtocolInputValue() === 'http' ? '8000' : '4443') : detailModuleElemViewModel.webEntryPort();
                        var isLBaaSRequired = lbaasConfigured ? 'Yes' : 'No';
                        eachGroupNode.webEntry.type = type;
                        eachGroupNode.webEntry.domain = domain ? domain.trim() : domain;
                        eachGroupNode.webEntry.host = host ? host.trim() : host;
                        eachGroupNode.webEntry.port = port;
                        eachGroupNode.webEntry.protocol = protocol;
                        if (isLBaaSRequired === 'Yes')
                        {
                            if (detailModuleElemViewModel.lbaasOptionValue() === 'DEPLOY_NEW')
                            {
                                eachGroupNode.webEntry.newLBaaS = new Object();
                                eachGroupNode.webEntry.newLBaaS.createNew = new Object();
                                eachGroupNode.webEntry.newLBaaS.createNew.shape = lbaasShape;
                            } else
                            {
                                eachGroupNode.webEntry.newLBaaS = new Object();
                                eachGroupNode.webEntry.newLBaaS.reuseFromZone = new Object();
                                eachGroupNode.webEntry.newLBaaS.reuseFromZone.zoneName = detailModuleElemViewModel.lbaasOptionValue();
                            }
                        }

                        // App Nodes
                        var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                        var appNodeArray = detailModuleElemViewModel.nodesObservableArray();

                        var fileSystemType = detailModuleElemViewModel.fileSystemModeSelected();
                        eachGroupNode.fileSystemType = fileSystemType;

                        for (var j = 0; j < appNodeCount; j++)
                        {
                            if (j === 0 && k === 1)
                            {
                                if (self.isCreateEnvFlow())
                                {
                                    var baseStorage = detailModuleElemViewModel.minimumStorageForRestore();
                                    additionalStorageEntered = appNodeArray[j].Storage() - baseStorage;
                                    console.log('For Row  #1 additional storage entered is : ' + additionalStorageEntered);

                                }
                            }
                            var appNodesShape = appNodeArray[j].Shape();
                            var eachNodeEntry = new Object();
                            eachNodeEntry.shape = appNodesShape;
                            eachNodeEntry.logicalHostName = appNodeArray[j].logicalHostname() ? appNodeArray[j].logicalHostname().toLowerCase() : appNodeArray[j].logicalHostname();
                            if (self.isCreateEnvFlow())
                            {
                                eachNodeEntry.storageType = 'BLOCK_VOLUME';
                                eachNodeEntry.faultDomain = appNodeArray[j].FaultDomain();
                            
                                if (fileSystemType === 'sfs')
                                {
                                    if (j === 0 && k === 1) {
                                        eachNodeEntry.additionalStorage = additionalStorageEntered;
                                    } else {
                                        // No addiitonal storage
                                    }
                                } else
                                {
                                    var baseStorage = detailModuleElemViewModel.minimumStorageForRestore();
                                    additionalStorageEntered = appNodeArray[j].Storage() - baseStorage;
                                    eachNodeEntry.additionalStorage = additionalStorageEntered;
                                }
                            }
                            eachGroupNode.nodes.push(eachNodeEntry);
                        }
                        zoneGroups.push(eachGroupNode);
                    }
                }
            }
            return zoneGroups;
        };

        self.getAppsLogicalDomain = function ()
        {
            var seq = 1; //first zone has the domain value
            var logicalDomain = null;
            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + seq);
            if (detailChildElemRoot !== null)
            {
                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                if (detailModuleElemViewModel !== null)
                {
                    logicalDomain = detailModuleElemViewModel.appsLogicalDomainValue();
                    logicalDomain = logicalDomain ? logicalDomain.toLowerCase() : logicalDomain;
                }

            }
            return logicalDomain;
        };

        self.getAppsLogicalHostOption = function ()
        {
            var seq = 1; //first zone has the domain value
            var logicalHostOption = null;
            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + seq);
            if (detailChildElemRoot !== null)
            {
                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                if (detailModuleElemViewModel !== null)
                {
                    logicalHostOption = detailModuleElemViewModel.logicalHostOptionSelection();
                }

            }
            return logicalHostOption;
        };

        self.getAppsLogicalHostPrefix = function ()
        {
            var seq = 1; //first zone has the domain value
            var logicalHostPrefix = null;
            var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + seq);
            if (detailChildElemRoot !== null)
            {
                var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                if (detailModuleElemViewModel !== null)
                {
                    logicalHostPrefix = detailModuleElemViewModel.appsLogicalHostPrefixValue();
                    logicalHostPrefix = logicalHostPrefix ? logicalHostPrefix.toLowerCase() : logicalHostPrefix;
                }

            }
            return logicalHostPrefix;
        };

        self.getAllAppsLogicalHostname = function ()
        {
            var currentSequenceNum = self.sequence();
            console.log("currentSeq=" + currentSequenceNum);
            var zoneGroups = new Array();
            for (var k = 1; k <= currentSequenceNum; k++)
            {
                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                if (detailChildElemRoot !== null)
                {
                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                    var nodeHostNames = new Array();
                    if (detailModuleElemViewModel !== null)
                    {
                        // App Nodes
                        var appNodeCount = detailModuleElemViewModel.nodesObservableArray().length;
                        var appNodeArray = detailModuleElemViewModel.nodesObservableArray();

                        for (var j = 0; j < appNodeCount; j++)
                        {
                            var appNodeLogicalHost = appNodeArray[j].logicalHostname() ? appNodeArray[j].logicalHostname().toLowerCase() : appNodeArray[j].logicalHostname();
                            nodeHostNames.push(appNodeLogicalHost);
                        }
                        zoneGroups.push(nodeHostNames);
                    }
                }
            }
            return zoneGroups;
        };

        self.getAllAppsNodesArray = function ()
        {
            var currentSequenceNum = self.sequence();
            console.log("currentSeq=" + currentSequenceNum);
            var zoneGroups = new Array();
            for (var k = 1; k <= currentSequenceNum; k++)
            {
                var detailChildElemRoot = document.getElementById('zoneModuleRoot_' + k);
                if (detailChildElemRoot !== null)
                {
                    var detailModuleElemViewModel = ko.dataFor(detailChildElemRoot);
                    if (detailModuleElemViewModel !== null)
                    {
                        // App Nodes
                        var appNodeArray = detailModuleElemViewModel.nodesObservableArray();
                        zoneGroups.push(appNodeArray);
                    }
                }
            }
            return zoneGroups;
        };

        self.getDBTierLogicalHostPrefix = function ()
        {
            var dbType = self.parentContainerViewModel().dbTypeUsed();
            var dbPrefix = '';
            if (dbType === 'Compute')
            {
                dbPrefix = self.parentContainerViewModel().dbLogicalHostNamePrefixValue();
            }
            //comment out following code as for now logical host is not supported for vmdb
            /*else if (dbType === 'VMDB System')
             {
             dbPrefix =  self.parentContainerViewModel().vmdbLogicalHostNamePrefixValue();
             if(self.parentContainerViewModel().dbNodesObservableArray().length > 1)
             {
             dbPrefix += "*";
             }
             }*/

            return dbPrefix;

        };

    }

    return AppTierDetailsContentViewModel;
});
