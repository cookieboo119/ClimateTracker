/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * jobs_oci module
 */
define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/navigation/pageNavigationHelper','ebs/popup/popupHelper', 'ebs/constants','ebs/utils/dateTimeHelper', 'ebs/utils/compartmentUtils', 
    'jquery', 'ojs/ojknockout', '', 'ojs/ojmenu', 'ojs/ojrouter', 'ojs/ojpopup', 'ojs/ojlistview',
    'ojs/ojtoolbar', 'ojs/ojnavigationlist', 'ojs/ojoffcanvas', 'ojs/ojmodule', 'ojs/ojtrain', 'ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojselectcombobox', 'ojs/ojdialog',
    'ojs/ojarraytabledatasource', 'ojs/ojinputtext', 'ojs/ojcollectiontabledatasource', 'ojs/ojselectcombobox', 'ojs/ojoffcanvas', 'ojs/ojjsontreedatasource', 'ojs/ojinputsearch',  'ojs/ojlistitemlayout'
], function (oj, ko, actionsHelper, pageNavigationHelper, popupHelper ,constants, dateTimeHelper, compartmentUtils) {
    /**
     * The view model for the main content view template
     */
    function jobs_ociContentViewModel() {
        var self = this;
        var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
        self.entityTypesList = ko.observableArray();
        rootViewModel.currentPageHeader(oj.Translations.getTranslatedString('pageHeader.activities'));
        rootViewModel.showContextHeader(false);
        rootViewModel.showNavTab(true);
        $( document ).ready(function(){
            var displayPopupId = rootViewModel.displayPopupId();
            if(displayPopupId !== ''){
                $(constants.divTags.activityConfPopupTag).ojPopup('open',constants.divTags.rootBodyDivTag);
                rootViewModel.displayPopupId('');
            }
        });
        var jobId;
        var jobIdNameMap = new Object();
        self.jobsLoaded = ko.observable(false);
        self.totalJobs = ko.observable();
        self.successfulJobs = ko.observable();
        self.pendingJobs = ko.observable();
        self.failedJobs = ko.observable();
        self.jobsList = ko.observableArray();
        self.datasourceForJobs = new oj.ArrayTableDataSource(self.jobsList, {idAttribute: 'id'});
        self.dataSource = ko.observable();
        self.selectedListItem = ko.observable();
        self.confirmRestartPage = ko.observable();
        
        self.envName = rootViewModel.currentEnvName();
        var parentPageModule = ko.dataFor(document.getElementById('landingModuleContent')).childRouterKO();
        self.isEnvSpecific = parentPageModule == constants.navModules.envDetailsModule;
        
        self.activityMenuItemsWithRestart = [
            {
                id: constants.contextMenu.restart,
                label: oj.Translations.getTranslatedString('contextMenu.retry'),
                disabled: false
            }, 
        ];
        
        self.activityMenuItemsWithoutRestart = [
            {
                id: constants.contextMenu.restart,
                label: oj.Translations.getTranslatedString('contextMenu.retry'),
                disabled: true
            }, 
        ];
        
        self.loadJobs = function(compartmentId){
            if (document.getElementById('filterEnvName') != null)
            {
                document.getElementById('filterEnvName').value = '';
            }
            self.jobsLoaded(false);
            if(self.envName != null && self.envName != '' && self.isEnvSpecific)
            {
                 actionsHelper.getEnvJobs(self.envName, function(error, jobs){
                    if(error === ''){
                        $.each(jobs, function(index,value){
                            var job = this;
                            jobIdNameMap[job.id]= job.name;
                            jobs[index].jobName = job.name;
                            jobs[index].startTime = dateTimeHelper.convertToUTC(job.startTime);
                            jobs[index].endTime = dateTimeHelper.convertToUTC(job.endTime);
                            jobs[index].parentId = jobs[index].parentId === null ? '' : jobs[index].parentId;
                           var isCloudMgrVersionPresent = false;
                            var mgrVersionAttr = jobs[index].cloudManagerVersion;
                            if(typeof(mgrVersionAttr) !== 'undefined'  && mgrVersionAttr !== null && mgrVersionAttr !== '' )
                            {
                                isCloudMgrVersionPresent = true;
                            }
                            else
                            {
                                isCloudMgrVersionPresent = false;
                            }
                            jobs[index].versionPresent = isCloudMgrVersionPresent;
                            jobs[index].entityLabel = self.findEntityLabelForEntityValue(jobs[index].entityType);

                        });
                        self.jobsList(jobs);
                        self.dataSource(self.datasourceForJobs);
                    }
                    self.jobsLoaded(true);
                });
            }
            else
            {
                compartmentId = compartmentUtils.getCurrentSelectedCompartmentId(compartmentId);
                actionsHelper.getJobs(compartmentId, function(error, jobs){
                    if(error === ''){
                        $.each(jobs, function(index,value){
                            jobIdNameMap[this.id]= this.name;
                             jobs[index].jobName = this.name;
                            jobs[index].startTime = dateTimeHelper.convertToUTC(this.startTime);
                            jobs[index].endTime = dateTimeHelper.convertToUTC(this.endTime);
                            jobs[index].parentId = jobs[index].parentId === null ? '' : jobs[index].parentId;
                           var isCloudMgrVersionPresent = false;
                            var mgrVersionAttr = jobs[index].cloudManagerVersion;
                            if(typeof(mgrVersionAttr) !== 'undefined'  && mgrVersionAttr !== null && mgrVersionAttr !== '' )
                            {
                                isCloudMgrVersionPresent = true;
                            }
                            else
                            {
                                isCloudMgrVersionPresent = false;
                            }
                            jobs[index].versionPresent = isCloudMgrVersionPresent;
                            /*if (jobs[index].action !== null && jobs[index].action === "cleanup-backup") {
                                jobs[index].environmentLabel = "Backup: ";
                            } else if (jobs[index].action !== null && jobs[index].action === "create-network-profile") {
                                jobs[index].environmentLabel = "Network Profile: ";
                            } else {
                                jobs[index].environmentLabel = "Environment: ";
                            }*/
                            jobs[index].entityLabel = self.findEntityLabelForEntityValue(jobs[index].entityType);
                        });
                        self.jobsList(jobs);
                        self.dataSource(self.datasourceForJobs);
                    }
                    self.jobsLoaded(true);
                });
           }
        };
        
        self.findEntityLabelForEntityValue  = function(entityValueInput){
            for(var i=0;i<self.entityTypesList().length;i++){
                var entity = self.entityTypesList()[i];
                var entityValue = entity.value;
                if(entityValue === entityValueInput){
                    return entity.label;
                }
            }
            return '';
        };
        
        
       actionsHelper.getEntityTypesList(function(error, list){
           self.entityTypesList(list);
           self.loadJobs();
       });
        
        
       // self.dataSource(self.datasourceForJobs);
        self.gotoJobDetails = function(job){
            console.log("details for job " + job.id);
            oj.Router.rootInstance.store(job.id);
            if(self.isEnvSpecific)
            {
                var context = ko.contextFor(document.getElementById(constants.divTags.envDetailsPageTopDiv));
                rootViewModel.activityDetailsParentPage(constants.navModules.envDetailsModule);
                pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, constants.navModules.activityDetailsModule);
            }
            else
            {  
                var context = ko.contextFor(document.getElementById(constants.divTags.activitiesPage));
                rootViewModel.activityDetailsParentPage(constants.navModules.envActivitiesModule);
                pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, constants.navModules.activityDetailsModule);
            }
        };
        
        self.gotoParentJobDetails = function(job){
            console.log("details for job " + job.parentId);
            oj.Router.rootInstance.store(job.parentId);
            if(self.isEnvSpecific)
            {
                var context = ko.contextFor(document.getElementById(constants.divTags.envDetailsPageTopDiv));
                rootViewModel.activityDetailsParentPage(constants.navModules.envDetailsModule);
                pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, constants.navModules.activityDetailsModule);
            }
            else
            {
                var context = ko.contextFor(document.getElementById(constants.divTags.activitiesPage));
                rootViewModel.activityDetailsParentPage(constants.navModules.envActivitiesModule);
                pageNavigationHelper.navigateToPage(context, constants.navModules.activityDetailsModule, constants.navModules.activityDetailsModule);
            }
        };
        
        self.activityActionsHandler = function(event, ui){
            console.log("selected List item " + self.selectedListItem());
            var localJobId = self.selectedListItem()[0];
            jobId = localJobId ? localJobId: jobId;
            var activityName = jobIdNameMap[jobId];
            console.log('Triggering restart action..');
            self.confirmRestartPage(oj.Translations.getTranslatedString("confirmPopup.restartJobAssertMsg", {activityName: activityName}));
            var popup = document.querySelector(constants.divTags.activityRestartConfPopupTag);
            popup.open(event.target);
            self.selectedListItem([]);
        };
        
        self.selectionChanged = function(event, ui){
            var currentJobId = self.selectedListItem()[0];
            jobId = currentJobId ? currentJobId : jobId;
        };
        
        self.flattenArrayDS =  function(data)  {    
            var collection = new oj.Collection();    
            for (var i=0;i<data.length;i++)    {        
                collection.add(data[i]);      
            }      
            return collection;  
        };

        self.nameFilter = function(model, attr, value)   { 
            var name = model.get('entityName'); 
            return (name.toLowerCase().indexOf(value.toLowerCase()) > -1); 
        };
        
        self.genericFilter = function(model, attr, value)   { 
            var name = (model.get('name') !== null)  ? model.get('name') : ''; 
            var entityName = (model.get('entityName') !== null)  ? model.get('entityName') : ''; 
            var action = (model.get('action') !== null) ? model.get('action') : '';
            var status = (model.get('status') !== null)? model.get('status') : '';
            var startTime = (model.get('startTime') !== null) ? model.get('startTime') : '';
            var endTime = (model.get('endTime') !== null) ? model.get('endTime') : '';
            var createdBy = (model.get('createdBy') !== null) ? model.get('createdBy') : '';
            
            return (
                    (name && (name.toLowerCase().indexOf(value.toLowerCase()) > -1)) ||
                    entityName.toLowerCase().indexOf(value.toLowerCase()) > -1 ||
                    action.toLowerCase().indexOf(value.toLowerCase()) > -1 ||
                    status.toLowerCase().indexOf(value.toLowerCase()) > -1 ||
                    startTime.toLowerCase().indexOf(value.toLowerCase()) > -1 ||
                    endTime.toLowerCase().indexOf(value.toLowerCase()) > -1 ||
                    createdBy.toLowerCase().indexOf(value.toLowerCase()) > -1
                    
                    ); 
        };
        
        self.searchText = ko.observable('');
        self.handleSearchTextChange = function(event, ui)
        {
           event.preventDefault();
            if (event.keyCode === 13) { //only handle enter key
                self.handleSearchCriteria(event, ui);
            }
        };
        self.handleSearchCriteria = function (event) {
            var filter = self.searchText();
            if (filter.length === 0) {
                self.dataSource(self.datasourceForJobs);
            } else {
                if (self.filteredDataSource === undefined) {
                    self.collection = self.flattenArrayDS(self.jobsList());
                    self.filteredCollection = self.collection.clone(); 
                    self.filteredDataSource = new oj.CollectionTableDataSource(self.filteredCollection);
                }
                var ret = self.collection.where({entityName: {value: filter, comparator: self.genericFilter}});
                self.filteredCollection.reset(ret);
                if (self.dataSource() === self.datasourceForJobs){
                    self.dataSource(self.filteredDataSource);
                }
            }
        };
        
        self.startAnimationListener = function (event,ui)
        {
            popupHelper.startAnimationListener(constants.divTags.activityConfPopupTag, event, ui);
        };
        
        self.confirmationPopupCloseHandler = function(data,event){
            popupHelper.confmPopuCloseHandler(constants.divTags.activityConfPopupTag, data, event);
        };
        
        self.closeConfirmRestartPopup = function(event, ui){
            var popup = document.querySelector(constants.divTags.activityRestartConfPopupTag);
            popup.close();
        };
        
        self.restartJob = function (event, ui){
            var popup = document.querySelector(constants.divTags.activityRestartConfPopupTag);
            popup.close();
            var jobName = jobIdNameMap[jobId];
            var infoMsg = oj.Translations.getTranslatedString("confirmPopup.restartJobInfoMsg", {'jobName': jobName});
            var msgOrigin = oj.Translations.getTranslatedString("confirmPopup.restartJobTitle");
            popupHelper.openInfoMsg(constants.divTags.activityConfPopupTag, infoMsg, msgOrigin);
            actionsHelper.restartActivity(jobId, function(error, success){
                if (error === '') {
                    var successMsg = oj.Translations.getTranslatedString("confirmPopup.restartJobSuccessMsg", {'jobName': jobName});
                    popupHelper.openSuccessMsg(constants.divTags.activityConfPopupTag,successMsg,msgOrigin);
                    self.loadJobs();
                } else {
                    var responseText = error.responseText;
                    var response = JSON.parse(responseText);
                    popupHelper.openErrorMsg(constants.divTags.activityConfPopupTag,response.message,msgOrigin);
                }
            });
        };
    }
    
    return jobs_ociContentViewModel;
});
