/*
 * THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A  PARTICULAR
 * PURPOSE.
 */

/* 
 * GetCorrections - This class makes getcorrections request and
 * displays the response.
 */
package com.bloomberg.datalic.dlws;

import com.bloomberg.datalic.dlws.stubs.CorrectionRecord;
import com.bloomberg.datalic.dlws.stubs.GetCorrectionsRequest;
import com.bloomberg.datalic.dlws.stubs.GetCorrectionsResponse;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS;
import com.bloomberg.datalic.dlws.stubs.PerSecurityWS_Service;
import com.bloomberg.datalic.dlws.stubs.ProgramFlag;

public class GetCorrections {

    // NOTE: The programFlag argument is ignored for this sample
    public void run(ProgramFlag programFlag) {
        try {
            PerSecurityWS ps = new PerSecurityWS_Service().getPerSecurityWSPort();

            // Send the request
            GetCorrectionsRequest getCorrectionsReq = new GetCorrectionsRequest();
            GetCorrectionsResponse getCorrectionsResp = ps.getCorrections(getCorrectionsReq);

            // Display response
            if (getCorrectionsResp.getStatusCode().getCode() == PerSecurity.SUCCESS) {
                System.out.println("getcorrections request successful.");
                for (CorrectionRecord correctionRecord : getCorrectionsResp.getCorrectionRecords()
                        .getCorrectionRecord()) {
                    String yellowKey = "";
                    if (correctionRecord.getInstrument().getYellowkey() != null) {
                        yellowKey = " "
                                + correctionRecord.getInstrument().getYellowkey().toString();
                    }

                    System.out.println("Corrections for "
                            + correctionRecord.getInstrument().getId() + yellowKey + ":"
                            + "\n  Field: " + correctionRecord.getField() + "\n  Old Value: "
                            + correctionRecord.getOldValue() + "\n  Old Date: "
                            + correctionRecord.getOldDateEntered() + "\n  New Value: "
                            + correctionRecord.getNewValue() + "\n  New Date: "
                            + correctionRecord.getNewDateEntered());
                }
            } else if (getCorrectionsResp.getStatusCode().getCode() == PerSecurity.DATA_NOT_AVAILABLE) {
                System.out.println("No corrections found");
            } else {
                System.out.println("Error in the submitted request");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}