define(['ojs/ojcore', 'knockout', 'ebs/constants', 'ebs/popup/popupHelper', 'ojs/ojpopup'],
        function (oj, ko, constants, popupHelper)
        {
            function confirmationMessagePopupModuleViewModel()
            {
                self.startAnimationListener = function (event, ui)
                {
                    popupHelper.startAnimationListener(constants.divTags.confirmationMessagePopupModuleTag, event, ui);
                };

                self.confirmationPopupCloseHandler = function (data, event) {
                    popupHelper.confmPopuCloseHandler(constants.divTags.confirmationMessagePopupModuleTag, data, event);
                };

            }
            return confirmationMessagePopupModuleViewModel;
        });