define(['ojs/ojcore', 'knockout', 'ebs/actions/actionsHelper', 'ebs/popup/popupHelper', 'ebs/constants', 
    'ojs/ojvalidator-regexp', 'ojs/ojarraydataprovider', 'ojs/ojasyncvalidator-numberrange', 'ebs/utils/compartmentsLov', 
    'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojbutton', 'ojs/ojradioset'],
        function (oj, ko, actionsHelper, popupHelper, constants, RegExpValidator, ArrayDataProvider, AsyncNumberRangeValidator) {
            function createPolicyScheduleViewModel() {
                var self = this;
                console.log('Loading Create Schedule Popup View Model');
                var rootViewModel = ko.dataFor(document.getElementById(constants.divTags.rootViewModelDivTag));
                self.createScheduleTitle = ko.observable('');
                self.selectedPeriod = ko.observable('EVERY_DAY');
                self.isEditMode = ko.observable(false);
                self.basePageScheduleId = ko.observable(-1);
                self.displayErrorMessage = ko.observable(false);
                self.policyIdentifier = ko.observable('');
                self.exisitingSchedules = ko.observableArray();
                self.dayOfMonthValidationMsg = ko.observable();

                self.periodOptions = [
                    {id: 'Daily', value: 'EVERY_DAY', label: 'Daily'},
                    {id: 'Weekly', value: 'EVERY_WEEK', label: 'Weekly'},
                    {id: 'Monthly', value: 'EVERY_MONTH', label: 'Monthly'},
                    {id: 'Yearly', value: 'EVERY_YEAR', label: 'Yearly'},
                ];

                self.hourOfDayOptions = ko.observableArray([
                    {value: 0, label: '00:00'},
                    {value: 1, label: '01:00'},
                    {value: 2, label: '02:00'},
                    {value: 3, label: '03:00'},
                    {value: 4, label: '04:00'},
                    {value: 5, label: '05:00'},
                    {value: 6, label: '06:00'},
                    {value: 7, label: '07:00'},
                    {value: 8, label: '08:00'},
                    {value: 9, label: '09:00'},
                    {value: 10, label: '10:00'},
                    {value: 11, label: '11:00'},
                    {value: 12, label: '12:00'},
                    {value: 13, label: '13:00'},
                    {value: 14, label: '14:00'},
                    {value: 15, label: '15:00'},
                    {value: 16, label: '16:00'},
                    {value: 17, label: '17:00'},
                    {value: 18, label: '18:00'},
                    {value: 19, label: '19:00'},
                    {value: 20, label: '20:00'},
                    {value: 21, label: '21:00'},
                    {value: 22, label: '22:00'},
                    {value: 23, label: '23:00'}
                ]);
                self.PeriodDaily_hourOfDay_Selected = ko.observable(0);
                self.PeriodWeekly_hourOfDay_Selected = ko.observable(0);
                self.PeriodMonthly_hourOfDay_Selected = ko.observable(0);
                self.PeriodYearly_hourOfDay_Selected = ko.observable(0);

                self.dayOfWeekOptions = ko.observableArray([
                    {value: 2, label: 'Monday'},
                    {value: 3, label: 'Tuesday'},
                    {value: 4, label: 'Wednesday'},
                    {value: 5, label: 'Thursday'},
                    {value: 6, label: 'Friday'},
                    {value: 7, label: 'Saturday'},
                    {value: 1, label: 'Sunday'}]);
                self.PeriodWeekly_dayOfWeek_Selected = ko.observable(2);


                self.PeriodMonthly_dayOfMonth_Selected = ko.observable(1);
                self.PeriodYearly_dayOfMonth_Selected = ko.observable(1);

                self.monthOfYearOptions = ko.observableArray([
                    {value: 1, label: 'January'},
                    {value: 2, label: 'February'},
                    {value: 3, label: 'March'},
                    {value: 4, label: 'April'},
                    {value: 5, label: 'May'},
                    {value: 6, label: 'June'},
                    {value: 7, label: 'July'},
                    {value: 8, label: 'August'},
                    {value: 9, label: 'September'},
                    {value: 10, label: 'October'},
                    {value: 11, label: 'November'},
                    {value: 12, label: 'December'}]);
                self.PeriodYearly_monthOfYear_Selected = ko.observable(1);



                self.openPopup = function (createMode, policyIdentifier, scheduleId, periodValue, hourOfDay, dayOfWeek, dayOfMonth, month) {
                    self.policyIdentifier(policyIdentifier);
                    if (createMode) {
                        self.createScheduleTitle('Create Schedule');
                        self.isEditMode(false);
                    } else {
                        self.isEditMode(true);
                        self.basePageScheduleId(scheduleId);
                        self.selectedPeriod(periodValue);
                        if (periodValue === 'EVERY_DAY') {
                            self.PeriodDaily_hourOfDay_Selected(hourOfDay);
                        } else if (periodValue === 'EVERY_WEEK') {
                            self.PeriodWeekly_hourOfDay_Selected(hourOfDay);
                            self.PeriodWeekly_dayOfWeek_Selected(parseInt(dayOfWeek));
                        } else if (periodValue === 'EVERY_MONTH') {
                            self.PeriodMonthly_dayOfMonth_Selected(parseInt(dayOfMonth));
                            self.PeriodMonthly_hourOfDay_Selected(hourOfDay);
                        } else if (periodValue === 'EVERY_YEAR') {
                            self.PeriodYearly_monthOfYear_Selected(parseInt(month));
                            self.PeriodYearly_dayOfMonth_Selected(parseInt(dayOfMonth));
                            self.PeriodYearly_hourOfDay_Selected(hourOfDay);
                        }
                        self.createScheduleTitle('Edit Schedule');
                    }
                    var popup = document.querySelector(constants.divTags.createSchedulePopupTag);
                    popup.open(event.target);
                };
                
                self.isSameDay = function(){
                      var baseScheduleTable = document.getElementById('scheduleTable');
                    var scheduleList = ko.dataFor(baseScheduleTable).schedules();
                    if (scheduleList === null || scheduleList.length < 1) {
                        return false;
                    } else {
                        var filteredScedulesByPeriod = self.filterSchedulesByPeriod(scheduleList, self.selectedPeriod());
                        if (filteredScedulesByPeriod === null || filteredScedulesByPeriod.length < 1) {
                            return false;
                        } else {
                            if (self.selectedPeriod() === 'EVERY_DAY') {
                                if(filteredScedulesByPeriod.length >= 1){
                                    return true;
                                }
                                else{
                                    return false;
                                }
                            } else if (self.selectedPeriod() === 'EVERY_WEEK') {
                                var everyWeekPeriod_selectedDayOfWeek = self.PeriodWeekly_dayOfWeek_Selected();
                               for (var i = 0; i < filteredScedulesByPeriod.length; i++) {
                                    var filteredSchedule = filteredScedulesByPeriod[i];
                                    var dayOfWeek = parseInt(filteredSchedule.dayOfWeek());
                                    if (dayOfWeek === everyWeekPeriod_selectedDayOfWeek) {
                                        return true;
                                    }
                                }
                                return false;
                            } else if (self.selectedPeriod() === 'EVERY_MONTH') {
                                var everyMonthPeriod_selectedDayOfMonth = self.PeriodMonthly_dayOfMonth_Selected();
                                 for (var i = 0; i < filteredScedulesByPeriod.length; i++) {
                                    var filteredSchedule = filteredScedulesByPeriod[i];
                                    var dayOfMonth = parseInt(filteredSchedule.dayOfMonth());
                                    if (dayOfMonth === everyMonthPeriod_selectedDayOfMonth) {
                                        return true;
                                    }
                                }
                                return false;
                            } else if (self.selectedPeriod() === 'EVERY_YEAR') {
                                var everyYearPeriod_selectedDayOfMonth = self.PeriodYearly_dayOfMonth_Selected();
                                var everyYearPeriod_selectedMonth = self.PeriodYearly_monthOfYear_Selected();
                                for (var i = 0; i < filteredScedulesByPeriod.length; i++) {
                                    var filteredSchedule = filteredScedulesByPeriod[i];
                                    var dayOfMonth = parseInt(filteredSchedule.dayOfMonth());
                                    var month = parseInt(filteredSchedule.month());
                                    if (dayOfMonth === everyYearPeriod_selectedDayOfMonth && everyYearPeriod_selectedMonth === month) {
                                        return true;
                                    }
                                }
                                return false;
                            }
                        }
                    }
                };

                self.isFormValid = function () {
                    var isFormValid = true;
                    var monthOfDayValidationForYearPeriod = self.validateDayOfMonth(null);
                    if (!monthOfDayValidationForYearPeriod) {
                        isFormValid = false;
                    }
                    
                    // To check if error, should not allow to move forward
                    // This condition will only be executed if monthly schedule and invalid day of the month is selected
                    var periodMonthlyDayOfMonth = document.getElementById("PeriodMonthly_dayOfMonth");
                    if (null !== periodMonthlyDayOfMonth && periodMonthlyDayOfMonth.valid !== 'valid') {
                        isFormValid = false;
                    }
                    
                    // To check if error, should not allow to move forward
                    // This condition will only be executed if yearly schedule and invalid day of the month is selected
                    var periodYearlyDayOfMonth = document.getElementById("PeriodYearly_dayOfMonth");
                    if (null !== periodYearlyDayOfMonth && periodYearlyDayOfMonth.valid !== 'valid') {
                        isFormValid = false;
                    }
                                
                    var isSameDay = self.isSameDay();
                    if(isSameDay){
                        self.displayErrorMessage(true);
                        isFormValid = false;
                    }
                    else{
                        self.displayErrorMessage(false);
                    }
                   
                    return isFormValid;
                };

                self.filterSchedulesByPeriod = function (schedulesList, period) {
                    var filteredSchedules = new Array();
                    for (var i = 0; i < schedulesList.length; i++) {
                        var schedule = schedulesList[i];
                        var periodOfSchedule = schedule.type_value();
                        var scheduleId = schedule.id;
                        if (period === periodOfSchedule) {
                            if (self.isEditMode() && scheduleId === self.basePageScheduleId()) {
                                continue; // In edit mode, dont compare with the current row element.
                            }
                            filteredSchedules.push(schedule);
                        }
                    }
                    return filteredSchedules;
                };

                self.isDuplicateSchedule = function () {
                    var baseScheduleTable = document.getElementById('scheduleTable');
                    var scheduleList = ko.dataFor(baseScheduleTable).schedules();
                    if (scheduleList === null || scheduleList.length < 1) {
                        return false;
                    } else {
                        var filteredScedulesByPeriod = self.filterSchedulesByPeriod(scheduleList, self.selectedPeriod());
                        if (filteredScedulesByPeriod === null || filteredScedulesByPeriod.length < 1) {
                            return false;
                        } else {
                            if (self.selectedPeriod() === 'EVERY_DAY') {
                                var everyDayPeriod_selectedHrOfDay = self.PeriodDaily_hourOfDay_Selected();
                                for (var i = 0; i < filteredScedulesByPeriod.length; i++) {
                                    var filteredSchedule = filteredScedulesByPeriod[i];
                                    var hrOfDay = filteredSchedule.hourOfDay();
                                    if (hrOfDay === everyDayPeriod_selectedHrOfDay) {
                                        return true;
                                    }
                                }
                                return false;
                            } else if (self.selectedPeriod() === 'EVERY_WEEK') {
                                var everyWeekPeriod_selectedDayOfWeek = self.PeriodWeekly_dayOfWeek_Selected();
                                var everyWeekPeriod_selectedHrOfDay = self.PeriodWeekly_hourOfDay_Selected();
                                for (var i = 0; i < filteredScedulesByPeriod.length; i++) {
                                    var filteredSchedule = filteredScedulesByPeriod[i];
                                    var hrOfDay = filteredSchedule.hourOfDay();
                                    var dayOfWeek = parseInt(filteredSchedule.dayOfWeek());
                                    if (hrOfDay === everyWeekPeriod_selectedHrOfDay && dayOfWeek === everyWeekPeriod_selectedDayOfWeek) {
                                        return true;
                                    }
                                }
                                return false;
                            } else if (self.selectedPeriod() === 'EVERY_MONTH') {
                                var everyMonthPeriod_selectedDayOfMonth = self.PeriodMonthly_dayOfMonth_Selected();
                                var everyMonthPeriod_selectedHrOfDay = self.PeriodMonthly_hourOfDay_Selected();
                                for (var i = 0; i < filteredScedulesByPeriod.length; i++) {
                                    var filteredSchedule = filteredScedulesByPeriod[i];
                                    var hrOfDay = filteredSchedule.hourOfDay();
                                    var dayOfMonth = parseInt(filteredSchedule.dayOfMonth());
                                    if (hrOfDay === everyMonthPeriod_selectedHrOfDay && dayOfMonth === everyMonthPeriod_selectedDayOfMonth) {
                                        return true;
                                    }
                                }
                                return false;
                            } else if (self.selectedPeriod() === 'EVERY_YEAR') {
                                var everyYearPeriod_selectedDayOfMonth = self.PeriodYearly_dayOfMonth_Selected();
                                var everyYearPeriod_selectedHrOfDay = self.PeriodYearly_hourOfDay_Selected();
                                var everyYearPeriod_selectedMonth = self.PeriodYearly_monthOfYear_Selected();
                                for (var i = 0; i < filteredScedulesByPeriod.length; i++) {
                                    var filteredSchedule = filteredScedulesByPeriod[i];
                                    var hrOfDay = filteredSchedule.hourOfDay();
                                    var dayOfMonth = parseInt(filteredSchedule.dayOfMonth());
                                    var month = parseInt(filteredSchedule.month());
                                    if (hrOfDay === everyYearPeriod_selectedHrOfDay && dayOfMonth === everyYearPeriod_selectedDayOfMonth && everyYearPeriod_selectedMonth === month) {
                                        return true;
                                    }
                                }
                                return false;
                            }
                        }
                    }

                };

                self.clearErrorMsg = function () {
                    self.displayErrorMessage(false);
                };

                // Holds max of days based on the month
                // Default initialized to 31
                self.maxNoOfDays = ko.observable(31);
                
                /*
                 * Setting max no of days in the month
                 */
                self.maxDaysInMonth = function (month) {
                    switch (month) {
                        case 2:
                            self.maxNoOfDays(28);
                            break;
                        case 1:
                        case 3:
                        case 5:
                        case 7:
                        case 8:
                        case 10:
                        case 12:
                            self.maxNoOfDays(31);
                            break;
                        case 4:
                        case 6:
                        case 9:
                        case 11:
                            self.maxNoOfDays(30);
                            break;
                    }
                };
                
                /*
                 * This is called on change of month or days
                 * This will compare the number of days in the selected month and the day selected
                 * Based on which it will throw error
                 */
                self.validateDayOfMonth = function (event) {
                    self.displayErrorMessage(false);
                    var messageContent = oj.Translations.getTranslatedString("validationMsgs.invalidDayOfMonth", {max: self.maxNoOfDays()});
                    var validationCustomMsg = {summary: messageContent, detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                    if (event === null) {
                        var periodSelected = self.selectedPeriod();
                        if (periodSelected === 'EVERY_YEAR') {
                            var monthOfYear = self.PeriodYearly_monthOfYear_Selected();
                            var dayOfMonth = self.PeriodYearly_dayOfMonth_Selected();
                            self.maxDaysInMonth(monthOfYear, dayOfMonth);
                            if (dayOfMonth > self.maxNoOfDays()) {
                                messageContent = oj.Translations.getTranslatedString("validationMsgs.invalidDayOfMonth", {max: self.maxNoOfDays()});
                                validationCustomMsg = {summary: messageContent, detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                self.dayOfMonthValidationMsg([validationCustomMsg]);
                                return false;
                            } else {
                                self.dayOfMonthValidationMsg([]);
                                return true;
                            }
                        } else {
                            self.dayOfMonthValidationMsg([]);
                            return true;
                        }
                    } else {
                        self.displayErrorMessage(false);
                        var newValue = event['detail'].value;
                        var targetElement = event.target || event.srcElement;
                        var targetElementId = targetElement.id;
                        // If the event was triggered from month, then validate the day of the month.
                        if (targetElementId === 'PeriodYearly_monthOfYear') {
                            var dayOfMonth = self.PeriodYearly_dayOfMonth_Selected();
                            self.maxDaysInMonth(newValue, dayOfMonth);
                            if (dayOfMonth > self.maxNoOfDays()) {
                                messageContent = oj.Translations.getTranslatedString("validationMsgs.invalidDayOfMonth", {max: self.maxNoOfDays()});
                                validationCustomMsg = {summary: messageContent, detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                self.dayOfMonthValidationMsg([validationCustomMsg]);
                                return false;
                            } else {
                                self.dayOfMonthValidationMsg([]);
                                return true;
                            }
                        } else if (targetElementId === 'PeriodYearly_dayOfMonth') {
                            var monthOfYear = self.PeriodYearly_monthOfYear_Selected();
                            self.maxDaysInMonth(monthOfYear, parseInt(newValue));
                            if (dayOfMonth > self.maxNoOfDays()) {
                                messageContent = oj.Translations.getTranslatedString("validationMsgs.invalidDayOfMonth", {max: self.maxNoOfDays()});
                                validationCustomMsg = {summary: messageContent, detail: messageContent, severity: oj.Message.SEVERITY_TYPE.ERROR};
                                self.dayOfMonthValidationMsg([validationCustomMsg]);
                                return false;
                            } else {
                                self.dayOfMonthValidationMsg([]);
                                return true;
                            }
                        }
                    }
                };

                self.createSchedulePopupCloseCleanUpHandler = function () {
                    self.resetPopupContents();
                };

                self.closeSchedulePopup = function () {
                    self.resetPopupContents();
                    var popup = document.querySelector(constants.divTags.createSchedulePopupTag);
                    popup.close();
                };

                self.resetPopupContents = function () {
                    self.selectedPeriod('EVERY_DAY');
                    self.PeriodDaily_hourOfDay_Selected(0);
                    self.PeriodWeekly_hourOfDay_Selected(0);
                    self.PeriodMonthly_hourOfDay_Selected(0);
                    self.PeriodYearly_hourOfDay_Selected(0);
                    self.PeriodWeekly_dayOfWeek_Selected(2);
                    self.PeriodMonthly_dayOfMonth_Selected(1);
                    self.PeriodYearly_dayOfMonth_Selected(1);
                    self.PeriodYearly_monthOfYear_Selected(1);
                    self.displayErrorMessage(false);
                };

                self.createSchedule = function () {
                    var isFormValid = self.isFormValid();
                    if (!isFormValid) {

                    } else {
                        var viewModelOfBasePageTable = ko.dataFor(document.getElementById("scheduleTable"));
                        if (!self.isEditMode()) {
                            if (self.selectedPeriod() === 'EVERY_DAY') {
                                viewModelOfBasePageTable.addSchedule(self.selectedPeriod(), self.PeriodDaily_hourOfDay_Selected(), null, null, null);
                            } else if (self.selectedPeriod() === 'EVERY_WEEK') {
                                viewModelOfBasePageTable.addSchedule(self.selectedPeriod(), self.PeriodWeekly_hourOfDay_Selected(), self.PeriodWeekly_dayOfWeek_Selected(), null, null);
                            } else if (self.selectedPeriod() === 'EVERY_MONTH') {
                                viewModelOfBasePageTable.addSchedule(self.selectedPeriod(), self.PeriodMonthly_hourOfDay_Selected(), null, self.PeriodMonthly_dayOfMonth_Selected(), null);
                            } else if (self.selectedPeriod() === 'EVERY_YEAR') {
                                viewModelOfBasePageTable.addSchedule(self.selectedPeriod(), self.PeriodYearly_hourOfDay_Selected(), null, self.PeriodYearly_dayOfMonth_Selected(), self.PeriodYearly_monthOfYear_Selected());
                            }
                        }
                        self.closeSchedulePopup();
                    }
                };

                self.editSchedule = function () {
                    var isFormValid = self.isFormValid();
                    if (!isFormValid) {

                    } else {
                        var viewModelOfBasePageTable = ko.dataFor(document.getElementById("scheduleTable"));
                        if (self.isEditMode()) {
                            if (self.selectedPeriod() === 'EVERY_DAY') {
                                viewModelOfBasePageTable.editSchedule(self.basePageScheduleId(), self.selectedPeriod(), self.PeriodDaily_hourOfDay_Selected(), null, null, null);
                            } else if (self.selectedPeriod() === 'EVERY_WEEK') {
                                viewModelOfBasePageTable.editSchedule(self.basePageScheduleId(), self.selectedPeriod(), self.PeriodWeekly_hourOfDay_Selected(), self.PeriodWeekly_dayOfWeek_Selected(), null, null);
                            } else if (self.selectedPeriod() === 'EVERY_MONTH') {
                                viewModelOfBasePageTable.editSchedule(self.basePageScheduleId(), self.selectedPeriod(), self.PeriodMonthly_hourOfDay_Selected(), null, self.PeriodMonthly_dayOfMonth_Selected(), null);
                            } else if (self.selectedPeriod() === 'EVERY_YEAR') {
                                viewModelOfBasePageTable.editSchedule(self.basePageScheduleId(), self.selectedPeriod(), self.PeriodYearly_hourOfDay_Selected(), null, self.PeriodYearly_dayOfMonth_Selected(), self.PeriodYearly_monthOfYear_Selected());
                            }
                        }
                        self.closeSchedulePopup();
                    }
                };

            }

            return createPolicyScheduleViewModel;
        });
